namespace java com.weixiaobao.wpush.client.thrift

service  PushService {
  void pushNotification(1:AppPayload appPayload)
}

enum APNSMode{
	All = 0,
	Signined = 1
}

enum OfflineMode{
	Ignore = 0,
	APNS = 1,
	SendAfterOnline = 2
}

const i32 APP_REQUEST_TYPE_PAYLOAD = 0x1;
const i32 APP_REQUEST_TYPE_NEW_TOPIC = 0x2;
const i32 APP_REQUEST_TYPE_NEW_TOPIC_CLIENT = 0x3;
const i32 APP_REQUEST_TYPE_REM_TOPIC = 0x4;
const i32 APP_REQUEST_TYPE_REM_TOPIC_CLIENT = 0x5;

struct AppPayload{
1: string appkey;
2: i32 typeId;
3: string title;
4: i32 badge;
5: string sound;
6: list<string> clients;
7: map<string,string> ext;
8: i32 topicObjectId;
9: bool broadcast;
10: i32 offlineMode = OfflineMode.Ignore;
11: i32 toMode = 0;
12: i32 apnsMode = APNSMode.All;
13: bool vibrate;
}


