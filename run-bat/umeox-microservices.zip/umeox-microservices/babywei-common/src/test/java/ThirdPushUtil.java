import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.plugin.PushClient;
import com.umeox.babywei.util.HuaWeiUtil;
import com.umeox.babywei.util.XiaoMiUtil;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

/**
 * 第三方推送：激光、小米、华为
 */
public class ThirdPushUtil {

    private static final Logger log = LoggerFactory.getLogger(ThirdPushUtil.class);

    public static final String default_title = "温馨提示";
    public static final String default_description = " ";

    /**
     *
     * @param member
     * @param device
     * @param title
     * @param msgContent
     * @param description
     * @param extra
     */
    public static void pushToApp(Member member, Device device, String title, String msgContent, String description, Map<String, String> extra) {

        log.info("推送日志# loginInfo:{},mobile:{},deviceType:{},saleChannel:{},title:{},msgContent:{},description:{}"
        ,member.getLoginInfo(),member.getMobile(),device.getDeviceType(),device.getSaleChannel(),title,msgContent,description);
        log.info("推送日志* extra:{}",extra);
        if (ApplicationSupport.isChinaEnv()){
            title = StringUtils.isEmpty(title)?default_title:title;
            description = StringUtils.isEmpty(description)?default_description:description;
        }

        if (StringUtils.isEmpty(member.getLoginInfo())){
            PushClient.sendTitlePushMessage(title,member.getMobile(), msgContent, extra, device.getDeviceType(),device.getSaleChannel());
        }else {
            String loginInfo = member.getLoginInfo();
            String[] infos = loginInfo.split(":");
            if (infos.length==3){
                XiaoMiUtil.sendMsg(infos[1],new ArrayList<String>(Arrays.asList(infos[2])),title,msgContent,msgContent,extra,XiaoMiUtil.Notification_Type);
            }else if(loginInfo.contains("huawei:")){
                if (infos.length==3)
                    HuaWeiUtil.notification_send(infos[1],infos[2],title,msgContent,extra);
            }
        }
    }

    public static void main(String[] args) {
        String md5Alias = DigestUtils.md5Hex("e14b10bbfecb33f5").toLowerCase().substring(8, 24);
        System.out.println("md5Alias = " + md5Alias);
    }
}
