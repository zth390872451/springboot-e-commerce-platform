package com.umeox.babywei.domain;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import com.umeox.babywei.domain.enums.ContentType;



/**
 * @author xmc
 *
 * @date 2015年6月24日 下午4:54:01
 */
@Entity
@Table(name = "ux_content")
public class Content extends BaseEntity{

	private static final long serialVersionUID = 1480089752232949948L;
	
	/**
	 * 父节点
	 */
	private Content parent;
	
	/**
	 * 类型
	 */
	private ContentType type;
	/**
	 * 标题
	 */
	private String title;
	
	/**
	 * 作者
	 */
	private String author;
	
	/**
	 * 图像
	 */
	private String img;
	
	/**
	 * 缩略图
	 */
	private String thumbnail;

	/**
	 * 摘要
	 */
	private String descriptions;
	
	/**
	 * 是否引用第三方内容
	 */
	private boolean isThirdContent;
	
	/**
	 * 内容
	 */
	private String content;
	
	/**
	 * 发布时间
	 */
	private Date publishDate;
	
	/**
	 * 是否有效
	 */
	private boolean enabled;
	
	/**
	 * 关联渠道
	 */
	private ChannelCustomer channelCustomer;
	
	/**
	 * 创建人
	 */
	private String createdUser;
	/**
	 * 阅读数
	 */
	private Long viewCnt;
	/**
	 * 排序
	 */
	private int seq;
	
	

	private List<Content> children = new ArrayList<Content>();
	
	@ManyToOne(fetch = FetchType.LAZY)
	public Content getParent() {
		return parent;
	}

	public void setParent(Content parent) {
		this.parent = parent;
	}

	@Column(nullable = false,length = 2)
	@Enumerated
	public ContentType getType() {
		return type;
	}

	public void setType(ContentType type) {
		this.type = type;
	}

	@Column(nullable = false)
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}
	
	public boolean getIsThirdContent() {
		return isThirdContent;
	}

	public void setIsThirdContent(boolean isThirdContent) {
		this.isThirdContent = isThirdContent;
	}

	@Type(type = "text")
	@Column(nullable = false)
	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	
	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	@Column(nullable = false,columnDefinition = "bit default 1")
	public boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "channel_id")
	public ChannelCustomer getChannelCustomer() {
		return channelCustomer;
	}

	public void setChannelCustomer(ChannelCustomer channelCustomer) {
		this.channelCustomer = channelCustomer;
	}

	
	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public Long getViewCnt() {
		return viewCnt;
	}

	public void setViewCnt(Long viewCnt) {
		this.viewCnt = viewCnt;
	}
	
	public int getSeq() {
		return seq;
	}
	
	public String getThumbnail() {
		return thumbnail;
	}

	public void setThumbnail(String thumbnail) {
		this.thumbnail = thumbnail;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	@OneToMany(mappedBy = "parent", fetch = FetchType.LAZY,cascade = CascadeType.REMOVE)
	@Where(clause = "enabled = 1 and publish_date <= now()")
	@OrderBy("seq desc")
	public List<Content> getChildren() {
		return children;
	}

	public void setChildren(List<Content> children) {
		this.children = children;
	}

	

}
