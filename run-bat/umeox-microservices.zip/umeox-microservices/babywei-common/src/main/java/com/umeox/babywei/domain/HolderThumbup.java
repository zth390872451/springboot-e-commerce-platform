package com.umeox.babywei.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @Desc 点赞(累计当天点赞数)
 * @author umeox
 * @version II
 */
@Entity
@Table(name = "ux_holder_thumbup")
public class HolderThumbup extends BaseEntity{

	private static final long serialVersionUID = 7996913445866737761L;
	
	private Holder holder;
	
	/**
	 * 点赞-当天累计值
	 */
	private Integer thumbupValue;
	
	/**
	 * 点赞-日期（yyyy-MM-dd）
	 */
	private Date thumbupDate;

	@ManyToOne
	@JoinColumn(name = "holder_id",nullable = false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public Integer getThumbupValue() {
		return thumbupValue;
	}

	public void setThumbupValue(Integer thumbupValue) {
		this.thumbupValue = thumbupValue;
	}

	@Temporal(TemporalType.DATE)
	public Date getThumbupDate() {
		return thumbupDate;
	}

	public void setThumbupDate(Date thumbupDate) {
		this.thumbupDate = thumbupDate;
	}
}
