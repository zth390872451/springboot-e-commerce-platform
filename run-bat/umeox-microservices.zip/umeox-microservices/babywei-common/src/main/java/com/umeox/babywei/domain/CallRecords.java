package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 通话记录
 */
@Entity
@Table(name = "ux_call_records")
public class CallRecords extends BaseEntity{
	
	private static final long serialVersionUID = 3164013695590533683L;
	
	public static final int CALL_TYPE_OUT = 1;
	public static final int CALL_TYPE_IN = 2; 
	
	public static final int NORMAL_TYPE  = 1;
	public static final int VIDEO_TYPE = 2;
	public static final int VOICE_TYPE = 3;
	
	private Long holderId;
	private FamilyNumber familyNumber;
	
	/**
	 * 通话开始时间
	 */
	private Long startTime;
	
	private Long endTime;
	
	/**
	 * 通话时长
	 */
	private Long callTime;
	
	/**
	 * 通话方式（1：手表打出；2：手表接进）
	 */
	private Integer callType;
	
	/**
	 * 通话类型[1：普通电话(SIM卡)；2：视频电话(数据流量)；3:语音电话(数据流量)]
	 */
	private Integer type;

	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="family_number_id")
	public FamilyNumber getFamilyNumber() {
		return familyNumber;
	}

	public void setFamilyNumber(FamilyNumber familyNumber) {
		this.familyNumber = familyNumber;
	}

	public Long getStartTime() {
		return startTime;
	}

	public void setStartTime(Long startTime) {
		this.startTime = startTime;
	}

	public Long getCallTime() {
		return callTime;
	}

	public void setCallTime(Long callTime) {
		this.callTime = callTime;
	}

	public Integer getCallType() {
		return callType;
	}

	public void setCallType(Integer callType) {
		this.callType = callType;
	}

	public Long getEndTime() {
		return endTime;
	}

	public void setEndTime(Long endTime) {
		this.endTime = endTime;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	
	
}
