package com.umeox.babywei.conf;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration("ruleConfiguration")
@ConfigurationProperties(prefix = "rule")
public class RuleConfiguration {

	private Map<String, String> mccLang = new HashMap<String, String>();

	private Map<String, String> channelTels = new HashMap<String, String>();

	public Map<String, String> getMccLang() {
		return mccLang;
	}
	
	public Map<String, String> getChannelTels() {
		return channelTels;
	}

}
