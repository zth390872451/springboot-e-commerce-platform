package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 * 亲情号码
 * @author ginger
 *
 */
@SuppressWarnings("serial")
@Entity
@Table(name = "ux_family_number")
public class FamilyNumber extends BaseEntity{
	
	public final static Integer TYPE_ALL = 0;

	public final static Integer ORIGIN_TYPE_CONTACTS = 0;
	public final static Integer ORIGIN_TYPE_ADMIN = 1;
	public final static Integer ORIGIN_TYPE_FOLLOWER = 2;
	public final static Integer ORIGIN_TYPE_DEVICE_FRIEND = 3;
	
	private Integer sort;//亲情号码1,2 sort= { 20:亲情号码1 ; 10:亲情号码2 ; 其他：白名单}
	private String name;
	private String mobile; 
	private String email;
	private Integer origin;//0:自己新增 (联系人号码)1：自己的号码(管理员号码) 2：关注者的号码3：好友设备的号码
	private String relation;//0 爸爸-1妈妈-2爷爷-3奶奶-4其他
	
	/**
	 * 所属胶囊
	 */
	private Holder holder;
	/**
	 * 头像标记
	 */
	private String photoFlag = "0";//deviceType = 4
	
	/**
	 * 权限类型(0：定位位置+语聊+打电话 关注者或者管理员；1：打电话 联系人)
	 */
	private Integer type;
	
	/**
	 * 头像(K3联系人有头像)
	 */
	private String avatar;
	
	/**
	 * 好友的imei号 （origin=3时才有值）
	 */
	private String friendImei;
	
	
	
	
	
	public String getFriendImei() {
		return friendImei;
	}
	public void setFriendImei(String friendImei) {
		this.friendImei = friendImei;
	}
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id")
	public Holder getHolder() {
		return holder;
	}
	
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public void setHolder(Holder holder) {
		this.holder = holder;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getOrigin() {
		return origin;
	}
	public void setOrigin(Integer origin) {
		this.origin = origin;
	}
	
	public String getPhotoFlag() {
		return photoFlag;
	}
	public void setPhotoFlag(String photoFlag) {
		this.photoFlag = photoFlag;
	}
	
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	@PrePersist
	  public void prePersist()
	  {
		if(this.getOrigin()==null)
	    this.setOrigin(0);
		if(this.getSort()==null)
		    this.setSort(0);
		if(this.getRelation()==null)
			this.setRelation("4");
		if (this.getType() == null) {
			this.setType(1);
		}
	  }
}
