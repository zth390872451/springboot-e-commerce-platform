package com.umeox.babywei.conf;

public final class Constants {
    
    //系统环境
    public static final String SPRING_PROFILE_DEVELOPMENT_CHINA = "dev-china";//国内开发环境
    public static final String SPRING_PROFILE_TEST_CHINA = "test-china";  //国内测试环境
    public static final String SPRING_PROFILE_PRODUCTION_CHINA = "prod-china";  //国内生产环境
    public static final String SPRING_PROFILE_DEVELOPMENT_AMAZON = "dev-amazon";//国外开发环境
    public static final String SPRING_PROFILE_TEST_AMAZON = "test-amazon";//国外开发环境
    public static final String SPRING_PROFILE_PRODUCTION_AMAZON = "prod-amazon";//国外生产环境
    public static final String SPRING_PROFILE_PRODUCTION_AMAZON_DOLLYPHIN = "prod-amazon-dollyphin";//传音生产环境
    public static final String SPRING_PROFILE_PRODUCTION_CHINA_LONLIV = "prod-china-lonliv";//lonliv生产环境
    public static final String SPRING_PROFILE_PRODUCTION_AMAZON_OAXIS = "prod-amazon-oaxis";//oaxis生产环境
   // public static final String SPRING_PROFILE_TEST_DIBAI = "test-dibai";
   // public static final String SPRING_PROFILE_PRODUCTION_DIBAI = "prod-dibai";
   // public static final String SPRING_PROFILE_PRODUCTION_LONLIV = "prod-lonliv";
    //public static final String SPRING_PROFILE_FAST = "fast";
    //public static final String SPRING_PROFILE_CLOUD = "cloud";
    // public static final String SYSTEM_ACCOUNT = "system";
}
