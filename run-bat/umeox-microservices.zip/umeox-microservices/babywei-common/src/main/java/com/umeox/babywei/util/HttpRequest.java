package com.umeox.babywei.util;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author umeox
 *
 */
public class HttpRequest {
	private final Logger log = LoggerFactory.getLogger(this.getClass());
	private HttpClient httpClient = new HttpClient();
	private List<NameValuePair> valuePairs = new ArrayList<NameValuePair>();
	private List<Header> headers = new ArrayList<Header>();

	public HttpRequest() {
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
		httpClient.getHttpConnectionManager().getParams().setSoTimeout(30000);
	}

	public HttpRequest addParam(String name, String value) {
		this.valuePairs.add(new NameValuePair(name, value));
		return this;
	}

	public HttpRequest addParam(String queryString) {
		if (ParamUtils.notEmpty(queryString)) {
			Map<String, String> queryMap = ParamUtils.queryToMap(queryString);
			Set<Entry<String, String>> querySet = queryMap.entrySet();
			for (Entry<String, String> nameVal : querySet) {
				this.addParam(nameVal.getKey(), nameVal.getValue());
			}
		}
		return this;
	}

	public HttpRequest addHeader(String name, String value) {
		this.headers.add(new Header(name, value));
		return this;
	}

	public String post(String url) {
		httpClient.getParams().setContentCharset("UTF-8");
		PostMethod pm = new PostMethod(url);
		if (this.valuePairs.size() > 0) {
			pm.addParameters(this.valuePairs.toArray(new NameValuePair[this.valuePairs.size()]));
		}
		if (this.headers.size() > 0) {
			for (Header header : this.headers) {
				pm.addRequestHeader(header);
			}
		}
		try {
			httpClient.executeMethod(pm);
			return pm.getResponseBodyAsString();
		} catch (Exception e) {

		}
		return "";
	}

	public String get(String url) {
		GetMethod gm = new GetMethod(url);
		if (this.headers.size() > 0) {
			for (Header header : this.headers) {
				gm.addRequestHeader(header);
			}
		}
		gm.setQueryString(this.valuePairs.toArray(new NameValuePair[this.valuePairs.size()]));
		try {
			httpClient.executeMethod(gm);
			return gm.getResponseBodyAsString();
		} catch (Exception e) {

		}
		return "";
	}

	/*
	 * public static void main(String[] args) { String resultVal = new
	 * HttpRequest().addHeader("User-Agent", "Mozilla/5.0") .addParam("x",
	 * "1cc-1-2540-7caa-9c-2540-7c3d-92-2540-7c48-81-2540-79b9-7e-2540-7c47-7d-2540-7bec-76-")
	 * .addParam("ta", "1") .addParam("p", "1") .addParam("needaddress","0")
	 *//**
		 * 我们这边的接口提供3种坐标： 1. 标准的gps 2. baidu地图的 3. google地图的 mt=0 1 2
		 *//*
		 * .addParam("mt","0") .get("http://minigps.net/as"); }
		 */
}
