package com.umeox.babywei.conf;

public class RedisKey {
	
	public final static String QUE_API2_SOCKET_IM = "que:api2socket:im"; //实时下发给设备，例手动定位、语聊、绑定等
	
	public final static String QUE_API2_SOCKET_DATA = "que:api2socket:data"; //可以延迟同步数据，例设备相关的设置等
	public final static String SYNC_DATA_FLAG_KEY = "syncDataFlag";
	public final static String LOCATION_DATA_KEY = "locationData";
	
	
	//-----------------------微话饼
	public final static String QUE_WETALK_SOCKET_IM = "que:wetalksocket:im";
	public final static String QUE_WETALK_SOCKET_DATA = "que:wetalksocket:data";
	public final static String WETALK_SYNC_DATA_FLAG = "syncFlag";
}
