package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 * 小米和华为的sdk 推送的维护信息
 */
@Entity
@Table(name = "push_app_info")
public class PushAppInfo {

    private Long id;
    //
    private String appId;
    //app的包名
    private String packageName;
    //app的key
    private String appKey;
    //秘钥
    private String appSecret;
    //摘要,简要描述
    private String description;
    // 0:小米 1：华为
    private Integer  appType;

    public static final Integer XIAOMI = 0;
    public static final Integer HUAWEI = 1;

    public Integer getAppType() {
        return appType;
    }

    public void setAppType(Integer appType) {
        this.appType = appType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    @Override
    public String toString() {
        return "PushAppInfo{" +
                "id=" + id +
                ", appId='" + appId + '\'' +
                ", packageName='" + packageName + '\'' +
                ", appKey='" + appKey + '\'' +
                ", appSecret='" + appSecret + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
