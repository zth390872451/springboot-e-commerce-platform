package com.umeox.babywei.constant;

/**
 * @creator ZTH
 * @modifier ZTH
 * @date 2017-07-27
 * 定义推送的相关默认值
 */
public class PushConstant {
	//fcm推送地址
	public static final String URL = "http://fcm.googleapis.com/fcm/send";
	//key=服务器的秘钥
	public static final String AUTHORIZATION_VALUE = "key=AAAAvLgchzY:APA91bGBnSke8JzRmWlcbYxNH9KKyx37LLVEKCRlCTINhPQ4FR0Rw3GiVf9hxiyKPP3flLi1VpKM0h9-zhLM08lY2hxjZr9ZhztdntNtqIo2y2MF-wnsP4QaNABDkS5pUga0QRQTvHpm";
	//主题前缀[官方要求必须]
	public static final String SUBJECT_PREFIX = "/topics/";
	//默认铃声
	public static String SOUND = "default";

	//通知提示：角标数字
	public static final int BADGE = 1;
	//离线消息保存时间：5天=5 * 86400L
	public static final Long DEFAULT_TIME_TO_LIVE = 5 * 86400L;

	//默认标题 国外
	public static final String DEFAULT_TITLE_EN = "Reminder";

}
