package com.umeox.babywei.util;

import java.util.Random;

//http://blog.csdn.net/springmvc_springdata/article/details/40340027
public class RandomUtils {
	
	public static final String ALLCHAR = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";  
    public static final String LETTERCHAR = "abcdefghijkllmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";  
    public static final String NUMBERCHAR = "0123456789";  
      
     /**  
     * 返回一个定长的随机字符串(只包含大小写字母、数字)  
     * @param length 随机字符串长度  
     * @author www.zuidaima.com 
     * @return 随机字符串  
     */   
    public static String generateString(int length){  
        StringBuffer sb = new StringBuffer();  
        Random random = new Random();  
        for (int i = 0; i < length; i++) {  
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));  
        }  
        return sb.toString();  
    }

}
