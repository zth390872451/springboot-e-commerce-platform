package com.umeox.babywei.util;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.domain.PushAppInfo;
import com.umeox.babywei.repository.PushAppInfoRepository;
import com.xiaomi.push.sdk.ErrorCode;
import com.xiaomi.xmpush.server.Constants;
import com.xiaomi.xmpush.server.Message;
import com.xiaomi.xmpush.server.Result;
import com.xiaomi.xmpush.server.Sender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/4/21.
 */
public class XiaoMiUtil {

    private static final Logger log = LoggerFactory.getLogger(XiaoMiUtil.class);

    public static final int maxRetryTimes = 3;

    // 测试
    public static final String MI_PACKAGE_NAME = "com.hemdenry.xiaomipush";
    public static final String MI_PACKAGE_ID = "2882303761517568634";
    public static final String APP_SECRET_KEY = "5711756859634";
    public static final String APP_SECRET = "mqw/TglF/B4v/QtlwNmWrg==";

   /* public static void main(String[] args) throws IOException, ParseException {
        String alias ="alias_zth";
        Sender sender = new Sender(APP_SECRET);
        Map<String,String> extras = new HashMap<>();
        extras.put("test","extra");
        Message message = HuaWeiUtil.androidMsg("descrip","title", "payload", null, extras);
        System.out.println("message = " + message);
        boolean flag = HuaWeiUtil.sendAndroidAll(MI_PACKAGE_NAME,new ArrayList<String>(Arrays.asList(alias)),"title","description","payload", extras);
        System.out.println("flag = " + flag);
    }*/

    private static PushAppInfoRepository pushAppInfoRepository;
    private static Map<String,Sender> instanceMap = new HashMap<String,Sender>();
    private static Long lastCreateInstanceTime= 0l;

    public static final int Notification_Type = 0;//通知栏消息(通知类型)
    public static final int Message_Type = 1;//透传消息(透传消息类型)

    static{
        pushAppInfoRepository = (PushAppInfoRepository) ApplicationSupport.getBean("pushAppInfoRepository");
        createInstanceMap();
    }

    //从数据库获取信息创建实例
    private static void  createInstanceMap(){
        synchronized (lastCreateInstanceTime){
            lastCreateInstanceTime = System.currentTimeMillis();
            List<PushAppInfo> pushAppInfos = pushAppInfoRepository.findAll();
            if (pushAppInfos != null && !pushAppInfos.isEmpty()){
                for(PushAppInfo pushAppInfo:pushAppInfos){
                    if (PushAppInfo.XIAOMI.equals(pushAppInfo.getAppType())){
                        String packageName = pushAppInfo.getPackageName();
                        instanceMap.put(packageName, new Sender(pushAppInfo.getAppSecret()));
                    }
                }
            }
            log.info("从数据库获取信息创建实例 instanceMap,instanceMap.size={}",lastCreateInstanceTime,instanceMap.size());
        }
    }


    /**
     * 根据包名获取(创建) Sender
     * @param packageName
     * @return
     */
    private static Sender getSender(String packageName){
        if (StringUtils.isEmpty(packageName)){
            log.error("packageName must not null");
            return null;
        }
        //更新instance策略，每间隔一个小时更新一次
        if(System.currentTimeMillis() > (lastCreateInstanceTime + 3600*1000)){
            createInstanceMap();
        }
        Sender sender = instanceMap.get(packageName);
        return sender;
    }

    /**
     * 构造安卓推送的Message
     * @param title
     * @param payload
     * @param extras
     * @return
     */
    private static Message androidMsg(String packageName, String title, String description, String payload, Map<String, String> extras, int msgType){
        Message.Builder builder = new Message.Builder()
                .payload(payload).title(title).description(description)
                .restrictedPackageName(packageName)
                .passThrough(msgType)  // 0：表示通知栏消息(默认是通知栏消息) 1：消息使用透传方式
                .notifyType(1);// 使用默认提示音提示
        if (extras != null && !extras.isEmpty()) {
            for (Map.Entry<String, String> entry : extras.entrySet()) {
                builder.extra(entry.getKey(), entry.getValue());
            }
        }
        builder.extra(Constants.EXTRA_PARAM_NOTIFY_FOREGROUND, "1");//0:关闭app在前台时的通知弹出 1:打开
        return builder.build();
    }

    /**
     * 推送安卓消息/通知 单个或者多个
     * @return
     */
    public static boolean sendMsg(String packageName,List<String> aliasList,String title,String description, String payload,Map<String, String> extras,int msgType) {
        log.info("push info packageName:{},token:{},title:{},content:{},extra:{}",packageName,aliasList,title,description,payload,extras);
        Sender sender = getSender(packageName);
        if (StringUtils.isEmpty(sender)){
            log.error("packageName={}需要对应的APP信息维护到数据库中或者已创建但尚未同步到内存中需等待,无法创建Sender",packageName);
            return false;
        }
        Result result = null;
        if(!StringUtils.isEmpty(aliasList)){//推送
            try {
//                extras.put("callback","url");//发送推送后，小米回调通知接口
                result = sender.sendToAlias(androidMsg(packageName,title,description,payload,extras,msgType), aliasList, maxRetryTimes);
                log.info("小米推送结果 send http, result  = {}",result);
            } catch (Exception e) {
                log.error("result ={},** e={}",result,e);
            }
         }
        return resultHandle(result);
    }

    private static boolean resultHandle(Result result) {
        return ErrorCode.Success.equals(result.getErrorCode());
    }


}
