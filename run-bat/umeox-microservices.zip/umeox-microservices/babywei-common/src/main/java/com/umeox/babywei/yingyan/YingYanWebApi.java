package com.umeox.babywei.yingyan;

/**
 * @author JT
 */

import com.umeox.babywei.util.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class YingYanWebApi {

    private static final Logger logger = LoggerFactory.getLogger(YingYanWebApi.class);

    //用户的ak，授权使用
    private static final String ak = "iM9npGKUwkgwI7wA8kO7kL1j";
    //service唯一标识
    private static final String service_id = "109434";


    private static final String API_GET_HISTORY = "http://api.map.baidu.com/trace/v2/track/gethistory";

    private static final String API_ADD_POINTS = "http://api.map.baidu.com/trace/v2/track/addpoints";

    /**
     * @param entity_name     entity唯一标识
     * @param start_time      起始时间
     * @param end_time        结束时间
     * @param sort_type       返回结果的排序规则
     * @param simple_return   返回精简的结果
     * @param is_processed    是否返回纠偏后轨迹
     * @param process_option  纠偏选项
     * @param supplement_mode 里程补偿方式
     * @param page_index      分页索引
     * @param page_size       分页大小
     * @return
     */
    public static YingYanHistoryResponse getHistory(String entity_name, long start_time, long end_time, int sort_type, int simple_return, int is_processed, String process_option, String supplement_mode, int page_index, int page_size) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("ak", ak);
        params.put("service_id", service_id);
        params.put("entity_name", entity_name);
        params.put("start_time", start_time + "");
        params.put("end_time", end_time + "");
        params.put("sort_type", sort_type + "");
        params.put("simple_return", simple_return + "");
        params.put("is_processed", is_processed + "");
        params.put("process_option", process_option);
        params.put("supplement_mode", supplement_mode);
        params.put("page_index", page_index + "");
        params.put("page_size", page_size + "");
        String resultStr = HttpUtil.httpGet(params, API_GET_HISTORY);
        YingYanHistoryResponse response = JsonUtils.toObject(resultStr, YingYanHistoryResponse.class);
        return response;
    }

    ;

    /**
     * 通过service _id和entity_name查找本entity历史轨迹点的具体信息
     * <p/>
     * 此方法设定默认值：返回结果loc_time从小到大排序,返回完整结果,返回纠偏轨迹(绑路),返回所有点
     *
     * @param entity_name
     * @param start_time
     * @param end_time
     * @return
     */
    public static YingYanHistoryResponse getHistory(String entity_name, long start_time, long end_time, int pageIndex, int pageSize, int is_processed) {
        return getHistory(entity_name, start_time, end_time, 1, 0, is_processed, "need_denoise=1,need_vacuate=1,need_mapmatch=1", "no_supplement", pageIndex, pageSize);
    }

    /**
     * *
     *
     * @param entity_name
     * @param points
     * @param pathName    临时文件目录存放目录
     * @return
     */
    public static YingYangAddPointsResponse addPoints(String entity_name, List<YingYanPointBean> points, String pathName) {
        //检查文件目录
        File f = new File(pathName);
        if (!f.exists()) {
            f.mkdirs();
        }
        String fileName = entity_name + "_" + System.currentTimeMillis() + ".csv";
        File file = PointsCsvFileBuilder.write(points, f.getAbsolutePath() + File.separator + fileName);
        logger.info("开始批量轨迹点上传,entity_name:{},loc_time_from:{},loc_time_to:{}", entity_name, points.get(0).getLoc_time(), points.get(points.size() - 1).getLoc_time());
        return addPoints(entity_name, file, points.size());
    }

    /**
     * *
     *
     * @param entity_name
     * @param file        csv轨迹点文件
     * @param total       文件轨迹点个数
     * @return
     */
    public static YingYangAddPointsResponse addPoints(String entity_name, File file, int total) {
        Map<String, Object> params = new HashMap<String, Object>();
        params.put("ak", ak);
        params.put("service_id", service_id);
        params.put("entity_name", entity_name);

        String resultStr = null;
        if (file.exists()) {
            Map<String, Object> binaryBodyMap = new HashMap<String, Object>();
            binaryBodyMap.put("name", "point_list");
            binaryBodyMap.put("fileName", file.getName());
            binaryBodyMap.put("file", file);
            resultStr = HttpUtil.httpPost(params, binaryBodyMap, API_ADD_POINTS);
        }

        if (resultStr != null) {
            YingYangAddPointsResponse response = JsonUtils.toObject(resultStr, YingYangAddPointsResponse.class);
            logger.info("结束批量轨迹点上传,entity_name:{},cost time:{}(s),response:{}", entity_name, response.getTime(), resultStr);
            if (response.getStatus() != 0) {
                logger.error("批量轨迹点上传失败,entity_name:{},message:{}", entity_name, response.getMessage());
            } else if (response.getTotal() != total) {
                logger.error("批量轨迹点上传部分失败，entity_name:{},total:{},message:{}", entity_name, response.getTotal(), response.getMessage());
            } else {
                //上传成功，删除此文件
                if(!logger.isInfoEnabled()){
                    file.delete();
                }
               
            }
            return response;
        }
        return null;
    }


  // public static void main(String[] args) {
        //测试获取历史轨迹点
       /* YingYanHistoryResponse response1 =  YingYanWebApi.getHistory("860705030000288", 1471517443l,1471521322l,1,5000,1);

        System.out.println(response1.getStatus());
        System.out.println(response1.getTotal());
        System.out.println(response1.getMessage());*/

        //批量添加轨迹点
     /*   List<YingYanPointBean> points = new ArrayList<YingYanPointBean>();
        points.add(new YingYanPointBean(113.947433333333, 22.5436616666667, 1, 1471517443l));
        points.add(new YingYanPointBean(113.947426666667, 22.5435766666667, 1, 1471517453l));
        points.add(new YingYanPointBean(113.947566666667, 22.5436866666667, 1, 1471517474l));

        YingYangAddPointsResponse response2 = YingYanWebApi.addPoints("860705030000288", points, "D:\\test1\\");*/

  
        //批量添加轨迹点

      /*  File file = new File("D:\\test1\\860705030000288_20160819_15.csv");
        YingYanWebApi.addPoints("860705030000288",file,190);*/



  // }

}
