package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * 天气预报历史记录
 *
 * @author JT
 */
@Entity
@Table(name = "ux_weather_his")
public class WeatherHis extends BaseEntity {
    
    public static final int REFRESH_FLAG_DAY = 0;
    public static final int REFRESH_FLAG_HOUR = 1;
    public static final int REFRESH_FLAG_MINUTE = 2;

    public static final int WEATHER_TYPE_LIVE = 0;
    public static final int WEATHER_TYPE_FORECAST = 1;
    

    //省
    private String province;

    //城市
    private String city;

    //区域编码
   // private String adcode;

    //时间刷新标记
    //0:按天，1：按每小时，2：按分钟
    private int refreshFlag;

    //天气预报内容，JSON字符串格式
    private String content;
    
    //气象类型 0:内容为实况天气  1：内容为预报天气
    private Integer weatherType;

    //天气预报调用时间
    private String strDate;

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getRefreshFlag() {
        return refreshFlag;
    }

    public void setRefreshFlag(int refreshFlag) {
        this.refreshFlag = refreshFlag;
    }

    @Column(length=1024)
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getWeatherType() {
        return weatherType;
    }

    public void setWeatherType(Integer weatherType) {
        this.weatherType = weatherType;
    }

    public String getStrDate() {
        return strDate;
    }

    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }

}
