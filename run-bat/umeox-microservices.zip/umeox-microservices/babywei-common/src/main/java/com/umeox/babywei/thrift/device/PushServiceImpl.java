package com.umeox.babywei.thrift.device;

import org.apache.thrift.TException;

public class PushServiceImpl implements PushService.Iface{

	@Override
	public void pushNotification(AppPayload appPayload) throws TException {
		System.out.println(appPayload.getClients().get(0)+":"+appPayload.getBadge());
	}

}
