package com.umeox.babywei.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

public class StringDeflatUtil {

	private int a[];
	private int b[];
	private boolean isDeflat;
	private static final char mychart[] = { '0', '1', '2', '3', '4', '5', '6',
			'7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
			'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w',
			'x', 'y', 'z' };

	public StringDeflatUtil() {
		this(false);
	}

	public StringDeflatUtil(boolean isNeedDeflat) {
		// isDeflat = true;
		isDeflat = isNeedDeflat;
	}

	public boolean initCode(String code) {
		if (code == null || code.length() > 256)
			return false;
		byte abyte0[];
		try {
			abyte0 = code.getBytes("UTF8");
		} catch (UnsupportedEncodingException unsupportedencodingexception) {
			return false;
		}
		a = new int[256];
		b = new int[256];
		for (int i = 0; i < 256; i++)
			a[i] = i;

		int j1 = abyte0.length;
		int i1;
		int l = i1 = 0;
		for (int j = 0; j < 256; j++) {
			i1 = (abyte0[l] & 0xff) + a[j] + i1 & 0xff;
			int k1 = a[j];
			a[j] = a[i1];
			a[i1] = k1;
			l = (l + 1) % j1;
		}

		for (int k = 0; k < 256; k++)
			b[k] = a[k];

		return true;
	}

	public String getEncryptStr(String s) {
		if (s == null || a == null)
			return null;
		byte abyte0[];
		if (isDeflat)
			abyte0 = getDeflaterByte(s);
		else
			try {
				abyte0 = s.getBytes("UTF8");
			} catch (UnsupportedEncodingException unsupportedencodingexception) {
				return null;
			}
		return a(abyte0, true);
	}

	public String getDecryptStr(String s) {
		byte abyte0[] = (byte[]) null;
		if (s == null || a == null) {
			return null;
		} else {
			byte abyte1[] = d(s);
			return a(abyte1, false);
		}
	}

	public String a(byte abyte0[]) {
		StringBuffer stringbuffer = new StringBuffer(abyte0.length * 2);
		for (int i = 0; i < abyte0.length; i++) {
			byte byte0 = abyte0[i];
			stringbuffer.append(mychart[(byte0 & 0xf0) >> 4]);
			stringbuffer.append(mychart[byte0 & 0xf]);
		}

		return stringbuffer.toString();
	}

	public byte[] d(String s) {
		if (s == null)
			return null;
		int k = s.length();
		byte abyte0[] = new byte[k / 2];
		for (int l = 0; l < abyte0.length; l++) {
			int i = s.charAt(l * 2);
			int j = s.charAt(l * 2 + 1);
			if (i >= 48 && i <= 57)
				i -= 48;
			else if (i >= 97 && i <= 102)
				i -= 87;
			else
				return null;
			if (j >= 48 && j <= 57)
				j -= 48;
			else if (j >= 97 && j <= 102)
				j -= 87;
			else
				return null;
			abyte0[l] = (byte) ((i << 4) + j);
		}

		return abyte0;
	}

	private String a(byte abyte0[], boolean flag) {
		String s = null;
		if (abyte0 == null)
			return s;
		for (int i = 0; i < 256; i++)
			a[i] = b[i];

		int k1 = abyte0.length;
		byte abyte1[] = new byte[k1];
		int l;
		int k = l = 0;
		for (int j = 0; j < k1; j++) {
			k = k + 1 & 0xff;
			l = a[k] + l & 0xff;
			int i1 = a[k];
			a[k] = a[l];
			a[l] = i1;
			int j1 = a[k] + a[l] & 0xff;
			abyte1[j] = (byte) (abyte0[j] ^ a[j1]);
		}

		if (flag)
			s = a(abyte1);
		else if (isDeflat)
			s = getInflaterFromByte(abyte1);
		else
			try {
				s = new String(abyte1, "UTF8");
			} catch (UnsupportedEncodingException unsupportedencodingexception) {
			}
		return s;
	}

	public static byte[] getDeflaterByte(String s) {
		Deflater deflater = new Deflater(9);
		try {
			deflater.setInput(s.getBytes("UTF8"));
		} catch (UnsupportedEncodingException unsupportedencodingexception) {
		}
		deflater.finish();
		boolean flag = false;
		ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
		while (!flag) {
			byte abyte0[] = new byte[256];
			int i = deflater.deflate(abyte0);
			bytearrayoutputstream.write(abyte0, 0, i);
			if (i < abyte0.length)
				flag = true;
		}
		try {
			bytearrayoutputstream.flush();
			bytearrayoutputstream.close();
		} catch (IOException ioexception) {
		}
		return bytearrayoutputstream.toByteArray();
	}

	public static String getInflaterFromByte(byte abyte0[]) {
		Inflater inflater = new Inflater();
		inflater.setInput(abyte0);
		String s = null;
		boolean flag = false;
		ByteArrayOutputStream bytearrayoutputstream = new ByteArrayOutputStream();
		while (!flag) {
			byte abyte1[] = new byte[256];
			try {
				int i = inflater.inflate(abyte1);
				bytearrayoutputstream.write(abyte1, 0, i);
				if (i < abyte1.length)
					flag = true;
			} catch (DataFormatException dataformatexception) {
				flag = true;
			}
		}
		try {
			s = new String(bytearrayoutputstream.toByteArray(), "UTF8");
		} catch (UnsupportedEncodingException unsupportedencodingexception) {
		}
		bytearrayoutputstream = null;
		return s;
	}

}