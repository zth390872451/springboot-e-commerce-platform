package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 邮箱服务器信息
 */
@Entity
@Table(name = "sys_mail")
public class MailServer extends BaseEntity{

	private static final long serialVersionUID = -5832079785508677581L;
	
	/**
	 * clientId(根据id查找，如果没找到就使用默认账号发送)
	 * 该字段为多个client_id的集合，用逗号分隔开
	 */
	private String clientId;
	/**
	 * 服务器地址
	 */
	private String host;
	/**
	 * 端口
	 */
    private Integer port;
    /**
     * 账号
     */
    private String username;
    /**
     * 密码
     */
    private String password;
    /**
     * 地址 from是关键字 不能作为 列名
     */
    private String fromWhere;
    /**
     * 是否认证
     */
    private boolean auth;
    /**
     * 这个字段对于邮件发送无用
     */
    private String personal;
    
    
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public String getFromWhere() {
		return fromWhere;
	}

	public void setFromWhere(String fromWhere) {
		this.fromWhere = fromWhere;
	}

	public boolean isAuth() {
		return auth;
	}
	public void setAuth(boolean auth) {
		this.auth = auth;
	}
	public String getPersonal() {
		return personal;
	}
	public void setPersonal(String personal) {
		this.personal = personal;
	}
	
    
}
