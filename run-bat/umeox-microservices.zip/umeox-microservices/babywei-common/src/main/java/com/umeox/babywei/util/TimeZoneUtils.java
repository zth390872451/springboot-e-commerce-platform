package com.umeox.babywei.util;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

public class TimeZoneUtils {

    public static String displayTimeZone(String timeZodeId) {
        TimeZone timeZone = TimeZone.getTimeZone(timeZodeId);
        Calendar calendar = Calendar.getInstance(timeZone);
        int timeLong = timeZone.getOffset(calendar.getTimeInMillis());
        long hours = TimeUnit.MILLISECONDS.toHours(timeLong);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeLong) - TimeUnit.HOURS.toMinutes(hours);
        // avoid -4:-30 issue
        minutes = Math.abs(minutes);

        String result = "";
        if (hours > 0) {
            //result = String.format("(GMT+%d:%02d) %s", hours, minutes, timeZone.getID());
            result = String.format("GMT+%02d:%02d", hours, minutes);
        } else {
            //result = String.format("(GMT%d:%02d) %s", hours, minutes, timeZone.getID());
            result = String.format("GMT-%02d:%02d", -hours, minutes);
        }
        return result;
    }
    
    public static Map<String,Object> displayTimeZoneMap(String timeZodeId) {
        TimeZone timeZone = TimeZone.getTimeZone(timeZodeId);
        Calendar calendar = Calendar.getInstance(timeZone);
        int timeLong = timeZone.getOffset(calendar.getTimeInMillis());
        long hours = TimeUnit.MILLISECONDS.toHours(timeLong);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(timeLong) - TimeUnit.HOURS.toMinutes(hours);
        // avoid -4:-30 issue
        minutes = Math.abs(minutes);

        String result = "";
        if (hours > 0) {
            //result = String.format("(GMT+%d:%02d) %s", hours, minutes, timeZone.getID());
            result = String.format("GMT+%02d:%02d", hours, minutes);
        } else {
            //result = String.format("(GMT%d:%02d) %s", hours, minutes, timeZone.getID());
            result = String.format("GMT-%02d:%02d", -hours, minutes);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("result", result);
        map.put("time", timeLong);
        
        return map;
    }
}
