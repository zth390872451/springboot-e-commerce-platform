package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 * 拍拍秀空间表
 */
@Entity
@Table(name = "ux_paipai_space")
public class HolderPaipaiSpace extends BaseEntity{
    
    private static final long serialVersionUID = 7830173452947051696L;

    //持有者
    private Holder holder;
    
    //最后分享时间
    private Long lastShareTime;

    //最后分享文件
    private HolderAlbumsFile lastShareFile;
    
    private Integer zanNum;
    
    //最多点赞文件
    private HolderAlbumsFile mostZanFile;

    private Integer viewNum;
    
    //最多查看文件
    private HolderAlbumsFile mostViewFile;

    @OneToOne
    @JoinColumn(name = "holder_id",nullable = false)
    public Holder getHolder() {
        return holder;
    }

    public void setHolder(Holder holder) {
        this.holder = holder;
    }

    @Column(nullable = false)
    public Long getLastShareTime() {
        return lastShareTime;
    }
    
    public void setLastShareTime(Long lastShareTime) {
        this.lastShareTime = lastShareTime;
    }

    @OneToOne
    @JoinColumn(name = "last_share_file_id",nullable = true)
    public HolderAlbumsFile getLastShareFile() {
        return lastShareFile;
    }

    public void setLastShareFile(HolderAlbumsFile lastShareFile) {
        this.lastShareFile = lastShareFile;
    }

    @OneToOne
    @JoinColumn(name = "most_zan_file_id",nullable = true)
    public HolderAlbumsFile getMostZanFile() {
        return mostZanFile;
    }

    public void setMostZanFile(HolderAlbumsFile mostZanFile) {
        this.mostZanFile = mostZanFile;
    }

    @OneToOne
    @JoinColumn(name = "most_view_file_id",nullable = true)
    public HolderAlbumsFile getMostViewFile() {
        return mostViewFile;
    }

    public void setMostViewFile(HolderAlbumsFile mostViewFile) {
        this.mostViewFile = mostViewFile;
    }
    
    @Column(name = "zan_num")
    public Integer getZanNum() {
        return zanNum==null?0:zanNum;
    }

    public void setZanNum(Integer zanNum) {
        this.zanNum = zanNum;
    }
    
    @Column(name = "view_num")
    public Integer getViewNum() {
        return viewNum==null?0:viewNum;
    }

    public void setViewNum(Integer viewNum) {
        this.viewNum = viewNum;
    }

    @PrePersist
    public void prePersist(){
        if(this.getViewNum()==null)
            this.setViewNum(0);
        if(this.getZanNum()==null)
            this.setViewNum(0);
    }
}
