package com.umeox.babywei.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Desc 时区参数
 * @author umoex
 * @version II
 */
@Entity
@Table(name = "ux_time_zone")
public class TimeZone implements Serializable{

	private static final long serialVersionUID = 1922620543229289558L;
	
	private Long id;
	
	/**
	 * 时区ID
	 */
	private String timeZoneId;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(nullable = true)
	public String getTimeZoneId() {
		return timeZoneId;
	}

	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}
	
	
}
