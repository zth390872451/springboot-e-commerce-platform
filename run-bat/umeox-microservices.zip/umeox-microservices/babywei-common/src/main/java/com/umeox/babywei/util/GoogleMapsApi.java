package com.umeox.babywei.util;

import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.GeolocationApi;
import com.google.maps.model.*;
import com.umeox.babywei.bean.Position;
import com.umeox.babywei.constant.PositioningMode;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 谷哥地图API调用
 */
public class GoogleMapsApi {

    private static final Logger LOGGER = LoggerFactory.getLogger(GoogleMapsApi.class);

    private static GeoApiContext[] context = new GeoApiContext[2];

    private static AtomicInteger apiUsedTimes = new AtomicInteger(0);

    static {
        context[0] = new GeoApiContext()
                //.setEnterpriseCredentials("gme-elecahklimited", "urCHSb41-bUYrjqfU026NwV7UYI=")
                //.setConnectTimeout(5, TimeUnit.SECONDS).disableRetries()
                .setQueryRateLimit(50)
                .setConnectTimeout(15, TimeUnit.SECONDS)
                .setReadTimeout(15, TimeUnit.SECONDS)
                .setWriteTimeout(15, TimeUnit.SECONDS)
                .setApiKey("AIzaSyCnpFy0QttAqTu5v4QDjb_014XWf5edta0"); // first key
                //.setApiKey("AIzaSyBntp99E_2zVZWCxmiPZy3vdeZTJ-f5Ajc");//this is for old one

        context[1] = new GeoApiContext()
                //.setEnterpriseCredentials("gme-elecahklimited", "urCHSb41-bUYrjqfU026NwV7UYI=")
                //.setConnectTimeout(5, TimeUnit.SECONDS).disableRetries()
                .setQueryRateLimit(50)
                .setConnectTimeout(15, TimeUnit.SECONDS)
                .setReadTimeout(15, TimeUnit.SECONDS)
                .setWriteTimeout(15, TimeUnit.SECONDS)
                .setApiKey("AIzaSyCgCyAaCx-3XKOwwd4srsKn-p4nWPfaMzI"); //second key

    }

    /**
     * 根据WiFI和基站信息获取位置和精确半径
     * @param position
     */
    public static void geolocationByPosition(Position position) {
        String strStations = null, strMacs = null, strWifiSignals = null;
        if (PositioningMode.WIFI.value().equals(position.getLocationMode()) && !StringUtils.isEmpty(position.getWifiMac())) {
            strMacs = position.getWifiMac();
            strWifiSignals = position.getWifiSignal();
        }

        if (!StringUtils.isEmpty(position.getStationMsg())) {
            strStations = String.format("%s#%s#%s#%s#%s|", position.getMcc(), position.getMnc(), position.getCi(), position.getLac(), position.getSignalStrength()) + position.getStationMsg();
        }

        GeolocationResult result = geolocation(Integer.parseInt(position.getMcc(), 16), Integer.parseInt(position.getMnc(), 16), parseCellTowers(strStations), parseWifiAccessPoints(strMacs, strWifiSignals));

        if (result != null) {
            position.setLatitude(result.location.lat);
            position.setLongitude(result.location.lng);
            position.setRadius((int) result.accuracy);
        }
    }

    /**
     * 反向地理编码
     *
     * @param latLng
     * @param language
     * @return
     */
    public static String geocoding(final LatLng latLng, final String language) {
        String address = "";
        try {
            GeocodingResult[] results = GeocodingApi.newRequest(context[apiUsedTimes.getAndIncrement()%2])
                    .latlng(latLng).language(language).await();

            if (results != null && results.length > 0) {
                address = results[0].formattedAddress;
            }
        } catch (Exception ex) {
            LOGGER.error("Geocoding发生错误", ex);
        }
        return address;
    }

    /**
     * 根据WiFI和基站信息获取位置和精确半径
     *
     * @param mcc              所属国家代码
     * @param mnc              移动网号
     * @param cellTowers       基站信息  0#0#0#0#0|0#0#0#0#0|0#0#0#0#0 ??
     * @param wifiAccessPoints Wifi信息
     */
    private static GeolocationResult geolocation(int mcc, int mnc, CellTower[] cellTowers, WifiAccessPoint[] wifiAccessPoints) {
        LOGGER.info("mcc={},mnc={},cellTowers={},wifiAccessPoints={}", mcc, mnc, cellTowers, wifiAccessPoints);
        GeolocationResult result = null;
        try {
            result = GeolocationApi.newRequest(context[apiUsedTimes.getAndIncrement()%2])
                    .ConsiderIp(false)
                    .HomeMobileCountryCode(mcc)
                    .HomeMobileNetworkCode(mnc)
                    .RadioType("gsm")
                            //.Carrier("T-Mobile")
                    .CellTowers(cellTowers) //可以设为null
                    .WifiAccessPoints(wifiAccessPoints) //可以设为null
                    .CreatePayload()
                    .await();
        } catch (Exception ex) {
            LOGGER.error("geolocation发生错误", ex);
        }
        return result;
    }

    /**
     * 转换基站信息
     *
     * @param strStations 14e#3#4268#28e8#8a|14e#3#4268#28e9#89|14e#3#4268#2a46#7f|14e#3#4268#fca#7d
     * @return
     */
    private static CellTower[] parseCellTowers(String strStations) {
        if (StringUtils.isEmpty(strStations)) return null;
        CellTower[] cellTowers = null;
        if (!StringUtils.isEmpty(strStations)) {
            String array[] = strStations.split("\\|");
            cellTowers = new CellTower[array.length];
            for (int i = 0; i < array.length; i++) {
                String lbs[] = array[i].split("#");
                cellTowers[i] = new CellTower.CellTowerBuilder()
                        .MobileCountryCode(Integer.parseInt(lbs[0], 16)) //所属国家代码
                        .MobileNetworkCode(Integer.parseInt(lbs[1], 16)) //移动网号
                        .CellId(Integer.parseInt(lbs[2], 16))            //基站小区编号
                        .LocationAreaCode(Integer.parseInt(lbs[3], 16))  //位置区域码
                        .SignalStrength(convertSignalStrength(lbs[4]))   //信号强度
                        .Age(0)
                        .createCellTower();
            }
        }
        return cellTowers;
    }

    /**
     * 转换Wifi信息
     *
     * @param strMacs        ac:ec:80:d2:7d:b0#d4:5:98:74:db:10#e4:a8:b6:c0:73:8#bc:ca:b5:6e:ce:a0
     * @param strWifiSignals -40#-87#-86#-85
     * @return
     */
    private static WifiAccessPoint[] parseWifiAccessPoints(String strMacs, String strWifiSignals) {
        if (StringUtils.isEmpty(strMacs)) return null;
        String[] mac = strMacs.split("#");
        String[] signal = strWifiSignals.split("#");
        WifiAccessPoint[] wifiAccessPoints = new WifiAccessPoint[mac.length];
        for (int i = 0; i < mac.length; i++) {
            wifiAccessPoints[i] = new WifiAccessPoint.WifiAccessPointBuilder()
                    .MacAddress(checkMac(mac[i]))
                    .SignalStrength(Integer.parseInt(signal[i]))
                    .createWifiAccessPoint();
        }
        return wifiAccessPoints;
    }

    private static String checkMac(String mac) {
        if (mac.length() < 17) {
            String[] array = mac.split(":");
            String verify = "";
            for (String str : array) {
                if (str.length() < 2) {
                    verify += "0" + str + ":";
                } else {
                    verify += str + ":";
                }
            }
            mac = verify.substring(0, verify.length() - 1).toUpperCase();
        }
        return mac;
    }

    //转换设备上传的基站强度信号为有效范围：-107 =< dbm  < -77,因目前功能机设备基站强度是从设备里面读取对应的rxlev+110然后转换为16进制
    //转换方法： 去掉最高位后转换成10进制再减去110
    private static int convertSignalStrength(String hex) {
        return (Integer.valueOf(hex, 16) & 0x7f) - 110;
    }


    /*public static void main(String[] args) {

        for(int i =0 ;i <4;i++) {
            int mcc = Integer.parseInt("26d", 16);
            int mnc = Integer.parseInt("1e", 16);
            //需要连接基站数据连接附近基站数据
            String strStations = "26d#1e#d5e1#4b12#a0|26d#1e#4b12#11b3#8f|26d#1e#4b12#8305#8d|26d#1e#4b12#d5e0#8d";
            String strMacs = "8c:79:67:a6:81:57#80:e8:6f:98:23:c0#0:36:76:61:e6:95#b0:c0:90:2:b8:75#ec:b1:d7:cc:1f:2#80:e8:6f:48:7c:30";
            String strWifiSignals = "-54#-72#-62#-50#-84#-50";

            GeolocationResult result = geolocation(mcc, mnc, parseCellTowers(strStations), parseWifiAccessPoints(strMacs, strWifiSignals));
            if (result != null) {
                System.out.println(result.accuracy);
                System.out.println(result.location);
            }

           *//* Position p = new Position();
            p.setMcc("26d");
            p.setMnc("1e");
            p.setCi("d5e1");
            p.setLac("4b12");
            p.setSignalStrength("a0");
            p.setStationMsg(strStations);
            p.setLocationMode(PositioningMode.WIFI.value());
            p.setWifiMac(strMacs);
            p.setWifiSignal(strWifiSignals);
            geolocationByPosition(p);
            System.out.println(p.getRadius());
            System.out.println(p.getLatitude() + "," + p.getLongitude());*//*
        }
    }*/

}
