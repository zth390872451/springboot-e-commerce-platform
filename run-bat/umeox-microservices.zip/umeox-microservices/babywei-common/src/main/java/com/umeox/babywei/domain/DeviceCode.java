/**
 * 
 */
package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author xmc
 */
@Entity
@Table(name = "ux_device_code")
public class DeviceCode extends BaseEntity{
	
	private static final long serialVersionUID = 8107684849070849806L;

	/**
	 * IMEI号
	 */
	private String imei;
	
	/**
	 * 绑定号
	 */
	private String bindCode;
	
	/**
	 * 批号
	 */
	private String lot;
	
	/**
	 * 二维码
	 */
	private String qrcode;

	
	@Column(name = "imei", nullable = false, unique = true, updatable = false, length = 20)
	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	@Column(name = "bind_code", nullable = false, unique = true, updatable = false, length = 20)
	public String getBindCode() {
		return bindCode;
	}

	public void setBindCode(String bindCode) {
		this.bindCode = bindCode;
	}

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getQrcode() {
		return qrcode;
	}

	public void setQrcode(String qrcode) {
		this.qrcode = qrcode;
	}
}
