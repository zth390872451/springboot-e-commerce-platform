package com.umeox.babywei.domain;

import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name = "ux_log_message")
public class LogMessage extends BaseEntity {
	private static final long serialVersionUID = -5348717414253415771L;
	/**
	 * 关注者
	 */
	private String member;
	/**
	 * 主监护人
	 */
	private String admin;
	/**
	 * 设备持有人信息
	 */
	private Holder holder;
	
	/**
	 * 消息类型 
	 * 17：电量警告
	 * 15：超出围栏
	 * 12:定位消息
	 * 13：录音消息
	 * 18：追踪模式
	 */
	private int type;
	/**
	 * 消息说明
	 */
	private String msg;
	
	/**39.35487	维度：
	当时的GPS位置数据维度(当未开启GPS，此数据填0)
	无论当时是否开启GPS，每个位置上报都需要当前关联的基站信息
	 */
	private Double latitude;
	/**160.2357	经度：
	当时的GPS位置数据经度 (当未开启GPS，此数据填0)
	 */
	private Double longitude;
	
	private String address;
	/**
	 * 安全区域
	 */
	private Barrier barrier;
	
	private String recordpath;
	
	/**
	 * 手表时间
	 */
	private Date msgTime;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id")
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="barrier_id")
	public Barrier getBarrier() {
		return barrier;
	}


	public void setBarrier(Barrier barrier) {
		this.barrier = barrier;
	}

	public String getMember() {
		return member;
	}

	public void setMember(String member) {
		this.member = member;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getRecordpath() {
		return recordpath;
	}

	public void setRecordpath(String recordpath) {
		this.recordpath = recordpath;
	}

	@Column(name = "msg_time")
	public Date getMsgTime() {
		return msgTime;
	}

	public void setMsgTime(Date msgTime) {
		this.msgTime = msgTime;
	}
	@PrePersist
	  public void prePersist()
	  {
		if(this.getMsgTime()==null)
	    this.setMsgTime(new Date());
	  }
}
