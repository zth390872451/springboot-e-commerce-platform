package com.umeox.babywei.bean;

public class RedisCommand {
	
	public final static Integer CMD_POSITION = 0x01;          //请求定位
	public final static Integer CMD_CHAT = 0x02;              //语聊消息
	public final static Integer CMD_DEVICE_BIND_TWO = 0x04;   //设备绑定
	public final static Integer CMD_UNBOUND = 0x08;           //设备解绑
	public final static Integer CMD_STORY = 0x10; 				//故事消息
	
	
	
	public final static Integer CMD_DEVICE_PARAM = 0x100;     //设备参数修改
	public final static Integer CMD_FAMILY_NUMBER = 0x200;    //联系人 
	public final static Integer CMD_IM_RELATION = 0x400;      //同步好友
	public final static Integer CMD_CONCERN_TIME = 0x800;     //特殊关心时段
	public final static Integer CMD_CLASS_TIME = 0x1000;      //上课禁用时段
	public final static Integer CMD_ALARM = 0x2000;			  //闹钟设置
	public final static Integer CMD_TIMEZONE = 0x4000;		  //时区设置
	
	public final static Integer CMD_AUDIO_TYPE = 0x8000;      //情景模式 
	public final static Integer CMD_ANSWER_MODE = 0x10000;    //接听方式

	public final static Integer CMD_WIFI = 0x20000;    //同步WiFI配置
	public final static Integer CMD_CLASS_SCHEDULE = 0x40000;    //同步课程表设置
	public final static Integer CMD_TAKE_PHOTO = 0x80000;    //请求拍照
	public final static Integer CMD_ANSWER_PHONE = 0x100000;    //请求监听

	public final static Integer CMD_SEDENTARY_TIME = 0x200000;    //久座提醒设置
	public final static Integer CMD_DEVICE_WORK_MODEL = 0x400000;    //设备工作模式
	public final static Integer CMD_VOLUME_TIME = 0x800000;    //音量大小设置
}
