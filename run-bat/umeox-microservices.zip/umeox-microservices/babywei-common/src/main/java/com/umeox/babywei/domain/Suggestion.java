package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * 反馈意见
 */
@Entity
@Table(name = "ux_suggestion")
public class Suggestion extends BaseEntity {
	private static final long serialVersionUID = -9073242317066524089L;
	
	private String clientId;

	/**
	 * 会员账号
	 */
	private String mobile;

	private String imei;
	/**
	 * 1 绑定相关 2 定位相关 3消息相关 4其他 5手表相关 6客户端相关 7语聊相关
	 */
	private String suggestType;

	private String suggestContext;

	private String phoneSystem;
	
	private String systemVersion;
	
	private String phoneType;


	/**
	 * APP版本号
	 */
	private String appVersion;


	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	@Column(name = "mobile")
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	@Column(name = "imei")
	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}
	
	@Column(name = "suggest_type")
	public String getSuggestType() {
		return suggestType;
	}

	public void setSuggestType(String suggestType) {
		this.suggestType = suggestType;
	}

	@Column(name = "suggest_context")
	public String getSuggestContext() {
		return suggestContext;
	}

	public void setSuggestContext(String suggestContext) {
		this.suggestContext = suggestContext;
	}

	@Column(name = "phone_system")
	public String getPhoneSystem() {
		return phoneSystem;
	}

	public void setPhoneSystem(String phoneSystem) {
		this.phoneSystem = phoneSystem;
	}

	@Column(name = "system_version")
	public String getSystemVersion() {
		return systemVersion;
	}

	public void setSystemVersion(String systemVersion) {
		this.systemVersion = systemVersion;
	}

	@Column(name = "phone_type")
	public String getPhoneType() {
		return phoneType;
	}

	public void setPhoneType(String phoneType) {
		this.phoneType = phoneType;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	
	
}
