package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ux_tags")
public class Tags extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = 401704392288418427L;
	
	private String tagName;
	
	private String coverUrlSmall;
	
	private String coverUrlMiddle;
	
	private String coverUrlLarge;

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

	public String getCoverUrlSmall() {
		return coverUrlSmall;
	}

	public void setCoverUrlSmall(String coverUrlSmall) {
		this.coverUrlSmall = coverUrlSmall;
	}

	public String getCoverUrlMiddle() {
		return coverUrlMiddle;
	}

	public void setCoverUrlMiddle(String coverUrlMiddle) {
		this.coverUrlMiddle = coverUrlMiddle;
	}

	public String getCoverUrlLarge() {
		return coverUrlLarge;
	}

	public void setCoverUrlLarge(String coverUrlLarge) {
		this.coverUrlLarge = coverUrlLarge;
	}

}
