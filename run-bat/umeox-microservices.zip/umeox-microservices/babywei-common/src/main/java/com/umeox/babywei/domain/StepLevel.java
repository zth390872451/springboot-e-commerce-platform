package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 宠物等级
 */
@Entity
@Table(name = "ux_step_level")
public class StepLevel {
	private Long id;
	
	/**
	 * 等级（1,2,3......）
	 */
	private Integer level;
	
	/**
	 * 记步起始（大于或等于）
	 */
	private Long start;
	
	/**
	 * 记步结束（小于不包含等于）
	 */
	private Long end;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Long getStart() {
		return start;
	}

	public void setStart(Long start) {
		this.start = start;
	}

	public Long getEnd() {
		return end;
	}

	public void setEnd(Long end) {
		this.end = end;
	}

	
}
