package com.umeox.babywei.domain;

import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name="sys_role")
public class Role extends BaseEntity
{
  private static final long serialVersionUID = -6614052029623997372L;
  private String name;
  private Boolean isSystem;
  private String description;
  private List<String> authorities = new ArrayList<String>();
  private Set<Admin> admins = new HashSet<Admin>();

  @NotEmpty
  @Length(max=255)
  @Column(nullable=false)
  public String getName()
  {
    return this.name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  @Column(nullable=false, updatable=false)
  public Boolean getIsSystem()
  {
    return this.isSystem;
  }

  public void setIsSystem(Boolean isSystem)
  {
    this.isSystem = isSystem;
  }

  @Length(max=255)
  public String getDescription()
  {
    return this.description;
  }

  public void setDescription(String description)
  {
    this.description = description;
  }

  @ElementCollection
  @CollectionTable(name="sys_role_authority",joinColumns={@JoinColumn(name="role",referencedColumnName="id")})
  public List<String> getAuthorities()
  {
    return this.authorities;
  }

  public void setAuthorities(List<String> authorities)
  {
    this.authorities = authorities;
  }
  //映射关系由主表admin来维护
  @ManyToMany(mappedBy="roles", fetch=FetchType.LAZY)
  public Set<Admin> getAdmins()
  {
    return this.admins;
  }

  public void setAdmins(Set<Admin> admins)
  {
    this.admins = admins;
  }
}