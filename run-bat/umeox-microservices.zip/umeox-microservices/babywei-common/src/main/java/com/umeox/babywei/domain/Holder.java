package com.umeox.babywei.domain;


import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * 设备持有人信息
 * 
 * @author umeox
 * 
 */
@Entity
@Table(name = "ux_holder")
public class Holder extends BaseEntity {
	/*
	 * 开启跟踪功能状态
	 */
	public static final int OPEN_TRACKING_STATUS = 1;
	/*
	 * 关闭跟踪功能状态
	 */
	public static final int CLOSE_TRACKING_STATUS = -1;
	private static final long serialVersionUID = 1915720890420229147L;
	public Holder() {
		// TODO Auto-generated constructor stub
	}
	public Holder(Long id) {
		this.setId(id);
	}
	/**
	 * 持有设备
	 */
	private Device device;
	
	/**
	 * 设备IMEI冗余
	 */
	private String imei;

	/**
	 * 持有者名称
	 */
	private String name;
	
	/**
	 * 持有者姓
	 */
	private String familyName;

	/**
	 * 头像
	 */
	private String avatar;

	/**
	 * SIM卡号
	 */
	private String sim;

	/**
	 * 生日
	 */
	private Date birthday;

	/**
	 * 年级
	 */
	private String grade;
	
	/**
	 * 身高
	 */
	private String height;
	
	/**
	 * 体重
	 */
	private String weight;
	/**
	 * 性别 男male 女 woman
	 */
	private String gender;
	
	/**
	 * 定位频率
	 */
	private Frequency frequency;
	
	/**
	 * 运动提醒
	 * 是否接收运动静止状态改变的推送，叫做运动提醒；
	 * 如果APP打开了开关，服务器需要记录状态，以备推送状态信息判断
	 * 
	 * 海外：静(静止状态)转动(运动状态)就会推送提醒
	 * 国内：静止1小时 以上才会推送提醒
	 */
	private Boolean isMoveRemind;
	/**
	 * 静止提醒开关
	 * 在静止时间段手表一分钟未动，就处于静止状态，就会静止提醒；静止状态下手表上报位置频率为1小时
	 */
	private Boolean staticOpen;
	/**
	 * 静止提醒开始时间
	 */
	private String startHours;
	
	/**
	 * 静止提醒结束时间
	 */
	private String endHours;
	
	/**
	 * 情景模式
	 * 1：标准 （默认） 震动10秒再响铃(功能机),   震动并响铃（智能机）
	 * 2：震动
	 * 3：静音
	 */
	private String audioTypes;
	
	private String timeZone;
	
	private Integer trackingStatus;

	private Integer locationFlag;//【 0:关闭 ;1或者Null:开启 】 设备是否开启定位标记 默认为1(s600设备可发送请求，修改该标记)
	
	/**
	 * 接听方式
	 */
	private Integer answer;
	/**
	 * SOS设定
	 */
	private List<String> sos = new ArrayList<String>();
	@Column(name = "tracking_status")
	public Integer getTrackingStatus() {
		return trackingStatus;
	}
	public void setTrackingStatus(Integer trackingStatus) {
		this.trackingStatus = trackingStatus;
	}
	/**
	 * 0.省电 默认设置为 1小时一点
		1.普通 默认设置为15分钟一个点	修改成30分钟
		2.高 默认设置为 5分钟一个点	修改成10分钟
		3追踪模式 默认设置为 1分钟一个点
		4 手动模式 默认设置为 24小时一个点
	 *
	 */
	public enum Frequency{
		PD{
			public Integer label() {
				return 60;
			}
		},
		NM{
			public Integer label() {
				return 30;//15
			}
		},
		HI{
			public Integer label() {
				return 10;//5
			}
		},
		TK{
			public Integer label() {
				return 1;
			}
		},
		MANUAL {
			public Integer label() {
				return 60*24;
			}
		};
		public Integer label() {
			return this.label();
		}
	}

	public Integer getLocationFlag() {
		return locationFlag;
	}

	public void setLocationFlag(Integer locationFlag) {
		this.locationFlag = locationFlag;
	}

	@OneToOne(mappedBy = "holder")
	@JsonBackReference//Json转换时，防止循环转换
	public Device getDevice() {
		return device;
	}

	public void setDevice(Device device) {
		this.device = device;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFamilyName() {
		return familyName;
	}
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	
	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getSim() {
		return sim;
	}

	public void setSim(String sim) {
		this.sim = sim;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	@ElementCollection
	@CollectionTable(name = "ux_holder_sos",joinColumns = {@JoinColumn(name="holder",referencedColumnName="id")})
	public List<String> getSos() {
		return sos;
	}

	public void setSos(List<String> sos) {
		this.sos = sos;
	}

	@Enumerated
	public Frequency getFrequency() {
		return frequency;
	}

	public void setFrequency(Frequency frequency) {
		this.frequency = frequency;
	}

	@Column(name = "imei", nullable = true, unique = true, updatable = false)
	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}
	
	public Boolean getIsMoveRemind() {
		return isMoveRemind;
	}
	public void setIsMoveRemind(Boolean isMoveRemind) {
		this.isMoveRemind = isMoveRemind;
	}
	@PrePersist
	public void prePersist(){
		if(this.getFrequency()==null)
			this.setFrequency(Frequency.NM);//初始化为：普通模式 30分钟
		if(this.getIsMoveRemind()==null)
			this.setIsMoveRemind(false);//初始化为：运动提醒关闭
		if(this.getAudioTypes() == null)
			this.setAudioTypes("1");//初始化为：震动10秒再响铃
		if(this.getLocationFlag() == null)
			this.setLocationFlag(1);//默认设置为1 开启 NUll值也代表开启
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public Boolean getStaticOpen() {
		return staticOpen;
	}
	public void setStaticOpen(Boolean staticOpen) {
		this.staticOpen = staticOpen;
	}
	public String getStartHours() {
		return startHours;
	}
	public void setStartHours(String startHours) {
		this.startHours = startHours;
	}
	public String getEndHours() {
		return endHours;
	}
	public void setEndHours(String endHours) {
		this.endHours = endHours;
	}
	@Column(name = "audio_types")
	public String getAudioTypes() {
		return audioTypes;
	}
	public void setAudioTypes(String audioTypes) {
		this.audioTypes = audioTypes;
	}
	
	@Column(length = 255)
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public Integer getAnswer() {
		return answer;
	}
	public void setAnswer(Integer answer) {
		this.answer = answer;
	}
	
}
