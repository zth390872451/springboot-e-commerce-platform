package com.umeox.babywei.bean;

import java.io.Serializable;

public class Notice implements Serializable{
	
	private static final long serialVersionUID = 3443040429297150625L;
	
	private String avatar;
	private String noticeContent;
	private Long messageId;
	private Long noticeTime;
	
	
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getNoticeContent() {
		return noticeContent;
	}
	public void setNoticeContent(String noticeContent) {
		this.noticeContent = noticeContent;
	}
	public Long getMessageId() {
		return messageId;
	}
	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}
	public Long getNoticeTime() {
		return noticeTime;
	}
	public void setNoticeTime(Long noticeTime) {
		this.noticeTime = noticeTime;
	}
	
}
