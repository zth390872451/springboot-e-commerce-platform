package com.umeox.babywei.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * 相册文件表
 */
@Entity
@Table(name = "ux_holder_albums_file")
public class HolderAlbumsFile extends BaseEntity{

    private static final long serialVersionUID = 3115833151206815842L;
    
    //相册ID
    private HolderAlbums holderAlbums;

    //相册持有者
    private Holder holder;
    
    //上传文件名
    private String fileName;
    
    //文件上传时间戳
    private Long uploadTime;
    
    //文件大小，单位(Byte)
    private Long fileSize;
    
    //文件访问标记 0: 私有  1：空间（拍拍秀）
    private Integer accessFlag;
    //status 只标记相册的文件状态(状态为删除状态时，不意味着 拍拍空间中该文件也被删除了 )
    //文件状态，0:正常，1：隐藏，2：删除
    private Integer status = 0 ;
    public static final Integer EXIST=0;
    public static final Integer HIDED=1;
    public static final Integer DELETED=2;
    public static final Integer INDIVIDUAL=0;
    public static final Integer SHARED=1;
    
    //纬度
    private Double latitude;

    //经度
    private Double longitude;

    //省
    private String province;

    //城市
    private String city;
    
    //温度
    private String temperature;
    
    //天气
    private String weather;

    
    //拍拍秀被点赞数
    private Integer zanNum;

    //拍拍秀被查看数
    private Integer viewNum;
    
    //拍拍秀分享标题
    private String shareTitle;
    
    //拍拍秀分享描述
    private String shareDesc;

    //分享日期
    private Date shareDate;
    
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "holder_albums_id",nullable = false)
    public HolderAlbums getHolderAlbums() {
        return holderAlbums;
    }

    public void setHolderAlbums(HolderAlbums holderAlbums) {
        this.holderAlbums = holderAlbums;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "holder_id",nullable = false)
    public Holder getHolder() {
        return holder;
    }

    public void setHolder(Holder holder) {
        this.holder = holder;
    }

    @Column(nullable = false)
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @Column(nullable = false)
    public Long getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(Long uploadTime) {
        this.uploadTime = uploadTime;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public Integer getAccessFlag() {
        return accessFlag;
    }

    public void setAccessFlag(Integer accessFlag) {
        this.accessFlag = accessFlag;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getWeather() {
        return weather;
    }

    public void setWeather(String weather) {
        this.weather = weather;
    }

    public Integer getZanNum() {
        return zanNum==null?0:zanNum;
    }

    public void setZanNum(Integer zanNum) {
        this.zanNum = zanNum;
    }

    public Integer getViewNum() {
        return viewNum ==null?0: viewNum;
    }

    public void setViewNum(Integer viewNum) {
        this.viewNum = viewNum;
    }

    public String getShareTitle() {
        return shareTitle;
    }

    public void setShareTitle(String shareTitle) {
        this.shareTitle = shareTitle;
    }

    public String getShareDesc() {
        return shareDesc;
    }

    public void setShareDesc(String shareDesc) {
        this.shareDesc = shareDesc;
    }

    public Date getShareDate() {
        return shareDate;
    }

    public void setShareDate(Date shareDate) {
        this.shareDate = shareDate;
    }

    @PrePersist
    public void prePersist(){
        if(this.getViewNum()==null)
            this.setViewNum(0);
        if(this.getZanNum()==null)
            this.setZanNum(0);
        if(this.getAccessFlag()==null)
            this.setAccessFlag(0);//0: 私有
        if(this.getStatus()==null)
            this.setStatus(0);//0: 正常
    }

}
