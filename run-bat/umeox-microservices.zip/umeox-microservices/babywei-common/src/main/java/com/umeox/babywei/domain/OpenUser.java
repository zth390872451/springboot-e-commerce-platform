package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 *
 */
@Entity
@Table(name = "open_user")
public class OpenUser extends BaseEntity{
	private static final long serialVersionUID = 4039386100296265556L;
	private Long memberId;
	private String userId;//md5(client_id+mobile) 16位小写 或 第三方平台的OpenID(例微信OpenID)， 相当于卫小宝用户的OpenID
	private String clientId;//卫小宝分配给客户端ID
	private String mobile;//手机号码 或者 第三方平台的OpenID(例微信OpenID) 或者邮箱，对一个客户来说要唯一
	private String clientUserId ;//第三方平台用户ID （不再使用）
	public Long getMemberId() {
		return memberId;
	}
	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getClientUserId() {
		return clientUserId;
	}
	public void setClientUserId(String clientUserId) {
		this.clientUserId = clientUserId;
	}
	
}
