package com.umeox.babywei.service.impl;

import com.umeox.babywei.service.PushService;
import com.umeox.babywei.util.JsonUtils;
import com.umeox.babywei.yingyan.HttpUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.Map;

import static com.umeox.babywei.constant.PushConstant.*;

/**
 * @creator ZTH
 * @modifier ZTH
 * @date 2017-07-26
 *  推送服务
 */
@Async
@Transactional
@Service("pushServiceImpl")
public class PushServiceImpl implements PushService {

	private static final Logger logger = LoggerFactory.getLogger(PushServiceImpl.class);

	/**
	 * 发送通知和自定义消息
	 *
	 * @param packageName 目标APP
	 * @param target      目标主题
	 * @param title       通知标题
	 * @param content     通知内容
	 * @param extras      自定义消息数据[可选,若不为空，则为带自定义消息的通知。为空，则为纯通知]
	 */
	@Override
	public void sendNoticeAndMsg(String packageName, String target, String title, String content, Map<String, String> extras, Long timeToLive) {
		title = StringUtils.isEmpty(title) ? DEFAULT_TITLE_EN : title;

		Map<String, Object> jsonBody = new HashMap<>();
		Map<String, String> headers = new HashMap<>();
		Map<String, Object> notification = new HashMap<>();

		String topic = SUBJECT_PREFIX + target;
		headers.put("Authorization", AUTHORIZATION_VALUE);

		notification.put("title", title);
		if (!StringUtils.isEmpty(content)) {
			notification.put("body", content);
		}
		String sound = SOUND;
		if (!CollectionUtils.isEmpty(extras) && !StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == 14) {
			sound = "cs_alarm.wav";
		}
		notification.put("sound", sound);
		notification.put("badge", BADGE);
		jsonBody.put("notification", notification);

		jsonBody.put("to", topic);
		if (!StringUtils.isEmpty(packageName)) {
			jsonBody.put("restricted_package_name", packageName);//指定推送的目标APP
		}
		//自定义消息
		if (!CollectionUtils.isEmpty(extras)) {
			jsonBody.put("content_available", true);
			if (extras.get("from")!=null){
				extras.put("from_key",extras.get("from"));
				extras.remove("from");//在FCM中，from这个是保留字段
			}
			jsonBody.put("data", extras);
			jsonBody.put("time_to_live", timeToLive);
		}

		String body = JsonUtils.toJson(jsonBody);
		String res = HttpUtil.httpPost(URL, headers, body);
		if (StringUtils.isEmpty(res)) {
			logger.error("FCM push subject failed,res:{}", res);
			return;
		}
		Map result = JsonUtils.toObject(res, Map.class);
		if (result!=null && result.get("message_id") != null) {
			logger.info("FCM push subject success,result:{}", result);
		} else {
			logger.error("FCM push subject failed,result:{}", result);
		}
	}

	/**
	 * 发送自定义消息
	 *
	 * @param packageName 目标APP
	 * @param target      目标主题
	 * @param title       通知标题
	 * @param content     通知内容
	 * @param extras      自定义消息数据[可选,若不为空，则为带自定义消息的通知。为空，则为纯通知]
	 */
	@Override
	public void sendMsg(String packageName, String target, String title, String content, Map<String, String> extras, Long timeToLive) {
		title = StringUtils.isEmpty(title) ? DEFAULT_TITLE_EN : title;

		Map<String, Object> jsonBody = new HashMap<>();
		Map<String, String> headers = new HashMap<>();
		Map<String, Object> notification = new HashMap<>();
		Map<String, Object> data = new HashMap<>();
		if (extras.get("from")!=null){
			extras.put("from_key",extras.get("from"));
			extras.remove("from");//在FCM中，from这个是保留字段
		}
		data.putAll(extras);
		String topic = SUBJECT_PREFIX + target;
		headers.put("Authorization", AUTHORIZATION_VALUE);

		String sound = SOUND;
		if (!CollectionUtils.isEmpty(extras) && !StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == 14) {
			sound = "cs_alarm.wav";
		}
		notification.put("title", title);
		if (!StringUtils.isEmpty(content)) {
			notification.put("body", content);
		}
		notification.put("sound", sound);
		//自定义消息将 通知内容放入data结构体中
		data.put("notification",notification);

		if (!StringUtils.isEmpty(packageName)) {
			jsonBody.put("restricted_package_name", packageName);//指定推送的目标APP
		}
		jsonBody.put("to", topic);
		jsonBody.put("data", data);
		jsonBody.put("time_to_live", timeToLive);
		String body = JsonUtils.toJson(jsonBody);
		String res = HttpUtil.httpPost(URL, headers, body);
		if (StringUtils.isEmpty(res)) {
			logger.error("FCM push subject failed,res:{}", res);
			return;
		}
		Map result = JsonUtils.toObject(res, Map.class);
		if (result!=null && result.get("message_id") != null) {
			logger.info("FCM push subject success,result:{}", result);
		} else {
			logger.error("FCM push subject failed,result:{}", result);
		}
	}
	//推送测试:手表发送语聊信息，APP端收到消息
	/*public static void main(String[] args) {
		Map<String, String> param = new HashMap<String, String>();
		param.put("cmd", Push.IM_CHAT + "");
		param.put("from","60946" );
		PushService pushService = new PushServiceImpl();
		String packageName = "com.doki.dokiwatch";
		String title = "Receive Message";
		String alias = "FCM_71305_ANDROID";
		String msgContent = "taylor dark has sent you a new message test02 zth";
		pushService.sendMsg(packageName,alias,title,msgContent,param,DEFAULT_TIME_TO_LIVE);
	}*/
}
