package com.umeox.babywei.conf;

public class RedisKeyPre {
	
	public static final String DEVICE_IMEI_KEY = "device:imei:";
	
	public static final String HOLDER_IMEI_KEY = "holder:imei:";
	
	public static final String CHANNEL_WH_IMEI_KEY = "channelwh:imei:";

	public static final String HOLDER_SALE_CHANNEL_key = "holder:salechannel:";
	
	public final static String USER_HOLDER = "user:holder:";
	
	public final static String OAUTH2_TOKEN = "o2:t:";
	
	public final static String IM_USERNAME = "im:un:";
	
	//---------------------------微话饼  & K3
	public final static String FRIEND_CHAT = "fc:";//私聊 格式 fc:memberId:holderId  k3格式(会员：fc:'m'memberId:'h'holderId;设备：fc:'h'holderId:'m'memberId  fc:'h'holderId:'h'holderId)
	public final static String GROUP_CHAT = "gc:";//群聊  格式gc:groupId(ID)
	public final static String NOTICE = "nt:";//通知，格式 微话饼针对用户 nt:memberId ,K3针对设备nt:memberId:holderId
	public final static String ATTENTION_CODE = "ac:";//关注码 格式ac:code 有效期24小时
	public final static String HOLDER_CHAT = "h";//
	public final static String MEMBER_CHAT = "m";//
}
