package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.Date;

/**
 *
 * 记录短信的流动(状态变迁)
 *
 */
@Entity
@Table(name="ux_sms_result")
public class SmsResult extends BaseEntity{

    private String mobile;//手机号码
    private Date sendTime;//短信发送时间
    private String content;//发送内容
    private Integer type;//内容类型 0(注册) 1(找回密码) 2(实名认证失败)
    private Integer status;
    //短信状态：0-我司发送http给短信公司成功;
    // 1-我司发送http收到回复失败(平台响应结果失败)或者http请求失败(网络连接失败);
    // 2-短信公司回执通知(回执接口)，短信发送给用户成功;
    // 3-短信公司回执通知(回执接口)，短信发送给用户失败
    //4-用户收到验证码，并正常使用了(验证码不为空时，才有的状态)
    private String code;//发送的验证码(注册和找回密码时才不为空)
    private Date codeUsedDate;//验证码使用时间(注册、找回密码)
    private Date receiptDate;////接收到短信平台的回执请求时间
    private String msgId;//短信发送成功时的短信平台消息Id(可定向查询)

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getCodeUsedDate() {
        return codeUsedDate;
    }

    public void setCodeUsedDate(Date codeUsedDate) {
        this.codeUsedDate = codeUsedDate;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Date getSendTime() {
        return sendTime;
    }

    public void setSendTime(Date sendTime) {
        this.sendTime = sendTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(Date receiptDate) {
        this.receiptDate = receiptDate;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }
}
