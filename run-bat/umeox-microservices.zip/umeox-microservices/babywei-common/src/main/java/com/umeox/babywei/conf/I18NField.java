package com.umeox.babywei.conf;

public class I18NField {
	//--------------------common
		//--------发送邮件
	public static final String email_regist_subject = "email.regist.subject";//主题
	public static final String email_regist_content = "email.regist.content";//内容
	public static final String email_forget_subject = "email.forget.subject";//主题
	public static final String email_forget_content = "email.forget.content";//内容
	
	//--------------------k3
		//--------新增关注者
	public static final String k3_add_attention_title = "k3.add.attention.title";//标题--添加手表提醒
	public static final String k3_add_attention_content = "k3.add.attention.content";//内容--{xxx}添加了{xx}的手表
}
