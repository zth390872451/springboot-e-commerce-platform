package com.umeox.babywei.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @author JT
 */
public class I18nUtil {

    //返回java所支持的全部国家和语言的数组
    public List<String> getAvailableLocales() {
        Locale[] localeList = Locale.getAvailableLocales();
        List<String> availableLocales = new ArrayList<String>();
        for (int i = 0; i < localeList.length; i++) {
            //打印出所支持的国家和语言
            System.out.println(localeList[i].getDisplayCountry() + "=" + localeList[i].getCountry() + "  " + localeList[i].getDisplayLanguage() + "=" + localeList[i].getLanguage());
            availableLocales.add(localeList[i].getDisplayCountry() + "=" + localeList[i].getCountry() + "  " + localeList[i].getDisplayLanguage() + "=" + localeList[i].getLanguage());
        }
        return availableLocales;
    }
}
