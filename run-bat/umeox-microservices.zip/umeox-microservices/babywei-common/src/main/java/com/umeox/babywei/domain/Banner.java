package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 * @author JT
 */
@Entity
@Table(name = "ux_paipai_banner")
public class Banner {
    
    private Long id;
    //标题
    private String title;
    //图片地址
    private String picUrl;
    //跳转网页地址
    private String url;
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
