package com.umeox.babywei.constant;

/**
 * 定位模式
 * 
 * @author Jiang Jieming
 *
 * @date 2015年12月22日 下午4:44:22
 */
public enum PositioningMode {

	GPS("0"), LBS("1"), WIFI("2");

	private String value;

	PositioningMode(String value) {
		this.value = value;
	}

	public String value() {
		return value;
	}

	@Override
	public String toString() {
		return "PositioningMode{" + "value=" + value + '}';
	}
}
