package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 相册基本表
 */
@Entity
@Table(name = "ux_holder_albums")
public class HolderAlbums extends BaseEntity {
    
    private static final long serialVersionUID = 6291973381501674307L;
    
    //相册持有者
    private Holder holder;

    //可用空间大小,单位（Byte）
    private Long availableSize;
    
    //访问域名
    private String domain;
    
    //存储空间
    private String bucket;
    
    @OneToOne
    @JoinColumn(name = "holder_id",nullable = false)
    public Holder getHolder() {
        return holder;
    }
    
    public void setHolder(Holder holder) {
        this.holder = holder;
    }

    public Long getAvailableSize() {
        return availableSize;
    }

    public void setAvailableSize(Long availableSize) {
        this.availableSize = availableSize;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }
}
