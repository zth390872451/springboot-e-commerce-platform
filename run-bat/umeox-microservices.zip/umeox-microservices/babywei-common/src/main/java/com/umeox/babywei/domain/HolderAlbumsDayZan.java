package com.umeox.babywei.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * 相册日集点赞表
 */
@Entity
@Table(name = "ux_holder_albums_day_zan")
public class HolderAlbumsDayZan {

    private Long id;

    //相册
    private HolderAlbums holderAlbums;
    
    //用户
    private Member member;

    //相集日期（yyyy-MM-dd)
    private Date day;
    
    //点赞日期
    private Date zanTime;

    //是否点赞
    private Boolean isZan;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "holder_albums_id",nullable = false)
    public HolderAlbums getHolderAlbums() {
        return holderAlbums;
    }

    public void setHolderAlbums(HolderAlbums holderAlbums) {
        this.holderAlbums = holderAlbums;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id",nullable = false)
    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        this.day = day;
    }

    @Column(nullable = false)
    public Date getZanTime() {
        return zanTime;
    }

    public void setZanTime(Date zanTime) {
        this.zanTime = zanTime;
    }

    public Boolean getIsZan() {
        return isZan;
    }

    public void setIsZan(Boolean isZan) {
        this.isZan = isZan;
    }
}
