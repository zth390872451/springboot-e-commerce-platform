package com.umeox.babywei.conf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AppDetails {
	
	public final static List<String> WHERECOM_K2_POMO_CLIENT_IDS = new ArrayList<String>(Arrays.asList("wherecom_k2_pomo_api_ios", "wherecom_k2_pomo_api_android"));
	public final static List<String> WHERECOM_K2_IRIST_CLIENT_IDS = new ArrayList<String>(Arrays.asList("wherecom_k2_irist_api_ios", "wherecom_k2_irist_api_android"));
	public final static List<String> WXB_DOKI_CLIENT_IDS = new ArrayList<String>(Arrays.asList("wxb_doki_api_ios", "wxb_doki_api_android"));
	public final static List<String> WHERECOM_DOKI_CLIENT_IDS = new ArrayList<String>(Arrays.asList("wherecom_dokiwatch_api_ios","wherecom_dokiwatch_api_android"));
	//K3_CLIENT_IDS:海外k3以及南非k2v(基于k3的定制版)
	public final static List<String> K3_CLIENT_IDS = new ArrayList<String>(Arrays.asList("wherecom_k3_api_ios","wherecom_k3_api_android","wherecom_k3_tinytrackv2_api_ios","wherecom_k3_tinytrackv2_api_android","wherecom_k3_oaxis_watchphone_api_ios","wherecom_k3_oaxis_watchphone_api_android","wherecom_k3_funparkwatch_api"));
	public final static List<String> S3_CLIENT_IDS = new ArrayList<String>(Arrays.asList("wherecom_s3_api_ios","wherecom_s3_api_android"));

	public final static String  APP_ID = "app_id";
	
	public final static String CLIENT_ID = "client_id";
	
	//public final static String ANDROID_PACKAGE_WHERECOM = "com.umeox.wherecom.oversea";
	
	//public final static String PACKAGE_BABYWEI_GX3T = "com.weixiaobao.gx3t";//沒用了
	
	public final static String ANDROID_PACKAGE_BABYWEI = "com.umeox.capsule";//卫小宝国内安卓版包名
	
	public final static String IOS_PACKAGE_WHERECOM = "com.umeox.wherecom.oversea";//卫小宝海外安卓和iOS版的包名

	public final static String  IOS_PACKAGE_SONQUI = "com.umeox.SONQUI";
	
	public final static String IOS_PACKAGE_SONQUI_PET = "net.sonqui.sonqui-pet";
	
	//public final static String  IOS_PACKAGE_BABYWEI= "com.umeox.wherecom";//卫小宝国内iOS版的包名
	
	//public final static String PACKAGE_WHERECOM_K2 = "com.wherecom.k2";
	
	//public final static String PACKAGE_WHERECOM_K2_POMO = "com.wherecom.k2.pomo";//定制版本
	
	//public final static String PACKAGE_WHERECOM_K2_IRIST = "com.wherecom.k2.irist";//定制版本

	//public final static String PACKAGE_WHERECOM_K3 = "com.wherecom.k3";
	
	//public final static String PACKAGE_WHERECOM_K3_DOKI = "com.wherecom.dokiwatch";

	//public final static String PACKAGE_WATCH_KIDWATCH = "com.watch.kidwatch"; //支持K5,K6,Q50的中性APP包名

	//public final static List<String> DEVICE_TYPE_WHERECOM = new ArrayList<String>(Arrays.asList("1", "2", "3", "4", "6", "8", "9", "11","15"));

	//public final static List<String> DEVICE_TYPE_BABYWEI  = new ArrayList<String>(Arrays.asList("1", "2", "3","4", "6", "8", "9", "11", "14","15","16","17","18"));
	
	//----------------------------------------------
	public final static Long HOME_POSITION_GT_MINUTES = 10L;//首页定位大于时间(分钟)
	public final static Long HOME_POSITION_LT_MINUTES = 90L;//首页定位小于时间(分钟)
	
	//设备类型：功能机和智能机中语聊功能和设备交友（或交友生成联系人）
	public final static List<String> DEVICE_TYPE_ADD_RELATION = new ArrayList<String>(Arrays.asList("4", "5","6","7","10","14","17","18","19","20","21","23","24","25","26"));

	//拥有设备在线查询功能的功能机机型
	public final static List<String> G2_DEVICE_ONLINE_SEARCH = new ArrayList<String>(Arrays.asList("18","24","25","26"));
	//K7、K7S、K7C
	public final static List<String> DEVICE_K7_SERIES = new ArrayList<String>(Arrays.asList("18","24","25","26"));

	//设备类型：功能机设备类型（MQTT协议），用于：修改设备sim号同步好友联系人，同步时区
	//public final static List<String> K2_SERIES_DEVICE_TYPE = new ArrayList<String>(Arrays.asList("4", "6", "14","18","19"));
	
	//设备类型：使用Redis队列同步标记，功能机长连接(MQTT协议)
	public final static List<String> DEVICE_TYPE_SEND_MARK = new ArrayList<String>(Arrays.asList("4", "6", "8", "9","14", "11","15","16","18","19","22","23","24","25","26"));

	//设备类型：通过设置标记同步数据，功能机短连接 一代 MsgSetting表
	public final static List<String> DEVICE_TYPE_SYNC_MARK = new ArrayList<String>(Arrays.asList("1", "2","3"));

	//设备类型：使用Thrift协议发送消息到设备，智能机 HTTP长连接
	public final static List<String> THRIFT_ISSUE_DEVICE_TYPE = new ArrayList<String>(Arrays.asList("7","10","12","13","20","21"));


	//设备类型：智能机K3&Doki系列
	public final static List<String> K3_SERIES_DEVICE_TYPE = new ArrayList<String>(Arrays.asList("7","10","20","21"));
	
	//设备类型：智能机老人机S600
	public final static List<String> S3_SERIES_DEVICE_TYPE = new ArrayList<String>(Arrays.asList("12","13"));
	

	//public final static List<String> DEVICE_TYPE_MSGINREDIS_AND_JPUSH = new ArrayList<String>(Arrays.asList("5"));//通知放在队列中并且使用JPUSH的设备类型
	
	//public final static List<String> DEVICE_SHORT_CONN = new ArrayList<String>(Arrays.asList("1", "2", "3"));//短连接，需要更新标记

	public final static String K2_DEVICE_TYPE = "4";
	public final static String K6_DEVICE_TYPE = "17";

	//public final static	List<String> WATCH_KIDWATCH_DEVICE_TYPE = new ArrayList<String>(Arrays.asList("15", "17", "16"));//K5、K6、Q50 依次的设备类型

	public final static String DEFAULT_NAME = "关注者";//中文；添加成为好友，可能没有设置名称，默认名称

	public final static String DEFAULT_NAME_EN = "Follower";//英文；添加成为好友，可能没有设置名称，默认名称
	
	//public final static String FIRST_BIND_SET_NAME = "管理员";

	//public final static String FIRST_BIND_SET_NAME_EN = "Admin";

	//public final static String FIRST_BIND_SET_NAME_ARABIC = "المشرف";
	
	//public final static String FILE_URL = "http://114.55.230.160:7878";//语音上传文件服务器地址
	
	//-------------------------------------------------微话饼
	public final static String WETALK_CLIENT_ID = "wxb_wetalk_api_android";
	public final static String WHERECOM_WETALK_CLIENT_ID = "wherecom_wetalk_api_android";
	public final static List<String> DEVICE_TYPE_ADD_GROUP = new ArrayList<String>(Arrays.asList("5"));//需要添加群组的设备类型
	public final static String WE_TALK_DEVICE_TYPE = "5";//微话饼设备类型
	
	public final static String GROUP_PRE = "gf";	
	
	public final static Integer FRIEND_TYPE = 0;//私聊
	public final static Integer GROUP_TYPE = 1;//群聊
	
	public final static Integer API2_REDIS_KEY = 0;
	public final static int WETALK_REDIS_KEY = 1;
	
	public final static String K3_DEVICE_TYPE = "10";
	public final static String DOKI_DEVICE_TYPE = "7";
	
	//------------------------------------------------K1c  = 8
	//public final static String K1C_DEVICE_TYPE = "8";
	
	//------------------------------------------------candy2c = 9
	//public final static String C2C_DEVICE_TYPE = "9";
	
	//----------------------------------------第三方
	public final static List<String> THIRD_PARTY_CLIENT_IDS = new ArrayList<String>(Arrays.asList("wxb_weixin_open_client"));//一号专线 限制一对一设备绑定
	//public final static List<String> THIRD_PARTY_DEVICE_TYPE  = new ArrayList<String>(Arrays.asList("1", "2", "3","4", "6", "7", "8", "9", "10", "11"));
	//与funpark 公司对接调用相关接口：查看文档：FunPark-Watch-API(智趣王版本).doc
	public final static List<String> FUNPARK_APP = new ArrayList<String>(Arrays.asList("wherecom_k3_funparkwatch_api"));//funpark 公司的定制APP
}
