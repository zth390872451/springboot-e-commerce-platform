package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * Entity - 设备
 * 
 * @author Yan
 */
@Entity
@Table(name = "ux_command")
public class Command extends BaseEntity {

	private static final long serialVersionUID = 7414635704969444891L;

	/**
	 * 指令来源手机号
	 */
	private String mobile;

	/**
	 * 对应设备IMEI
	 */
	private String imei;

	/**
	 * 指令（随机码）
	 */
	private String code;
	
	/**
	 * 命令类型
	 */
	private int type; // 1 定位 2 语音

	/**
	 * 附加信息
	 */
	private String remark;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

}
