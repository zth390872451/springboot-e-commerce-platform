package com.umeox.babywei.util;

public class PostionCorrectUtils {

	private static long apartMinute = 10;//单位：分钟
	private static double apartDistance = 5000;//单位：米
	
	/**
	 * 当前定位与缓存数据对比
	 * 1、缓存数据不存在，不处理
	 * 2、与缓存数据时间对比，如果相隔大于X分钟并且距离相隔大于y米，把当前数据坐标换成缓存的坐标
	 */
	public static boolean isConvertLocation(double currentLat, double currentLng, long currentLocationTime, 
							  double cacheLat,double cacheLng, long cacheLocationTime){
		long apartTime = (currentLocationTime - cacheLocationTime) / 1000 / 60;
		if (apartTime < apartMinute) {
			double distance = MapUtil.getDistance(currentLat, currentLng, cacheLat, cacheLng);
			if (distance > apartDistance) {
				return true;
			}
		}
		return false;
	}
}
