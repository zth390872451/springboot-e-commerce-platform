package com.umeox.babywei.domain;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.persistence.*;
import java.io.Serializable;

/**
 * 需求：一个APP应用A的用户a_aa关注了 设备类型为1 的手表watch_01,设备类型为2 的手表 watch_02和设备类型为3的手表watch_03等等。
 *  需要在关注的设备列表中显示手表 watch_01、watch_02、watch_03(其他的则不显示)
 *
 *  以app的包名(appId)为键，需要显示的设备类型列表为值
 *
 *
 *
 * 设备类型分为兩种：
 * 1、 功能机***设备类型有：["1", "2", "3","4", "6", "8", "9", "11", "14","15","16","17","18"] + ["5"]
 * 2、 智能机***设备类型有：["7","10","12","13"] 【也就是Doki + K3 + 老人机(S3和S600)】
 */
@Entity
@Table(name = "ux_app_device_type")
public class AppToDeviceType implements Serializable {

    /** ID */
    private Long id;
    //应用标识
    private String appId;
    //应用需要显示的设备类型列表
    private String deviceTypes;
    //描述(冗余字段)
    private String descr;

    @JsonProperty
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getDeviceTypes() {
        return deviceTypes;
    }

    public void setDeviceTypes(String deviceTypes) {
        this.deviceTypes = deviceTypes;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(String descr) {
        this.descr = descr;
    }
}
