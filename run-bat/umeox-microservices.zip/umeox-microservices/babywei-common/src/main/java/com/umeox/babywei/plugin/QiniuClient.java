package com.umeox.babywei.plugin;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.qiniu.common.QiniuException;
import com.qiniu.http.Response;
import com.qiniu.storage.UploadManager;
import com.qiniu.util.Auth;
import com.qiniu.util.StringMap;

public class QiniuClient {
	//移动网络 可以使用 upyd.qiniu.com 这个上传host试下
	//联通和电信 用 uptx.qiniu.com 这个上传host
	protected static final Logger log = LoggerFactory.getLogger(QiniuClient.class);
	
	public static final String imDomain = "http://7xnjip.dl2.z0.glb.qiniucdn.com/";
	
	private static final String accessKey = "84K8sL8DAH0Ywv1xpvZtYYfD5Yxn7JQ8xgOKFsIb";
	private static final String secretKey = "Zxgvc5g2X2NFwPjt3YzEFM38liM8dohp0v6Wz5ZG";
	private static final String bucket = "babywei";
	private static final Long upExpires = 7 * 24 * 60 * 60L;//上传--单位：秒
	private static final Long downloadExpires = 7 * 24 * 60 * 60L;//下载--单位：秒
	private static final Long fsizeLimit = 10 * 1024 * 1024L;//单位：字节
	private static UploadManager uploadManager = new UploadManager();
	
	private static Auth auth = null;

	
	public static Auth getAuth(){
		if (auth == null) {
			auth = Auth.create(accessKey, secretKey); 
		}
		return auth;
	}
	
	/**
	 * 获取语聊上传策略
	 */
	public static String getImUpToken(){
		/*return getAuth().uploadToken(bucket, null, upExpires, new StringMap()
			//.put("endUser", "uid")
			.put("fsizeLimit", fsizeLimit));*/
		return "asjdfoj8JOJOISJDIO67898";
	}
	
	/**
	 * 获取语聊私有下载策略
	 * @return 直接访问文件的url
	 */
	public static String getImDownLoadToken(String baseUrl){
		return getAuth().privateDownloadUrl(baseUrl,downloadExpires);
	}
	
	/**
	 * 上传
	 */
	private static void upload(String filePath, String key, String upToken){
		try {
			Response res = uploadManager.put(filePath, key, upToken);
			if (res.isOK()) {
				System.out.println("success");
			}else {
				System.out.println("fails");
			}
		} catch (QiniuException e) {
			Response r = e.response;
			log.error(r.toString()); // 请求失败时简单状态信息
			try {
				log.error(r.bodyString());// 响应的文本信息
			} catch (QiniuException e1) {
				//ignore
			}
		}
	}
	
	/*public static void main(String[] args)  {
		String upToken = getImUpToken();
		System.out.println(upToken);
		String filePath = "G:/zzzz.jpg";
		upload(filePath, "imei/2015/10/22", upToken);
		
		String baseUrl = "http://7xnjip.dl2.z0.glb.qiniucdn.com/888888888888885_20151024111043.amr";
		System.out.println(getImDownLoadToken(baseUrl));
	}*/
}
