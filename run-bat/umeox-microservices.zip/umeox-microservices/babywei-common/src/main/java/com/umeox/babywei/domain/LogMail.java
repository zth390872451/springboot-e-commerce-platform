package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "ux_log_mail")
public class LogMail extends BaseEntity{

	private static final long serialVersionUID = -2089917103197387572L;

	private String receiver;
	
	private String subject;
	
	private String content;
	
	private String status;

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
