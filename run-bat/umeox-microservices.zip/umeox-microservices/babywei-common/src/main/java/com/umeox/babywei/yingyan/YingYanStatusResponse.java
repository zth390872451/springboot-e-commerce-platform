package com.umeox.babywei.yingyan;

/**
 * @author JT
 */
public class YingYanStatusResponse {

    //状态码
    private Integer status;

    //响应信息,对status的中文描述
    private String message;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
