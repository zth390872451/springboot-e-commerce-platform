package com.umeox.babywei.domain.enums;

public enum AppType {
	ISO,ANDROID,DEVICE
}
