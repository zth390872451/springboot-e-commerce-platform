package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @Desc 设备设置参数
 * @author umeox
 * @version II
 */
@Entity
@Table(name = "ux_holder_set")
public class HolderSet extends BaseEntity{

	private static final long serialVersionUID = 1064147116642322556L;

	public static final Boolean OFF_DEFAULT_TYPE = false;
	public static final Boolean ON_TYPE = true;


	private Holder holder;

	/**
	 * 自动接听模式(0:自动接听；1:按SOS接听)
	 * 设备类型为3(candy2)时，默认为1
	 */
	private Boolean answer = OFF_DEFAULT_TYPE;

	/**
	 * 是否开启报告位置（0:关闭；1：开启）
	 */
	private Boolean callLocation = OFF_DEFAULT_TYPE;

	/**
	 * 是否预留应急电量（0：关闭；1：开启）
	 */
	private Boolean electricProtect = OFF_DEFAULT_TYPE;

	/**
	 * 是否关机上报位置（0：关闭；1：开启）
	 */
	private Boolean powerOffLocation = OFF_DEFAULT_TYPE;

	/**
	 * 是否开启拒绝陌生人来电（0：关闭；1：开启）
	 */
	private Boolean refusePhone = OFF_DEFAULT_TYPE;

	/**
	 * 是否开启上课禁用（0：关闭；1：开启）
	 */
	private Boolean classTimeProtect = OFF_DEFAULT_TYPE;

	/**
	 * 是否开启特殊关心时段（0：关闭；1：开启）
	 */
	private Boolean concernTimeProtect = OFF_DEFAULT_TYPE;


	/**
	 * 是否开启脱落提醒（0：关闭；1：开启）
	 */
	private Boolean deviceOffAlarm = OFF_DEFAULT_TYPE;


	/**
	 * 设备工作模式 (0：默认模式	 1：省电模式	 2：夜间关机模式	 3: 极限省电模式	 4: 实时监控模式)
	 *
	 */
	private Integer deviceWorkModel = 0;

	/**
	 *  开启或关闭蓝牙随行
	 */
	private Boolean bluetoothAccompanyState = OFF_DEFAULT_TYPE;

	@OneToOne
	@JoinColumn(name = "holder_id",nullable = false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getAnswer() {
		return answer;
	}

	public void setAnswer(Boolean answer) {
		this.answer = answer;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getCallLocation() {
		return callLocation;
	}

	public void setCallLocation(Boolean callLocation) {
		this.callLocation = callLocation;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getElectricProtect() {
		return electricProtect;
	}

	public void setElectricProtect(Boolean electricProtect) {
		this.electricProtect = electricProtect;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getPowerOffLocation() {
		return powerOffLocation;
	}

	public void setPowerOffLocation(Boolean powerOffLocation) {
		this.powerOffLocation = powerOffLocation;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getRefusePhone() {
		return refusePhone;
	}

	public void setRefusePhone(Boolean refusePhone) {
		this.refusePhone = refusePhone;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getClassTimeProtect() {
		return classTimeProtect;
	}

	public void setClassTimeProtect(Boolean classTimeProtect) {
		this.classTimeProtect = classTimeProtect;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getConcernTimeProtect() {
		return concernTimeProtect;
	}

	public void setConcernTimeProtect(Boolean concernTimeProtect) {
		this.concernTimeProtect = concernTimeProtect;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getDeviceOffAlarm() {
		return deviceOffAlarm;
	}

	public void setDeviceOffAlarm(Boolean deviceOffAlarm) {
		this.deviceOffAlarm = deviceOffAlarm;
	}

	public Integer getDeviceWorkModel() {
		return deviceWorkModel;
	}

	public void setDeviceWorkModel(Integer deviceWorkModel) {
		this.deviceWorkModel = deviceWorkModel;
	}

	@Column(nullable = false,columnDefinition = "bit default 0")
	public Boolean getBluetoothAccompanyState() {
		return bluetoothAccompanyState;
	}

	public void setBluetoothAccompanyState(Boolean bluetoothAccompanyState) {
		this.bluetoothAccompanyState = bluetoothAccompanyState;
	}
}
