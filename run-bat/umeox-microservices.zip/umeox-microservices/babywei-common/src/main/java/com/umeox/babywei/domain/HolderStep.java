package com.umeox.babywei.domain;

import java.util.Date;

import javax.persistence.*;

/**
 * @deac 计步(每天产生一条新的记录，每次上传都是当天步数的累积)
 * @author umeox
 * @version II
 */
@Entity
@Table(name = "ux_holder_step",uniqueConstraints = {@UniqueConstraint(columnNames={"holder_id","step_date"})})
public class HolderStep extends BaseEntity{

	private static final long serialVersionUID = 2233862480256498686L;

	private Holder holder;
	
	/**
	 * 记步-计划值 这个值：是从HolderStepPlan中获取的计划值，然后存储。
	 */
	private Integer planValue = 0;
	
	/**
	 * 记步-当天累计值
	 */
	private Integer stepValue;
	
	/**
	 * 记步-日期（yyyy-MM-dd）
	 */
	private Date stepDate;
	
	/**
	 * 是否达到目标值（K3）
	 */
	private Boolean reachGoal;

	
	@ManyToOne
	@JoinColumn(name = "holder_id",nullable = false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public Integer getPlanValue() {
		return planValue;
	}

	public void setPlanValue(Integer planValue) {
		this.planValue = planValue;
	}

	public Integer getStepValue() {
		return stepValue;
	}

	public void setStepValue(Integer stepValue) {
		this.stepValue = stepValue;
	}

	@Temporal(TemporalType.DATE)
	@Column(name = "step_date")
	public Date getStepDate() {
		return stepDate;
	}

	public void setStepDate(Date stepDate) {
		this.stepDate = stepDate;
	}

	public Boolean getReachGoal() {
		return reachGoal;
	}

	public void setReachGoal(Boolean reachGoal) {
		this.reachGoal = reachGoal;
	}

	@PrePersist
	public void prePersist(){
		if (this.getReachGoal()==null){
			this.reachGoal=false;
		}
	}
}
