package com.umeox.babywei.util;

import java.awt.Font;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.DecimalFormat;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringToolUtil
{

	private static long a = 0L;
	private static final DecimalFormat format1 = new DecimalFormat("#,##0");
	private static final DecimalFormat format2 = new DecimalFormat("#,##0.0");
	private static final DecimalFormat format3 = new DecimalFormat("#,##0.00");
	private static final DecimalFormat format4 = new DecimalFormat("#,##0.00");
	private static final DecimalFormat format5 = new DecimalFormat("###0.0");
	private static final DecimalFormat format6 = new DecimalFormat("###0.00");

	public StringToolUtil()
	{
	}

	public static int[] getArrayInt(String s)
	{
		int ai[] = (int[]) null;
		int i = 0;
		if (s.length() > 0)
		{
			StringTokenizer stringtokenizer = new StringTokenizer(s, ",");
			ai = new int[stringtokenizer.countTokens()];
			while (stringtokenizer.hasMoreElements())
				try
				{
					ai[i] = Integer.parseInt(stringtokenizer.nextToken());
					i++;
				} catch (NumberFormatException numberformatexception)
				{
				}
		}
		return ai;
	}

	public static String getOnlyKey()
	{
		if (a == 0L)
			a = 0x3cd39820L;
		else
			a++;
		return String.valueOf(a);
	}

	public static String getFormat1Str(double d1)
	{
		return format1.format(d1);
	}

	public static String getFormat2Str(double d1)
	{
		return format2.format(d1);
	}

	public static String getFormat5Str(double d1)
	{
		return format5.format(d1);
	}

	public static String getFormat4Str(double d1)
	{
		return format4.format(d1);
	}

	public static String formatStringValue(String s, int i, int j)
	{
		return formatDoubleValue(getDouble(s, 0.0D), i, j, 0);
	}

	public static String formatDoubleValue(double d1, int i, int j)
	{
		return formatDoubleValue(d1, i, j, 0);
	}

	public static String formatDoubleValue(double d1, int i, int j, int k)
	{
		double d2;
		if (j == 0)
			d2 = Math.round(getRoundDouble(d1, i + k, j + k));
		else
			d2 = getRoundDouble(d1, i + k, j + k);
		DecimalFormat decimalformat = new DecimalFormat();
		String s = "0";
		if (j > 0)
		{
			s = (new StringBuilder(String.valueOf(s))).append(".").toString();
			for (int l = 0; l < j; l++)
				s = (new StringBuilder(String.valueOf(s))).append("0").toString();

			for (int i1 = 0; i1 < k; i1++)
				s = (new StringBuilder(String.valueOf(s))).append("#").toString();

		}
		decimalformat.applyPattern(s);
		return decimalformat.format(d2);
	}

	public static double getDouble(String s, int i, int j)
	{
		return getRoundDouble(getDouble(s, 0.0D), i, j);
	}

	public static double getRoundDouble(double d1, int i, int j)
	{
		double d2 = (double) Math.round(d1 * Math.pow(10D, i) + 0.0001D) / Math.pow(10D, i);
		double d3 = (double) Math.round(d2 * Math.pow(10D, j)) / Math.pow(10D, j);
		return d3;
	}

	public static double getDouble(String s, double d1)
	{
		double d2 = 0.0D;
		try
		{
			d2 = Double.parseDouble(s.replaceAll(",", ""));
		} catch (NumberFormatException numberformatexception)
		{
			d2 = d1;
		} catch (NullPointerException nullpointerexception)
		{
			d2 = d1;
		}
		return d2;
	}

	public static long getLongValue(String s, long l)
	{
		long l1 = 0L;
		try
		{
			l1 = (long) Double.parseDouble(s);
		} catch (NumberFormatException numberformatexception)
		{
			l1 = l;
		} catch (NullPointerException nullpointerexception)
		{
			l1 = l;
		}
		return l1;
	}

	public static int getint(String parsevalue, int defaultValue)
	{
		int j = 0;
		try
		{
			j = (int) Double.parseDouble(parsevalue);
		} catch (NumberFormatException numberformatexception)
		{
			j = defaultValue;
		} catch (NullPointerException nullpointerexception)
		{
			j = defaultValue;
		}
		return j;
	}

	public static void printException(Throwable throwable)
	{
		StringBuffer stringbuffer = new StringBuffer();
		if (throwable != null && (throwable instanceof Throwable))
		{
			StringWriter stringwriter = new StringWriter();
			throwable.printStackTrace(new PrintWriter(stringwriter));
			stringwriter.flush();
			stringbuffer.append(stringwriter.toString());
			try
			{
				stringwriter.close();
			} catch (IOException ioexception)
			{
			}
		}
		stringbuffer.setLength(0);
		stringbuffer = null;
	}

	public static String getCode()
	{
		return new String(new char[] { '9', 'z', 'r', 'z', 'k', 'l', 'y', '0', 'e', 'o', '4', '1', 'v', '5', 'n', 'x', '8', 'c', 'q', 'n' });
	}

	public static String getstatementCode()
	{
		return new String(new char[] { 'z', '6', 'd', 'c', 'm', '2', 't', '6', 'd', 'r', 'b', 'v', 'e', 'a', 'v', 'p', 'q', 'c', 'w', 'v' });
	}

	public static Locale getLocale(int i)
	{
		Locale locale;
		switch (i)
		{
			case 1: // '\001'
				locale = Locale.TRADITIONAL_CHINESE;
				break;

			case 2: // '\002'
				locale = Locale.SIMPLIFIED_CHINESE;
				break;
			default:
				locale = Locale.ENGLISH;
				break;
		}
		return locale;
	}

	public static String FontName(int i)
	{
		String s = "Dialog";
		switch (i)
		{
			case 1: // '\001'
				if (Font.decode("MingLiU") != null)
					s = "MingLiU";
				break;

			case 2: // '\002'
				if (Font.decode("SimSun") != null)
					s = "SimSun";
				break;

			case 3: // '\003'
				if (Font.decode("Dialog") != null)
					s = "Dialog";
				break;

			default:
				if (Font.decode("Arial") != null)
					s = "Arial";
				break;
		}
		return s;
	}

	public static String getStringByObject(Object obj) {
		String returnMsg = "";
		if(obj==null) {
			return returnMsg;
		}
		return String.valueOf(obj);
	}
	
	public static String getTextByBundle(ResourceBundle resourcebundle, String s)
	{
		String s1;
		try
		{
			s1 = resourcebundle.getString(s);
			if (resourcebundle.getLocale() != Locale.ENGLISH)
				try
				{
					String s2 = new String(s1.getBytes("iso-8859-1"), "UTF-8");
					s1 = s2;
				} catch (Throwable throwable)
				{
				}
		} catch (MissingResourceException missingresourceexception)
		{
			s1 = s;
		}
		return s1;
	}
	public static String bytesToHexString(byte[] src){  
	    StringBuilder stringBuilder = new StringBuilder("");  
	    if (src == null || src.length <= 0) {  
	        return null;  
	    }  
	    for (int i = 0; i < src.length; i++) {  
	        int v = src[i] & 0xFF;  
	        String hv = Integer.toHexString(v);  
	        if (hv.length() < 2) {  
	            stringBuilder.append(0);  
	        }  
	        stringBuilder.append(hv);  
	    }  
	    return stringBuilder.toString();  
	}  
	/** 
	 * Convert hex string to byte[] 
	 * @param hexString the hex string 
	 * @return byte[] 
	 */  
	public static byte[] hexStringToBytes(String hexString) {  
	    if (hexString == null || hexString.equals("")) {  
	        return null;  
	    }  
	    hexString = hexString.toUpperCase();  
	    int length = hexString.length() / 2;  
	    char[] hexChars = hexString.toCharArray();  
	    byte[] d = new byte[length];  
	    for (int i = 0; i < length; i++) {  
	        int pos = i * 2;  
	        d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));  
	    }  
	    return d;  
	}  
	/** 
	 * Convert char to byte 
	 * @param c char 
	 * @return byte 
	 */  
	 private static byte charToByte(char c) {  
	    return (byte) "0123456789ABCDEF".indexOf(c);  
	} 

	//条件不完善
	@Deprecated
	 public static boolean isMobileNO(String mobiles){  
		  
		Pattern p = Pattern.compile("^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$");  
		  
		Matcher m = p.matcher(mobiles);  
		  
		return m.matches();  
	}

	/**
	 * 由于手机号有很多中，我们需要支持座机号，等其他虚拟运营商号码
	 * 判断账号是包含有$或#
	 *
	 * @param userName
	 * @return
	 */
	public static boolean isEmailNO(String userName) {//use
		if (userName.contains("$") || userName.contains("#")
				|| userName.contains("@")) {// 如果是邮箱，返回false
			return false;
		}
		return true;
	}
    /**
     * 是否纯数字
     */
	public static boolean isNumber(String mobile){
		String reg = "^\\d+$";
		return mobile.matches(reg);
	}
	
	
	public static String toString(Integer pushType){
		return pushType != null ? pushType.toString() : null;
	}

}