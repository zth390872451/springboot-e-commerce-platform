package com.umeox.babywei.yingyan;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author JT
 *         <p/>
 *         生成.csv轨迹点文件
 */
public class PointsCsvFileBuilder {

    private static final String[] File_HEAND  = {"longitude", "latitude", "loc_time", "coord_type"};

    private static FileWriter fileWriter = null;
    private static CSVPrinter csvPrinter = null;
    private static CSVFormat csvFormat = CSVFormat.DEFAULT.withRecordSeparator("\n\r");  // 每条记录间隔符

    public static File write(List<YingYanPointBean> points, String pathName) {
        File file = new File(pathName);
        try {
            if (!file.exists()) {
                fileWriter = new FileWriter(pathName, true);  // 创建.csv的字符输出流
                csvPrinter = new CSVPrinter(fileWriter, CSVFormat.DEFAULT);
                csvPrinter.printRecord(File_HEAND );  // 生成.csv表的字段名
            } else {
                fileWriter = new FileWriter(pathName, true);  // 创建.csv的字符输出流
                csvPrinter = new CSVPrinter(fileWriter, csvFormat);
            }
            if (points != null && !points.isEmpty()) {
                for (YingYanPointBean p : points) {
                    List<String> idName = new ArrayList();
                    idName.add(p.getLongitude() + "");
                    idName.add(p.getLatitude() + "");
                    idName.add(p.getLoc_time() + "");
                    idName.add(p.getCoord_type() + "");
                    csvPrinter.printRecord(idName);  // 向.csv文件中添加记录数据
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                csvPrinter.flush();
                fileWriter.flush();
                fileWriter.close();
                csvPrinter.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return file;
    }
}
