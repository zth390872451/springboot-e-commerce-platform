package com.umeox.babywei.thrift.device;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.umeox.babywei.ApplicationSupport;

public class ThriftClient {
	private static final Logger log = LoggerFactory.getLogger(ThriftClient.class);

	
	private static final String SERVER_IP = ApplicationSupport.getParamVal("thrift.device.serverIp");
	private static final int SERVER_PORT = Integer.parseInt(ApplicationSupport.getParamVal("thrift.device.serverPort"));
	private static final String APP_KEY = ApplicationSupport.getParamVal("thrift.device.serverKey");
	private static final int TIMEOUT = 30000;
	
	private static TTransport transport = null;
	
	public static PushService.Client getClient(){
		if (transport == null || !transport.isOpen()) {
			transport = new TFramedTransport(new TSocket(SERVER_IP,SERVER_PORT, TIMEOUT));
			try {
				transport.open();
			} catch (TTransportException e) {
				e.printStackTrace();
			}
		}
		// 协议要和服务端一致
		TProtocol protocol = new TCompactProtocol(transport);
		PushService.Client client = new PushService.Client(protocol);
		return client;
	}
	
	public static AppPayload getDefaultAppPayload(String client,String extCmd){
		AppPayload appPayload = new AppPayload();
		appPayload.setAppkey(APP_KEY);
		appPayload.setTypeId(pushServiceConstants.APP_REQUEST_TYPE_PAYLOAD);
		appPayload.setOfflineMode(OfflineMode.SendAfterOnline.ordinal());
		List<String> clients = new ArrayList<String>();
		clients.add(client);
		appPayload.setClients(clients);
		Map<String,String> ext = new HashMap<String,String>();
		ext.put("syncFlag", extCmd);
		appPayload.setExt(ext);
		return appPayload;
	}
	
	public static AppPayload getDefaultAppPayload(String client,Map<String,String> ext){
		AppPayload appPayload = new AppPayload();
		appPayload.setAppkey(APP_KEY);
		appPayload.setTypeId(pushServiceConstants.APP_REQUEST_TYPE_PAYLOAD);
		appPayload.setOfflineMode(OfflineMode.SendAfterOnline.ordinal());
		List<String> clients = new ArrayList<String>();
		clients.add(client);
		appPayload.setClients(clients);
		appPayload.setExt(ext);
		return appPayload;
	}

	public static AppPayload getDefaultAppPayload(String client,Map<String,String> ext,int offlineMode){
		AppPayload appPayload = new AppPayload();
		appPayload.setAppkey(APP_KEY);
		appPayload.setTypeId(pushServiceConstants.APP_REQUEST_TYPE_PAYLOAD);
		appPayload.setOfflineMode(offlineMode);
		List<String> clients = new ArrayList<String>();
		clients.add(client);
		appPayload.setClients(clients);
		appPayload.setExt(ext);
		return appPayload;
	}
	
	public static void pushNotification(AppPayload appPayload){
		log.info("{}",appPayload);
		try {
			getClient().pushNotification(appPayload);
		} catch (TException e) {
			log.error("与Thrift服务链接异常： {}",e.getMessage());
			transport.close();
		}
	}
	
	/*public static void main(String[] args) {
		for (int i = 0; i < 100; i++) {
			AppPayload appPayload = getDefaultAppPayload("xx");
			appPayload.setBadge(i);
			pushNotification(appPayload);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}*/
}
