package com.umeox.babywei.util;

public class Point{
	private static final double x_pi = 3.14159265358979324 * 3000.0 / 180.0;
	public double lat;
	public double lng;
	
	public Point() {
		super();
	}

	public Point(double lat, double lng) {
		super();
		this.lat = lat;
		this.lng = lng;
	}
	
	public static Point bd_encrypt(Point gg)
	{
	    double x = gg.lng, y = gg.lat;
	    double z = Math.sqrt(x * x + y * y) + 0.00002 * Math.sin(y * x_pi);
	    double theta = Math.atan2(y, x) + 0.000003 * Math.cos(x * x_pi);
	    Point out = new Point(z * Math.sin(theta) + 0.006, z * Math.cos(theta) + 0.0065);
	    return out;
	}

	public static Point bd_decrypt(Point bd)
	{
	    double x = bd.lng - 0.0065, y = bd.lat - 0.006;
	    double z = Math.sqrt(x * x + y * y) - 0.00002 * Math.sin(y * x_pi);
	    double theta = Math.atan2(y, x) - 0.000003 * Math.cos(x * x_pi);
	    return new Point(z * Math.sin(theta), z * Math.cos(theta));
	}
}
