package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @Desc 时间表设置（1.上课禁用时段、2.特别关心时段）
 * @author umeox
 * @version II
 */
@Entity
@Table(name = "ux_holder_schedule")
public class HolderSchedule extends BaseEntity{

	private static final long serialVersionUID = -4979647439024887726L;
	
	public static final Integer SCHEDULE_TYPE_CLASS = 0;
	public static final Integer SCHEDULE_TYPE_CONCERN = 1;
	public static final Integer SCHEDULE_TYPE_SEDENTARY = 2;
	public static final Integer SCHEDULE_TYPE_VOLUME = 3;

	/**
	 * 时间表类型（0：上课禁用时段；1：特别关心时段; 2：久座提醒时段 ;3:音量调节时段 24小时制）
	 */
	private Integer scheduleType;
	
	private Holder holder;
	
	/**
	 * 上午时段（12小时制，例 08:30-11:30）
	 */
	private String amSec;
	
	/**
	 * 下午时段（12小时制，例 01:30-04:30）
	 */
	private String pmSec;
	/**
	 * 晚间时段(18:00-23:30)
	 */
	private String nightSec;
	/**
	 * 重复规则（周日，周一至周六；例1100010：周日、周一、周五计算）
	 */
	private String repeatExpression;
	
	/**
	 * 状态（0：未开启；1：已开启）
	 */
	private Boolean status;
	
	/**
	 *  定位频率（0-4）--注：1：特别关心时段使用
	    0:	1分钟
	 	1:	5分钟,默认值
		2:	10分钟
		3:	30分钟
		4:	60分钟
	 */
	private Integer frequency;

	/*
	*音量大小数值，0代表静音
	*
	*/
	private Integer volumeNum;

	@Column(nullable = false,length = 2)
	public Integer getScheduleType() {
		return scheduleType;
	}

	public void setScheduleType(Integer scheduleType) {
		this.scheduleType = scheduleType;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "holder_id",nullable = false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	@Column(nullable = false)
	public String getAmSec() {
		return amSec;
	}

	public void setAmSec(String amSec) {
		this.amSec = amSec;
	}

	@Column(nullable = false)
	public String getPmSec() {
		return pmSec;
	}

	public void setPmSec(String pmSec) {
		this.pmSec = pmSec;
	}

	@Column(length = 32)
	public String getRepeatExpression() {
		return repeatExpression;
	}

	public void setRepeatExpression(String repeatExpression) {
		this.repeatExpression = repeatExpression;
	}

	@Column(nullable = false)
	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public String getNightSec() {
		return nightSec;
	}

	public void setNightSec(String nightSec) {
		this.nightSec = nightSec;
	}

	public Integer getVolumeNum() {
		return volumeNum;
	}

	public void setVolumeNum(Integer volumeNum) {
		this.volumeNum = volumeNum;
	}
}
