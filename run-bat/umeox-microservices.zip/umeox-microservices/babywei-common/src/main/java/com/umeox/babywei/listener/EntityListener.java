package com.umeox.babywei.listener;

import com.umeox.babywei.domain.BaseEntity;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import java.util.Date;


public class EntityListener
{
  @PrePersist
  public void prePersist(BaseEntity entity)
  {
	if(entity.getCreateDate() == null){
		entity.setCreateDate(new Date());
	}
    if(entity.getModifyDate() == null){
    	entity.setModifyDate(new Date());
    }
  }

  @PreUpdate
  public void preUpdate(BaseEntity entity)
  {
    entity.setModifyDate(new Date());
  }
}