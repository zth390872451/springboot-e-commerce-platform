package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @creator ZTH
 * @modifier ZTH
 * @date 2017-08-21
 */
@Entity
@Table(name = "ux_apns_info")
public class ApnsInfo implements Serializable{
	@Id
	@GeneratedValue
	private Long id;
	//APP的包名
	private String packageName;
	//证书路径
	private String path;
	//证书秘钥
	private String secret;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}
}
