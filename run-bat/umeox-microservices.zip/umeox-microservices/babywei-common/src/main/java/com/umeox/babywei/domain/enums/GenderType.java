package com.umeox.babywei.domain.enums;

public enum GenderType {
	MAN,WOMAN
}
