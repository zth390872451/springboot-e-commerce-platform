package com.umeox.babywei.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * SOS事件
 */
@Entity
@Table(name = "sos_event")
public class SosEvent extends BaseEntity{

	private static final long serialVersionUID = -8558389574024783327L;
	/**
	 * IMEI
	 */
	private String imei;
	/**
	 * 事件编号
	 */
	private String eventCode;
	/**
	 * SOS开始时间
	 */
	private Date dateStart;
	/**
	 * SOS结束时间
	 */
	private Date dateEnd;
	/**
	 * 是否在服务区
	 */
	private boolean isServiceArea;
	/**
	 * 经度
	 */
	private double longitude;
	/**
	 * 纬度
	 */
	private double latitude;
	/**
	 * 地址
	 */
	private String address;
	/**
	 * 精度（单位：米）
	 */
	private int radius;
	/**
	 * 状态(0：开始，1：结束，2:正在处理中)
	 */
	private int status;
	public static final Integer SOS_START = 0;
	public static final Integer SOS_END = 1;
	public static final Integer SOS_PROCESSING = 2;
	
	
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public Date getDateStart() {
		return dateStart;
	}
	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}
	public Date getDateEnd() {
		return dateEnd;
	}
	public void setDateEnd(Date dateEnd) {
		this.dateEnd = dateEnd;
	}
	public boolean isServiceArea() {
		return isServiceArea;
	}
	public void setServiceArea(boolean isServiceArea) {
		this.isServiceArea = isServiceArea;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}
