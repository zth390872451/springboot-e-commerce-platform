package com.umeox.babywei.conf.mail;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component("mailProperties")
@ConfigurationProperties(prefix = "spring.mail")
public class MailProperties {
	
	//默认
    private String host;
    private Integer port;
    private String username;
    private String password;
    private String from;
    private boolean auth;
    private String personal;
    
    //POMO
    private String pomoHost;
    private Integer pomoPort;
    private String pomoUsername;
    private String pomoPassword;
    private String pomoFrom;
    private boolean pomoAuth;
    private String pomoPersonal;
    
   //IRIST
    private String iristHost;
    private Integer iristPort;
    private String iristUsername;
    private String iristPassword;
    private String iristFrom;
    private boolean iristAuth;
    private String iristPersonal;
    
    //海外 doki
    private String dokiHost;
    private Integer dokiPort;
    private String dokiUsername;
    private String dokiPassword;
    private String dokiFrom;
    private boolean dokiAuth;
    private String dokiPersonal;
    
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public Integer getPort() {
		return port;
	}
	public void setPort(Integer port) {
		this.port = port;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public boolean isAuth() {
		return auth;
	}
	public void setAuth(boolean auth) {
		this.auth = auth;
	}
    
	
	
	public String getPomoHost() {
		return pomoHost;
	}
	public void setPomoHost(String pomoHost) {
		this.pomoHost = pomoHost;
	}
	public Integer getPomoPort() {
		return pomoPort;
	}
	public void setPomoPort(Integer pomoPort) {
		this.pomoPort = pomoPort;
	}
	public String getPomoUsername() {
		return pomoUsername;
	}
	public void setPomoUsername(String pomoUsername) {
		this.pomoUsername = pomoUsername;
	}
	public String getPomoPassword() {
		return pomoPassword;
	}
	public void setPomoPassword(String pomoPassword) {
		this.pomoPassword = pomoPassword;
	}
	public String getPomoFrom() {
		return pomoFrom;
	}
	public void setPomoFrom(String pomoFrom) {
		this.pomoFrom = pomoFrom;
	}
	public boolean isPomoAuth() {
		return pomoAuth;
	}
	public void setPomoAuth(boolean pomoAuth) {
		this.pomoAuth = pomoAuth;
	}
	public String getPersonal() {
		return personal;
	}
	public void setPersonal(String personal) {
		this.personal = personal;
	}
	public String getPomoPersonal() {
		return pomoPersonal;
	}
	public void setPomoPersonal(String pomoPersonal) {
		this.pomoPersonal = pomoPersonal;
	}
	public String getIristHost() {
		return iristHost;
	}
	public void setIristHost(String iristHost) {
		this.iristHost = iristHost;
	}
	public Integer getIristPort() {
		return iristPort;
	}
	public void setIristPort(Integer iristPort) {
		this.iristPort = iristPort;
	}
	public String getIristUsername() {
		return iristUsername;
	}
	public void setIristUsername(String iristUsername) {
		this.iristUsername = iristUsername;
	}
	public String getIristPassword() {
		return iristPassword;
	}
	public void setIristPassword(String iristPassword) {
		this.iristPassword = iristPassword;
	}
	public String getIristFrom() {
		return iristFrom;
	}
	public void setIristFrom(String iristFrom) {
		this.iristFrom = iristFrom;
	}
	public boolean isIristAuth() {
		return iristAuth;
	}
	public void setIristAuth(boolean iristAuth) {
		this.iristAuth = iristAuth;
	}
	public String getIristPersonal() {
		return iristPersonal;
	}
	public void setIristPersonal(String iristPersonal) {
		this.iristPersonal = iristPersonal;
	}
	public String getDokiHost() {
		return dokiHost;
	}
	public void setDokiHost(String dokiHost) {
		this.dokiHost = dokiHost;
	}
	public Integer getDokiPort() {
		return dokiPort;
	}
	public void setDokiPort(Integer dokiPort) {
		this.dokiPort = dokiPort;
	}
	public String getDokiUsername() {
		return dokiUsername;
	}
	public void setDokiUsername(String dokiUsername) {
		this.dokiUsername = dokiUsername;
	}
	public String getDokiPassword() {
		return dokiPassword;
	}
	public void setDokiPassword(String dokiPassword) {
		this.dokiPassword = dokiPassword;
	}
	public String getDokiFrom() {
		return dokiFrom;
	}
	public void setDokiFrom(String dokiFrom) {
		this.dokiFrom = dokiFrom;
	}
	public boolean isDokiAuth() {
		return dokiAuth;
	}
	public void setDokiAuth(boolean dokiAuth) {
		this.dokiAuth = dokiAuth;
	}
	public String getDokiPersonal() {
		return dokiPersonal;
	}
	public void setDokiPersonal(String dokiPersonal) {
		this.dokiPersonal = dokiPersonal;
	}
	
	
	
	
	/*@PostConstruct
    private void checkConfiguration() {
        if (StringUtils.isEmpty(host) || StringUtils.isEmpty(password) || StringUtils.isEmpty(username))
            throw new NullPointerException("Configuration Setting Incomplete, Please provide spring.mail.host,spring.mail.username,spring.mail.password in Configuration Properties");
    }*/
}
