package com.umeox.babywei.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.springframework.util.StringUtils;

public class RedisUtils {

	/**
	 * 时间戳根据时区转换成日期
	 */
	public static Date timestampToDate(String token,Long timestamp){
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		//TODO 根据token获取用户认证时保存的时区
		if (StringUtils.isEmpty(token)) {
			String timeZodeId = "";
			TimeZone timeZone = TimeZone.getTimeZone(timeZodeId);
			format.setTimeZone(timeZone);
		}
		String str = format.format(timestamp);
		try {
			return format.parse(str);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return new Date();
	}
}
