package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.umeox.babywei.domain.enums.AppType;

@Entity
@Table(name = "sys_app_version")
public class AppVersion {
	private Long id;
	
	/**
	 * 客户端ID
	 */
	private String clientId;
	
	/**
	 * App类型
	 */
	private AppType type;
	
	/**
	 * App版本
	 */
	private Double appVersion;
	
	/**
	 * 是否强制更新
	 */
	private Boolean forcedUpdate;
	
	/**
	 * 更新类容
	 */
	private String content;
	
	/**
	 * 下载地址
	 */
	private String download;
	/**
	 * 版本名称
	 */
	private String versionName;
	/**
	 * 文件大小
	 */
	private String size;

	public String getVersionName() {
		return versionName;
	}

	public void setVersionName(String versionName) {
		this.versionName = versionName;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public AppType getType() {
		return type;
	}

	public void setType(AppType type) {
		this.type = type;
	}


	public Double getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(Double appVersion) {
		this.appVersion = appVersion;
	}

	public Boolean getForcedUpdate() {
		return forcedUpdate;
	}

	public void setForcedUpdate(Boolean forcedUpdate) {
		this.forcedUpdate = forcedUpdate;
	}

	public String getDownload() {
		return download;
	}

	public void setDownload(String download) {
		this.download = download;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
