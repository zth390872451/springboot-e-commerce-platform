package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

//社区
@Entity
@Table(name = "community")
public class Community extends BaseEntity{

	private static final long serialVersionUID = -6288048309472813835L;
	
	/**
	 * 社区名称
	 */
	private String name;
	/**
	 * 对应的渠道编码
	 */
	private String saleChannel;
	/**
	 * 社区经度
	 */
	private double longitude;
	/**
	 * 社区纬度
	 */
	private double latitude;
	/**
	 * 社区半径范围（单位：米）
	 */
	private int radius;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSaleChannel() {
		return saleChannel;
	}
	public void setSaleChannel(String saleChannel) {
		this.saleChannel = saleChannel;
	}
	public double getLongitude() {
		return longitude;
	}
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}
	public double getLatitude() {
		return latitude;
	}
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	
}
