package com.umeox.babywei.domain;

import javax.persistence.*;


/**
 * 系统消息
 * @author Yan
 *
 */
@Entity
@Table(name = "ux_message")
public class Message extends BaseEntity {

	private static final long serialVersionUID = -3249914150921383554L;
	/**
	 * 会员
	 */
	private Member member;
	
	private Member admin;
	
	/**
	 * 会员
	 */
	private Holder holder;
	
	/**
	 * 消息类型 
	 * 4：请求绑定提醒
	 * 5：关注邀请
	 */
	private int type;
	
	
	/**
	 * 附加信息
	 */
	private String remark;
	
	/**
	 * 默认状态0未处理; 1 已同意或者已接受; -1 已拒绝忽略
	 */
	private Integer state;

	/**
	 * 安全区域
	 */
	private Barrier barrier;
	/**
	 * 发送消息
	 */
	private String msg;


	public int getType() {
		return type;
	}


	public void setType(int type) {
		this.type = type;
	}


	public String getRemark() {
		return remark;
	}


	public void setRemark(String remark) {
		this.remark = remark;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="barrier_id")
	public Barrier getBarrier() {
		return barrier;
	}


	public void setBarrier(Barrier barrier) {
		this.barrier = barrier;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="member_id")
	public Member getMember() {
		return member;
	}


	public void setMember(Member member) {
		this.member = member;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id")
	public Holder getHolder() {
		return holder;
	}


	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="admin_id")
	public Member getAdmin() {
		return admin;
	}


	public void setAdmin(Member admin) {
		this.admin = admin;
	}


	public Integer getState() {
		return state;
	}


	public void setState(Integer state) {
		this.state = state;
	}
	
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}


	@PrePersist
	public void prePersist(){
		if(this.getState()==null)
			this.setState(0);
    }
}
