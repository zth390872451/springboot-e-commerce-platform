package com.umeox.babywei.domain;

import javax.persistence.*;


/**
 * Entity - 监护列表
 * 
 * @author Yan
 */
@Entity
@Table(name = "ux_monitor")
public class Monitor extends BaseEntity {
	private static final long serialVersionUID = -6193780032824662688L;

	/**
	 * 手机端会员
	 */
	private Member member;

	/**
	 * 设备持有人
	 */
	private Holder holder;

	/**
	 * 是否为主监护人
	 */
	private Boolean isAdmin = false;

	/**
	 * 与设备持有人的关系
	 */
	private String relation;
	
	/**
	 * 监护状态 True表示为正常, false表示解除关系
	 */
	private Boolean status = false;

	private String deviceType;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(nullable=false)
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id",nullable=false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	@PrePersist
    public void prePersist() {
		if(this.getRelation()==null){
			this.setRelation("4");//初始化关系为关注者
		}
    }
}
