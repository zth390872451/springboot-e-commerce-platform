package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Deprecated
@Entity
@Table(name = "ux_yzx_client")
public class YzxClient extends BaseEntity {

	private static final long serialVersionUID = 2672835408990399187L;
	public static final Integer member_type = 0;
	public static final Integer device_type = 1;

	/**
	 * Client号码
	 */
	private String clientNumber;

	/**
	 * Client密码
	 */
	private String clientPwd;
	
	/**
	 * 类型(0:app用户,1:设备)
	 */
	private Integer type;

	/**
	 * 会员账号|设备IMEI
	 */
	private String account;

	public String getClientNumber() {
		return clientNumber;
	}

	public void setClientNumber(String clientNumber) {
		this.clientNumber = clientNumber;
	}

	public String getClientPwd() {
		return clientPwd;
	}

	public void setClientPwd(String clientPwd) {
		this.clientPwd = clientPwd;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

}
