package com.umeox.babywei.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SessionUtil {
	private List list;
	private StringDeflatUtil util;

	public SessionUtil() {
		util = new StringDeflatUtil(true);
		list = new ArrayList();
	}

	/**
	 * 返回数据 例如：001,357409039055233,1.0,10000，u_sk_verifi，**，1,15845687452\r\n
	 */
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			if (i == list.size() - 1) {
				sb.append(list.get(i));
			} else
				sb.append(list.get(i)).append(",");
		}

		return sb.toString();
	}

	public boolean addValue(String value) {
		return list.add(value);
	}

	/**
	 * 产生随机字符串
	 * */
	private static Random randGen = null;
	private static char[] numbersAndLetters = null;

	public static final String randomString(int length) {
		if (length < 1) {
			return null;
		}
		if (randGen == null) {
			randGen = new Random();
			numbersAndLetters = ("0123456789" + "0123456789").toCharArray();
		}
		char[] randBuffer = new char[length];
		for (int i = 0; i < randBuffer.length; i++) {
			randBuffer[i] = numbersAndLetters[randGen.nextInt(7)];
			// randBuffer[i] = numbersAndLetters[randGen.nextInt(35)];
		}
		return new String(randBuffer);
	}

	/*public static void main(String[] args) {
		// SessionUtil deliversession =new SessionUtil();
		// deliversession.addValue("001");
		// deliversession.addValue("357409039055233");
		// deliversession.addValue("1.0");
		// String sendMsgStr = deliversession.toString();
		// System.out.print(sendMsgStr);
		// String rstr =
		// "001,0123456789,1.0,10000,u_sk_login,**,1,1,192.168.1.1,80\r\n";
		// System.out.print(rstr);
		
	}*/
}