package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 *	关于
 */
@Entity
@Table(name = "ux_holder_wallpaper")
public class HolderWallpaper extends BaseEntity{

	private static final long serialVersionUID = -756752868627526511L;
	/**
	 * 关联设备持有者，一对一关联
	 */
	private Holder holder;
	/**
	 * 桌面壁纸URL
	 */
	private String wallpaperUrl;

	@OneToOne
	@JoinColumn(name = "holder_id",nullable = true)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}


	public String getWallpaperUrl() {
		return wallpaperUrl;
	}

	public void setWallpaperUrl(String wallpaperUrl) {
		this.wallpaperUrl = wallpaperUrl;
	}

	@Override
	public String toString() {
		return "HolderWallpaper{" +
				"holder=" + holder +
				", wallpaperUrl='" + wallpaperUrl + '\'' +
				'}';
	}
}
