package com.umeox.babywei.util;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.PushService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import static com.umeox.babywei.domain.Member.FCM_PUSH;

/**
 * 推送工具类
 * 国内安卓：华为小米推送
 * 国外安卓：谷歌旗下的FCM推送
 */
public class PushUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(PushUtils.class);

	//默认标题 国内
	public static final String DEFAULT_TITLE_ZH = "温馨提示";
	//默认标题 国外
	public static final String DEFAULT_TITLE_EN = "Reminder";

	public static final String DEFAULT_DESCRIPTION = " ";

	public static final String PREFIX = "FCM_";

	public static final String SUFIFX_ANDROID = "_ANDROID";

	public static final String SUFIFX_IOS = "_IOS";

	//台湾的funpark 的APP
	public static final String FUNPARK_PACKAGE = "com.wherecom.funparkwatch";
	/**
	 * 国内的安卓极光推送的同时，进行小米或者华为的推送
	 *
	 * @param alias
	 * @param title
	 * @param msgContent
	 * @param description
	 * @param extras
	 */
	public static void pushToApp(String alias, String title, String msgContent, String description, Map<String, String> extras) {
		if (ApplicationSupport.isChinaEnv() && StringToolUtil.isMobileNO(alias)) {
			MemberRepository memberRepository = (MemberRepository) ApplicationSupport.getBean("memberRepository");
			Member member = null;
			member = memberRepository.findOneByMobile(alias);//jpa的实现
			if (member != null && !StringUtils.isEmpty(member.getLoginInfo())) {
				String loginInfo = member.getLoginInfo();
				String[] infos = loginInfo.split(":");
				title = StringUtils.isEmpty(title) ? DEFAULT_TITLE_ZH : title;
				description = StringUtils.isEmpty(description) ? DEFAULT_DESCRIPTION : description;
				if (loginInfo.contains("xiaomi:")) {
					if (infos.length == 3) {
						XiaoMiUtil.sendMsg(infos[1], new ArrayList<String>(Arrays.asList(infos[2])), title, description, msgContent, extras, XiaoMiUtil.Notification_Type);
					}
				} else if (loginInfo.contains("huawei:")) {
					if (infos.length == 3) {
						HuaWeiUtil.notification_send(infos[1], infos[2], title, msgContent, extras);
					}
				}
			}
		}
	}


	/**
	 * 国外的的定制APP，某些版本[有fcmPush标记的]使用FCM推送
	 * FCM主题订阅发布推送不区分 平台是Android还是iOS
	 *
	 * @param title      推送标题
	 * @param alias      别名(将转换为主题)
	 * @param msgContent 通知内容
	 * @param extras     自定义消息体
	 * @return 是否使用FCM推送 true:是 false：不是
	 */
	public static boolean fcmPush(String title, String alias, String msgContent, Map<String, String> extras, Long timeToLive) {
		if (ApplicationSupport.isAmazonEnv()) {
			MemberRepository memberRepository = (MemberRepository) ApplicationSupport.getBean("memberRepository");
			Member member = memberRepository.findOneByMobile(alias);
			if (member!=null && !StringUtils.isEmpty(member.getPackageName()) && FCM_PUSH.equals(member.getPushMode())) {
				PushService pushService = (PushService) ApplicationSupport.getBean("pushServiceImpl");
				if (FUNPARK_PACKAGE.contains(member.getPackageName())){
					String subject = PREFIX + member.getId();
					pushService.sendNoticeAndMsg(member.getPackageName(), subject, title, msgContent, extras, timeToLive);
				}else {
					String subjectAndroid = PREFIX + member.getId() + SUFIFX_ANDROID;
					//Android只发自定义消息(将通知的内容放入自定义消息中)
					pushService.sendMsg(member.getPackageName(), subjectAndroid, title, msgContent, extras, timeToLive);
					String subjectIos = PREFIX + member.getId() + SUFIFX_IOS;
					//IOS发自定义消息和通知
					pushService.sendNoticeAndMsg(member.getPackageName(), subjectIos, title, msgContent, extras, timeToLive);
				}
				return true;
			}
		}
		return false;
	}



}
