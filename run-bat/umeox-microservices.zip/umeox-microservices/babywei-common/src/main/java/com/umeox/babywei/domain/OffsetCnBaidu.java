package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("serial")
@Entity
@Table(name = "ux_offset_cn_baidu")
public class OffsetCnBaidu {
	/** ID */
	private Long id;
	
	private Double lat;
	private Double lon;
	private Double offsetLat;
	private Double offsetLon;
	
	@JsonProperty
	//@DocumentId
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	/**
	 * 设置ID
	 * 
	 * @param id
	 *            ID
	 */
	public void setId(Long id) {
		this.id = id;
	}
	@Index(name="UX_OFFSET_CN_BAIDU_INDEX_LAT")
	public Double getLat() {
		return lat;
	}

	public void setLat(Double lat) {
		this.lat = lat;
	}
	@Index(name="UX_OFFSET_CN_BAIDU_INDEX_LON")
	public Double getLon() {
		return lon;
	}

	public void setLon(Double lon) {
		this.lon = lon;
	}
    @Column(name="offsetlat")
	public Double getOffsetLat() {
		return offsetLat;
	}

	public void setOffsetLat(Double offsetLat) {
		this.offsetLat = offsetLat;
	}
	 @Column(name="offsetlon")
	public Double getOffsetLon() {
		return offsetLon;
	}

	public void setOffsetLon(Double offsetLon) {
		this.offsetLon = offsetLon;
	}

	
	
}
