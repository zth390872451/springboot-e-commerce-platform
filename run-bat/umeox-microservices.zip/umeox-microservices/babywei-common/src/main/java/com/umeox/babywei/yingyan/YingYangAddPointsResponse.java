package com.umeox.babywei.yingyan;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * @author JT
 *
 *  批量添加轨迹点返回
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class YingYangAddPointsResponse extends YingYanStatusResponse {

    //提交任务过程耗时,单位：秒
    private Integer time;

    //成功上传数量
    private Integer total;

    //上传失败的轨迹点列表
    private List<YingYanPointBean> error_tracks;

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public List<YingYanPointBean> getError_tracks() {
        return error_tracks;
    }

    public void setError_tracks(List<YingYanPointBean> error_tracks) {
        this.error_tracks = error_tracks;
    }
}
