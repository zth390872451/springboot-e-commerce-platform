package com.umeox.babywei.domain;

import javax.persistence.*;

@Entity
@Table(name = "ux_holder_class_schedule")
public class HolderClassSchedule extends BaseEntity {
	private static final long serialVersionUID = -2158109459123036967L;
	//可设置的课程列表
	public static String[] courseList = {"语文","数学","英语","音乐","体育"};
	private Holder holder;
	//w1-w5代表周一到周五的每天八节课的课程名称
	private String w1;
	private String w2;
	private String w3;
	private String w4;
	private String w5;

	public HolderClassSchedule() {

	}

	public HolderClassSchedule(Holder holder, String w1, String w2, String w3, String w4, String w5) {
		this.holder = holder;
		this.w1 = w1;
		this.w2 = w2;
		this.w3 = w3;
		this.w4 = w4;
		this.w5 = w5;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id",nullable=false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public String getW1() {
		return w1;
	}

	public void setW1(String w1) {
		this.w1 = w1;
	}

	public String getW2() {
		return w2;
	}

	public void setW2(String w2) {
		this.w2 = w2;
	}

	public String getW3() {
		return w3;
	}

	public void setW3(String w3) {
		this.w3 = w3;
	}

	public String getW4() {
		return w4;
	}

	public void setW4(String w4) {
		this.w4 = w4;
	}

	public String getW5() {
		return w5;
	}

	public void setW5(String w5) {
		this.w5 = w5;
	}

}