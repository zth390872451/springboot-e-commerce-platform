/**
 * 
 */
package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.umeox.babywei.domain.enums.StatusType;

/**
 * @author xmc
 */
@Entity
@Table(name = "ux_device_code_log")
public class DeviceCodeLog extends BaseEntity{

	private static final long serialVersionUID = 3117807993380766846L;

	/**
	 * 批号
	 */
	private String lot;
	
	/**
	 * 导入描述
	 */
	private String des;
	
	/**
	 * 导入状态
	 */
	private StatusType status;
	
	/**
	 * 导入失败原因
	 */
	private String failCause;

	
	@Column(name = "lot", nullable = false, unique = true)
	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getDes() {
		return des;
	}

	public void setDes(String des) {
		this.des = des;
	}

	public StatusType getStatus() {
		return status;
	}

	public void setStatus(StatusType status) {
		this.status = status;
	}

	public String getFailCause() {
		return failCause;
	}

	public void setFailCause(String failCause) {
		this.failCause = failCause;
	}
	
}
