package com.umeox.babywei.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * 事件处理记录
 */
@Entity
@Table(name = "sos_event_process")
public class SosEventProcess extends BaseEntity{
	
	private static final long serialVersionUID = -840094304313203647L;
	
	private SosEvent sosEvent;
	/**
	 * 处理类型（0：设备端；1：App端；2：Web端）
	 * 注：设备发生SOS，需检查是否有异常未关闭的SOS
	 */
	private int processType;
	
	/**
	 * 处理者账号（设备imei；关注者账号；监控中心账号）
	 */
	private String processAccount;
	
	/**
	 * 处理者名字（冗余设计）
	 */
	private String processName;
	
	/**
	 * 处理时间
	 */
	private Date processDate;
	
	/**
	 * 处理概述
	 */
	private String processDesc;
	
	/**
	 * sos状态
	 */
	private int sosStatus;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sos_event_id")
	public SosEvent getSosEvent() {
		return sosEvent;
	}

	public void setSosEvent(SosEvent sosEvent) {
		this.sosEvent = sosEvent;
	}

	public int getProcessType() {
		return processType;
	}

	public void setProcessType(int processType) {
		this.processType = processType;
	}

	public String getProcessAccount() {
		return processAccount;
	}

	public void setProcessAccount(String processAccount) {
		this.processAccount = processAccount;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public Date getProcessDate() {
		return processDate;
	}

	public void setProcessDate(Date processDate) {
		this.processDate = processDate;
	}

	public String getProcessDesc() {
		return processDesc;
	}

	public void setProcessDesc(String processDesc) {
		this.processDesc = processDesc;
	}

	public int getSosStatus() {
		return sosStatus;
	}

	public void setSosStatus(int sosStatus) {
		this.sosStatus = sosStatus;
	}
	
}
