package com.umeox.babywei.util;

import com.aliyun.oss.OSSClient;
import com.aliyun.oss.common.utils.BinaryUtil;
import com.aliyun.oss.model.PolicyConditions;
import com.amazonaws.util.BinaryUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.sql.Date;
import java.util.*;

/**
 * @author JT
 */
public class CloudServiceHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(CloudServiceHelper.class);

    //Aliyun OSS Setting
    public static final String ALIYUN_OSS_ACCESS_ID = "LTAIK9CPEimWgdpM";
    public static final String ALIYUN_OSS_ACCESS_KEY = "aoJWHR51c23L0Me1iNR129JZ9aQLFy";
    public static final String ALIYUN_OSS_BUCKET = "wxb01";
    public static final String ALIYUN_OSS_REGION = "cn-hangzhou";
    public static final String ALIYUN_OSS_DOMAIN = "oss-" + ALIYUN_OSS_REGION + ".aliyuncs.com";

    //AWS S3 Setting
    public static final String AWS_S3_ACCESS_ID = "AKIAJQVSAGFNUHHT757A";
    public static final String AWS_S3_ACCESS_KEY = "U25esIOWlHwnJj2/krKUvHDeKIhjXt7vKdc9yhvY";
    public static final String AWS_S3_BUCKET = "wherecom-ireland";
    public static final String AWS_S3_REGION = "eu-west-1";
    public static final String AWS_S3_DOMAIN = "s3-" + AWS_S3_REGION + ".amazonaws.com";


    public static final long EXPIRE_TIME = 60 * 60 * 24 * 5; //单位秒，AWS最大7天失效，Aliyun没有限制时间

    public static final long CACHE_TIME = (long) (EXPIRE_TIME * 0.9) * 1000; //缓存失效时间,单位毫秒

    private static Map<String, String> ossSignatureInstance;
    private static Map<String, String> s3SignatureInstance;

    public static Map<String, String> getOssSignatureInstance() {
        if (ossSignatureInstance == null || Long.parseLong(ossSignatureInstance.get("time")) + CACHE_TIME < System.currentTimeMillis()) {
            if(ossSignatureInstance != null){
                LOGGER.info("生成OSS文件上传签名，缓存失效时间：{}，当前时间：{}",Long.parseLong(ossSignatureInstance.get("time")) + CACHE_TIME , System.currentTimeMillis());
            }else{
                LOGGER.info("首次获取OSS文件上传签名，当前时间：{}", System.currentTimeMillis());
            }
            Map<String, String> map = generateOssPostObjectPolicy(ALIYUN_OSS_ACCESS_ID, ALIYUN_OSS_ACCESS_KEY, ALIYUN_OSS_BUCKET, ALIYUN_OSS_DOMAIN, EXPIRE_TIME);
            ossSignatureInstance = new HashMap(map);
        }
        return ossSignatureInstance;
    }

    public static Map<String, String> getS3SignatureInstance() { 
        if (s3SignatureInstance == null || Long.parseLong(s3SignatureInstance.get("time")) + CACHE_TIME < System.currentTimeMillis()) {
            if(s3SignatureInstance != null){
                LOGGER.info("生成S3文件上传签名，缓存失效时间：{}，当前时间：{}",Long.parseLong(s3SignatureInstance.get("time")) + CACHE_TIME , System.currentTimeMillis());
            }else{
                LOGGER.info("首次获取S3文件上传签名，当前时间：{}", System.currentTimeMillis());
            }
            Map<String, String> map = generateS3PostObjectPolicy(AWS_S3_ACCESS_ID, AWS_S3_ACCESS_KEY, AWS_S3_BUCKET, AWS_S3_DOMAIN, EXPIRE_TIME, AWS_S3_REGION);
            s3SignatureInstance = new HashMap(map);
        }
        return s3SignatureInstance;
    }


    /**
     * *
     *
     * @param accessId   用户请求的accessid
     * @param accessKey  用户请求的accessKey
     * @param bucket     存储空间
     * @param endpoint   OSS 对外服务的访问域名
     * @param expireTime 过期时间（秒）
     * @return
     */
    public static synchronized Map<String, String> generateOssPostObjectPolicy(String accessId, String accessKey, String bucket, String endpoint, long expireTime) {
        Map<String, String> respMap = new LinkedHashMap<String, String>();
        OSSClient client = new OSSClient(endpoint, accessId, accessKey);
        try {
            long expireEndTime = System.currentTimeMillis() + expireTime * 1000;
            Date expiration = new Date(expireEndTime);
            PolicyConditions policyConds = new PolicyConditions();
            policyConds.addConditionItem(PolicyConditions.COND_CONTENT_LENGTH_RANGE, 0, 1048576000);
            //policyConds.addConditionItem(MatchMode.StartWith, PolicyConditions.COND_KEY, dir);

            String postPolicy = client.generatePostPolicy(expiration, policyConds);
            byte[] binaryData = postPolicy.getBytes("utf-8");
            String encodedPolicy = BinaryUtil.toBase64String(binaryData);
            String postSignature = client.calculatePostSignature(postPolicy);


            respMap.put("accessId", accessId);
            respMap.put("host", bucket + "." + endpoint);
            respMap.put("port", "80");
            respMap.put("uri", "/");
            respMap.put("policy", encodedPolicy);
            respMap.put("signature", postSignature);
            respMap.put("acl", "");
            respMap.put("credential", "");
            respMap.put("algorithm", "");
            respMap.put("date", "");
            respMap.put("time", System.currentTimeMillis() + ""); //缓存计算时间
            //respMap.put("expire", formatISO8601Date(expiration));
            //respMap.put("dir", dir);          
            //JSONObject ja1 = JSONObject.fromObject(respMap);            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return respMap;
    }


    public static synchronized Map<String, String> generateS3PostObjectPolicy(String accessId, String accessKey, String bucket, String endpoint, long expireTime, String region) {
        Map<String, String> respMap = new LinkedHashMap<String, String>();
        try {   
            final String UTC_YYYYMMDD = getUTCTimeStr(null, "yyyyMMdd");
            final String UTC_AMAZE_DATE = getUTCTimeStr(null, "yyyyMMddTHHmmssZ");
            Calendar calendar = Calendar.getInstance();
            calendar.add(calendar.SECOND,(int)expireTime);
            final String UTC_EXPIRE = getUTCTimeStr(calendar, "yyyy-MM-ddTHH:mm:ss.000Z");
            
            List conditionsList = new ArrayList();
            Map bucketMap = new HashMap();
            bucketMap.put("bucket", bucket); //bucket name
            Map acl = new HashMap();
            acl.put("acl", "public-read");
            Map credential = new HashMap();
            credential.put("x-amz-credential", accessId + "/" + UTC_YYYYMMDD + "/" + region + "/s3/aws4_request");
            Map algorithm = new HashMap();
            algorithm.put("x-amz-algorithm", "AWS4-HMAC-SHA256");
            Map successActionStatus = new HashMap();
            successActionStatus.put("success_action_status", "200");

            Map date = new HashMap();
            date.put("x-amz-date", UTC_AMAZE_DATE);
            List keyRules = new ArrayList();
            keyRules.add("starts-with");
            keyRules.add("$key");
            keyRules.add("");

            conditionsList.add(bucketMap);
            conditionsList.add(acl);
            conditionsList.add(credential);
            conditionsList.add(algorithm);
            conditionsList.add(date);
            conditionsList.add(successActionStatus);
            conditionsList.add(keyRules);

            Map policyMap = new HashMap();
            policyMap.put("expiration", UTC_EXPIRE);
            policyMap.put("conditions", conditionsList);

            System.out.println("Policy:     " + JsonUtils.toJson(policyMap));
            //转换UTF-8编码的policy 为 Base64编码
            //可使用在线工具：在线工具：https://www.base64encode.org/
            String stringToSign = Base64.encodeBytes(JsonUtils.toJson(policyMap).getBytes());
            System.out.println("Policy Base64:     " + stringToSign);

            //模似siger.newSigningKey方法生成signing key
            //以下参数同policy x-amz-credential
            //AccessKeySecret对应AccessKeyID
            String dateStamp = UTC_YYYYMMDD;  //同 x-amz-credential
            String regionName = region; //同 x-amz-credential
            String serviceName = "s3";       //同 x-amz-credential
            byte[] signingKey = getSignatureKey(accessKey, dateStamp, regionName, serviceName);
            String xAmzSignature = BinaryUtils.toHex(computeSignature(stringToSign, signingKey));

            respMap.put("accessId", accessId);
            respMap.put("host", endpoint);
            respMap.put("port", "80");
            respMap.put("uri", "/" + bucket);
            respMap.put("policy", stringToSign);
            respMap.put("signature", xAmzSignature);
            respMap.put("acl", "public-read");
            respMap.put("credential", accessId + "/"+UTC_YYYYMMDD+"/" + region + "/s3/aws4_request");
            respMap.put("algorithm", "AWS4-HMAC-SHA256");
            respMap.put("date", UTC_AMAZE_DATE);
            respMap.put("time", System.currentTimeMillis() + "");
            //respMap.put("expire", formatISO8601Date(expiration));
            //respMap.put("dir", dir);          
            //JSONObject ja1 = JSONObject.fromObject(respMap);            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return respMap;
    }
    
    public static byte[] HmacSHA256(String data, byte[] key) throws Exception {
        String algorithm = "HmacSHA256";
        Mac mac = Mac.getInstance(algorithm);
        mac.init(new SecretKeySpec(key, algorithm));
        return mac.doFinal(data.getBytes("UTF8"));
    }
    
    public static byte[] getSignatureKey(String key, String dateStamp, String regionName, String serviceName) throws Exception {
        byte[] kSecret = ("AWS4" + key).getBytes("UTF8");
        byte[] kDate = HmacSHA256(dateStamp, kSecret);
        byte[] kRegion = HmacSHA256(regionName, kDate);
        byte[] kService = HmacSHA256(serviceName, kRegion);
        byte[] kSigning = HmacSHA256("aws4_request", kService);
        return kSigning;
    }
    
    protected static final byte[] computeSignature(String stringToSign,
                                                   byte[] signingKey) throws Exception {
        return HmacSHA256(stringToSign, signingKey);
    }
    
    private static String getUTCTimeStr(Calendar calendar, String pattern) {
        Assert.notNull(pattern, "pattern 不能为空");
        if (calendar == null) {
            calendar = Calendar.getInstance();
        }
        // 2、取得时间偏移量：
        int zoneOffset = calendar.get(java.util.Calendar.ZONE_OFFSET);
        // 3、取得夏令时差：
        int dstOffset = calendar.get(java.util.Calendar.DST_OFFSET);
        // 4、从本地时间里扣除这些差量，即可以取得UTC时间：
        calendar.add(java.util.Calendar.MILLISECOND, -(zoneOffset + dstOffset));
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        String parseDate = pattern;

        if (parseDate.contains("yyyy")) {
            parseDate = parseDate.replace("yyyy", year + "");
        }

        if (parseDate.contains("MM")) {
            parseDate = parseDate.replace("MM", String.format("%02d", month));
        }

        if (parseDate.contains("dd")) {
            parseDate = parseDate.replace("dd", String.format("%02d", day));
        }

        if (parseDate.contains("HH")) {
            parseDate = parseDate.replace("HH", String.format("%02d", hour));
        }

        if (parseDate.contains("mm")) {
            parseDate = parseDate.replace("mm", String.format("%02d", minute));
        }

        if (parseDate.contains("ss")) {
            parseDate = parseDate.replace("ss", String.format("%02d", second));
        }
        return parseDate;
    }

   /* public static void main(String[] args) {
        System.out.println( generateS3PostObjectPolicy(AWS_S3_ACCESS_ID, AWS_S3_ACCESS_KEY, AWS_S3_BUCKET, AWS_S3_DOMAIN, EXPIRE_TIME, AWS_S3_REGION));
       // System.out.println(generateOssPostObjectPolicy(ALIYUN_OSS_ACCESS_ID, ALIYUN_OSS_ACCESS_KEY, ALIYUN_OSS_BUCKET, ALIYUN_OSS_DOMAIN, EXPIRE_TIME));
        //2017-04-25T00:00:00.000Z
      *//*  System.out.println(getUTCTimeStr(null, "yyyy-MM-ddTHH:mm:ss.000Z"));
        //20170420
        System.out.println(getUTCTimeStr(null, "yyyyMMdd"));
        //20170420T000000Z
        System.out.println(getUTCTimeStr(null, "yyyyMMddTHHmmssZ"));*//*

    }*/
}
