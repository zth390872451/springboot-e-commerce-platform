package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "push_client")
public class PushClient {
	
	private Long id;
	//对应的数据库的表字段 client_id　只是一个key,暂时无用
	private String clientId;
	//设备类型
	private String deviceType;
	//渠道编码
	private String saleChannel;
	//推送用的key 相当于用户名
	private String pushKey;
	//推送用的secret 相当于密码
	private String pushSecret;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getPushKey() {
		return pushKey;
	}

	public void setPushKey(String pushKey) {
		this.pushKey = pushKey;
	}

	public String getPushSecret() {
		return pushSecret;
	}

	public void setPushSecret(String pushSecret) {
		this.pushSecret = pushSecret;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getSaleChannel() {
		return saleChannel;
	}

	public void setSaleChannel(String saleChannel) {
		this.saleChannel = saleChannel;
	}
	
}
