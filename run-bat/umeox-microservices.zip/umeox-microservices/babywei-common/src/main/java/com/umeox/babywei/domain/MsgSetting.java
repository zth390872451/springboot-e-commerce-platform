package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;


@Entity
@Table(name = "ux_msg_setting")
public class MsgSetting  extends BaseEntity{
	private static final long serialVersionUID = 4772784121614416977L;
	/*这个跟socket通讯有关的，就是一个标识？但是暂时不知道 为嘛放这儿。zth
	正常状态	01
	追踪状态	02
	围栏状态	03
	SOS状态，	
	设置白名单	04
	设置sos号码	05
	设置上报策略	06
	设置录音策略	07
	设置服务器地址	08
	设置时间段停止上报	09
	睡眠状态	10
	*/
	private String whiteList;//白名单 1:已处理 0：未处理  ---未使用
	private String sosNumber;//1:已处理 0：未处理
	private String reportingStrategy;//上报策略 1:已处理 0：未处理
	private String recordingStrategy;//录音策略 1:已处理 0：未处理
	private String serverAddress;//服务器地址 1:已处理 0：未处理
	private String stopReportingTime;//设置时间段停止上报 1:已处理 0：未处理
	private String sleepStrategy;//睡眠状态 1:已处理 0：未处理
	private String audioProfiles;//设置手表状态 1：已处理 0：未处理
	private String answerMode;// 接听方式 0:自动接听，1：单按SOS接听
	/**
	 * 持有者
	 */
	private Holder holder;

	
	private Long holderId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id",nullable=false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public String getWhiteList() {
		return whiteList;
	}

	public void setWhiteList(String whiteList) {
		this.whiteList = whiteList;
	}

	public String getSosNumber() {
		return sosNumber;
	}

	public void setSosNumber(String sosNumber) {
		this.sosNumber = sosNumber;
	}

	public String getReportingStrategy() {
		return reportingStrategy;
	}

	public void setReportingStrategy(String reportingStrategy) {
		this.reportingStrategy = reportingStrategy;
	}

	public String getRecordingStrategy() {
		return recordingStrategy;
	}

	public void setRecordingStrategy(String recordingStrategy) {
		this.recordingStrategy = recordingStrategy;
	}

	public String getServerAddress() {
		return serverAddress;
	}

	public void setServerAddress(String serverAddress) {
		this.serverAddress = serverAddress;
	}

	public String getStopReportingTime() {
		return stopReportingTime;
	}

	public void setStopReportingTime(String stopReportingTime) {
		this.stopReportingTime = stopReportingTime;
	}

	public String getSleepStrategy() {
		return sleepStrategy;
	}

	public void setSleepStrategy(String sleepStrategy) {
		this.sleepStrategy = sleepStrategy;
	}
	@Column(name = "audio_profiles")
	public String getAudioProfiles() {
		return audioProfiles;
	}

	public void setAudioProfiles(String audioProfiles) {
		this.audioProfiles = audioProfiles;
	}

	@Transient
	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}
	
	public String getAnswerMode() {
		return answerMode;
	}

	public void setAnswerMode(String answerMode) {
		this.answerMode = answerMode;
	}

	@PrePersist
	public void prePersist(){
		if(this.getWhiteList()==null)
			setWhiteList("1");
		if(this.getSosNumber()==null)
			setSosNumber("1");
		if(this.getReportingStrategy()==null)
			setReportingStrategy("1");
		if(this.getRecordingStrategy()==null)
			setRecordingStrategy("1");
		if(this.getServerAddress()==null)
			setServerAddress("1");
		if(this.getStopReportingTime()==null)
			setStopReportingTime("1");
		if(this.getSleepStrategy()==null)
			setSleepStrategy("1");
		if(this.getAudioProfiles()==null)
			setAudioProfiles("1");
	}
	
}
