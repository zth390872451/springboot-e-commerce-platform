package com.umeox.babywei.util.pos;

public class DistCnvter {
	private final static double PI = 3.14159265358979323; // 圆周率
	private final static double R = 6371229; // 地球的半径

	public static double getDistance(double longt1, double lat1, double longt2, double lat2) {
		double x, y, distance;
		x = (longt2 - longt1) * PI * R * Math.cos(((lat1 + lat2) / 2) * PI / 180) / 180;
		y = (lat2 - lat1) * PI * R / 180;
		distance = Math.hypot(x, y);
		return distance;
	}

	public static double cal2PDis(double lat1, double lon1, double lat2, double lon2) {
		double result = 0;
		double lat = Math.abs(lat1 - lat2);
		double lon = Math.abs(lon1 - lon2);
		double latRadian = Math.toRadians(lat1);
		double kmPerLat = 111.13295 - 0.55982 * Math.cos(2 * latRadian) + 0.00117 * Math.cos(4 * latRadian);
		double latKm = lat * kmPerLat;
		double kmPerLon = 111.41288 * Math.cos(latRadian) - 0.09350 * Math.cos(3 * latRadian)
				+ 0.00012 * Math.cos(5 * latRadian);
		double lonKm = lon * kmPerLon;
		result = Math.sqrt(latKm * latKm + lonKm * lonKm) * 1000;
		return result;
	}

}