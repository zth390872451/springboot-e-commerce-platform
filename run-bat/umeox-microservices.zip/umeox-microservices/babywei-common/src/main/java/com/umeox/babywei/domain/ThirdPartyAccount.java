package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 * 第三方账号
 */
@Entity
@Table(name = "ux_third_party_account")
public class ThirdPartyAccount extends BaseEntity{
    //绑定的会员
    private Member member;
    //第三方认证的登录信息(标识) 比如：微信的OpenId
    private String openId;
    //第三方的认证信息，如 微信的AccessToken
    private String thirdToken;
    //accountToken 的有效时间
    private Long expire;
    //第三方的类别：如 0代表微信;1代表qq;2代表新浪微博3代表联想Lenovo
    private Integer type;

    public Long getExpire() {
        return expire;
    }

    public void setExpire(Long expire) {
        this.expire = expire;
    }

    @ManyToOne(fetch= FetchType.EAGER)
    @JoinColumn(nullable=false)
    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getThirdToken() {
        return thirdToken;
    }

    public void setThirdToken(String thirdToken) {
        this.thirdToken = thirdToken;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
