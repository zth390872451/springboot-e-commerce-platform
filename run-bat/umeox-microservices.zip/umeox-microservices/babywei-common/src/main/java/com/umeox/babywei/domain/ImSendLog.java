package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author umeox
 * @version II
 * @Desc 发送聊天记录
 */
@Entity
@Table(name = "ux_im_send_log")
public class ImSendLog extends BaseEntity {

	private static final long serialVersionUID = -939692098562587115L;

	public static final Integer MSG_TYPE_NORMAL = 0;
	public static final Integer MSG_TYPE_FILE = 1;//文件类型
	public static final Integer MSG_TYPE_EMOTICON = 2;

	public static final Integer DATA_FLAG_NEW = 1;
	public static final Integer DATA_FLAG_HISTORY = -1;
	/**
	 * 发送者(imei|mobile)
	 */
	private String userId;

	/**
	 * 发送者昵称
	 */
	private String userName;

	/**
	 * 发送者头像
	 */
	private String userAvatar;
	/**
	 * 接收者(imei|mobile|groupId)
	 */
	private String friendId;

	//0：普通文本，(W&K3) 1：语聊文件，(W&k3) 2：表情包括点赞 3：SOS录音文件（K3）4：SOS上报位置（K3）5：单张动态图(K3)
	//6：Url静态图(K3) 7：多表情（用英文逗号分隔）(K3) 8：超出安全区域提醒 9：通知类型(W) 10：关机提醒
	//11：低电提醒 12：新添关注者 13：手表添加手表为好提醒 20：系统消息
	/**
	 * 消息类型(0:普通文本，1:语聊文件，2:表情包括点赞--消息类容为1表示点赞),9:通知类型
	 */
	private Integer msgType;

	/**
	 * 语聊文件相当路径
	 */
	//private String filePath;

	/**
	 * 文件大小(字节)
	 */
	//private Long fileSize;

	/**
	 * 消息内容(消息类型为语聊，msg代表文件Key)
	 */
	private String msg;

	/**
	 * 发送时间（时间戳格式）
	 */
	private Long msgTime;

	/**
	 * 语聊方式（0：私聊；1：群聊）
	 */
	private Integer imType = 0;


	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserAvatar() {
		return userAvatar;
	}

	public void setUserAvatar(String userAvatar) {
		this.userAvatar = userAvatar;
	}

	public Integer getImType() {
		return imType;
	}

	public void setImType(Integer imType) {
		this.imType = imType;
	}

	@Column(nullable = false)
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(nullable = false)
	public String getFriendId() {
		return friendId;
	}

	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}

	@Column(nullable = false)
	public Integer getMsgType() {
		return msgType;
	}

	public void setMsgType(Integer msgType) {
		this.msgType = msgType;
	}

	/*public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}*/

	@Column(length = 1000)
	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Column(nullable = false)
	public Long getMsgTime() {
		return msgTime;
	}

	public void setMsgTime(Long msgTime) {
		this.msgTime = msgTime;
	}
}
