package com.umeox.babywei.conf;

/**
 * @author umeox
 */
public final class Push {
	public static final String KEY = "key";// key+电话号码作为唯一key
	public static final String CLIENT_ID = "clientId";// clientId+电话号码作为唯一key
	public static final String MEMBER_ID = "id";// id+电话号码作为唯一key
	public static final String MEMBER_LOCALE = "locale";// 区域设置

	public static final int NOTIFICATION = 1;// 消息通知
	public static final int IM_CHAT = 2;// 聊天消息(私聊)
	public static final int IM_GROUP_CHAT = 3;// 聊天消息(群聊)
	public static final int APPLY = 4;// 关注申请
	public static final int INVITATION = 5;// 邀请关注
	public static final int LOCATION = 12;// 上报当前地理位置
	public static final int RECORD = 13;// 录音
	public static final int SOS = 14;// sos提醒
	public static final int BARRIER = 15;// 5.电子围栏消息推送
	public static final int LOW_POWER = 17;// 低电提醒
	public static final int UNBOUND = 19;// 解除绑定
	public static final int STATICREMIND = 20;// 静止提醒
	public static final int YUENOTIFACTION = 21;// 余额提醒
	public static final int ACCEPT = 22;// 管理员同意关注申请
	public static final int REFUSE = 23;// 管理员拒绝关注申请
	public static final int MOVEREMIND = 24;// 运动提醒
	public static final int CALL = 25;// 通话上报位置
	public static final int SHUTDOWN = 26;// 关机上报位置
	public static final int FRIEND = 27;// 手表与手表成为好友
	public static final int IMPORTANT_NOTICE = 28;// 重要通知
	public static final int ADMIN_DEL_FOLLOWER = 29;// 管理员删除关注,k1 & k2用了UNBOUND
	public static final int FOLLOWER_ADD = 30;// 新添关注
	public static final int FOLLOWER_CANCEL = 31;// 取消关注
	public static final int GROUP_CREATE = 32; // 新建群组
	public static final int GROUP_DELETE = 33; // 解散群组
	public static final int REALNAME = 35;//实名认证
	public static final int SIM_STATUS = 36;//sim卡状态改变
	public static final int PAY_SUCCESS = 37;//支付成功
	public static final int Data_Stream = 38;//流量通知
	public static final int Soon_Expire = 39;//套餐即将到期通知
	public static final int WATCHSTRAP_STATUS_CHANGE = 40; //表带状态发生变化
	public static final int VIDEO_DEVICE_NOTIFY_JOINC_HANNEL = 50; //设备通知对方加入视频对话
	public static final int VIDEO_DEVICE_NOTIFY_CANCEL_CHANNEL = 51;//设备通知对方取消视频对话
	public static final int REMOTE_TAKE_PHONE = 52;//远程拍照
	public static final int DEVICE_OFF_ALARM = 53;//手表脱落提醒
	public static final int SEDENTARY_ALARM  = 54;//久座上报位置
	public static final int VOICE_DEVICE_NOTIFY_JOINC_HANNEL = 55; //设备通知对方加入语音对话
	public static final int VOICE_DEVICE_NOTIFY_CANCEL_CHANNEL = 56;//设备通知对方取消语音对话


	// -------------------wetalk
	/*
	 * public static final String SYS_NOTICE = "0";//通知 public static final
	 * String FRIEND_CHAT = "1";//私聊 public static final String GROUP_CHAT =
	 * "2";//群聊 public static final String INVITE = "3";//邀请关注 public static
	 * final String UNFOLLOW = "4";//取消关注 public static final String UNBIND =
	 * "5";//解绑
	 */

	// -----K3 For Device
	public static final int K3_DEVICE_UNBIND = 0x01; // 解绑/恢复出厂设置
	public static final int K3_DEVICE_ACTIVE_SUCCESS = 0x02; // 激活成功
	public static final int K3_DEVICE_ACTIVE_FAIL = 0x04; // 激活失败
	public static final int K3_DEVICE_UPDATE_FRIEND = 0x08; // 更新好友人列表
	public static final int K3_DEVICE_UPDATE_CONTACT = 0x10; // 更新联系人列表
	public static final int K3_DEVICE_LOCATION = 0x20; // 请求定位
	public static final int K3_DEVICE_CLASS_TIME = 0x40; // 上课模式
	public static final int K3_DEVICE_CONCERN_TIME = 0x80; // 关爱时段
	public static final int K3_DEVICE_ALARM = 0x100; // 闹钟
	public static final int K3_DEVICE_CHAT = 0x200; // 语聊
	public static final int K3_DEVICE_UPDATE_CONFIG = 0x400; // 修改持有者消息
	public static final int K3_DEVICE_UPDATE_STEP = 0x800; // 修改记步目标值
	public static final int K3_DEVICE_NOTIFY_JOIN_CHANNEL = 0x1000; // 通知设备加入视频频道
	public static final int K3_DEVICE_UPDATE_BARRIER = 0x2000; // 更改安全区域
	public static final int K3_DEVICE_UPDATE_AUDIO_TYPES = 0x4000; //更新情景模式
	public static final int K3_DEVICE_CALL_PHONE = 0x8000; // 下发命令：让手表拨打指定号码
	public static final int K3_DEVICE_WALLPAPER = 0x10000; // 壁纸设置
	public static final int K3_DEVICE_WIFI_SYNC = 0x20000; // WiFi同步
	public static final int K3_DEVICE_NOTIFY_JOIN_VOICE_CHANNEL = 0x40000; // 通知设备加入语音频道
}
