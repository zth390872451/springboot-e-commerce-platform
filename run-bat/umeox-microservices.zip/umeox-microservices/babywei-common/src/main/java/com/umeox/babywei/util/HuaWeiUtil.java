package com.umeox.babywei.util;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.bean.PushRet;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.PushAppInfo;
import com.umeox.babywei.repository.PushAppInfoRepository;
import nsp.NSPClient;
import nsp.OAuth2Client;
import nsp.support.common.AccessToken;
import nsp.support.common.NSPException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/4/21.
 */
public class HuaWeiUtil {

    public static final String TIMESTAMP_NORMAL = "yyyy-MM-dd HH:mm:ss";

    private static final Logger log = LoggerFactory.getLogger(HuaWeiUtil.class);

    public static final int maxRetryTimes = 3;

    // 测试 XiaomiPushTest
    public static final String MI_PACKAGE_NAME = "com.hemdenry.xiaomipush";
    public static final String MI_PACKAGE_ID = "2882303761517568634";
    public static final String APP_SECRET_KEY = "5711756859634";
    public static final String APP_SECRET = "mqw/TglF/B4v/QtlwNmWrg==";

   /* public static void main(String[] args) throws IOException, ParseException {
        String alias ="alias_zth";
        Sender sender = new Sender(APP_SECRET);
        Map<String,String> extras = new HashMap<>();
        extras.put("test","extra");
        Message message = HuaWeiUtil.androidMessage("descrip","title", "payload", null, extras);
        System.out.println("message = " + message);
        boolean flag = HuaWeiUtil.sendAndroidAll(MI_PACKAGE_NAME,new ArrayList<String>(Arrays.asList(alias)),"title","description","payload", extras);
        System.out.println("flag = " + flag);
    }*/

    private static PushAppInfoRepository pushAppInfoRepository;
    private static SettingProperties settingProperties;
    private static Map<String, NSPClient> instanceMap = new HashMap<String,NSPClient>();
    private static Map<String, AccessToken> tokenMap = new HashMap<String,AccessToken>();
    private static Long lastCreateInstanceTime= 0l;//首次初始化时间
    //华为的AccessToken 保存时间为7天，所以设置 更新频率为6天一次
    private static Long updateInterval= 6*24*3600l;//每间隔6天 更新一次，将会更新AccessToken

    static{
        pushAppInfoRepository = (PushAppInfoRepository) ApplicationSupport.getBean("pushAppInfoRepository");
        settingProperties   = (SettingProperties) ApplicationSupport.getBean("settingProperties");
        createInstanceMap();
    }

    //从数据库获取信息创建实例
    private static void  createInstanceMap(){
        synchronized (lastCreateInstanceTime){
            lastCreateInstanceTime = System.currentTimeMillis();
            List<PushAppInfo> pushClients = pushAppInfoRepository.findAll();
            if (pushClients != null && !pushClients.isEmpty()){
                for(PushAppInfo pushAppInfo:pushClients){
                    if (PushAppInfo.HUAWEI.equals(pushAppInfo.getAppType())){
                        String packageName = pushAppInfo.getPackageName();
                        //华为AccessToken 保存时间7天
                        //而如果每一个小时刷新一次内存中的 NspClient对象【导致将向华为AccessToken接口1小时访问一次，太频繁】，则有可能受到华为的接口限流设置
                        NSPClient nspClient = createNSPClient(pushAppInfo);
                        instanceMap.put(packageName,nspClient);
                    }
                }
            }
            log.info("instanceMap = " + instanceMap);
            log.info("从数据库获取信息创建实例 lastCreateInstanceTime ={}, instanceMap.size={}",lastCreateInstanceTime,instanceMap.size());
        }
    }
    // 创建 NSPClient
    private static NSPClient createNSPClient(PushAppInfo pushAppInfo) {
        try {
            File file = new File(settingProperties.getKeyStorebjPath());
            InputStream inputStream = new FileInputStream(file);
            OAuth2Client oauth2Client = new OAuth2Client();
            oauth2Client.initKeyStoreStream(inputStream, "123456");
            AccessToken access_token = oauth2Client.getAccessToken("client_credentials", pushAppInfo.getAppId(), pushAppInfo.getAppSecret());
            NSPClient nspClient = new NSPClient(access_token.getAccess_token());
            nspClient.initHttpConnections(30, 50);//设置每个路由的连接数和最大连接数
            InputStream fileInputStream = new FileInputStream(file);
            nspClient.initKeyStoreStream(fileInputStream, "123456");//这个地方不能使用上面的 inputStream对象，注意！
            return nspClient;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 根据包名获取(创建)
     * @param packageName
     * @return
     */
    private static NSPClient getNSPClient(String packageName){
        if (StringUtils.isEmpty(packageName)){
            log.error("packageName must not null");
            return null;
        }
        //更新instance策略
        // 等到6天多的时候，重新创建一次
        if(System.currentTimeMillis() > (lastCreateInstanceTime + updateInterval)){
            createInstanceMap();
        }
        NSPClient nspClient = instanceMap.get(packageName);
        if (nspClient==null){
            PushAppInfo pushAppInfo = pushAppInfoRepository.findOneByPackageName(packageName);
            if (pushAppInfo!=null){
                nspClient = createNSPClient(pushAppInfo);
                instanceMap.put(packageName,nspClient);
                return nspClient;
            }
        }else {
            return nspClient;
        }
        return null;
    }

    /**
     *
     * 给安卓发送透传消息(无通知栏提醒)
     * @param packageName APP的包名
     * @param token  由客户端获取， 32 字节长度。手机上安装了push应用后，会到push服务器申请token，申请到的token会上报给应用服务器
     * @param message 最长为4096 字节（开发者自定义，自解析）
     *                原华为的 single_send(NSPClient client)
     */
    public static void sendMessage(String packageName,String token,String message){
        NSPClient nspClient = getNSPClient(packageName);
        if (nspClient==null)
        {
            log.error("无法创建未维护的包名 {}对应的推送客户端对象",packageName);
            return;
        }
        //构造请求
        HashMap<String, Object> hashMap = new HashMap<String, Object>();
        hashMap.put("deviceToken", token);
        hashMap.put("message", message);
        hashMap.put("priority", 1);//必选 0：高优先级  1：普通优先级  缺省值为1
        hashMap.put("cacheMode", 1);//消息是否需要缓存，必选 0：不缓存 1：缓存 缺省值为0
        hashMap.put("msgType", 1); //标识消息类型，必选 当TMID+msgType的值一样时，仅缓存最新的一条消息
//      hashMap.put("requestID", requestID);//如果请求消息中，没有带，则MC根据ProviderID+timestamp生成，各个字段之间用下划线连接
//      hashMap.put("expire_time", expire_time);//// 消息过期删除时间，如果不填写，默认超时时间为当前时间后48小时
        nspClient.setTimeout(10000, 15000);//设置http超时时间
        //接口调用
        PushRet resp = null;
        try {
            resp = nspClient.call("openpush.message.single_send", hashMap, PushRet.class);
            if (resp!=null && resp.getResultcode()!=0){
                log.error("单发接口消息响应:" + resp.getResultcode() + ",message:" + resp.getMessage());
            }
        } catch (NSPException e) {
            e.printStackTrace();
        }
    }

    /**
     * 通知栏消息接口
     * @throws NSPException
     * 原华为的 notification_send(NSPClient client)
     */
    public static void notification_send(String packageName,String token,String title,String content,Map<String,String> extras)
    {
        log.info("华为通知栏消息的包名 packageName:{},token:{},title:{},content:{},extra:{}",packageName,token,title,content,extras);
        NSPClient nspClient = getNSPClient(packageName);
        if (nspClient==null)
        {
            log.error("无法创建未维护的包名 {}对应的推送客户端对象",packageName);
            return;
        }
        //消息内容，必选
        //该样例是点击通知消息打开url连接。更多的android样例请参考http://developer.huawei.com/ -> 资料中心 -> Push服务 -> API文档 -> 4.2.1 android结构体
        String android = "{\"notification_title\":\"the good news!\",\"notification_content\":\"Price reduction!\",\"doings\":3,\"url\":\"vmall.com\"}";

        Map<String,Object> map = new HashMap<>();
        map.put("notification_title",title);//必须
        map.put("notification_content",content);//必须
        map.put("doings",1);
        String androidJson = JsonUtils.toJson(map);
        //构造请求
        HashMap<String, Object> hashMap = new HashMap<String, Object>();
        hashMap.put("push_type", 1);//推送范围，必选 1：指定用户，必须指定tokens字段 2：所有人，无需指定tokens，tags，exclude_tags
        hashMap.put("tokens", token);//目标用户，可选 当push_type=1时，该字段生效
//      hashMap.put("tags", tags);////标签，可选 当push_type的取值为2时，该字段生效
//      hashMap.put("exclude_tags", exclude_tags);//排除的标签，可选 当push_type的取值为2时，该字段生效
//      该样例是点击通知消息打开url连接。更多的android样例请参考http://developer.huawei.com/ -> 资料中心 -> Push服务 -> API文档 -> 4.2.1 android结构体
        hashMap.put("android", androidJson);//消息内容，必选 android结构体 doing=1：直接打开应用
//      hashMap.put("expire_time", expire_time);//消息过期时间，可选
        nspClient.setTimeout(10000, 15000);//设置http超时时间
        //接口调用
        try {
            String resp = nspClient.call("openpush.openapi.notification_send", hashMap, String.class);
            log.info("华为通知栏消息推送响应结果 resp:push token:{},resp :{}",token,resp);
        } catch (NSPException e) {
            e.printStackTrace();
        }
    }


}
