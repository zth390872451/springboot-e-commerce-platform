package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 用户扩展表
 */
@Entity
@Table(name = "ux_member_ext")
public class MemberExt {
	
	private Long id;
	/**
	 * 国家语言+国家地区代码
	 */
	private String locale;
	
	private Member Member;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "member_id",unique = true,nullable = false)
	public Member getMember() {
		return Member;
	}
	public void setMember(Member member) {
		Member = member;
	}
	
}
