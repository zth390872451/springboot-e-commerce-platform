package com.umeox.babywei.domain.enums;

public enum GroupType {
	FAMILY,DEVICE
}
