package com.umeox.babywei.conf;

import org.hibernate.validator.constraints.Length;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

@Configuration("settingProperties")
@ConfigurationProperties(prefix = "setting")
public class SettingProperties {
	/** 分隔符 */
	private static final String SEPARATOR = ",";
	/**
	 * 网站网址
	 */
	private String siteUrl;

	/**
	 * nginx代理地址
	 */
	private String nginxUrl;

	/**
	 * 图片上传路径
	 */
	private String imageUploadPath;

	/**
	 * 服务器路径
	 */
	private String tomcatPath;

	/**
	 * push地址
	 */
	private String pushUrl;

	private String certificatePath;

	private String certificatePassword;

	private String itCertificatePath;

	private String itCertificatePassword;

	private String wherecomCertificatePath;

	private String wherecomCertificatePassword;

	private String sonquipetCertificatePath;

	private String sonquipetCertificatePassword;

	private String dokiVoipCertificatePath;

	private String dokiVoipCertificatePassword;

 	private int tokenFlag;

	// Ios 环境
	private boolean iosProduction;

	/**
	 * 软件版本号
	 */
	private String wherecomVersion;

	private String babyweiVersion;

	/**
	 * APP下载地址
	 */
	private String wherecomAppDownloadPath;

	private String babyweiAppDownloadPath;

	/**
	 * APP 下载内容提示
	 */
	private String wherecomAppMessage;

	private String babyweiAppMessage;

	/** 上传文件最大限制 */
	private Integer uploadMaxSize;

	/** 允许上传图片扩展名 */
	private String uploadImageExtension;

	/** 允许上传Flash扩展名 */
	private String uploadFlashExtension;

	/** 允许上传媒体扩展名 */
	private String uploadMediaExtension;

	/** 允许上传文件扩展名 */
	private String uploadFileExtension;

	/** 发现图片上传路径 */
	private String contentUploadPath;

	/** Flash上传路径 */
	private String flashUploadPath;

	/** 媒体上传路径 */
	private String mediaUploadPath;

	/**
	 * 文件上传路径
	 */
	private String fileUploadPath;

	/**
	 * 录音上传路径
	 */
	private String recordUploadPath;

	/**
	 * GoogleMapAccount *
	 */
	private String gmapsClientId;

	private String gmapsClientKey;

	public String pushServerAddress;

	/**
	 * 二维码前缀
	 */
	private String qrCodePreUrl;

	/**
	 * 语聊语音上传路径
	 */
	private String imUploadPath;

	/**
	 * 文件服务器（ip+port）
	 */
	private String fileServerUrl;

	private String selfUrl;

	private String uploadDomain;

	private String sourceFileServerIP;

	private String fileServerPort;

	private String downloadDomain;

	private String downloadPort;

	private String upToken;

	/*private String appKey;

	private String wetalkAppKey;

	private String candy2CAppKey;

	private String pt100AppKey;

	private String w268PlusAppKey;

	private String w271AppKey;
	
	private String yihaozhuanxianAppKey;*/	
	
	private String deviceOnlineUrl;
	
	private String g2DeviceOnlineUrl;
	
	/**
	 * 文件下载地址，目前指向Nginx，K3系列在用
	 */
	private String fileDownloadAddress;
	/**
	 * 华为推送所需要的安全校验文件1
	 */
	private String keyStorePath;
	/**
	 * 华为推送所需要的安全校验文件2【暂时未用】
	 */
	private String keyStorebjPath;

	public String getKeyStorePath() {
		return keyStorePath;
	}

	public void setKeyStorePath(String keyStorePath) {
		this.keyStorePath = keyStorePath;
	}

	public String getKeyStorebjPath() {
		return keyStorebjPath;
	}

	public void setKeyStorebjPath(String keyStorebjPath) {
		this.keyStorebjPath = keyStorebjPath;
	}

	public String getDokiVoipCertificatePath() {
		return dokiVoipCertificatePath;
	}

	public void setDokiVoipCertificatePath(String dokiVoipCertificatePath) {
		this.dokiVoipCertificatePath = dokiVoipCertificatePath;
	}
	public String getDokiVoipCertificatePassword() {
		return dokiVoipCertificatePassword;
	}

	public void setDokiVoipCertificatePassword(String dokiVoipCertificatePassword) {
		this.dokiVoipCertificatePassword = dokiVoipCertificatePassword;
	}

	public String getFileDownloadAddress() {
		return fileDownloadAddress;
	}

	public void setFileDownloadAddress(String fileDownloadAddress) {
		this.fileDownloadAddress = fileDownloadAddress;
	}

	public String getDeviceOnlineUrl() {
		return deviceOnlineUrl;
	}

	public void setDeviceOnlineUrl(String deviceOnlineUrl) {
		this.deviceOnlineUrl = deviceOnlineUrl;
	}

	public String getG2DeviceOnlineUrl() {
		return g2DeviceOnlineUrl;
	}

	public void setG2DeviceOnlineUrl(String g2DeviceOnlineUrl) {
		this.g2DeviceOnlineUrl = g2DeviceOnlineUrl;
	}

	public String getSelfUrl() {
		return selfUrl;
	}

	public void setSelfUrl(String selfUrl) {
		this.selfUrl = selfUrl;
	}

	public String getFileServerUrl() {
		return fileServerUrl;
	}

	public void setFileServerUrl(String fileServerUrl) {
		this.fileServerUrl = fileServerUrl;
	}

	public String getImUploadPath() {
		return imUploadPath;
	}

	public void setImUploadPath(String imUploadPath) {
		this.imUploadPath = imUploadPath;
	}

	public String getWherecomCertificatePath() {
		return wherecomCertificatePath;
	}

	public void setWherecomCertificatePath(String wherecomCertificatePath) {
		this.wherecomCertificatePath = wherecomCertificatePath;
	}

	public String getWherecomCertificatePassword() {
		return wherecomCertificatePassword;
	}

	public void setWherecomCertificatePassword(String wherecomCertificatePassword) {
		this.wherecomCertificatePassword = wherecomCertificatePassword;
	}

	public String getSonquipetCertificatePath() {
		return sonquipetCertificatePath;
	}

	public void setSonquipetCertificatePath(String sonquipetCertificatePath) {
		this.sonquipetCertificatePath = sonquipetCertificatePath;
	}

	public String getSonquipetCertificatePassword() {
		return sonquipetCertificatePassword;
	}

	public void setSonquipetCertificatePassword(String sonquipetCertificatePassword) {
		this.sonquipetCertificatePassword = sonquipetCertificatePassword;
	}

	public String getWherecomVersion() {
		return wherecomVersion;
	}

	public void setWherecomVersion(String wherecomVersion) {
		this.wherecomVersion = wherecomVersion;
	}

	public String getBabyweiVersion() {
		return babyweiVersion;
	}

	public void setBabyweiVersion(String babyweiVersion) {
		this.babyweiVersion = babyweiVersion;
	}

	public String getWherecomAppDownloadPath() {
		return wherecomAppDownloadPath;
	}

	public void setWherecomAppDownloadPath(String wherecomAppDownloadPath) {
		this.wherecomAppDownloadPath = wherecomAppDownloadPath;
	}

	public String getBabyweiAppDownloadPath() {
		return babyweiAppDownloadPath;
	}

	public void setBabyweiAppDownloadPath(String babyweiAppDownloadPath) {
		this.babyweiAppDownloadPath = babyweiAppDownloadPath;
	}

	public String getWherecomAppMessage() {
		return wherecomAppMessage;
	}

	public void setWherecomAppMessage(String wherecomAppMessage) {
		this.wherecomAppMessage = wherecomAppMessage;
	}

	public String getBabyweiAppMessage() {
		return babyweiAppMessage;
	}

	public void setBabyweiAppMessage(String babyweiAppMessage) {
		this.babyweiAppMessage = babyweiAppMessage;
	}

	public String getQrCodePreUrl() {
		return qrCodePreUrl;
	}

	public void setQrCodePreUrl(String qrCodePreUrl) {
		this.qrCodePreUrl = qrCodePreUrl;
	}

	public String getPushServerAddress() {
		return pushServerAddress;
	}

	public void setPushServerAddress(String pushServerAddress) {
		this.pushServerAddress = pushServerAddress;
	}

	public String getGmapsClientId() {
		return gmapsClientId;
	}

	public void setGmapsClientId(String gmapsClientId) {
		this.gmapsClientId = gmapsClientId;
	}

	public String getGmapsClientKey() {
		return gmapsClientKey;
	}

	public void setGmapsClientKey(String gmapsClientKey) {
		this.gmapsClientKey = gmapsClientKey;
	}

	public String getRecordUploadPath() {
		return recordUploadPath;
	}

	public void setRecordUploadPath(String recordUploadPath) {
		this.recordUploadPath = pathExt(recordUploadPath);
	}

	public String getFileUploadPath() {
		return fileUploadPath;
	}

	public void setFileUploadPath(String fileUploadPath) {
		this.fileUploadPath = pathExt(fileUploadPath);
	}

	public String getCertificatePath() {
		return certificatePath;
	}

	public void setCertificatePath(String certificatePath) {
		this.certificatePath = certificatePath;
	}

	public String getCertificatePassword() {
		return certificatePassword;
	}

	public void setCertificatePassword(String certificatePassword) {
		this.certificatePassword = certificatePassword;
	}

	public String getPushUrl() {
		return pushUrl;
	}

	public void setPushUrl(String pushUrl) {
		this.pushUrl = pushUrl;
	}

	public String getSiteUrl() {
		return siteUrl;
	}

	public void setSiteUrl(String siteUrl) {
		this.siteUrl = siteUrl;
	}

	public String getNginxUrl() {
		return nginxUrl;
	}

	public void setNginxUrl(String nginxUrl) {
		this.nginxUrl = nginxUrl;
	}

	public String getImageUploadPath() {
		return imageUploadPath;
	}

	public void setImageUploadPath(String imageUploadPath) {
		this.imageUploadPath = pathExt(imageUploadPath);
	}

	public String getTomcatPath() {
		return tomcatPath;
	}

	public void setTomcatPath(String tomcatPath) {
		this.tomcatPath = tomcatPath;
	}

	public String getItCertificatePath() {
		return itCertificatePath;
	}

	public void setItCertificatePath(String itCertificatePath) {
		this.itCertificatePath = itCertificatePath;
	}

	public String getItCertificatePassword() {
		return itCertificatePassword;
	}

	public void setItCertificatePassword(String itCertificatePassword) {
		this.itCertificatePassword = itCertificatePassword;
	}

	public int getTokenFlag() {
		return tokenFlag;
	}

	public void setTokenFlag(int tokenFlag) {
		this.tokenFlag = tokenFlag;
	}

	public boolean isIosProduction() {
		return iosProduction;
	}

	public void setIosProduction(boolean iosProduction) {
		this.iosProduction = iosProduction;
	}

	public String getUploadDomain() {
		return uploadDomain;
	}

	public void setUploadDomain(String uploadDomain) {
		this.uploadDomain = uploadDomain;
	}

	public String getSourceFileServerIP() {
		return sourceFileServerIP;
	}

	public void setSourceFileServerIP(String sourceFileServerIP) {
		this.sourceFileServerIP = sourceFileServerIP;
	}

	public String getFileServerPort() {
		return fileServerPort;
	}

	public void setFileServerPort(String fileServerPort) {
		this.fileServerPort = fileServerPort;
	}

	public String getDownloadDomain() {
		return downloadDomain;
	}

	public void setDownloadDomain(String downloadDomain) {
		this.downloadDomain = downloadDomain;
	}

	public String getDownloadPort() {
		return downloadPort;
	}

	public void setDownloadPort(String downloadPort) {
		this.downloadPort = downloadPort;
	}

	public String getUpToken() {
		return upToken;
	}

	public void setUpToken(String upToken) {
		this.upToken = upToken;
	}

	/*public String getAppKey() {
		return appKey;
	}

	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}

	public String getWetalkAppKey() {
		return wetalkAppKey;
	}

	public void setWetalkAppKey(String wetalkAppKey) {
		this.wetalkAppKey = wetalkAppKey;
	}

	public String getCandy2CAppKey() {
		return candy2CAppKey;
	}

	public void setCandy2CAppKey(String candy2cAppKey) {
		candy2CAppKey = candy2cAppKey;
	}

	public String getPt100AppKey() {
		return pt100AppKey;
	}

	public void setPt100AppKey(String pt100AppKey) {
		this.pt100AppKey = pt100AppKey;
	}

	public String getW268PlusAppKey() {
		return w268PlusAppKey;
	}

	public void setW268PlusAppKey(String w268PlusAppKey) {
		this.w268PlusAppKey = w268PlusAppKey;
	}

	public String getW271AppKey() {
		return w271AppKey;
	}

	public void setW271AppKey(String w271AppKey) {
		this.w271AppKey = w271AppKey;
	}*/

	public Integer getUploadMaxSize() {
		return uploadMaxSize;
	}

	public void setUploadMaxSize(Integer uploadMaxSize) {
		this.uploadMaxSize = uploadMaxSize;
	}

	public String getUploadImageExtension() {
		return uploadImageExtension;
	}

	/**
	 * 设置允许上传图片扩展名
	 * 
	 * @param uploadImageExtension
	 *            允许上传图片扩展名
	 */
	public void setUploadImageExtension(String uploadImageExtension) {
		if (uploadImageExtension != null) {
			uploadImageExtension = uploadImageExtension.replaceAll("[,\\s]*,[,\\s]*", ",").replaceAll("^,|,$", "")
					.toLowerCase();
		}
		this.uploadImageExtension = uploadImageExtension;
	}

	/**
	 * 获取允许上传Flash扩展名
	 * 
	 * @return 允许上传Flash扩展名
	 */
	@Length(max = 200)
	public String getUploadFlashExtension() {
		return uploadFlashExtension;
	}

	/**
	 * 设置允许上传Flash扩展名
	 * 
	 * @param uploadFlashExtension
	 *            允许上传Flash扩展名
	 */
	public void setUploadFlashExtension(String uploadFlashExtension) {
		if (uploadFlashExtension != null) {
			uploadFlashExtension = uploadFlashExtension.replaceAll("[,\\s]*,[,\\s]*", ",").replaceAll("^,|,$", "")
					.toLowerCase();
		}
		this.uploadFlashExtension = uploadFlashExtension;
	}

	/**
	 * 获取允许上传媒体扩展名
	 * 
	 * @return 允许上传媒体扩展名
	 */
	@Length(max = 200)
	public String getUploadMediaExtension() {
		return uploadMediaExtension;
	}

	/**
	 * 设置允许上传媒体扩展名
	 * 
	 * @param uploadMediaExtension
	 *            允许上传媒体扩展名
	 */
	public void setUploadMediaExtension(String uploadMediaExtension) {
		if (uploadMediaExtension != null) {
			uploadMediaExtension = uploadMediaExtension.replaceAll("[,\\s]*,[,\\s]*", ",").replaceAll("^,|,$", "")
					.toLowerCase();
		}
		this.uploadMediaExtension = uploadMediaExtension;
	}

	public String getUploadFileExtension() {
		return uploadFileExtension;
	}

	public void setUploadFileExtension(String uploadFileExtension) {
		this.uploadFileExtension = uploadFileExtension;
	}

	public String getFlashUploadPath() {
		return flashUploadPath;
	}

	public void setFlashUploadPath(String flashUploadPath) {
		this.flashUploadPath = flashUploadPath;
	}

	public String getMediaUploadPath() {
		return mediaUploadPath;
	}

	public void setMediaUploadPath(String mediaUploadPath) {
		this.mediaUploadPath = mediaUploadPath;
	}

	public String getContentUploadPath() {
		return contentUploadPath;
	}

	public void setContentUploadPath(String contentUploadPath) {
		this.contentUploadPath = contentUploadPath;
	}

	/**
	 * 获取允许上传图片扩展名
	 * 
	 * @return 允许上传图片扩展名
	 */
	public String[] getUploadImageExtensions() {
		return StringUtils.split(uploadImageExtension, SEPARATOR);
	}

	/**
	 * 获取允许上传Flash扩展名
	 * 
	 * @return 允许上传Flash扩展名
	 */
	public String[] getUploadFlashExtensions() {
		return StringUtils.split(uploadFlashExtension, SEPARATOR);
	}

	/**
	 * 获取允许上传媒体扩展名
	 * 
	 * @return 允许上传媒体扩展名
	 */
	public String[] getUploadMediaExtensions() {
		return StringUtils.split(uploadMediaExtension, SEPARATOR);
	}

	/**
	 * 获取允许上传文件扩展名
	 * 
	 * @return 允许上传文件扩展名
	 */
	public String[] getUploadFileExtensions() {
		return StringUtils.split(uploadFileExtension, SEPARATOR);
	}

	private String pathExt(String path) {
		if (path != null) {
			if (!path.startsWith("/")) {
				path = "/" + path;
			}
			if (!path.endsWith("/")) {
				path = path + "/";
			}
		}
		return path;
	}

	@Override
	public String toString() {
		return "SettingProperties{" + "siteUrl='" + siteUrl + '\'' + ", imageUploadPath='" + imageUploadPath + '\''
				+ ", tomcatPath='" + tomcatPath + '\'' + ", pushUrl='" + pushUrl + '\'' + ", certificatePath='"
				+ certificatePath + '\'' + ", certificatePassword='" + certificatePassword + '\''
				+ ", itCertificatePath='" + itCertificatePath + '\'' + ", itCertificatePassword='"
				+ itCertificatePassword + '\'' + ", tokenFlag=" + tokenFlag + ", iosProduction=" + iosProduction
				+ ", wherecomVersion='" + wherecomVersion + '\'' + ", wherecomAppDownloadPath='"
				+ wherecomAppDownloadPath + '\'' + ", wherecomAppMessage='" + wherecomAppMessage + '\''
				+ ", babyweiVersion='" + babyweiVersion + '\'' + ", babyweiAppDownloadPath='" + babyweiAppDownloadPath
				+ '\'' + ", babyweiAppMessage='" + babyweiAppMessage + '\'' + ", fileUploadPath='" + fileUploadPath
				+ '\'' + ", recordUploadPath='" + recordUploadPath + '\'' + ", gmapsClientId='" + gmapsClientId + '\''
				+ ", gmapsClientKey='" + gmapsClientKey + '\'' + '}';
	}
}
