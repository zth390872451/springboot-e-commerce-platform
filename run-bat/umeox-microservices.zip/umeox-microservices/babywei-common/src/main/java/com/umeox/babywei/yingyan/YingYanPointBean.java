package com.umeox.babywei.yingyan;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author JT
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class YingYanPointBean {

    //经度
    private Double longitude;

    //纬度
    private Double latitude;

    /*坐标类型取值：
            1：GPS经纬度坐标
            2：国测局加密经纬度坐标
            3：百度加密经纬度坐标。
            注：国内的轨迹coord_type均为3：百度加密经纬度坐标*/
    private Integer coord_type;

    private Long loc_time;

    public YingYanPointBean() {
    }

    public YingYanPointBean(Double longitude, Double latitude, Integer coord_type, Long loc_time) {
        this.longitude = longitude;
        this.latitude = latitude;
        this.coord_type = coord_type;
        this.loc_time = loc_time;
    }


    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Integer getCoord_type() {
        return coord_type;
    }

    public void setCoord_type(Integer coord_type) {
        this.coord_type = coord_type;
    }

    public Long getLoc_time() {
        return loc_time;
    }

    public void setLoc_time(Long loc_time) {
        this.loc_time = loc_time;
    }
}
