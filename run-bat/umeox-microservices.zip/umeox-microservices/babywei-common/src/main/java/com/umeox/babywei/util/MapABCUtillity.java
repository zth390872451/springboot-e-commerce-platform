package com.umeox.babywei.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Iterator;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.URIException;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpClientParams;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;

//http://api.map.baidu.com/geocoder/v2/?ak=E4805d16520de693a3fe707cdc962045&callback=renderReverse&location=39.983424,116.322987&output=json&pois=1
public class MapABCUtillity {
	private static final Logger log = LoggerFactory.getLogger(MapABCUtillity.class);

	private static byte[] key;
	private static String clientId;
	private static String cryptoKey;
	private static SettingProperties setting;

	static {
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
		try {
			clientId = setting.getGmapsClientId();
			cryptoKey = setting.getGmapsClientKey();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static final String KEY = "b0a7db0b3a30f944a21c3682064dc70ef5b738b062f6479a5eca39725798b1ee300bd8d5de3a4ae3";
	// public static void main(String args[]) throws URIException,
	// NullPointerException, UnsupportedEncodingException {
	// // String[] strs = getDetails("广州市增城新塘镇港口大道北88号新客隆大旺城");
	// // for (int i = 0; i < strs.length; i++) {
	// // }
	// }
	private static final double EARTH_RADIUS = 6378.137 * 1000; // 地球的半径

	private static double rad(double d) {
		return d * Math.PI / 180.0;
	}

	/**
	 * 
	 * @param origin
	 *            起始地
	 * @param destination
	 *            目的地
	 * @return
	 */
	public static double getDistance(String origin, String destination) {
		String[] originCoordinates = getDetails(origin);
		String[] destinationCoordinates = getDetails(destination);

		return getDistance(Double.valueOf(originCoordinates[1]), Double.valueOf(originCoordinates[0]),
				Double.valueOf(destinationCoordinates[1]), Double.valueOf(destinationCoordinates[0]));
	}

	public static double getDistance(double lat1, double lng1, double lat2, double lng2) {
		double radLat1 = rad(lat1);
		double radLat2 = rad(lat2);
		double a = radLat1 - radLat2;
		double b = rad(lng1) - rad(lng2);
		double s = 2 * Math.asin(Math.sqrt(
				Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
		s = s * EARTH_RADIUS;
		s = Math.round(s * 10000) / 10000;
		return s;
	}

	@SuppressWarnings("unchecked")
	public static String parseXmlToGetXY(String xmlStr) {
		SAXReader saxReader = new SAXReader();
		Document document = null;
		String latitude = "0";
		String longitude = "0";
		StringBuffer sb = new StringBuffer("");
		try {
			document = saxReader.read(new StringReader(xmlStr));
		} catch (DocumentException e) {
			e.printStackTrace();
			return null;
		}
		Element root = document.getRootElement();
		for (Iterator i = root.elementIterator(); i.hasNext();) {
			Element ele = (Element) i.next();
			if (ele.getName().equalsIgnoreCase("list")) {
				for (Iterator j = ele.elementIterator(); j.hasNext();) {
					Element eles = (Element) j.next();
					if (eles.getName().equalsIgnoreCase("poi")) {
						for (Iterator k = eles.elementIterator(); k.hasNext();) {
							Element eless = (Element) k.next();
							if (eless.getName().equalsIgnoreCase("x")) {
								latitude = eless.getText();
							}
							if (eless.getName().equalsIgnoreCase("y")) {
								longitude = eless.getText();
							}
						}
					}
				}
			}
		}
		sb.append(latitude).append(",").append(longitude);
		return sb.toString();
	}

	/**
	 * 获取地址的经纬度
	 * 
	 * @param address
	 * @return
	 */
	public static String[] getDetails(String address) {
		log.info("address:" + address);
		// 构造HttpClient的实例
		HttpClient httpClient = new HttpClient();
		HttpClientParams params = httpClient.getParams();
		params.setHttpElementCharset("GBK");
		params.setContentCharset("GBK");
		// 创建GET方法的实例
		GetMethod getMethod = new GetMethod();
		// 使用系统提供的默认的恢复策略
		URI uri = null;
		try {
			uri = new URI("http://search1.mapabc.com/sisserver?config=GOC&address="
					+ java.net.URLEncoder.encode(address, "GBK") + "&a_k=" + KEY, true, "UTF8");
		} catch (URIException e1) {
			e1.printStackTrace();
		} catch (NullPointerException e1) {
			e1.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		try {
			getMethod.setURI(uri);
		} catch (URIException e1) {
			e1.printStackTrace();
		}
		getMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler());
		try {
			// 执行getMethod
			int statusCode = httpClient.executeMethod(getMethod);
			if (statusCode != HttpStatus.SC_OK) {
				System.err.println("Method failed: " + getMethod.getStatusLine());
			}
			// 读取内容
			byte[] responseBody = getMethod.getResponseBody();
			// 处理内容
			String xys = parseXmlToGetXY(new String(responseBody, "gbk"));
			log.info("xys:" + xys);
			if (org.apache.commons.lang.StringUtils.isEmpty(xys)) {
				return new String[] { "0", "0" };
			}
			return xys.split(",");
		} catch (HttpException e) {
			// 发生致命的异常，可能是协议不对或者返回的内容有问题
			e.printStackTrace();
		} catch (IOException e) {
			// 发生网络异常
			e.printStackTrace();
		} finally {
			// 释放连接
			getMethod.releaseConnection();
		}
		return null;

	}

	/**
	 * 获取地址的经纬度
	 * <p>
	 * coordtype 坐标的类型，目前支持的坐标类型包括：bd09ll（百度经纬度坐标）、gcj02ll（国测局经纬度坐标）、wgs84ll（
	 * GPS经纬度）
	 * </p>
	 * <p>
	 * location 是 无 38.76623,116.43213 lat<纬度>,lng<经度> 根据经纬度坐标获取地址
	 * </p>
	 * <p>
	 * pois 是否显示指定位置周边的poi，0为不显示，1为显示。当值为1时，显示周边100米内的poi
	 * </p>
	 * 
	 * @param address
	 * @return
	 */
	public static String getBaiduDetails(String location) {
		// 构造HttpClient的实例
		HttpClient httpClient = new HttpClient();
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
		httpClient.getHttpConnectionManager().getParams().setSoTimeout(30000);

		HttpClientParams params = httpClient.getParams();
		params.setHttpElementCharset("UTF8");
		params.setContentCharset("UTF8");
		// 创建GET方法的实例
		GetMethod getMethod = new GetMethod();
		// 使用系统提供的默认的恢复策略
		URI uri = null;
		try {
			String[] arr = { "AOckytRhYBsjR9PiuAWt1I4v", "BRn22dsNuKkVsUlIiNfZlXwX" };
			int index = (int) (Math.random() * arr.length);

			uri = new URI("http://api.map.baidu.com/geocoder/v2/?ak=" + arr[index] + "&callback=renderReverse&location="
					+ location + "&output=json&pois=0&coordtype=wgs84ll", true, "UTF8");
			getMethod.setURI(uri);
			getMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler());

			// 执行getMethod
			int statusCode = httpClient.executeMethod(getMethod);
			if (statusCode != HttpStatus.SC_OK) {
				log.error("getBaiduDetails Method failed:" + getMethod.getStatusLine());
				getMethod.abort();
				return null;
			}
			// 读取内容
			byte[] responseBody = getMethod.getResponseBody();
			// 处理内容
			String xys = new String(responseBody, "UTF8");
			return xys;
		} catch (HttpException e) {
			// 发生致命的异常，可能是协议不对或者返回的内容有问题
			getMethod.abort();
			e.printStackTrace();
		} catch (IOException e) {
			// 发生网络异常
			getMethod.abort();
			e.printStackTrace();
		} finally {
			// 释放连接
			getMethod.releaseConnection();
		}
		return null;

	}

	public static String QUERYADDRESS = "http://maps.googleapis.com/maps/api/geocode/json?latlng=%s&sensor=true&language=%s&client="
			+ clientId;
	static String addressResult = null;

	@SuppressWarnings("static-access")
	public MapABCUtillity(String keyString) throws IOException {
		keyString = keyString.replace('-', '+');
		keyString = keyString.replace('_', '/');
		this.key = Base64.decode(keyString);
	}

	public static String queryGoogleAddressByPoi(String location, String country) {
		String url = String.format(QUERYADDRESS, location, country);
		try {
			URL inputUrl = new URL(url);
			MapABCUtillity signer = new MapABCUtillity(cryptoKey);
			String request = signer.signRequest(inputUrl.getPath(), inputUrl.getQuery());
			url = inputUrl.getProtocol() + "://" + inputUrl.getHost() + request;
		} catch (Exception e2) {
			e2.printStackTrace();
		}
		log.info("location:" + location + " country:" + country + " url:" + url);
		// 构造HttpClient的实例
		HttpClient httpClient = new HttpClient();
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
		httpClient.getHttpConnectionManager().getParams().setSoTimeout(30000);
		
		HttpClientParams params = httpClient.getParams();
		params.setHttpElementCharset("UTF8");
		params.setContentCharset("UTF8");
		// 创建GET方法的实例
		GetMethod getMethod = new GetMethod();
		// 使用系统提供的默认的恢复策略
		URI uri = null;
		try {
			uri = new URI(url, true, "UTF8");
			getMethod.setURI(uri);
			getMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler());
			// 执行getMethod
			int statusCode = httpClient.executeMethod(getMethod);
			if (statusCode != HttpStatus.SC_OK) {
				log.error("queryGoogleAddressByPoi Method failed:" + getMethod.getStatusLine());
				getMethod.abort();
				return null;
			}
			// 读取内容
			byte[] responseBody = getMethod.getResponseBody();
			// 处理内容
			String xys = new String(responseBody, "UTF8");
			return xys;
		} catch (HttpException e) {
			// 发生致命的异常，可能是协议不对或者返回的内容有问题
			getMethod.abort();
			e.printStackTrace();
		} catch (IOException e) {
			// 发生网络异常
			getMethod.abort();
			e.printStackTrace();
		} finally {
			// 释放连接
			getMethod.releaseConnection();
		}
		return null;
	}

	public String signRequest(String path, String query)
			throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException, URISyntaxException {

		// Retrieve the proper URL components to sign
		String resource = path + '?' + query;

		// Get an HMAC-SHA1 signing key from the raw key bytes
		SecretKeySpec sha1Key = new SecretKeySpec(key, "HmacSHA1");

		// Get an HMAC-SHA1 Mac instance and initialize it with the HMAC-SHA1
		// key
		Mac mac = Mac.getInstance("HmacSHA1");
		mac.init(sha1Key);

		// compute the binary signature for the request
		byte[] sigBytes = mac.doFinal(resource.getBytes());

		// base 64 encode the binary signature
		String signature = Base64.encodeBytes(sigBytes);

		// convert the signature to 'web safe' base 64
		signature = signature.replace('+', '-');
		signature = signature.replace('/', '_');

		return resource + "&signature=" + signature;
	}

	public static String httpPost(String url, int timeOut) {
		String result = "";
		try {

			HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setReadTimeout(timeOut * 1000);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			conn.connect();
			// // 测试解决乱码
			// OutputStream os = conn.getOutputStream();
			// os.write(cs.getBytes("utf-8"));
			// os.close();

			conn.getResponseCode();
			BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String line = null;
			StringBuffer sb = new StringBuffer();
			while ((line = reader.readLine()) != null) {
				sb.append(line).append("\r\n");
			}
			result = new String(sb.toString().getBytes(), "UTF-8");

		} catch (Exception e) {
			e.printStackTrace();

		}
		return result;
	}

	/*public static void main(String[] args) {
		// String str = MapABCUtillity.getBaiduDetails("10.1302028,45.4541395");
		// log.debug("执行百度地图API 通过经纬度获取坐标 返回值:"+str);
		// str = str.replace("renderReverse&&renderReverse(", "");
		// str = str.replace(")", "");
		// JSONObject jsonObject = JSONObject.fromObject(str);
		// JSONObject object = jsonObject.getJSONObject("result");

		// String result = queryGoogleAddressByPoi("22.5405647,113.9474325");
		// JSONObject jsonObject = JSONObject.fromObject(result);
		// JSONArray array = jsonObject.getJSONArray("results");
		// JSONObject object = (JSONObject) array.get(0);

		String url = "https://api.skyhookwireless.com/wps2/location";
		String xmlString = getXmlInfo();
		String responseString = querySkyhookLocation(url, xmlString);
	}*/

	public static String querySkyhookUri(String urlStr) {
		String responseString = "";
		try {
			HttpURLConnection con = (HttpURLConnection) new URL(urlStr).openConnection();
			con.setDoOutput(true);
			con.setRequestProperty("Pragma:", "no-cache");
			con.setRequestProperty("Cache-Control", "no-cache");
			con.setRequestProperty("Content-Type", "text/xml");

			OutputStreamWriter out = new OutputStreamWriter(con.getOutputStream());
			String xmlInfo = getXmlInfo();
			out.write(new String(xmlInfo.getBytes("UTF-8")));
			out.flush();
			out.close();
			BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));

			for (responseString = br.readLine(); responseString != null; responseString = br.readLine()) {

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return responseString;
	}

	private static String getXmlInfo() {
		StringBuilder sb = new StringBuilder();
		// timezone-lookup='true'
		sb.append(
				"<LocationRQ xmlns='http://skyhookwireless.com/wps/2005' version='2.21' timezone-lookup='true' street-address-lookup='full'>");

		sb.append("<authentication version='2.2'>");
		sb.append(
				"<key key='eJwVwcENACAIBLC3w5Agh6BPJbiUcXdjW0vlDw29HHhqCBvp9iAVFepjgXLkjmksCdwHD0ILGA' username='wuxiaoyong@umeox.com'/>");

		// sb.append("<simple>");
		// sb.append("<username>joe</username>");
		// sb.append("<realm>skyhookwireless.com</realm>");
		// sb.append("</simple>");
		sb.append("</authentication>");

		// sb.append("<access-point>");
		// sb.append("<mac>000C4182D88C</mac>");
		// sb.append("<signal-strength>-50</signal-strength>");
		// sb.append("<age>149</age>");
		// sb.append("</access-point>");

		sb.append("<cell-tower>");
		sb.append("<mcc>460</mcc>");
		sb.append("<mnc>00</mnc>");
		sb.append("<lac>37270</lac>");
		sb.append("<ci>14617</ci>");
		sb.append("<rssi>-38</rssi>");
		sb.append("<age>10582</age>");
		sb.append("</cell-tower>");

		sb.append("</LocationRQ>");

		return sb.toString();
	}

	public static String querySkyhookLocation(String url, String xmlString) {
		String responseString = null;
		// 创建httpclient工具对象
		HttpClient client = new HttpClient();
		// 创建post请求方法
		PostMethod method = new PostMethod();
		URI uri = null;
		try {
			uri = new URI(url, true, "UTF8");
			method.setURI(uri);
			// 设置超时时间
			client.getHttpConnectionManager().getParams().setConnectionTimeout(5000);
			client.getHttpConnectionManager().getParams().setSoTimeout(5000);

			// 设置请求头部类型
			method.setRequestHeader("Content-Type", "text/xml");
			method.setRequestHeader("charset", "utf-8");

			// 设置请求体，即xml文本内容，注：这里写了两种方式，一种是直接获取xml内容字符串，一种是读取xml文件以流的形式
			// myPost.setRequestBody(xmlString);

			// InputStream
			// body=this.getClass().getResourceAsStream("/"+xmlString);
			// myPost.setRequestBody(body);

			method.setRequestEntity(new StringRequestEntity(xmlString, "text/xml", "utf-8"));

			int statusCode = client.executeMethod(method);
			if (statusCode == HttpStatus.SC_OK) {
				BufferedInputStream bis = new BufferedInputStream(method.getResponseBodyAsStream());
				byte[] bytes = new byte[1024];
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				int count = 0;
				while ((count = bis.read(bytes)) != -1) {
					bos.write(bytes, 0, count);
				}
				byte[] strByte = bos.toByteArray();
				responseString = new String(strByte, 0, strByte.length, "utf-8");
				bos.close();
				bis.close();
			} else {
				method.abort();
			}
		} catch (Exception e) {
			e.printStackTrace();
			method.abort();
		} finally {
			method.releaseConnection();
		}

		return responseString;
	}
}
