package com.umeox.babywei.domain;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ux_position")
public class Position extends BaseEntity {
	private static final long serialVersionUID = -9073242317066524089L;
	private String address;
	/**
	 * 001 终端类型
	 */
	private String terminalType;
	/**
	 * 357409039055233 IMEI
	 */
	private String imei;
	/**
	 * 1.0 协议版本
	 */
	private String protocolVersion;
	/**
	 * 10000 渠道号
	 */
	private String channel;
	/**
	 * 命令代码
	 */
	private String code;
	/**
	 *** 消息长度
	 **/
	private String msgLength;
	/**
	 * 2013-11-0411:12:13 上报时间： 上报时的时间 时间字符串为长度为19的 YYYY-MM-DD HH:MM:SS字符串。
	 */
	private Date reportTime;
	/**
	 * 0：来自于服务端命令的上报 1：正常基础信息上报 2：通话上报位置（可以无位置）3：关机上报位置（可以无位置）4：SOS触发上报位置（可以无位置）5：低电上报位置 （可以无位置）6：超出安全区域
	 */
	private String reportReason;
	/**
	 * 0 上报原因属性： 当上报原因为 1-来自于服务端命令的上报 时，上报原因属性为对应的命令序号（随机码）
	 */
	private String reportReasonAttr;
	/**
	 * 39.35487 维度： 当时的GPS位置数据维度(当未开启GPS，此数据填0) 无论当时是否开启GPS，每个位置上报都需要当前关联的基站信息
	 */
	private Double latitude;
	/**
	 * 160.2357 经度： 当时的GPS位置数据经度 (当未开启GPS，此数据填0)
	 */
	private Double longitude;
	/**
	 * 0 速度： 当时的GPS位置数据速度
	 */
	private String speed;
	/**
	 * 460 Mcc：国家代码 
	 * 十六进制 
	 */
	private String mcc;
	/**
	 * 0 Mnc：移动网络号	
	 */
	private String mnc;
	/**
	 * 0 455 Lac：位置区域码
	 * 存储十六进制
	 * 位置区域码, 取值范围：0-65535
	 */
	private String lac;
	/**
	 * 0 25568 Ci：基站编号
	 * 存储十六进制
	 * 0-65535，0-268435455，其中0,65535,268435455不使用 小区编号大于 65535 时为 3G 基站
	 */
	private String ci;
	/**
	 * -95 信号强度： 如信号强度(-95db),则数值为-95
	 * 存储十六进制且正数
	 * (如获得信号强度为正数，则请按照以下公式进行转换：获得的正信号强度 * 2 – 113 
	 * 取值范围：0 到-113dbm，有效值：-107 =< dbm  < -77
	 */
	private String signalStrength;
	/**
	 * 0:GPS 1:LBS 2:WIFI
	 * 0 定位方式： 0 开启GPS定位 1 未开启GPS定位  2:wifi 定位
	 */
	private String locationMode;
	/**
	 * 2013-11-04 11:12:13 定位时间
	 */
	private Date locationTime;
	// 95 电量：当时手表的电量，用0-100的整数表示的百分数
	private Integer electricity;
	// 0 是否在充电(0 未在充电 1 在充电)
	private Integer isElectricity;
	// 0 是否换SIM卡（0 未更换 已更换1）
	private Integer isChangeSim;
	/**
	 * 0 计步： 该信息是根据G-sensor计算走路的步数
	 */
	private String stepCounting;
	/**
	 * 0 气压值： 根据气压值，可以测算海拔高度
	 */
	private String pressureValue;
	// 0 温度
	private String temperature;
	/**
	 * 02 当前状态： 6.4终端状态定义
	 */
	private String status;
	/**
	 * 1 附加基站数目 无论当时是否开启GPS，每个位置上报都需要当前关联的基站信息， 例如:
	 * 除当前关联的基站外，还有4个基站可见，则附加基站数量为4.附加基站数量最多为7
	 */
	private Integer stations;
	/**
	 * 460#0#123#1111#-9 附加基站信息 附加基站信息格式: mcc#mnc#lac#ci|信号强度 例如:
	 * 460#0#123#2453#-91 (注意分隔符号为’#’）
	 * 存储十六进制
	 * 
	 */
	private String stationMsg;

	private String wifiMac;

	/**
	 * wif信号强度
	 * 存储十进制负数
	 * -40dbm~-85dbm
	 */
	private String wifiSignal;

	/**
	 * 精度（单位：米） GPS：默认10米
	 */
	private Integer radius;

	/**
	 * 持有者
	 */
	private Holder holder;
	/**
	 * 标注
	 */
	// private Integer label;//默认为0 表示该位置为附近范围内最新点 1:表示附近范围内出现新的点覆盖这点
	//
	private Integer nearbyPosition;// 附近点数量

	// private String timeQuantum;//时间段

	// private Long olderId;//最早的重叠位置ID

	private Date earlyDate;// 最早时间

	public Integer getRadius() {
		return radius;
	}

	public void setRadius(Integer radius) {
		this.radius = radius;
	}

	public String getWifiMac() {
		return wifiMac;
	}

	public void setWifiMac(String wifiMac) {
		this.wifiMac = wifiMac;
	}

	public String getWifiSignal() {
		return wifiSignal;
	}

	public void setWifiSignal(String wifiSignal) {
		this.wifiSignal = wifiSignal;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "holder_id", nullable = false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getProtocolVersion() {
		return protocolVersion;
	}

	public void setProtocolVersion(String protocolVersion) {
		this.protocolVersion = protocolVersion;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsgLength() {
		return msgLength;
	}

	public void setMsgLength(String msgLength) {
		this.msgLength = msgLength;
	}

	public Date getReportTime() {
		return reportTime;
	}

	public void setReportTime(Date reportTime) {
		this.reportTime = reportTime;
	}

	public String getReportReason() {
		return reportReason;
	}

	public void setReportReason(String reportReason) {
		this.reportReason = reportReason;
	}

	public String getReportReasonAttr() {
		return reportReasonAttr;
	}

	public void setReportReasonAttr(String reportReasonAttr) {
		this.reportReasonAttr = reportReasonAttr;
	}

	public String getSpeed() {
		return speed;
	}

	public void setSpeed(String speed) {
		this.speed = speed;
	}

	public String getMcc() {
		return mcc;
	}

	public void setMcc(String mcc) {
		this.mcc = mcc;
	}

	public String getMnc() {
		return mnc;
	}

	public void setMnc(String mnc) {
		this.mnc = mnc;
	}

	public String getLac() {
		return lac;
	}

	public void setLac(String lac) {
		this.lac = lac;
	}

	public String getCi() {
		return ci;
	}

	public void setCi(String ci) {
		this.ci = ci;
	}

	public String getSignalStrength() {
		return signalStrength;
	}

	public void setSignalStrength(String signalStrength) {
		this.signalStrength = signalStrength;
	}

	public String getLocationMode() {
		return locationMode;
	}

	public void setLocationMode(String locationMode) {
		this.locationMode = locationMode;
	}

	public Date getLocationTime() {
		return locationTime;
	}

	public void setLocationTime(Date locationTime) {
		this.locationTime = locationTime;
	}

	public Integer getElectricity() {
		return electricity;
	}

	public void setElectricity(Integer electricity) {
		this.electricity = electricity;
	}

	public Integer getIsElectricity() {
		return isElectricity;
	}

	public void setIsElectricity(Integer isElectricity) {
		this.isElectricity = isElectricity;
	}

	public Integer getIsChangeSim() {
		return isChangeSim;
	}

	public void setIsChangeSim(Integer isChangeSim) {
		this.isChangeSim = isChangeSim;
	}

	public String getStepCounting() {
		return stepCounting;
	}

	public void setStepCounting(String stepCounting) {
		this.stepCounting = stepCounting;
	}

	public String getPressureValue() {
		return pressureValue;
	}

	public void setPressureValue(String pressureValue) {
		this.pressureValue = pressureValue;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getStations() {
		return stations;
	}

	public void setStations(Integer stations) {
		this.stations = stations;
	}

	public String getStationMsg() {
		return stationMsg;
	}

	public void setStationMsg(String stationMsg) {
		this.stationMsg = stationMsg;
	}

	public Date getEarlyDate() {
		return earlyDate;
	}

	public void setEarlyDate(Date earlyDate) {
		this.earlyDate = earlyDate;
	}

	// public Integer getLabel() {
	// return label;
	// }
	//
	// public void setLabel(Integer label) {
	// this.label = label;
	// }
	// @PrePersist
	// public void prePersist()
	// {
	// this.setLabel(0);
	// }
	//
	public Integer getNearbyPosition() {
		return nearbyPosition;
	}

	public void setNearbyPosition(Integer nearbyPosition) {
		this.nearbyPosition = nearbyPosition;
	}

	// public String getTimeQuantum() {
	// return timeQuantum;
	// }
	//
	// public void setTimeQuantum(String timeQuantum) {
	// this.timeQuantum = timeQuantum;
	// }

	// public Long getOlderId() {
	// return olderId;
	// }
	//
	// public void setOlderId(Long olderId) {
	// this.olderId = olderId;
	// }
	//
}
