package com.umeox.babywei.domain;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by Administrator on 2016/7/14.
 * 国内用户登录短信通知日志:用于统计和日志查看
 */
@Entity
@Table(name="ux_sms_log")
public class SmsLog extends BaseEntity {

    private String mobile;//短信接收方mobile
    private Integer type;//内容类型 0(注册) 1(找回密码) 2(实名认证失败)
    private String msgContent;//短信内容
    private boolean flag;//true:发送成功 false:失败

    public SmsLog() {
    }

    public SmsLog(String mobile) {
        this.mobile = mobile;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    @Column(nullable = false)
    @NotEmpty
    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getMsgContent() {
        return msgContent;
    }

    public void setMsgContent(String msgContent) {
        this.msgContent = msgContent;
    }

}
