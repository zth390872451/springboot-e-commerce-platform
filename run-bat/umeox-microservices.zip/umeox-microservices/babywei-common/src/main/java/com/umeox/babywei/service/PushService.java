package com.umeox.babywei.service;

import java.util.Map;

/**
 * @creator ZTH
 * @modifier ZTH
 * @date 2017-07-26
 * 推送服务
 */
public interface PushService {
	/**
	 * FCM发送通知
	 *
	 * @param target  目标主题
	 * @param title   通知标题
	 * @param content 通知内容
	 * @param extras  自定义消息数据[可选,若不为空，则为带自定义消息的通知。为空，则为纯通知]
	 */
	void sendNoticeAndMsg(String packageName, String target, String title, String content, Map<String, String> extras, Long timeToLive);

	/**
	 * FCM发送纯消息
	 *
	 * @param target  目标主题
	 * @param title   通知标题
	 * @param content 通知内容
	 * @param extras  自定义消息数据[可选,若不为空，则为带自定义消息的通知。为空，则为纯通知]
	 */
	void sendMsg(String packageName, String target, String title, String content, Map<String, String> extras, Long timeToLive);

}
