package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ux_im_group_member")
public class ImGroupMember {
	
	private Long id;
	
	/**
	 * 群组ID(对应imGroup.id)
	 */
	private ImGroup imGroup;
	
	/**
	 * 用户ID（目前对应holder.id）
	 */
	private Long userId;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="im_group_id",nullable=false)
	public ImGroup getImGroup() {
		return imGroup;
	}

	public void setImGroup(ImGroup imGroup) {
		this.imGroup = imGroup;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
}
