package com.umeox.babywei.thrift.app;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TCompactProtocol;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TFramedTransport;
import org.apache.thrift.transport.TSocket;
import org.apache.thrift.transport.TTransport;
import org.apache.thrift.transport.TTransportException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ThriftAppClient {
	private static final Logger log = LoggerFactory.getLogger(ThriftAppClient.class);

	
	private static final String SERVER_IP = "114.55.230.160";
	private static final int SERVER_PORT = 8090;
	private static final int TIMEOUT = 30000;
	private static final String APP_KEY = "app01";
	
	private static TTransport transport = null;
	
	public static PushService.Client getClient(){
		if (transport == null || !transport.isOpen()) {
			transport = new TFramedTransport(new TSocket(SERVER_IP,SERVER_PORT, TIMEOUT));
			try {
				transport.open();
			} catch (TTransportException e) {
				e.printStackTrace();
			}
		}
		// 协议要和服务端一致
		TProtocol protocol = new TCompactProtocol(transport);
		PushService.Client client = new PushService.Client(protocol);
		return client;
	}
	
	
	
	public static void push(PushPayload pushPayload){
		log.info("{}",pushPayload);
		try {
			getClient().push(pushPayload);
		} catch (TException e) {
			log.error("与Thrift服务链接异常： {}",e.getMessage());
			transport.close();
		}
	}
	
	/*public static void main(String[] args) {
		for (int i = 0; i < 100; i++) {
			AppPayload appPayload = getDefaultAppPayload("xx");
			appPayload.setBadge(i);
			pushNotification(appPayload);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}*/
}
