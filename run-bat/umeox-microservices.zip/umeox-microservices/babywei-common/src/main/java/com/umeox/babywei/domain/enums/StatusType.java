/**
 * 
 */
package com.umeox.babywei.domain.enums;

/**
 * @author xmc
 */
public enum StatusType {
	SUCCESS,FAIL
}
