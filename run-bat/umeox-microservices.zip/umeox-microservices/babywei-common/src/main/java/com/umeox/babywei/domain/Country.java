package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * Entity - 国家
 *
 */
@Entity
@Table(name = "ux_country")
public class Country extends BaseEntity{
	
	private static final long serialVersionUID = 1595268921941191653L;
	
	private String mcc;//MCC 移动国家码
	private String mnc;//MNC 移动网络代码
	private String name;//国家和地区名称
	private String code;//国家代码
	@Column(name = "mcc", nullable = false, unique = true, updatable = false)
	public String getMcc() {
		return mcc;
	}
	public void setMcc(String mcc) {
		this.mcc = mcc;
	}
	public String getMnc() {
		return mnc;
	}
	public void setMnc(String mnc) {
		this.mnc = mnc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
}
