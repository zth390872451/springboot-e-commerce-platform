package com.umeox.babywei.conf;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;

@Configuration
public class MvcConfiguration {
	
	/**
	 * 国际化
	 */
	@Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:/i18n/messages");
        messageSource.setFallbackToSystemLocale(false);//关闭使用默认文件，否则使用系统语言的国际化文件
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }
}
