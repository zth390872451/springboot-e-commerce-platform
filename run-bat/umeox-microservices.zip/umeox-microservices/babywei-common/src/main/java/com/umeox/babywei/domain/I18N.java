package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * 国际化
 */
@Entity
@Table(name = "ux_i18n")
public class I18N {
	
	private Long id;
	/**
	 * 国家语言+国家地区代码
	 */
	private String locale;
	
	private String mapkey;
	
	private String mapval;
	

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getMapkey() {
		return mapkey;
	}

	public void setMapkey(String mapkey) {
		this.mapkey = mapkey;
	}

	public String getMapval() {
		return mapval;
	}

	public void setMapval(String mapval) {
		this.mapval = mapval;
	}

}
