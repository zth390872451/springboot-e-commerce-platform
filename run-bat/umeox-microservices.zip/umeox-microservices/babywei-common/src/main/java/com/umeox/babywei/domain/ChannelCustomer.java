package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 * 渠道客户
 * @author Ginger
 *
 */
@Entity
@Table(name = "ux_channel_customer")
public class ChannelCustomer extends BaseEntity {
	private static final long serialVersionUID = 5727559386715674268L;
	/**
	 * 渠道客户
	 */
	private String name;
	/**
	 * 销售渠道
	 */
	private String saleChannel;
	private int smsFlag;//是否需要对短信进行处理，0无需短信处理,1需短信处理 （K1设备激活发送服务端配置时）,国内渠道才会
	
	private Admin admin;
	
	private String apiToken;
	private int tokenFlag;
	
	@Column(nullable = false)
	public String getSaleChannel() {
		return saleChannel;
	}

	public void setSaleChannel(String saleChannel) {
		this.saleChannel = saleChannel;
	}
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="admin_id")
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getSmsFlag(){
		return smsFlag;
	}
	
	public void setSmsFlag(int smsFlag){
		this.smsFlag = smsFlag;
	}

	@Column(length = 255)
	public String getApiToken() {
		return apiToken;
	}

	public void setApiToken(String apiToken) {
		this.apiToken = apiToken;
	}
	
	public int getTokenFlag() {
		return tokenFlag;
	}

	public void setTokenFlag(int tokenFlag) {
		this.tokenFlag = tokenFlag;
	}
	
	
}
