package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "ux_albums")
public class Albums extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1593608122048735528L;
	
	/**
	 * 专辑id
	 */
	private String albumId;
	
	/**
	 * 专辑名称
	 */
	private String albumTitle;
	
	/**
	 * 专辑标签列表
	 */
	private String albumTags;
	
	/**
	 * 专辑简介
	 */
	private String albumIntro;
	
	/**
	 * 分类id
	 */
	private String categoryId;
	
	/**
	 * 封面小图
	 */
	private String coverSmall;
	
	/**
	 * 封面中图
	 */
	private String coverMiddle;
	
	/**
	 * 封面大图
	 */
	private String coverLarge;
	
	/**
	 * 是否有效
	 */
	private boolean enabled;
	
	/**
	 * 是否显示
	 */
	private boolean displayed;
	
	/**
	 * 标签Id
	 */
	private Long tagId;
	
	private int seq;

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getAlbumId() {
		return albumId;
	}

	public void setAlbumId(String albumId) {
		this.albumId = albumId;
	}

	public String getAlbumTitle() {
		return albumTitle;
	}

	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}


	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}

	public String getCoverSmall() {
		return coverSmall;
	}

	public void setCoverSmall(String coverSmall) {
		this.coverSmall = coverSmall;
	}

	public String getCoverMiddle() {
		return coverMiddle;
	}

	public void setCoverMiddle(String coverMiddle) {
		this.coverMiddle = coverMiddle;
	}

	public String getCoverLarge() {
		return coverLarge;
	}

	public void setCoverLarge(String coverLarge) {
		this.coverLarge = coverLarge;
	}

	public boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public String getAlbumIntro() {
		return albumIntro;
	}

	public void setAlbumIntro(String albumIntro) {
		this.albumIntro = albumIntro;
	}

	public String getAlbumTags() {
		return albumTags;
	}

	public void setAlbumTags(String albumTags) {
		this.albumTags = albumTags;
	}

	public Long getTagId() {
		return tagId;
	}

	public void setTagId(Long tagId) {
		this.tagId = tagId;
	}

	public boolean getDisplayed() {
		return displayed;
	}

	public void setDisplayed(boolean displayed) {
		this.displayed = displayed;
	}
	
}
