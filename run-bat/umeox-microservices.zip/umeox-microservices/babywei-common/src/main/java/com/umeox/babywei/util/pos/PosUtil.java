package com.umeox.babywei.util.pos;

public class PosUtil {
	/**
	 * 100米对应的度数
	 * 
	 * @param dis
	 *            距离
	 * @return
	 */
	public static Integer buf(Integer dis) {
		double degToMeter = Math.PI * 6378137 / 180.0;// 6378137赤道半径，一度对应赤道上的一米
		int buf = (int) (dis * 1.0e7 / degToMeter);// 1公里（dis）对应多少度
		return buf;
	}
}
