package com.umeox.babywei.plugin;

import cn.jpush.api.common.resp.APIConnectionException;
import cn.jpush.api.common.resp.APIRequestException;
import cn.jpush.api.common.resp.DefaultResult;
import cn.jpush.api.device.*;
import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.domain.PushClient;
import com.umeox.babywei.repository.PushClientRepository;
import com.umeox.babywei.service.RedisService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Device-API：用于在服务器端查询、设置、更新、删除设备的 tag,alias 信息
 */
public class JPushDeviceApi {

    private static PushClientRepository pushClientRepository;
    private static RedisService redisService;
    protected static final Logger log = LoggerFactory.getLogger(JPushDeviceApi.class);
    static{
        pushClientRepository = (PushClientRepository) ApplicationSupport.getBean("pushClientRepository");
        redisService = (RedisService) ApplicationSupport.getBean("redisServiceImpl");
    }
    /**
     根据 client_id_key 查询 APP的对应的 jpushDeviceAccount
    * @return
            */
    public static com.umeox.babywei.domain.PushClient getJpushAccount(String client_id_key){
        Map<String, com.umeox.babywei.domain.PushClient> map = (Map<String, com.umeox.babywei.domain.PushClient>) redisService.get("pushDeviceAccount");
        if (map == null) {
            map = new HashMap<String, com.umeox.babywei.domain.PushClient>();
            List<com.umeox.babywei.domain.PushClient> list = pushClientRepository.findAll();
            for (com.umeox.babywei.domain.PushClient pushClient : list) {
                String key = pushClient.getClientId();
                map.put(key,pushClient);
            }
            redisService.set("pushDeviceAccount", map);
        }
        com.umeox.babywei.domain.PushClient result = map.get(client_id_key);
        if (result==null) {//缓存中找不到，从数据库中找
            result = pushClientRepository.findOneByLikeClientId(client_id_key);
            if (result!=null)//数据库中找到了，再加入缓存中
            {
                map.put(result.getClientId(),result);
                redisService.set("pushDeviceAccount", map);
            }
        }
        return result;
    }

    /**
     * 根据 client_id_key 找到 pushClient，删除别名对应的设备信息
     * @param client_id_key 这个字段 为 client_id 去除尾部的 _ios _android _device 的部分(如果是海外的wherecom_k2_app_api 或者 wherecom_k2_api_ios，则值为wherecom_k2_ap)
     * @param alias
     */
    public static void deleteAliasByClientIdKey(String client_id_key, String alias){
        PushClient pushClient = getJpushAccount(client_id_key);
        if (pushClient==null){
            log.error("找不到相应的 pushClient 对象 ");
            return ;
        }
        DeviceClient deviceClient = new DeviceClient(pushClient.getPushSecret(), pushClient.getPushKey());
        try {
            DefaultResult result = deviceClient.deleteAlias(alias, null);//null代表所有的平台
            log.info("<JPushDevice>Got result - success" + result);
        } catch (APIConnectionException e) {
            log.error("<Jpush>Jpush Connection error. Should retry later. ", e);
        } catch (APIRequestException e) {
            log.error("<Jpush>Error response from JPush server. Should review and fix it. ", e);
            log.info("<Jpush>HTTP Status: " + e.getStatus());
            log.info("<Jpush>Error Code: " + e.getErrorCode());
            log.info("<Jpush>Error Message: " + e.getErrorMessage());
        }
    }

    public static void main(String[] args) {
     //   DeviceClient deviceClient = new DeviceClient("74cab5e77e6d49959c7a19e1", "d27976158c7123bca213eb9a");//wherecom
        DeviceClient deviceClient = new DeviceClient("b3d3a9019afdb3a2d7a5b227", "300bad27ea2be688804f3f41");//传音
     //   DeviceClient deviceClient = new DeviceClient("9a5f62db56e12417d4eaf436", "9e2491225f33933d77da2da7");//doki
        try {
          // DefaultResult result = deviceClient.deleteAlias("819312432_qq_com", null);//null代表所有的平台 根据别名删除 设备相关信息
          AliasDeviceListResult result = deviceClient.getAliasDeviceList("819312432_qq_com", null); //根据别名查询
           log.info("<JPushDevice>Got result - success" + result);
        } catch (APIConnectionException e) {
            log.error("<Jpush>Jpush Connection error. Should retry later. ", e);
        } catch (APIRequestException e) {
            log.error("<Jpush>Error response from JPush server. Should review and fix it. ", e);
            log.info("<Jpush>HTTP Status: " + e.getStatus());
            log.info("<Jpush>Error Code: " + e.getErrorCode());
            log.info("<Jpush>Error Message: " + e.getErrorMessage());
        }
    }
}
