package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.umeox.babywei.domain.enums.GroupType;

/**
 * @Desc 语聊-群组
 * @author umeox
 *
 */
@Entity
@Table(name = "ux_im_group")
public class ImGroup extends BaseEntity{

	private static final long serialVersionUID = 4327340592599036538L;

	/**
	 * 群组ID
	 * 规则（家庭群组："g_"+holderId;小孩群组：uuid）
	 */
	private String groupId;
	
	/**
	 * 群名
	 */
	private String groupName;
	
	/**
	 * 群类型（0：家庭群组；1：设备群组）
	 */
	private GroupType type;

	
	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public GroupType getType() {
		return type;
	}

	public void setType(GroupType type) {
		this.type = type;
	}
	
}
