package com.umeox.babywei.domain;

import javax.persistence.*;


/**
 * 录音
 * @author Yan
 *
 */
@Entity
@Table(name = "ux_record")
public class Record extends BaseEntity {
	private static final long serialVersionUID = 2747262244527849279L;
	
	/**
	 * 会员
	 */
	private Holder holder;
	
	/**
	 * 会员
	 */
	private Member member;
	
	/**
	 * 设备IMEI
	 */
	private String imei;
	
	
	/**
	 * 录音地址
	 */
	private String path;
	
	/**
	 * 地址
	 */
	private String address;
	
	/**
	 * 经度
	 */
	private Double longitude;
	
	/**
	 * 纬度
	 */
	private Double latitude;
	
	/**
	 * 录音长度
	 */
	private Long length;
	
	private Position position;
	

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="position_id")
	public Position getPosition() {
		return position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="member_id")
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}


	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Long getLength() {
		return length;
	}

	public void setLength(Long length) {
		this.length = length;
	}


	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id")
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	
	

}
