package com.umeox.babywei.domain;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;


/**
 * Entity - 设备
 * 
 * @author Yan
 */
@Entity
@Table(name = "ux_device")
public class Device extends BaseEntity {

	private static final long serialVersionUID = -9073242367066524086L;

	/**
	 * IMEI号
	 */
	private String imei;

	/**
	 * 设备号
	 */
	private String ecode;

	/**
	 * 设备类型
	 */
	private String deviceType;
	
	/**
	 * 二维码
	 */
	private String qrCode;

	/**
	 * 硬件版本号
	 */
	private String version;

	/**
	 * 出厂日期
	 */
	@DateTimeFormat(pattern="yyyy-MM-dd")  
	private Date exFactoryDate;

	/**
	 * 销售国家
	 */
	private String saleCountry;

	/**
	 * 销售渠道
	 */
	private String saleChannel;

	/**
	 * 状态（启用,停用） 不再使用。
	 */
	private Status status;
	/**
	 * 状态（启用,停用）
	 */
	private ActivityStatus activityStatus;
	/**
	 * 持有者信息
	 */
	private Holder holder;

	/**
	 * 服务器信息
	 */
	private Server server;
	/**
	 * KEY：用于IMEI加密
	 */
	private String imeiKey;
	/**
	 * 测试文本：
	服务端生成的随机测试消息
	 */
	private String returnMsg;
	/**
	 * 4位验证码(胶囊显示的)
	 */
	private String captcha;
	/**
	 * 显示时长:
	   单位：分钟,如果返回验证码，在屏幕显示时长
	 */
	private Integer captchaDisplayTime;
	/**
	 * 4位验证码生成时间
	 */
	private Date captchaBuildTime;
	/**
	 * 设备颜色
	 */
	private Colour colour;
	
	/**
	 * 当前连接的服务器IP
	 */
	private String ip;
	/**
	 * 端口
	 */
	private String port;
	/**
	 * 注册随机码
	 */
	private String registCode;
	/**
	 * 设备颜色
	 */
	public enum Colour{
		blue,
		red,
		orange,
		yellow
	};
	private String unboundCode;//解除绑定随机码
	
	private Admin admin;
	/**
	 * 最新解绑时间
	 */
	private Date unbindDate;
	/**
	 * 激活时间
	 */
	private Date activityDate;
	/**
	 * 最新激活时间
	 */
	private Date lastActivityDate;
	
	/**
	 * 绑定码
	 */
	private String bindCode;
	
	/**
	 * 国家代码(十进制)
	 */
	private String mcc;
	
	/**
	 * 设备时区
	 */
	private String timeZone;
	
	/**
	 * 标记（0：默认；1：与jasper平台有关，是合约机）
	 */
	private Integer flag;
	/**
	 *（即SIM卡卡号）
	 */
	private String iccid;

	public String getIccid() {
		return iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public enum Status {
		UN_REGIST {
			public String label() {
				return "未注册";
			}
		},
		REGIST {
			public String label() {
				return "已注册";
			}
		};
		public String label() {
			return this.label();
		}
	}
	/**
	 * 持久化进入数据库，一般不存在null值(有prePersist方法检测)，若存在，可能是数据异常
	 */
	public enum ActivityStatus {
		UN_ACTIVITY {
			public String label() {
				return "未激活";//0
			}
		},
		ACTIVITY {
			public String label() {
				return "已激活";//1
			}
		};

		public String label() {
			return this.label();
		}
	}
	// ============================================================//

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	
	@Column(name = "imei", nullable = false, unique = true, updatable = false, length = 20)
	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}
	
	@Column(name = "device_type")
	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	@Column(name = "ecode")
	public String getEcode() {
		return ecode;
	}

	public void setEcode(String ecode) {
		this.ecode = ecode;
	}
	@Column(name = "colour")
	public Colour getColour(){
		return colour;
	}
	public void setColour(Colour colour){
		this.colour = colour;
	}
	@Column(name = "qr_code")
	public String getQrCode() {
		return qrCode;
	}

	public void setQrCode(String qrCode) {
		this.qrCode = qrCode;
	}

	@Column(name = "version", length = 32)
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Column(name = "ex_factory_date")
	public Date getExFactoryDate() {
		return exFactoryDate;
	}

	public void setExFactoryDate(Date exFactoryDate) {
		this.exFactoryDate = exFactoryDate;
	}

	@Column(name = "sale_country", length = 32)
	public String getSaleCountry() {
		return saleCountry;
	}

	public void setSaleCountry(String saleCountry) {
		this.saleCountry = saleCountry;
	}

	@Column(name = "sale_channel", length = 32)
	public String getSaleChannel() {
		return saleChannel;
	}

	public void setSaleChannel(String saleChannel) {
		this.saleChannel = saleChannel;
	}

	@Enumerated
	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "holder_id")
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="server_id")
	public Server getServer() {
		return server;
	}
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="admin_id")
	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public void setServer(Server server) {
		this.server = server;
	}
	
	 public String getImeiKey() {
		return imeiKey;
	}

	public void setImeiKey(String imeiKey) {
		this.imeiKey = imeiKey;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public Integer getCaptchaDisplayTime() {
		return captchaDisplayTime;
	}

	public void setCaptchaDisplayTime(Integer captchaDisplayTime) {
		this.captchaDisplayTime = captchaDisplayTime;
	}

	public Date getCaptchaBuildTime() {
		return captchaBuildTime;
	}

	public void setCaptchaBuildTime(Date captchaBuildTime) {
		this.captchaBuildTime = captchaBuildTime;
	}
	
	
	@Enumerated
	public ActivityStatus getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(ActivityStatus activityStatus) {
		this.activityStatus = activityStatus;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getRegistCode() {
		return registCode;
	}

	public void setRegistCode(String registCode) {
		this.registCode = registCode;
	}

	public String getUnboundCode() {
		return unboundCode;
	}

	public void setUnboundCode(String unboundCode) {
		this.unboundCode = unboundCode;
	}
	
	@Column(name = "unbind_date")
	public Date getUnbindDate() {
		return unbindDate;
	}

	public void setUnbindDate(Date unbindDate) {
		this.unbindDate = unbindDate;
	}
	@Column(name = "activity_date")
	public Date getActivityDate() {
		return activityDate;
	}

	public void setActivityDate(Date activityDate) {
		this.activityDate = activityDate;
	}

	public Date getLastActivityDate() {
		return lastActivityDate;
	}

	public void setLastActivityDate(Date lastActivityDate) {
		this.lastActivityDate = lastActivityDate;
	}

	public String getBindCode() {
		return bindCode;
	}

	public void setBindCode(String bindCode) {
		this.bindCode = bindCode;
	}

	public String getMcc() {
		return mcc;
	}

	public void setMcc(String mcc) {
		this.mcc = mcc;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}

	@PrePersist
	public void prePersist(){
		if(this.getStatus()==null){
			this.setStatus(Status.UN_REGIST);//初始化未注册
		}
		if(this.getActivityStatus()==null){
			this.setActivityStatus(ActivityStatus.UN_ACTIVITY);//初始化未激活
		}
		if(this.getCaptchaDisplayTime()==null){
			this.setCaptchaDisplayTime(10);//默认10分钟
		}
		if(this.getFlag()==null){
			this.setFlag(0);//默认0 与平台无关
		}
	}
}
