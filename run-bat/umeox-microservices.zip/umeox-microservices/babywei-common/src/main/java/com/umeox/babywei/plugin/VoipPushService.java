package com.umeox.babywei.plugin;

import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;
import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.ApnsInfo;
import com.umeox.babywei.repository.ApnsInfoRepository;
import com.umeox.babywei.service.RedisService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * 使用 voip 向ios发送信息
 */
public class VoipPushService {

    private static SettingProperties settingProperties ;
    private static RedisService redisService;
    private static ApnsInfoRepository apnsInfoRepository;
    protected static final Logger log = LoggerFactory.getLogger(VoipPushService.class);
    static{
        settingProperties   = (SettingProperties) ApplicationSupport.getBean("settingProperties");
        redisService = (RedisService) ApplicationSupport.getBean("redisServiceImpl");
        apnsInfoRepository = (ApnsInfoRepository) ApplicationSupport.getBean("apnsInfoRepository");
    }

    /**
     * 发送 标题、内容自定义参数
     * 发送自定义消息
     * @param deviceToken
     * @param param
     */
    public static void pushMessage(String packageName,String deviceToken,String title,String body,Map<String, String> param){
        ApnsInfo apnsInfo = (ApnsInfo) redisService.get(packageName);
        if (apnsInfo==null){
            apnsInfo = apnsInfoRepository.findOneByPackageName(packageName);
            if (apnsInfo!=null){
                redisService.set(packageName,apnsInfo,30*60);
            }else {
                log.error("packageName:{} not map to ApnsInfo",packageName);
                return ;
            }
        }
        log.info("pushMessage,deviceToken:{},title:{},body:{},param:{}", deviceToken,title,body,param.toString());
//        1、建立连接
        ApnsService service =
                APNS.newService()
                        .withCert(apnsInfo.getPath(),apnsInfo.getSecret()).withProductionDestination()
                        .withAppleDestination(false)
                        .build();
//        2、构建发送信息
        String payload = APNS.newPayload().alertTitle(title).customFields(param).alertBody(body).build();
//        3、发送
        service.push(deviceToken, payload);
//        4、发送结果(debug级别)
        service.getInactiveDevices();
    }
    //测试 ios的voip推送
    /*public static void main(String[] args) {
        //推送
        Map<String, String> param = new HashMap<String, String>();
        param.put("cmd", Push.VIDEO_DEVICE_NOTIFY_JOINC_HANNEL + "");
        param.put("holderId", 157368 + "");
        param.put("channel", "渠道号");
        param.put("timestamp", System.currentTimeMillis() + "");

        String title = "标题";
        String msgContent = "内容msgContent";
        String deviceToken = "3541d921fe7ecb3842b9d60d586a5fd65919ded1bc7c166ab4e3adb1212f554b";//deviceToken
        String voipCertificatePath ="D:\\zth\\wxb.p12";
        String voipCertificatePassword ="123456";
        ApnsService service =
                APNS.newService()
                        .withCert(voipCertificatePath,voipCertificatePassword).withProductionDestination()
                        .withAppleDestination(false)
                        .build();
        String payload = APNS.newPayload().alertTitle(title).customFields(param).alertBody(msgContent).build();
        ApnsNotification push = service.push(deviceToken, payload);
//       To query the feedback service for inactive devices:
        Map<String, Date> inactiveDevices = service.getInactiveDevices();
        System.out.println("inactiveDevices = " + inactiveDevices);
    }*/
}
