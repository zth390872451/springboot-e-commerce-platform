package com.umeox.babywei.util;

/**
 * @author umeox
 * 坐标本地转换辅助工具
 */
public class PointConvert {

    //gcj-02坐标转百度坐标
    public static Point gcj02ToBaidu(double lat, double lng) {
        return Point.bd_encrypt(new Point(lat, lng));
    }
}
