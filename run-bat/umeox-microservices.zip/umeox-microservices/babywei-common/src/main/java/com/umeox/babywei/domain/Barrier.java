package com.umeox.babywei.domain;

import javax.persistence.*;


@Entity
@Table(name = "ux_barrier")
public class Barrier extends BaseEntity {
	private static final long serialVersionUID = -9073242367066524089L;
	
	/**
	 * 监护人
	 */
	private Member member;
	
	/**
	 * 持有者
	 */
	private Holder holder;
	
	/**
	 * 地址
	 */
	private String address;
	
	/**
	 * 经度
	 */
	private Double longitude;
	
	/**
	 * 纬度
	 */
	private Double latitude;
	
	/**
	 * 区域范围
	 */
	private Double radius;
	
	/**
	 * 启用 1开启 0未开启
	 */
	private int open = 0;
	
	private String railName;
	
	/**
	 * 星期选择项
	 */
	private String weekTime;
	

	/**
	 * 围栏开始时间
	 */
	private String startHours;
	
	/**
	 * 围栏结束时间
	 */
	private String endHours;

	public Barrier() {
	}

	public Barrier(Holder holder, String address, Double longitude, Double latitude,Double radius,Member member, int open) {
		this.holder = holder;
		this.address = address;
		this.longitude = longitude;
		this.latitude = latitude;
		this.radius = radius;
		this.member = member;
		this.open = open;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="holder_id",nullable=false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(nullable=false)
	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	@Column(nullable=false)
	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	@Column(nullable=false)
	public Double getRadius() {
		return radius;
	}

	public void setRadius(Double radius) {
		this.radius = radius;
	}

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="member_id",nullable=false)
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public int isOpen() {
		return open;
	}

	public void setOpen(int open) {
		this.open = open;
	}

	public String getRailName() {
		return railName;
	}

	public void setRailName(String railName) {
		this.railName = railName;
	}

	public String getWeekTime() {
		return weekTime;
	}

	public void setWeekTime(String weekTime) {
		this.weekTime = weekTime;
	}

	public String getStartHours() {
		return startHours;
	}

	public void setStartHours(String startHours) {
		this.startHours = startHours;
	}

	public String getEndHours() {
		return endHours;
	}

	public void setEndHours(String endHours) {
		this.endHours = endHours;
	}

}
