package com.umeox.babywei.repository;

import com.umeox.babywei.domain.PushAppInfo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PushAppInfoRepository extends JpaRepository<PushAppInfo, Long>{
	
	PushAppInfo findOneByPackageName(String packageName);
}
