package com.umeox.babywei;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import com.umeox.babywei.conf.Constants;

@Component
public class ApplicationSupport implements DisposableBean, ApplicationContextAware {

	private static ApplicationContext appContext;

	// 获取配置文件参数值
	public static String getParamVal(String paramKey){
		return appContext.getEnvironment().getProperty(paramKey);
	}
	
	private static boolean hasProfile(String profile) {
		if (!appContext.getEnvironment().getProperty("spring.profiles.active").startsWith(profile)) {
			return false;
		}
		return true;
	}

	// 测试环境
	public static boolean isDevEnv() {
		//return hasProfile(Constants.SPRING_PROFILE_DEVELOPMENT) || hasProfile(Constants.SPRING_PROFILE_DEVELOPMENT_AMAZON);
		return false;
	}
	
	// 国内环境 开发、测试和生产
	public static boolean isChinaEnv() {
		return hasProfile(Constants.SPRING_PROFILE_PRODUCTION_CHINA)
				|| hasProfile(Constants.SPRING_PROFILE_DEVELOPMENT_CHINA)
				|| hasProfile(Constants.SPRING_PROFILE_TEST_CHINA);
	}

	// 国外环境 开发、测试和生产
	public static boolean isAmazonEnv() {
		return hasProfile(Constants.SPRING_PROFILE_PRODUCTION_AMAZON)
				|| hasProfile(Constants.SPRING_PROFILE_DEVELOPMENT_AMAZON)
				|| hasProfile(Constants.SPRING_PROFILE_TEST_AMAZON)
		 		|| hasProfile(Constants.SPRING_PROFILE_PRODUCTION_AMAZON_OAXIS);
	}
	
	public static boolean isEnv(String profile){
		return  hasProfile(profile);		
	}

	// 获取bean对象
	public static Object getBean(String name) {
		Assert.hasText(name);
		return appContext.getBean(name);
	}

	public static <T> T getBean(Class<T> clazz) {
		return appContext.getBean(clazz);
	}

	public static <T> Map<String, T> getBeansOfType(Class<T> type) {
		return appContext.getBeansOfType(type);
	}

	// 根据系统环境国际化
	public static String getMessageByEnv(String code) {
		if (isChinaEnv()) {
			return getMessage(code, null, Locale.SIMPLIFIED_CHINESE);
		} else {
			return getMessage(code, null, Locale.ENGLISH);
		}
	}

	public static String getMessageByEnv(String code,Object[] args) {
		if (isChinaEnv()) {
			return getMessage(code, args, Locale.SIMPLIFIED_CHINESE);
		} else {
			return getMessage(code, args, Locale.ENGLISH);
		}
	}


	public static String getMessage(String code, Locale locale) {
		return getMessage(code, null, locale);
	}

	// 占位符
	public static String getMessage(String code, Object[] args, Locale locale) {
		String result = appContext.getMessage(code, args, null, locale);
		return result;
	}

	public static String getCloudStorageEndPoint(String domain, String bucket) {
		if (isAliyunOssDomain(domain)) {
			//aliyun oss like:  wx01.oss-cn-hangzhou.aliyuncs.com
			return "http://" + bucket + "." + domain + "/";
		} else if (isAwsS3Domain(domain)) {
			// aws s3 like: s3-eu-west-1.amazonaws.com/wherecom-ireland
			return "http://" + domain + "/" + bucket + "/";
		} else {
			//自己服务
			return "http://" + domain + "/";
		}
	}

	public static String getCloudStorageURL(String domain, String bucket, String fileId) {		
		if (!fileId.startsWith("http://")) {
			try {
				fileId =  getCloudStorageEndPoint(domain, bucket) + URLEncoder.encode(fileId,"utf-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		return fileId;
	}

	public static boolean isAwsS3Domain(String domain) {
		if (domain.contains(".amazonaws.com")) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isAliyunOssDomain(String domain) {
		if (domain.contains(".aliyuncs.com")) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		appContext = applicationContext;
	}

	@Override
	public void destroy() throws Exception {
		appContext = null;
	}
	
	public static ApplicationContext getApplicationContext(){
		return appContext;
	}
}
