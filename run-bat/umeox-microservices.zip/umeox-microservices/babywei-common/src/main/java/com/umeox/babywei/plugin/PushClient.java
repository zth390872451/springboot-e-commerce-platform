package com.umeox.babywei.plugin;

import cn.jpush.api.JPushClient;
import cn.jpush.api.common.resp.APIConnectionException;
import cn.jpush.api.common.resp.APIRequestException;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.PushPayload;
import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.repository.PushClientRepository;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.util.CommonUtils;
import com.umeox.babywei.util.Encryptor;
import com.umeox.babywei.util.PushUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.constant.PushConstant.DEFAULT_TIME_TO_LIVE;

/**
 * 极光推送应用客户端
 */
public class PushClient {

    protected static final Logger LOGGER = LoggerFactory.getLogger(PushClient.class);
    //默认应用Key和密钥
    private static final String appKey = "b0c80ae505561d91535df2ed";
    private static final String masterSecret = "27c470b9c607bd408f153acf";

    //极光推送应用实例，每1小时更新一次
    private static Map<String, JPushClient> jpushClientInstanceMap = new HashMap<String, JPushClient>();
    private static Long lastCreateJpushClientInstanceTime = 0l;

    private static PushClientRepository pushClientRepository;
    private static RedisService redisService;

    static {
        pushClientRepository = (PushClientRepository) ApplicationSupport.getBean("pushClientRepository");
        redisService = (RedisService) ApplicationSupport.getBean("redisServiceImpl");
        //初始化
        createJpushClientInstanceMap();
    }

    //从数据库获取信息创建实例
    public static void createJpushClientInstanceMap() {
        synchronized (lastCreateJpushClientInstanceTime) {
            lastCreateJpushClientInstanceTime = System.currentTimeMillis();
            List<com.umeox.babywei.domain.PushClient> pushClients = pushClientRepository.findAll();
            if (pushClients != null && !pushClients.isEmpty()) {
                for (com.umeox.babywei.domain.PushClient c : pushClients) {
                    String k = c.getDeviceType();
                    if (!StringUtils.isEmpty(c.getSaleChannel())) {
                        k = k + "_" + c.getSaleChannel();
                    }
                    jpushClientInstanceMap.put(k, new JPushClient(c.getPushSecret(), c.getPushKey()));
                }
            }
            LOGGER.info("从数据库获取信息创建实例", lastCreateJpushClientInstanceTime);
        }
    }

    public static JPushClient getJpushClient(String deviceType, String saleChannel) {
        if (StringUtils.isEmpty(deviceType)) {
            LOGGER.error("设备类型must not null");
            return null;
        }

        //更新instance策略，每间隔一个小时更新一次
        if (System.currentTimeMillis() > (lastCreateJpushClientInstanceTime + 3600 * 1000)) {
            createJpushClientInstanceMap();
        }

        String key = deviceType;
        JPushClient pushClient = jpushClientInstanceMap.get(key);

        if (!StringUtils.isEmpty(saleChannel)) {
            //根据设备类型+渠道号去获取实例
            key = key + "_" + saleChannel;
            if (jpushClientInstanceMap.get(key) != null) {
                pushClient = jpushClientInstanceMap.get(key);
            }
        }

        if (pushClient == null) {
            //使用默认的构造
            pushClient = new JPushClient(masterSecret, appKey);
        }
        return pushClient;
    }


    //iOS通知
    public static void sendPushIosNotification(String alias, String alert, Map<String, String> extras, String deviceType, String saleChannel) {
        if (PushUtils.fcmPush(alert, alias, alert, extras, DEFAULT_TIME_TO_LIVE)) {
            ;//使用了FCM推送
        } else {
            String md5Alias = Encryptor.parseStrToMd5U16(alias);
            alias = CommonUtils.aliasHandle(alias);
            PushPayload payload = PushBuild.buildPushObjectIosNotification(new String[]{md5Alias, alias}, alert, extras);
            pushInfo(deviceType, saleChannel, payload);
            LOGGER.info("alias = {}，payload = {}，deviceType = {},saleChannel = {}", alias, payload, deviceType.toString(), saleChannel);
        }
    }


    //Android通知
    public static void sendPushAndroidNotification(String alias, String alert, Map<String, String> extras, String deviceType, String saleChannel) {
        if (PushUtils.fcmPush(alert, alias, alert, extras, DEFAULT_TIME_TO_LIVE)) {
            ;//使用了FCM推送
        } else {
            String md5Alias = Encryptor.parseStrToMd5U16(alias);
            alias = CommonUtils.aliasHandle(alias);
            PushPayload payload = PushBuild.buildPushObjectAndroidNotification(new String[]{md5Alias, alias}, alert, extras);
            pushInfo(deviceType, saleChannel, payload);
            LOGGER.info("alias = {}，payload = {}，deviceType = {},saleChannel = {}", alias, payload, deviceType.toString(), saleChannel);
            PushUtils.pushToApp(alias, "", alert, "", extras);
        }
    }


    //iOS通知和自定义消息,Android通知 不需要区分平台调用
    public static void sendTitlePushMessage(String title, String alias, String msgContent, Map<String, String> extras, String deviceType, String saleChannel) {
        if (PushUtils.fcmPush(title, alias, msgContent, extras, DEFAULT_TIME_TO_LIVE)) {
            ;//使用了FCM推送
        } else {
            String md5Alias = Encryptor.parseStrToMd5U16(alias);
            alias = CommonUtils.aliasHandle(alias);
            PushPayload payload = PushBuild.buildTitlePushObjectMessage(title, new String[]{md5Alias, alias}, msgContent, extras);
            pushInfo(deviceType, saleChannel, payload);
            LOGGER.info("alias = {}，payload = {}，deviceType = {},saleChannel = {}", alias, payload, deviceType.toString(), saleChannel);
            PushUtils.pushToApp(alias, title, msgContent, "", extras);
        }
    }


    //Android 自定义消息 自定义离线时间
    public static void sendAndroidTitlePushMessage(String title, String alias, String msgContent, Map<String, String> extras, String deviceType, String saleChannel, long timeToLive) {
        if (PushUtils.fcmPush(title, alias, msgContent, extras, timeToLive)) {
            ;//使用了FCM推送
        } else {
            String md5Alias = Encryptor.parseStrToMd5U16(alias);
            alias = CommonUtils.aliasHandle(alias);
            PushPayload payload = PushBuild.buildAndroidTitlePushMessage(title, new String[]{md5Alias, alias}, msgContent, extras, timeToLive);
            pushInfo(deviceType, saleChannel, payload);
            LOGGER.info("alias = {}，payload = {}，deviceType = {},saleChannel = {}", alias, payload, deviceType.toString(), saleChannel);
            PushUtils.pushToApp(alias, title, msgContent, "", extras);
        }
    }


    //发送群聊消息
    public static void sendTagPushMessage(String title, String tagValue, String msgContent, Map<String, String> extras, String deviceType, String saleChannel) {
        PushPayload payload = PushBuild.buildTagPushObjectMessage(title, tagValue, msgContent, extras);
        pushInfo(deviceType, saleChannel, payload);
    }

    private static void pushInfo(String deviceType, String saleChannel, PushPayload payload) {
        try {
            PushResult result = getJpushClient(deviceType, saleChannel).sendPush(payload);
            LOGGER.info("<Jpush>Got result - " + result);
        } catch (APIConnectionException e) {
            LOGGER.error("<Jpush>Jpush Connection error. Should retry later. ", e);
        } catch (APIRequestException e) {
            LOGGER.error("<Jpush>Error response from JPush server. Should review and fix it. ", e);
            LOGGER.info("<Jpush>HTTP Status: " + e.getStatus());
            LOGGER.info("<Jpush>Error Code: " + e.getErrorCode());
            LOGGER.info("<Jpush>Error Message: " + e.getErrorMessage());
        }
    }

	/*public static void main(String[] args) throws APIConnectionException, APIRequestException {
        JPushClient jPushClient = new JPushClient("27c470b9c607bd408f153acf", "b0c80ae505561d91535df2ed");
		Map<String, String> extras = new HashMap<String, String>();
		extras.put("cmd", "cmd");
		extras.put("holderId","holderId");
		PushPayload payload = PushBuild.buildAndroidTitlePushMessage("test",new String[]{"15019271280","2c395bf1352f83ef"},"msgContent",  extras);
		try {
			PushResult result = jPushClient.sendPush(payload);
			LOGGER.info("<Jpush>Got result - " + result);
		} catch (APIConnectionException e) {
			LOGGER.error("<Jpush>Jpush Connection error. Should retry later. ", e);
		} catch (APIRequestException e) {
			LOGGER.error("<Jpush>Error response from JPush server. Should review and fix it. ", e);
			LOGGER.info("<Jpush>HTTP Status: " + e.getStatus());
			LOGGER.info("<Jpush>Error Code: " + e.getErrorCode());
			LOGGER.info("<Jpush>Error Message: " + e.getErrorMessage());
		}
	}*/

}
