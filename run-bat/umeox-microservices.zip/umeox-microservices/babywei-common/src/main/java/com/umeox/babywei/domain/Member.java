package com.umeox.babywei.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.umeox.babywei.domain.enums.GenderType;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;


/**
 * Entity - 会员
 * @author umeox
 */
@Entity
@Table(name = "ux_member")
public class Member extends BaseEntity {
	
	private static final long serialVersionUID = 100007152668889L;
	
	public final static int PUSH_TYPE_DEFAULT = 0;
	public final static int PUSH_TYPE_JPUSH = 1;
	
	/**
	 * 手机（账号：mobile/email）
	 * 其它补充：  mobile不唯一，值来源还包括： 第三方APP跳转传送的手机号，通过OpenAPI在绑定设备时传入的手机号或第三方OpenID(例 微信OpenID)
	 * 注册的手机号在APP和跳转APP及OpenAPI手机号绑定的互相影响
	 */
	private String mobile; 
	
	/**
	 * 电话号码(海外)
	 */
	private String tel;

	/**
	 * 密码
	 */
	private String password;

	/**
	 * 昵称
	 */
	private String nickName; 
	
	
	private String locationCode;//主动定位/录音随机码
	
	private String appId;
	//值为：1、 iOS 2、苹果的voip证书对应的token【苹果普通证书的设备token与voip证书的token不是同一个token】
	private String token;

	/**
	 * 推送类型(null或0走默认的推送，1走极光推送)
	 */
	private Integer pushType;
	
	/**
	 * oauth2认证的clientId
	 */
	private String clientId;
	
	private Set<Monitor> monitorSet = new HashSet<Monitor>();
	private Set<Message> messageSet;
	
	/**
	 * 用户扩展表
	 */
	private MemberExt memberExt;
	
	private String name;
	private String email;
	private String address;
	private String birthday;
	private String cap;
	private String familyName;
	private String hobbies;
	private String profession;
	
	/**
	 * 头像--微话饼&k3
	 * 系统图标（1-8数字，自定义头像）
	 */
	private String avatar;
	
	/**
	 * 性别（0：男；1：女）
	 */
	private GenderType gender;

	/**
	 * 小米登录: xiaomi:包名:别名标识
	 * 华为登录: huawei:包名:deviceToken【手机客户端登录获取的唯一标识】
	 */
	private String loginInfo;

	/**
	 * 用户最后一次登录的APP的包名
	 */
	private String packageName;

	/**
	 * 第三方推送平台：0代表私有， 1、极光 2、FCM
	 */
	private Integer pushMode;

	public static final Integer UMEOX_PUSH = 0;
	public static final Integer JPUSH_PUSH = 1;
	public static final Integer FCM_PUSH = 2;
	/**
	 * 当前用户最近一次登录的APP的版本号
	 */
	private String appVersion;

	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public Integer getPushMode() {
		return pushMode;
	}

	public void setPushMode(Integer pushMode) {
		this.pushMode = pushMode;
	}

	public String getLoginInfo() {
		return loginInfo;
	}

	public void setLoginInfo(String loginInfo) {
		this.loginInfo = loginInfo;
	}
	
	
	@OneToOne(cascade = {CascadeType.PERSIST},mappedBy = "member")
	@JsonBackReference
	public MemberExt getMemberExt() {
		return memberExt;
	}

	public void setMemberExt(MemberExt memberExt) {
		this.memberExt = memberExt;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public GenderType getGender() {
		return gender;
	}

	public void setGender(GenderType gender) {
		this.gender = gender;
	}

	public Integer getPushType() {
		return pushType;
	}

	public void setPushType(Integer pushType) {
		this.pushType = pushType;
	}

	public Member(Member member){
		super();
		this.mobile = member.getMobile();
		this.password = member.getPassword();
	}
	
	public Member() {
	}
	

	public Member(Long id) {
		super.setId(id);
	}

	@Column(name = "mobile", nullable = false, unique = true, updatable = false)
	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}


	public String getLocationCode() {
		return locationCode;
	}


	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	/**
	 * 因为最初安卓端在调用appid字段在登录回调接口(iosInit)中传入的appid是null，所以后面使用init接口替换，
	 * 为了兼容推送，所以做如下处理
	 * @return 最后一次登录APP的包名
	 */
	public String getAppId() {
		if (StringUtils.isEmpty(appId)){
			return packageName;
		}
		return appId;
	}


	public void setAppId(String appId) {
		this.appId = appId;
	}


	public String getToken() {
		return token;
	}


	public void setToken(String token) {
		this.token = token;
	}

	@OneToMany(fetch = FetchType.LAZY)
	//@JoinColumn(name="monitor_set",referencedColumnName="id")
	@JoinTable(name="ux_member_monitor_set" ,joinColumns = {@JoinColumn(name="ux_member", referencedColumnName="id")},
			inverseJoinColumns = {@JoinColumn(name="monitor_set",referencedColumnName="id")})
	//TODO xmc  key ux_member
	public Set<Monitor> getMonitorSet() {
		return monitorSet;
	}


	public void setMonitorSet(Set<Monitor> monitorSet) {
		this.monitorSet = monitorSet;
	}


	@OneToMany(mappedBy = "member",fetch = FetchType.LAZY)
	public Set<Message> getMessageSet() {
		return messageSet;
	}


	public void setMessageSet(Set<Message> messageSet) {
		this.messageSet = messageSet;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getBirthday() {
		return birthday;
	}


	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}


	public String getCap() {
		return cap;
	}


	public void setCap(String cap) {
		this.cap = cap;
	}


	public String getFamilyName() {
		return familyName;
	}


	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}


	public String getHobbies() {
		return hobbies;
	}


	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}


	public String getProfession() {
		return profession;
	}


	public void setProfession(String profession) {
		this.profession = profession;
	}
	
	@Transient
	public String getLocale(){
		if (getMemberExt() != null) {
			return getMemberExt().getLocale();
		}
		return null;
	}
	/*@PrePersist
	public void prePersist(){
		if (this.getAvatar() == null) {
			this.setAvatar("0");//注册默认头像
		}
	}*/
}
