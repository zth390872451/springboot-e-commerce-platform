package com.umeox.babywei.util;


import com.umeox.babywei.domain.Member;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MapUtil {
	private final static double EARTH_RADIUS = 6378.137;// 地球半径

	private static double rad(double d) {
		return d * Math.PI / 180.0;
	}

	public static double getDistance(double lata, double lnga, double latb,
			double lngb) {
		return cal2PDis(lata,lnga,latb,lngb);
	}
	
	public static double cal2PDis(double lat1, double lon1, double lat2, double lon2)
	{
		double result = 0;
        double lat = Math.abs(lat1 - lat2);
        double lon = Math.abs(lon1 - lon2);
        double latRadian = Math.toRadians(lat1);
        double kmPerLat = 111.13295 - 0.55982 * Math.cos(2 * latRadian) + 0.00117 * Math.cos(4 * latRadian);
        double latKm = lat * kmPerLat;
        double kmPerLon = 111.41288 * Math.cos(latRadian)
                - 0.09350 * Math.cos(3 * latRadian) + 0.00012 * Math.cos(5 * latRadian);
        double lonKm = lon * kmPerLon;
        result = Math.sqrt(latKm * latKm + lonKm * lonKm) * 1000;
		return result;
	}

	/**
	 * 判断坐标是不是在给定的坐标半径范围内
	 * 
	 * @return Boolean
	 */
	public static Boolean check(Double latitude, Double longitude, Double lat,
			Double log, Double r) {
		double distance = getDistance(latitude, longitude, lat, log);
		return  r > distance;
	}
	
	
	private static double distance(double lat1, double lon1, double lat2, double lon2) {
        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2))
                + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2))
                * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        return (dist);
    }

    private static double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }

    private static double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
    }

	/*
	利用到了java的内省（ Introspector ）和反射（reflect）机制。
	其思路为： 通过类 Introspector 来获取某个对象的 BeanInfo 信息，
	然后通过 BeanInfo 来获取属性的描述器PropertyDescriptor，
	再利用属性描述器获取某个属性对应的 getter/setter 方法，
	然后通过反射机制来getter和setter。*/
	/**
	 *	map转对象
     */
	public static Object convertMap(Class type, Map map)
			throws IntrospectionException, IllegalAccessException,
			InstantiationException, InvocationTargetException {
		BeanInfo beanInfo = Introspector.getBeanInfo(type); // 获取类属性
		Object obj = type.newInstance(); // 创建 JavaBean 对象

		// 给 JavaBean 对象的属性赋值
		PropertyDescriptor[] propertyDescriptors =  beanInfo.getPropertyDescriptors();
		for (int i = 0; i< propertyDescriptors.length; i++) {
			PropertyDescriptor descriptor = propertyDescriptors[i];
			String propertyName = descriptor.getName();

			if (map.containsKey(propertyName)) {
				// 下面一句可以 try 起来，这样当一个属性赋值失败的时候就不会影响其他属性赋值。
				Object value = map.get(propertyName);
				Object[] args = new Object[1];
				args[0] = value;
				descriptor.getWriteMethod().invoke(obj, args);
			}
		}
		return obj;
	}

	/**
	 * @return	对象转map
     */
	public static Map convertBean(Object bean) throws IntrospectionException, InvocationTargetException, IllegalAccessException {
		Class beanClass = bean.getClass();
		Map returnMap = new HashMap();
		BeanInfo beanInfo = Introspector.getBeanInfo(beanClass);//将JavaBean中的属性封装起来进行操作。在程序把一个类当做JavaBean来看，就是调用Introspector.getBeanInfo()方法，得到的BeanInfo对象封装了把这个类当做JavaBean看的结果信息，即属性的信息。
		PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
		for (int i = 0; i < propertyDescriptors.length; i++) {
			PropertyDescriptor propertyDescriptor = propertyDescriptors[i];
			String propertyName = propertyDescriptor.getName();
			 if (!propertyName.equals("class")){
				 Method readMethod = propertyDescriptor.getReadMethod();
				 Object result = readMethod.invoke(bean,null);
				 if (result!=null){
					 returnMap.put(propertyName,result);
				 }else {
					 returnMap.put(propertyName,"");
				 }
			 }
		}
		return returnMap;
	}


/*	public static void main(String[] args) throws Exception {
		Member member = new Member();
	}*/
	/**
	 * 首字母转大写
	 * @param s 字符串
	 * @return 首字母大写的字符串
	 * @date 2015年4月11日 上午10:24:41
	 * @author zoufaxiang
	 */
	public static String toUpperCaseFirstOne(String s){
		if(Character.isUpperCase(s.charAt(0)))
			return s;
		else
			return (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
	}

}
