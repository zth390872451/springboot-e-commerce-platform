package com.umeox.babywei.repository;

import com.umeox.babywei.domain.ApnsInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component("apnsInfoRepository")
public interface ApnsInfoRepository extends JpaRepository<ApnsInfo, Long>{

	ApnsInfo findOneByPackageName(String packageName);
}
