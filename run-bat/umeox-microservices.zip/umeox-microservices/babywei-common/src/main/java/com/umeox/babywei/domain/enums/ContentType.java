package com.umeox.babywei.domain.enums;


public enum ContentType {
	ONE(0,"单图文"),MULT(1,"多图文"),AD(2,"广告位"),EAT(3,"美食"),HEALTH(4,"健康"),EVERYDAY(5,"每天"),
	STORY(6,"故事"),SONG(7,"儿歌"),ENGLISH(8,"英语"),ENCYCLOPEDIA(9,"百科");
	
	Integer id;
	String label;
	private ContentType(Integer id,String label){
		this.id = id;
		this.label = label;
	}
	public Integer getId() {
		return id;
	}
	public String getLabel() {
		return label;
	}
	
	
}
