package com.umeox.babywei.bean;

import java.io.Serializable;
import java.util.Date;

public class Position implements Serializable {

	private static final long serialVersionUID = 4026470044989512675L;

	private Long id;

	private Date createDate;

	private Date modifyDate;

	private Double latitude;

	private Double longitude;

	private Long holderId;

	private String channel;

	private String ci;

	private String code;

	private Integer electricity;

	private String imei;

	private Integer isChangeSim;

	private Integer isElectricity;

	private String lac;

	private String locationMode;

	private Date locationTime;

	private String mcc;

	private String mnc;

	private String msgLength;

	private String pressureValue;

	private String protocolVersion;

	private String reportReason;

	private String reportReasonAttr;

	private Date reportTime;

	private String signalStrength;

	private String speed;//标记该地址是经过服务器转换

	private String stationMsg;

	private Integer stations;

	private String status;

	private String stepCounting;

	private String temperature;

	private String terminalType;

	private String address;

	private Date earlyDate;

	private Integer nearbyPosition;

	private String wifiMac;

	private String wifiSignal;

	private Integer radius;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCi() {
		return ci;
	}

	public void setCi(String ci) {
		this.ci = ci;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Integer getElectricity() {
		return electricity;
	}

	public void setElectricity(Integer electricity) {
		this.electricity = electricity;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public Integer getIsChangeSim() {
		return isChangeSim;
	}

	public void setIsChangeSim(Integer isChangeSim) {
		this.isChangeSim = isChangeSim;
	}

	public Integer getIsElectricity() {
		return isElectricity;
	}

	public void setIsElectricity(Integer isElectricity) {
		this.isElectricity = isElectricity;
	}

	public String getLac() {
		return lac;
	}

	public void setLac(String lac) {
		this.lac = lac;
	}

	public String getLocationMode() {
		return locationMode;
	}

	public void setLocationMode(String locationMode) {
		this.locationMode = locationMode;
	}

	public Date getLocationTime() {
		return locationTime;
	}

	public void setLocationTime(Date locationTime) {
		this.locationTime = locationTime;
	}

	public String getMcc() {
		return mcc;
	}

	public void setMcc(String mcc) {
		this.mcc = mcc;
	}

	public String getMnc() {
		return mnc;
	}

	public void setMnc(String mnc) {
		this.mnc = mnc;
	}

	public String getMsgLength() {
		return msgLength;
	}

	public void setMsgLength(String msgLength) {
		this.msgLength = msgLength;
	}

	public String getPressureValue() {
		return pressureValue;
	}

	public void setPressureValue(String pressureValue) {
		this.pressureValue = pressureValue;
	}

	public String getProtocolVersion() {
		return protocolVersion;
	}

	public void setProtocolVersion(String protocolVersion) {
		this.protocolVersion = protocolVersion;
	}

	public String getReportReason() {
		return reportReason;
	}

	public void setReportReason(String reportReason) {
		this.reportReason = reportReason;
	}

	public String getReportReasonAttr() {
		return reportReasonAttr;
	}

	public void setReportReasonAttr(String reportReasonAttr) {
		this.reportReasonAttr = reportReasonAttr;
	}

	public Date getReportTime() {
		return reportTime;
	}

	public void setReportTime(Date reportTime) {
		this.reportTime = reportTime;
	}

	public String getSignalStrength() {
		return signalStrength;
	}

	public void setSignalStrength(String signalStrength) {
		this.signalStrength = signalStrength;
	}

	public String getSpeed() {
		return speed;
	}

	public void setSpeed(String speed) {
		this.speed = speed;
	}

	public String getStationMsg() {
		return stationMsg;
	}

	public void setStationMsg(String stationMsg) {
		this.stationMsg = stationMsg;
	}

	public Integer getStations() {
		return stations;
	}

	public void setStations(Integer stations) {
		this.stations = stations;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStepCounting() {
		return stepCounting;
	}

	public void setStepCounting(String stepCounting) {
		this.stepCounting = stepCounting;
	}

	public String getTemperature() {
		return temperature;
	}

	public void setTemperature(String temperature) {
		this.temperature = temperature;
	}

	public String getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getEarlyDate() {
		return earlyDate;
	}

	public void setEarlyDate(Date earlyDate) {
		this.earlyDate = earlyDate;
	}

	public Integer getNearbyPosition() {
		return nearbyPosition;
	}

	public void setNearbyPosition(Integer nearbyPosition) {
		this.nearbyPosition = nearbyPosition;
	}

	public String getWifiMac() {
		return wifiMac;
	}

	public void setWifiMac(String wifiMac) {
		this.wifiMac = wifiMac;
	}

	public String getWifiSignal() {
		return wifiSignal;
	}

	public void setWifiSignal(String wifiSignal) {
		this.wifiSignal = wifiSignal;
	}

	public Integer getRadius() {
		return radius;
	}

	public void setRadius(Integer radius) {
		this.radius = radius;
	}

}
