package com.umeox.babywei.bean;

import java.io.Serializable;

public class HomeDto implements Serializable{

	private static final long serialVersionUID = -6712893059525101166L;

	private Long holderId;
	
	private Double longitude = 0.0;
	
	private Double latitude = 0.0;
	
	private Integer locationMode;
	
	private Long locationTimeStamp;
	
	private Integer electric;
	
	private String address;
	
	private Integer stepValue = 0;
	
	private Integer calory = 0;
	//当天运动距离：单位米
	private Integer distance = 0;
	
	private Integer radius = 0;
	//计步排行领先比
	private Integer rank = 0;

	private String mcc;

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public Integer getRadius() {
		return radius;
	}

	public void setRadius(Integer radius) {
		this.radius = radius;
	}

	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Integer getLocationMode() {
		return locationMode;
	}

	public void setLocationMode(Integer locationMode) {
		this.locationMode = locationMode;
	}

	public Long getLocationTimeStamp() {
		return locationTimeStamp;
	}

	public void setLocationTimeStamp(Long locationTimeStamp) {
		this.locationTimeStamp = locationTimeStamp;
	}

	public Integer getElectric() {
		return electric;
	}

	public void setElectric(Integer electric) {
		this.electric = electric;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getStepValue() {
		return stepValue;
	}

	public void setStepValue(Integer stepValue) {
		this.stepValue = stepValue;
	}

	public Integer getCalory() {
		return calory;
	}

	public void setCalory(Integer calory) {
		this.calory = calory;
	}

	public Integer getDistance() {
		return distance;
	}

	public void setDistance(Integer distance) {
		this.distance = distance;
	}

	public String getMcc() {
		return mcc;
	}

	public void setMcc(String mcc) {
		this.mcc = mcc;
	}
}
