package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @desc 闹钟
 * @author umeox
 * @version II
 */
@Entity
@Table(name = "ux_holder_alarm")
public class HolderAlarm extends BaseEntity{
	
	private static final long serialVersionUID = -1341205379208434199L;

	private Holder holder;
	
	/**
	 * 闹钟名称
	 */
	private String alarmName;
	
	/**
	 * 闹钟时间（时间戳）
	 */
	private Long alarmTime;
	
	/**
	 * 闹钟时间（24小时制：14:24）
	 */
	private String alarmTimeStr;
	
	/**
	 * 是否重复（0:不重复; 1:按周）
	 */
	private Integer repeatFlag;
	
	/**
	 * 重复规则（周日，周一至周六；例1100010：周日、周一、周五计算）
	 */
	private String repeatExpression;
	
	/**
	 * 状态（0：未开启，1：已开启）
	 */
	private Boolean status;
	
	/**
	 * 铃声类型（0：默认铃声）
	 */
	private Integer ringType;

	/**
	 *图标
	 */
	private String icon;

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Integer getRingType() {
		return ringType;
	}

	public void setRingType(Integer ringType) {
		this.ringType = ringType;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "holder_id",nullable = false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	@Column(nullable = false)
	public String getAlarmName() {
		return alarmName;
	}

	public void setAlarmName(String alarmName) {
		this.alarmName = alarmName;
	}

	public Long getAlarmTime() {
		return alarmTime;
	}

	public void setAlarmTime(Long alarmTime) {
		this.alarmTime = alarmTime;
	}
	
	public String getAlarmTimeStr() {
		return alarmTimeStr;
	}

	public void setAlarmTimeStr(String alarmTimeStr) {
		this.alarmTimeStr = alarmTimeStr;
	}

	@Column(nullable = false,length = 2)
	public Integer getRepeatFlag() {
		return repeatFlag;
	}

	public void setRepeatFlag(Integer repeatFlag) {
		this.repeatFlag = repeatFlag;
	}

	@Column(length = 32)
	public String getRepeatExpression() {
		return repeatExpression;
	}

	public void setRepeatExpression(String repeatExpression) {
		this.repeatExpression = repeatExpression;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	
}
