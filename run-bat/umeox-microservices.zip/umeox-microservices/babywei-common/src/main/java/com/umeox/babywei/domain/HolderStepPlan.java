package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * 运动记步计划值
 */
@Entity
@Table(name = "ux_holder_step_plan")
public class HolderStepPlan extends BaseEntity{

	private static final long serialVersionUID = -3808290347587045927L;
	
	private Holder holder;
	
	/**
	 * 记步-计划值
	 */
	private Integer planValue;
	
	/**
	 * 奖品
	 */
	private String prize;

	@OneToOne
	@JoinColumn(name = "holder_id",nullable = false)
	public Holder getHolder() {
		return holder;
	}

	public void setHolder(Holder holder) {
		this.holder = holder;
	}

	public Integer getPlanValue() {
		return planValue;
	}

	public void setPlanValue(Integer planValue) {
		this.planValue = planValue;
	}

	public String getPrize() {
		return prize;
	}

	public void setPrize(String prize) {
		this.prize = prize;
	}

}
