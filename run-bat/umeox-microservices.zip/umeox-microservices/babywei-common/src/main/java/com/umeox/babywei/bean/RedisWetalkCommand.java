package com.umeox.babywei.bean;

public class RedisWetalkCommand {
	public final static Integer CMD_BIND = 0x01;              //设备绑定
	public final static Integer CMD_UNBOUND = 0x02;           //设备解绑
	public final static Integer CMD_CHAT = 0x04;              //语聊消息(群聊/私聊)
	
	
	public final static Integer CMD_FRIEND = 0x100;           //同步好友
	public final static Integer CMD_GROUP = 0x200;            //同步群组
	public final static Integer CMD_TIMEZONE = 0x400;         //同步时区
}
