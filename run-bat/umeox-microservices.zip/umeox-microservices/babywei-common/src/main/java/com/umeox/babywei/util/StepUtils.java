package com.umeox.babywei.util;

import java.text.DecimalFormat;

public class StepUtils {

	public static final double DEFAULT_HEIGHT=167.1d;//中国成人平均身高,cm
	public static final double DEFAULT_WEIGHT=61.5;//中国成人平均体重,kg
	
	/**
	 * 	根据升高计算步长
	           人的赤脚长约是身高的1/7  
		单步长在166cm以上的一般为高个  
		身高＝单步长＋1/3足迹长  
		单步长在148cm--166cm以上的一般为中个  
		身高＝单步长＋1/2足迹长 
		单步长在140cm以下的一般为矮个 
		身高＝单步长＋2/3足迹长
		赤脚：cj
		身高：sg  height
		足迹长：zjc
		单步长：dbc
		步长：bc
		系数：x
		cj = 1/7*sg;
		sg = dbc + x*zjc
		dbc = 2bc + zjc
		zjc = cj + 4cm
		@param height 身高
	 */
	public static double getDistance(double height){ 
		if(height == 0) height = DEFAULT_HEIGHT;
		DecimalFormat df  = new DecimalFormat("###.0000");
		double x = Double.parseDouble(df.format(2.0/3.0));
		if (height >= 180) {
			x = Double.parseDouble(df.format(1.0/3.0));
		} else if (height >= 160) {
			x = Double.parseDouble(df.format(1.0/2.0));
		} 
		double bc = (height - (1 + x) * (1.0/7.0 * height + 4)) * 1/2.0;
		return bc;
	}
	
	/**
	 *  已知体重、距离
		跑步热量（kcal）＝体重（kg）×距离（公里）×1.036
		@param weight 体重
		@param distance 距离
	 */
	public static double getKcal(double weight,double distance){ 
		if(weight == 0 ) weight = DEFAULT_WEIGHT;
		DecimalFormat df  = new DecimalFormat("###.00");
		double kcal = weight * distance * 1.036;
		return Double.parseDouble(df.format(kcal));
	}

}
