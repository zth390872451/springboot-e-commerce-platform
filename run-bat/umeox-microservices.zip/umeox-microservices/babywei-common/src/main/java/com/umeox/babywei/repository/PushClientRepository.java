package com.umeox.babywei.repository;

import com.umeox.babywei.domain.PushClient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

@Component("pushClientRepository")
public interface PushClientRepository extends JpaRepository<PushClient, Long>{

	PushClient findOneByClientId(String clientId);

	PushClient findOneByDeviceTypeAndSaleChannel(String deviceType, String saleChannel);

	PushClient findOneByDeviceTypeAndSaleChannelIsNull(String deviceType);
	
	@Query(value = "select * from push_client where client_id =?1 limit 1",nativeQuery = true)
	PushClient findOneByLikeClientId(String client_id);
}
