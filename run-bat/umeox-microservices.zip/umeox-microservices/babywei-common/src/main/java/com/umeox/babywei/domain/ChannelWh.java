package com.umeox.babywei.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


/**
 * 
 * 貌似暂不用 16-04-08
 * @author Yan
 */
@Entity
@Table(name = "ux_channel_wh")
public class ChannelWh extends BaseEntity {

	private static final long serialVersionUID = -9073242367066524086L;

	/**
	 * IMEI号
	 */
	private String imei;

	/**
	 * sim卡号
	 */
	private String phone;
	
	/**
	 * 渠道号
	 */
	private String saleChannel;
	
	// ============================================================//

	@Column(name = "imei", nullable = false, unique = true, updatable = false, length = 20)
	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}
	
	@Column(name = "phone", nullable = false, unique = true, updatable = false, length = 20)
	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "sale_channel", length = 32)
	public String getSaleChannel() {
		return saleChannel;
	}

	public void setSaleChannel(String saleChannel) {
		this.saleChannel = saleChannel;
	}

}
