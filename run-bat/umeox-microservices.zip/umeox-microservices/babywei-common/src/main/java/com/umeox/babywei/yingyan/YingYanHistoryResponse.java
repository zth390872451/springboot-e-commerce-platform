package com.umeox.babywei.yingyan;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

/**
 * @author JT
 * 
 * 查询历史轨迹点的返回，具体信息包括经纬度，时间，其他用户自定义信息等
 *  
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class YingYanHistoryResponse extends YingYanStatusResponse{
    
    //忽略掉page_index，page_size后的轨迹点数量,代表一共有多少条符合条件的track
    private Integer total;
    
    //返回的结果条数,代表本页返回了多少条符合条件的轨迹点数量
    private Integer size;
    
    //此段轨迹的里程数，单位：米,符合条件的所有轨迹点的总里程，中断5分钟以上的区间不记入总里程。注意：是total个轨迹点的里程，和分页及本页显示的size无关。
    private Double distance;
    
    private YingYanPointBean start_point;
    
    private YingYanPointBean end_point;
    
    private List<YingYangHisPointBean> points;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public YingYanPointBean getStart_point() {
        return start_point;
    }

    public void setStart_point(YingYanPointBean start_point) {
        this.start_point = start_point;
    }

    public YingYanPointBean getEnd_point() {
        return end_point;
    }

    public void setEnd_point(YingYanPointBean end_point) {
        this.end_point = end_point;
    }

    public List<YingYangHisPointBean> getPoints() {
        return points;
    }

    public void setPoints(List<YingYangHisPointBean> points) {
        this.points = points;
    }
}
