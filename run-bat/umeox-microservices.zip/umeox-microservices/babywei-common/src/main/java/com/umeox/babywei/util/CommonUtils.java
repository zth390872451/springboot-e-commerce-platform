package com.umeox.babywei.util;

import org.apache.commons.lang.RandomStringUtils;
import org.springframework.util.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommonUtils {

	/**
	 * 产生随机数
	 */
	public static String getRandomNumber(int count){
		return RandomStringUtils.random(count, "0123456789");
	} 
	
	public static String getRandomNumber(){
		return RandomStringUtils.random(6, "0123456789");
	}
	
	/**
	 * w1代周期是星期一开始,clientId为空
	 * 新版app的clientId不为空
	 */
	public static String getConvertWeek(String clientId,String weekTime){
		if (StringUtils.isEmpty(weekTime)) {
			return null;
		}
		if (weekTime.length() != 7) {
			return weekTime;
		}
		
		if (StringUtils.isEmpty(clientId)) {
			return weekTime.substring(6) + weekTime.substring(0, 6);
		}
		return weekTime;
	}

	public static String getRevertWeek(String clientId,String weekTime){
		if (StringUtils.isEmpty(weekTime)) {//历史数据有未选
			return "1111111";
		}
		if (weekTime.length() != 7) {
			return weekTime;
		}
		
		if (StringUtils.isEmpty(clientId)) {
			return  weekTime.substring(1, 7) + weekTime.substring(0, 1);
		}
		return weekTime;
	}
	
	public static String aliasHandle(String alias){
		alias = alias.replaceAll("[@$.-]", "_");
		if (alias.length() > 40) {//jpush 别名长度不能超过40位
			alias = alias.substring(0, 40);
		}
		return alias;
	}
	
	/**
	 * 判断是否为IMEI --长度为15的数字
	 * @param str
	 * @return
	 */
	public static Boolean isImei(String str){
		if (str.length() != 15) {
			return false;
		}
		Pattern pattern = Pattern.compile("[0-9]*"); 
	    Matcher isNum = pattern.matcher(str);
	    if( !isNum.matches() ){
	       return false; 
	    } 
	    return true;
	}
	
}
