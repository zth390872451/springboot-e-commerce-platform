package com.umeox.babywei.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * 相册日集
 */
@Entity
@Table(name = "ux_holder_albums_day")
public class HolderAlbumsDay {
    private Long id;
    
    //相册
    private HolderAlbums holderAlbums;

     //相集日期（yyyy-MM-dd)    
    private Date day;

    //当日照片总数
    private Integer dayNum;

    //可用空间大小,单位（Byte）
    private Long dayUsedSize;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "holder_albums_id",nullable = false)
    public HolderAlbums getHolderAlbums() {
        return holderAlbums;
    }

    public void setHolderAlbums(HolderAlbums holderAlbums) {
        this.holderAlbums = holderAlbums;
    }

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    public Date getDay() {
        return day;
    }

    public void setDay(Date day) {
        this.day = day;
    }

    @Column(nullable = false)
    public Integer getDayNum() {
        return dayNum;
    }

    public void setDayNum(Integer dayNum) {
        this.dayNum = dayNum;
    }

    @Column(nullable = false)
    public Long getDayUsedSize() {
        return dayUsedSize;
    }

    public void setDayUsedSize(Long dayUsedSize) {
        this.dayUsedSize = dayUsedSize;
    }
}
