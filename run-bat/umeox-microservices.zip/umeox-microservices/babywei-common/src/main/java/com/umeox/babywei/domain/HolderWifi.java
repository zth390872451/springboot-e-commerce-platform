package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 *
 */
@Entity
@Table(name = "ux_holder_wifi")
public class HolderWifi extends BaseEntity  {

    public static final Integer WIFI_MAX_SIZE = 3 ;

    //系统ID(WiFi的ID) 就是 主键 ID Long
    private String ssid;//WiFi名称

    private String password;//WiFi密码

    private Holder holder;

    public HolderWifi() {
    }

    public HolderWifi(String ssid, String password, Holder holder) {
        this.ssid = ssid;
        this.password = password;
        this.holder = holder;
    }

    public HolderWifi(String ssid, String password) {
        this.ssid = ssid;
        this.password = password;
    }
    @ManyToOne(fetch= FetchType.LAZY)
    @JoinColumn(name="holder_id",nullable=false)
    public Holder getHolder() {
        return holder;
    }

    public void setHolder(Holder holder) {
        this.holder = holder;
    }

    @Column(nullable = false)
    public String getSsid() {
        return ssid;
    }

    public void setSsid(String ssid) {
        this.ssid = ssid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
