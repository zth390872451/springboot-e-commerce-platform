package com.umeox.babywei.util;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.Constants;
import com.umeox.babywei.conf.RuleConfiguration;
import org.apache.commons.lang.StringUtils;

import java.util.Locale;

public class RuleSupport {

    private static RuleConfiguration ruleConfiguration;

    static {
        ruleConfiguration = (RuleConfiguration) ApplicationSupport.getBean("ruleConfiguration");
    }

    // 例 "20066": "66,0;44，0"，表示渠道20066的66开头字符串替换成0
    // 国外环境一个渠道可以多个电话码
    public static String filterMobile(String channel, String mobile) {
        if (!ApplicationSupport.isChinaEnv()) {
            String tel = ruleConfiguration.getChannelTels().get(channel);
            if (tel != null) {
                String[] tArray = tel.split(";");
                for (int i = 0; i < tArray.length; i++) {
                    String[] t = tArray[i].split(",");
                    String src = t[0];
                    String tar = t[1];
                    if (mobile.matches("^" + src + ".*")) {
                        mobile = tar + mobile.substring(src.length());
                        break;
                    }
                }
            }
        }
        return mobile;
    }

    // 获取国家代码mcc相关的语言文本
    public static String getMsgByMcc(String mcc, String code, Object[] args) {
        String locale = "en";
        if (ApplicationSupport.isEnv(Constants.SPRING_PROFILE_PRODUCTION_CHINA_LONLIV)) {
            locale = "zh_LONLIV";
        }else if(ApplicationSupport.isChinaEnv()){
            locale = "zh-CN";
        } else {
            locale = getLangByMcc(mcc);
        }
        return getMsgByLocale(locale, code, args);
    }

    public static String getMsgByMcc(String mcc, String code) {
        return getMsgByMcc(mcc, code, null);
    }

    // 根据国家代码获取语言
    public static String getLangByMcc(String mcc) {
        String lang = "en";   // 默认英文
        if(!StringUtils.isEmpty(mcc)){
            lang = ruleConfiguration.getMccLang().get(mcc.toLowerCase());
            if (lang == null) {
                lang = "en";
            }
        }
        return lang;
    }

    public static String getMsgByLocale(String locale, String code) {
        return getMsgByLocale(locale, code, null);
    }

    //根据语言获取国际化资源信息，按以下顺序：语言-国家，语言，默认(英文)
    public static String getMsgByLocale(String locale, String code, Object[] args) {
        String msg = "";
        if (ApplicationSupport.isChinaEnv()) {
            // 中国环境，只有中文
            msg = ApplicationSupport.getMessage(code, args, Locale.SIMPLIFIED_CHINESE);
        } else {
            // 外国环境
            if (StringUtils.isEmpty(locale)) {
                // 默认英文
                locale = "en";
            }
            int idx = locale.replace("_", "-").indexOf("-");
            String l = locale;
            String c = "";
            if (idx != -1) {
                l = locale.substring(0, idx);
                c = locale.substring(idx + 1, locale.length());
            }
            msg = ApplicationSupport.getMessage(code, args, new Locale(l, c));
        }
        return msg;
    }

}
