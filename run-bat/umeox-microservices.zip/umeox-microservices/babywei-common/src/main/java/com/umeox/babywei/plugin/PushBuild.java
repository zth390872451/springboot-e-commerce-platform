package com.umeox.babywei.plugin;

import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.AndroidNotification;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;
import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.conf.SettingProperties;
import org.springframework.util.StringUtils;

import java.util.Map;

/**
 * 极光应用PushPayload(通知或自定义消息)构建类
 */
public class PushBuild {

	private static final int BADGE = 1; //角标数字
	private static String SOUND = "default";
	private static long timeToLive = 5 * 86400;//单位：秒；86400（1天）
	
	private static final SettingProperties setting;
	static{
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}
	
	
	/**
	 * 构建通知消息
	 * 平台: android setAlert("") 不使用极光SDK显示通知栏
	 */
	/*public static PushPayload buildTitlePushObjectAndroidNotification(String alias, String title,Map<String, String> extras){
		return PushPayload.newBuilder()
				.setPlatform(Platform.android())
				.setAudience(Audience.alias(alias))
				.setNotification(Notification.newBuilder()
						.addPlatformNotification(AndroidNotification.newBuilder()
								.setAlert("")
								.setTitle(title)
								.addExtras(extras)
								.build())
						.build())
				.setOptions(Options.newBuilder()
						.setTimeToLive(TIME_TO_LIVE)
						.build())
				.build();
	}*/

	/**
	 *  构建Android通知消息 .setAlert("") 为了不使用极光SDK显示通知栏，因APP自行处理
	 * @param aliasArray	推送别名
	 * @param alert		通知内容，暂不使用
	 * @param extras	业务参数
	 * @return
	 */
	public static PushPayload buildPushObjectAndroidNotification(String[] aliasArray, String alert,Map<String, String> extras){
		if(!StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == Push.CALL ){
			//通话上报通知放在msg中，以便Android APP获取使用
			extras.put("msg",alert);
		}
		
		return PushPayload.newBuilder()
				.setPlatform(Platform.android())
				.setAudience(Audience.alias(aliasArray))
				.setNotification(Notification.newBuilder()
						.addPlatformNotification(AndroidNotification.newBuilder()
								.setAlert("")
								.addExtras(extras)
								.build())
						.build())
				.setOptions(Options.newBuilder()
						.setTimeToLive(timeToLive)
						.build())
				.build();
	}

	/**
	 * 构建iOS通知消息
	 * @param aliasArray	推送别名
	 * @param alert		通知内容
	 * @param extras	业务参数
	 * @return
	 */
	public static PushPayload buildPushObjectIosNotification(String[] aliasArray, String alert,Map<String, String> extras){
		String sound = SOUND;
		if(!StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == 14 ){
			sound = "cs_alarm.caf";
		}
		return PushPayload.newBuilder()
				.setPlatform(Platform.ios())
				.setAudience(Audience.alias(aliasArray))
				.setNotification(Notification.newBuilder()
						.addPlatformNotification(IosNotification.newBuilder()
								.setAlert(alert)
								.setBadge(BADGE)
								.setSound(sound)
								.addExtras(extras)
								.build())
						.build())
				.setOptions(Options.newBuilder()
						.setApnsProduction(setting.isIosProduction())
						.setTimeToLive(timeToLive)
						.build())
				.build();
	}
	
	/**
	 *  构建Android和iOS平台标签推送通知和自定义消息,iOS同时发送通知和自定义消息，android只使用自定义消息
	 * @param title			自定义消息标题
	 * @param tagValue		标签
	 * @param msgContent	自定义消息内容
	 * @param extras		业务参数
	 * @return
	 */
	public static PushPayload buildTagPushObjectMessage(String title,String tagValue,String msgContent,Map<String, String> extras){
		String sound = SOUND;
		if(!StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == 14 ){
			sound = "cs_alarm.caf";
		}		
		return PushPayload.newBuilder()
				.setPlatform(Platform.android_ios())
				.setAudience(Audience.tag(tagValue))
				.setNotification(Notification.newBuilder()
						.addPlatformNotification(IosNotification.newBuilder()
								.setAlert(msgContent)
								.setBadge(BADGE)
								.setSound(sound)
								.addExtras(extras)
								.build())
						.build())
				.setMessage(Message.newBuilder()
						.setMsgContent(msgContent)
						.setTitle(title)
						.addExtras(extras)
						.build())
				.setOptions(Options.newBuilder()
						.setApnsProduction(setting.isIosProduction())
						.setTimeToLive(timeToLive)
						.build())
				.build();
	}
	
	/**
	 *  构建Android和iOS平台别名推送通知和自定义消息,iOS同时发送通知和自定义消息，android只使用自定义消息
	 * @param alias			推送别名
	 * @param msgContent	自定义消息内容
	 * @param extras		业务参数
	 * @return
	 */
	/*public static PushPayload buildPushObjectMessage(String alias,String msgContent,Map<String, String> extras){
		String sound = SOUND;
		if(!StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == 14 ){
			sound = "cs_alarm.caf";
		}
		return PushPayload.newBuilder()
				.setPlatform(Platform.android_ios())
				.setAudience(Audience.alias(alias))
				.setNotification(Notification.newBuilder()
						.addPlatformNotification(IosNotification.newBuilder()
								.setAlert(msgContent)
								.setBadge(BADGE)
								.setSound(sound)
								.addExtras(extras)
								.build())
						.build())
				.setMessage(Message.newBuilder()
						.setMsgContent(msgContent)
						.addExtras(extras)
						.build())
				.setOptions(Options.newBuilder()
						.setApnsProduction(setting.isIosProduction())
						.setTimeToLive(TIME_TO_LIVE)
						.build())
				.build();
	}*/
	
	/**
	 *  构建Android和iOS平台别名推送通知和自定义消息,iOS同时发送通知和自定义消息，android只使用自定义消息
	 * @param title			自定义消息标题
	 * @param aliasArray			推送别名
	 * @param msgContent	自定义消息内容
	 * @param extras		业务参数
	 * @return
	 */
	public static PushPayload buildTitlePushObjectMessage(String title,String[] aliasArray,String msgContent,Map<String, String> extras){
		String sound = SOUND;
		long newTimeToLive  =  timeToLive;
		if(!StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == 14 ){
			sound = "cs_alarm.caf";
		}else if(!StringUtils.isEmpty(extras.get("cmd")) && Integer.parseInt(extras.get("cmd").toString()) == Push.VIDEO_DEVICE_NOTIFY_JOINC_HANNEL){
			//sound = "cs_alarm.caf";
			newTimeToLive = 15;
		}
		return PushPayload.newBuilder()
				.setPlatform(Platform.android_ios())
				.setAudience(Audience.alias(aliasArray))
				.setNotification(Notification.newBuilder()
						.addPlatformNotification(IosNotification.newBuilder()
								.setAlert(msgContent)
								.setBadge(BADGE)
								.setSound(sound)
								.addExtras(extras)
								.build())
						.build())
				.setMessage(Message.newBuilder()
						.setMsgContent(msgContent)
						.setTitle(title)
						.addExtras(extras)
						.build())
				.setOptions(Options.newBuilder()
						.setApnsProduction(setting.isIosProduction())
						.setTimeToLive(newTimeToLive)
						.build())
				.build();
	}

	/**
	 *  构建Android和iOS平台别名推送slient通知和自定义消息,iOS同时发送通知和自定义消息，android只使用自定义消息
	 *  构建 slient 通知,针对iOS如果只携带content-available: 1,不携带任何badge，sound 和消息内容等参数  
	 *  则可以不打扰用户的情况下进行内容更新等操作即为“Silent Remote Notifications  
	 * @param title			自定义消息标题
	 * @param aliasArray			推送别名
	 * @param msgContent	自定义消息内容
	 * @param extras		业务参数
	 * @param timeToLive  	0表示不保存，单位为秒                                              
	 * @return
	 */
	public static PushPayload buildSlientTitlePushObjectMessage(String title,String[] aliasArray,String msgContent,Map<String, String> extras,long timeToLive){
		return PushPayload.newBuilder()
				.setPlatform(Platform.android_ios())
				.setAudience(Audience.alias(aliasArray))
				.setNotification(Notification.newBuilder()
						.addPlatformNotification(IosNotification.newBuilder()
								.setAlert("")
								.addExtras(extras)
								.build())
						.build())
				.setMessage(Message.newBuilder() //自定义消息
						.setMsgContent(msgContent)
						.setTitle(title)
						.addExtras(extras)
						.build())
				.setOptions(Options.newBuilder()
						.setApnsProduction(setting.isIosProduction())
						.setTimeToLive(timeToLive)
						.build())
				.build();
	}

	/**
	 * 构建Android平台别名推送自定义消息
	 * @param title			自定义消息标题
	 * @param aliasArray			推送别名
	 * @param msgContent	自定义消息内容
	 * @param extras		业务参数
	 * @return
	 */
	public static PushPayload buildAndroidTitlePushMessage(String title, String[] aliasArray, String msgContent, Map<String, String> extras){
		return buildAndroidTitlePushMessage(title,aliasArray,msgContent,extras,timeToLive);
	}


	/**
	 * 构建Android平台别名推送自定义消息
	 * @param title			自定义消息标题
	 * @param aliasArray			推送别名
	 * @param msgContent	自定义消息内容
	 * @param extras		业务参数
	 * @param timeToLive  0表示不保存，单位为秒
	 * @return
	 */
	public static PushPayload buildAndroidTitlePushMessage(String title, String[] aliasArray, String msgContent, Map<String, String> extras, long timeToLive){
		return PushPayload.newBuilder()
				.setPlatform(Platform.android())
				.setAudience(Audience.alias(aliasArray))
				.setMessage(Message.newBuilder() //自定义消息
						.setMsgContent(msgContent)
						.setTitle(title)
						.addExtras(extras)
						.build())
				.setOptions(Options.newBuilder()
						.setTimeToLive(timeToLive)
						.build())
				.build();
	}
}
