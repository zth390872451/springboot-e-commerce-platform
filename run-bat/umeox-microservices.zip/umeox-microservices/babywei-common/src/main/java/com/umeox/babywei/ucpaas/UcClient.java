package com.umeox.babywei.ucpaas;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.ucpaas.client.JsonReqClient;
import com.umeox.babywei.util.JsonUtils;

public class UcClient {
	
	private static final Logger logger = LoggerFactory.getLogger(UcClient.class);
	private static final String accountSid = ApplicationSupport.getParamVal("ucpaas.accountSid");
	private static final String authToken = ApplicationSupport.getParamVal("ucpaas.authToken");
	private static String appId = ApplicationSupport.getParamVal("ucpaas.appId");

	/**
	 * 申请云之讯账号
 	 * @return
     */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> createClient(){
		if (accountSid == null || authToken == null || appId == null) {
			logger.error("需在application.yml文件配置ucpass认证信息");
			return null;
		}
		String result = sendRequest(accountSid, authToken, appId, null, "0", "0", null);
		if (result == null) {
			return null;
		}
		Map<String, Object> resultMap = JsonUtils.toObject(result, HashMap.class);
		if (resultMap != null) {
			Map<String, String> resp = JsonUtils.toObject(JsonUtils.toJson(resultMap.get("resp")), HashMap.class);
			if (resp != null) {
				if (resp.get("respCode").equals("000000")) {
					Map<String, String> detail = JsonUtils.toObject(JsonUtils.toJson(resp.get("client")),HashMap.class);
					if (detail != null) {
						Map<String, Object> map = new HashMap<String,Object>();
						map.put("balance", detail.get("balance"));
						map.put("clientNumber", detail.get("clientNumber"));
						map.put("clientPwd", detail.get("clientPwd"));
						map.put("createDate", detail.get("createDate"));
						return map;
					}
				}else {
					logger.error("申请云之讯账号失败，respCode = {0}",resp.get("respCode"));
				}
			} 
			/*else if (resp != null && (resp.get("respCode").equals("103104") || resp.get("respCode").equals("103114"))) {
				String resultStr = findClientByMobile(accountSid,authToken, mobile, appId);
				if (StringUtils.isEmpty(resultStr)) {
					return null;
				}
				Map<String, Object> resultKV = JsonUtils.toObject(resultStr, HashMap.class);
				if (resultKV != null) {
					Map<String, String> respKV = JsonUtils.toObject(JsonUtils.toJson(resultKV.get("resp")),HashMap.class);
					if (respKV != null) {
						if (respKV.get("respCode").equals("000000")) {
							Map<String, String> detailKV = JsonUtils.toObject(JsonUtils.toJson(respKV.get("client")), HashMap.class);
							if (detailKV != null) {
								Map<String, Object> map = new HashMap<String,Object>();
								map.put("balance", detailKV.get("balance"));
								map.put("clientNumber", detailKV.get("clientNumber"));
								map.put("clientPwd", detailKV.get("clientPwd"));
								map.put("createDate", detailKV.get("createDate"));
								return map;
							}
						}
					}
				}
			}*/
		}
		return null;
	}

	
	private static String sendRequest(String accountSid, String authToken, String appId, String clientName,
			String chargeType, String charge, String mobile) {
		try {
			String result = new JsonReqClient().createClient(accountSid, authToken, appId, clientName,
					chargeType, charge, mobile);
			return result;
		} catch (Exception e) {
			logger.error(null, e);
		}
		return null;
	}
	
	/*private static String findClientByMobile(String accountSid, String authToken, String mobile,
			String appId) {
		try {
			String result = new JsonReqClient().findClientByMobile(accountSid, authToken, mobile, appId);
			return result;
		} catch (Exception e) {
			logger.error(null, e);
		}
		return null;
	}*/
	
	/*private static String findClientByNbr(String accountSid, String authToken, String clientNumber,String appId) {
		try {
			String result = new JsonReqClient().findClientByNbr(accountSid, authToken, clientNumber, appId);
			return result;
		} catch (Exception e) {
			logger.error(null, e);
		}
		return null;
	}*/
}
