package com.umeox.babywei.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
 * @Desc 好友
 * @author umeox
 * @version II
 */
@Entity
@Table(name = "ux_im_relation")
public class ImRelation {
	
	private Long id;
	
	/**
	 * 设备(imei)
	 */
	private String userId;
	
	/**
	 * 好友(imei或账号[手机号或邮箱])
	 */
	private String friendId;
	
	/**
	 * 关系
	 */
	private Integer state = 2;
	
	/**
	 * 创建时间(默认系统时间)
	 */
	private Long createTime;
	
	/**
	 * 好友昵称
	 */
	private String nick;
	
	/**
	 * 好友头像标记
	 */
	private String photoFlag = "0";

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getFriendId() {
		return friendId;
	}

	public void setFriendId(String friendId) {
		this.friendId = friendId;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Long getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Long createTime) {
		this.createTime = createTime;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	
	public String getPhotoFlag() {
		return photoFlag;
	}

	public void setPhotoFlag(String photoFlag) {
		this.photoFlag = photoFlag;
	}

	@PrePersist
    public void prePersist(){
		this.createTime = System.currentTimeMillis();
	}
}
