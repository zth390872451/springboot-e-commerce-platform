package com.umeox.babywei.domain;

import javax.persistence.*;

/**
 * Created by Administrator on 2017/5/24.
 */
@Table(name = "ux_suggestion_operation")
@Entity
public class SuggestionOperation  extends BaseEntity {
    /**
     * 操作备注
     */
    private String remarks;
    /**
     * 操作状态 1：进行中 2：已解决
     */
    private Integer status;
    /**
     * 处理人
     */
    private String processor;
    /**
     * 所属的反馈记录
     */
    private Suggestion suggestion;

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @ManyToOne(fetch= FetchType.LAZY)
    @JoinColumn(name="suggestion_id")
    public Suggestion getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(Suggestion suggestion) {
        this.suggestion = suggestion;
    }

    public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }
}
