package com.umeox.babywei.domain;

import javax.persistence.*;
import java.util.Date;

/**
 * 拍拍点赞
 */
@Entity
@Table(name = "ux_paipai_zan")
public class HolderPaipaiZan {
    
    private Long id;
    
    private HolderPaipaiSpace paipaiSpace;
    
    //用户
    private Member member;
    
    //点赞日期
    private Date zanTime;
    
    //点赞照片
    private HolderAlbumsFile zanFile;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paipai_space_id",nullable = false)
    public HolderPaipaiSpace getPaipaiSpace() {
        return paipaiSpace;
    }

    public void setPaipaiSpace(HolderPaipaiSpace paipaiSpace) {
        this.paipaiSpace = paipaiSpace;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id",nullable = false)
    public Member getMember() {
        return member;
    }

    public void setMember(Member member) {
        this.member = member;
    }

    public Date getZanTime() {
        return zanTime;
    }
    
    public void setZanTime(Date zanTime) {
        this.zanTime = zanTime;
    }

    @OneToOne
    @JoinColumn(name = "zan_file_id",nullable = false)
    public HolderAlbumsFile getZanFile() {
        return zanFile;
    }

    public void setZanFile(HolderAlbumsFile zanFile) {
        this.zanFile = zanFile;
    }
}
