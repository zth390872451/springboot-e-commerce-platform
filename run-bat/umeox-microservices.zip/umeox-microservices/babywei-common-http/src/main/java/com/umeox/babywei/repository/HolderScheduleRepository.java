package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.HolderSchedule;

import java.util.List;

@Component("holderScheduleRepository")
public interface HolderScheduleRepository extends JpaRepository<HolderSchedule, Long>{
	List<HolderSchedule> findByHolderIdAndScheduleType(Long holderId,Integer scheduleType);

	HolderSchedule findFirstByHolderIdAndScheduleType(Long holderId, Integer scheduleType);

	HolderSchedule findFirstByHolderIdAndScheduleTypeAndStatus(Long holderId, Integer scheduleType, Boolean status);

	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_schedule where holder_id = ?1", nativeQuery = true)
	void deleteByHolderId(Long holderId);

	@Query(value = "select * from ux_holder_schedule where holder_id = ?1 and schedule_type=?2", nativeQuery = true)
	List<HolderSchedule> findVolumeTimeList(Long holderId ,Integer scheduleType);
	
}
