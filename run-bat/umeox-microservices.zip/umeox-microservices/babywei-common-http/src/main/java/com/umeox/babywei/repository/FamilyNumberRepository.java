package com.umeox.babywei.repository;

import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Holder;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component("familyNumberRepository")
public interface FamilyNumberRepository extends JpaRepository<FamilyNumber, Long> {

	List<FamilyNumber> findByMobile(String mobile);

	FamilyNumber findOneByMobileAndHolderId(String mobile, Long holderId);

	List<FamilyNumber> findListByMobileAndHolderId(String mobile, Long holderId);

	FamilyNumber findOneByEmailAndHolderId(String email, Long holderId);

	FamilyNumber findOneByFriendImei(String friendId);

	@Modifying
	@Transactional
	@Query(value = "delete from ux_family_number where holder_id = ?1 and mobile = ?2", nativeQuery = true)
	void deleteByHolderIdAndMobile(Long holderId, String mobile);

	@Modifying
	@Transactional
	@Query(value = "delete from ux_family_number where holder_id = ?1", nativeQuery = true)
	void deleteByHolderId(Long holderId);

	List<FamilyNumber> findByHolderId(Long holderId);

	@Query(value = "SELECT * FROM ux_family_number WHERE holder_id = ?1 ORDER BY id ASC", nativeQuery = true)
	List<FamilyNumber> findOrderByHolderId(Long holderId);

	List<FamilyNumber> findByHolderIdAndOriginIs(Long holderId, Integer origin);

	List<FamilyNumber> findByHolderIdAndOriginNot(Long holderId, Integer origin);

	@Modifying
	@Transactional
	@Query("update FamilyNumber set sort = ?1 where holder = ?2 and sort = ?3")
	void setSortFro(Integer sort, Holder holder, Integer sort1);

	@Modifying
	@Transactional
	@Query("update FamilyNumber set mobile = ?1 where mobile = ?2 and holder_id = ?3")
	void setMobile(String newMobile, String oldMobile, Long holderId);
	//当Member属于国外用户时，FamilyNumber表中的mobile字段存储的是账号是：邮箱注册，tel才是对应手机号码
	//当Member属于国内用户时，FamilyNumber表中的mobile字段存储的是账号是：手机号码注册
	@Modifying
	@Transactional
	@Query("update FamilyNumber set mobile = ?1 where email = ?2 and holder_id = ?3")
	void updateMobileByEmail(String newMobile, String email, Long holderId);

	@Query(value = "SELECT * FROM ux_family_number WHERE holder_id IN (SELECT id FROM ux_holder WHERE imei = ?1)", nativeQuery = true)
	List<FamilyNumber> findByImei(String imei);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM ux_family_number WHERE mobile IN ?1 AND holder_id IN (SELECT id FROM ux_holder WHERE imei = ?2)", nativeQuery = true)
	void deleteByMobileAndImei(List<String> list, String imei);

}
