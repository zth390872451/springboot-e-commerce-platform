package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Content;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ContentRepository extends JpaRepository<Content, Long>,JpaSpecificationExecutor<Content>{
	
	@Query(value = "select c.* from ux_content c where c.type in ('0','1','2') and c.parent is null and c.enabled IS true and c.channel_id = ?1  order by c.seq desc,c.publish_date",nativeQuery = true)
	List<Content> findAllParent(String channeId);
	
//	@Query("select c from Content c where c.parent is null and c.enabled = true and channelCustomer is null and c.publishDate <= now() and "
//			+ " ContentType = '0' order by c.seq desc,c.publishDate desc")
	@Query(value = "select c.* from ux_content c where c.type in ('0','1','2') and c.parent is null and c.enabled = true and c.channel_id is null and c.publish_date <= now()  order by c.seq desc,c.publish_date",nativeQuery = true)
	List<Content> findAllParent();
	
	@Query(value = "select c.* from ux_content c where c.enabled IS true and c.publish_date <= now() and c.type=?1 order by c.seq desc,c.publish_date desc limit 0,?2",nativeQuery = true)
	List<Content> findByTypeAndLimit(Integer type,Integer limit);
	
	@Query(value = "select c.* from ux_content c where c.enabled IS true and c.publish_date <= now() and c.type=?1 order by c.seq desc,c.publish_date desc",nativeQuery = true)
	List<Content> findByType(Integer type);
}
