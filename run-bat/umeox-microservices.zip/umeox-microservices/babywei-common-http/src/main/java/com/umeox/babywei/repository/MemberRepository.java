/**
 * 
 */
package com.umeox.babywei.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import com.umeox.babywei.domain.Member;

import java.util.List;

@Component("memberRepository")
public interface MemberRepository extends JpaRepository<Member, Long>, JpaSpecificationExecutor<Member> {

	public Member findOneByMobile(String mobile);
	
	public Member findOneByMobileAndPassword(String mobile,String password);
	
	public Member findOneByTel(String tel);

	@Query(value = "SELECT * FROM ux_member WHERE push_type = ?1 AND Date(modify_date) > Date('2016-05-01')", nativeQuery = true)
	public List<Member> findMemberByTokenNotNullAndPushType(Integer pushType);

	@Transactional
	@Modifying
	@Query(value = "delete from ux_member where id IN (?1)", nativeQuery = true)
	public void deleteByIds(Long[] ids);

	@Query(value = "SELECT * FROM ux_member WHERE mobile = ?1 AND location_code = ?2", nativeQuery = true)
	Member findMemberByMobileAndCode(String mobile, String locationCode);

}
