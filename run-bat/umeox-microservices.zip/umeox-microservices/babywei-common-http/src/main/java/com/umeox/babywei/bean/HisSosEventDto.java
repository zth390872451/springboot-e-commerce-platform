package com.umeox.babywei.bean;

/**
 历史Sos事件传输对象
 */
public class HisSosEventDto {
    private Long sosEventId;
    private String eventCode;
    private String phone;
    private int status;
    private String name;
    private String dateStart;
    private String address;

    public Long getSosEventId() {
        return sosEventId;
    }

    public void setSosEventId(Long sosEventId) {
        this.sosEventId = sosEventId;
    }

    public String getEventCode() {
        return eventCode;
    }

    public void setEventCode(String eventCode) {
        this.eventCode = eventCode;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDateStart() {
        return dateStart;
    }

    public void setDateStart(String dateStart) {
        this.dateStart = dateStart;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
