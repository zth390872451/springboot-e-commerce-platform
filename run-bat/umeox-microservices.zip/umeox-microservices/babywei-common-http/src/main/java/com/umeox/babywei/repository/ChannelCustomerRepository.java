package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Admin;
import com.umeox.babywei.domain.ChannelCustomer;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.List;

import javax.transaction.Transactional;

@Component("channelCustomerRepository")
public interface ChannelCustomerRepository extends JpaRepository<ChannelCustomer, Long>,JpaSpecificationExecutor<ChannelCustomer>{

	List<ChannelCustomer> findBySmsFlag(int smsFlag);
	
	ChannelCustomer findOneBySaleChannel(String saleChannel);
	
	ChannelCustomer findOneByAdmin(Admin admin);
	
	List<ChannelCustomer> findByTokenFlagAndSaleChannel(int tokenFlag, String saleChannel);
	
	@Transactional
	@Modifying
	@Query(value = "delete from ux_channel_customer where id IN (?1)",nativeQuery= true)
	void deleteByIds(List<Long> ids);
	@Transactional
	@Modifying
	@Query(value = "update ux_channel_customer set admin_id = null  where admin_id IN (?1)",nativeQuery= true)
	void setAdminIsNull(List<Long> ids);
	
}
