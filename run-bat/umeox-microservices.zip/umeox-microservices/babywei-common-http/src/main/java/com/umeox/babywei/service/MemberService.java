package com.umeox.babywei.service;

import com.umeox.babywei.domain.Member;


public interface MemberService {
	
	public Member regist(String mobile, String password, String nickName,String tel);
	
	public void setAuth(Member member,String userId,Boolean isAddOpenUser);
	
	public Boolean update(Member member,String newTel);
	
	public void save(Member member,String clientId);
}
