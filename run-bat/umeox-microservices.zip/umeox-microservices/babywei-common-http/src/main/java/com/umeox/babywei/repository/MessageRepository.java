package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Message;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component("messageRepository")
public interface MessageRepository extends JpaRepository<Message, Long>{

	@Modifying
	@Transactional
	@Query(value = "delete from ux_message where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	@Query(value = "select * from ux_message where holder_id = ?1 and ( admin_id = ?2 or member_id = ?3 ) ",nativeQuery = true)
	List<Message> findByHolderIdAndAdminIdOrMemberId(Long holderId, Long adminId, Long memberId);
}
