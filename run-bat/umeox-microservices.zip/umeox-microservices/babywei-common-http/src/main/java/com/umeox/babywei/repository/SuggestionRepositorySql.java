package com.umeox.babywei.repository;

import com.umeox.babywei.bean.SuggestionDto;
import com.umeox.babywei.domain.Suggestion;
import com.umeox.babywei.domain.SuggestionOperation;
import com.umeox.babywei.util.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class SuggestionRepositorySql {
	@PersistenceUnit
	private EntityManagerFactory emf;

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private SuggestionOperationRepository suggestionOperationRepository;

	/**
	 * 如果角色为渠道管理员的角色，则查询该渠道管理员所能查询的客户反馈意见
	 * @param saleChannel
	 * @return
	 */
	public Page<SuggestionDto> findSuggestionBySaleChannel(String saleChannel, Pageable pageable, final Suggestion suggestion){

		StringBuffer  sqlDomain = new  StringBuffer();
		sqlDomain.append("SELECT us.*,us.client_id,d.device_type FROM ux_suggestion us LEFT JOIN ux_device d ON d.imei = us.imei ");

		if(!StringUtils.isEmpty(saleChannel)) {
			sqlDomain.append(" INNER JOIN open_channel ucc ON us.client_id = ucc.client_id ");
		}else{

		}
		sqlDomain.append("WHERE 1=1 ");
		//查询当前登录用户所管理的渠道号下的APP收到的反馈
		if(!StringUtils.isEmpty(saleChannel)){
			sqlDomain.append(" AND ucc.sale_channel = "+ saleChannel +" ");
		}
		if(!StringUtils.isEmpty(suggestion.getCreateDate())){
			String createDate = DateTimeUtils.getFormatDate(suggestion.getCreateDate(), DateTimeUtils.PART_DATE_FORMAT);
			sqlDomain.append(" AND DATE(us.create_date) = DATE('"+createDate+"') ");
		}
		if(!StringUtils.isEmpty(suggestion.getSuggestType())){
			sqlDomain.append(" AND us.suggest_type = "+suggestion.getSuggestType()+" ");
		}
		String sqlCount = sqlDomain.toString().replace("us.*,us.client_id,d.device_type", "count(1)");
		int current = pageable.getPageNumber() * pageable.getPageSize();
		int size = pageable.getPageSize();
		sqlDomain .append(" ORDER BY us.create_date DESC LIMIT ").append(current).append(',').append(size).append(" ");

		List<SuggestionDto> result = jdbcTemplate.query(sqlDomain.toString(),
				new ParameterizedRowMapper<SuggestionDto>() {
					@Override
					public SuggestionDto mapRow(ResultSet rs, int index)
							throws SQLException {
						SuggestionDto suggestionDto = new SuggestionDto();
						suggestionDto.setMobile(rs.getString("mobile"));
						suggestionDto.setClientId(rs.getString("client_id"));
						suggestionDto.setCreateDate(rs.getDate("create_date"));
						suggestionDto.setImei(rs.getString("imei"));
						suggestionDto.setId(rs.getLong("id"));
						suggestionDto.setPhoneSystem(rs.getString("phone_system"));
						suggestionDto.setPhoneType(rs.getString("phone_type"));
						suggestionDto.setSystemVersion(rs.getString("system_version"));
						suggestionDto.setSuggestContext(rs.getString("suggest_context"));
						suggestionDto.setSuggestType(rs.getString("suggest_type"));
						suggestionDto.setDeviceType(rs.getInt("device_type"));
						suggestionDto.setAppVersion(rs.getString("app_version"));
						return suggestionDto;
					}
				});

		Long total = jdbcTemplate.queryForObject(sqlCount,null,Long.class);
		for (SuggestionDto suggestionDto:result){
			SuggestionOperation suggestionOperation = suggestionOperationRepository.findFirstBySuggestionIdOrderByCreateDateDesc(suggestionDto.getId());
			List<SuggestionOperation> list = new ArrayList<>();
			if (suggestionOperation!=null){
				list.add(suggestionOperation);
			}
			suggestionDto.setSuggestionOperations(list);
		}

		PageImpl<SuggestionDto> suggestionPage = new PageImpl<SuggestionDto>(result, pageable, total);
		return suggestionPage;
	}

}
