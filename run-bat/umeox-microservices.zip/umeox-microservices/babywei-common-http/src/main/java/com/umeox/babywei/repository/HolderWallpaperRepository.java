package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderWallpaper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface HolderWallpaperRepository extends JpaRepository<HolderWallpaper, Long>{

	List<HolderWallpaper> findAllByHolderId(Long holderId);

	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_wallpaper where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);


	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_wallpaper where holder_id = ?1 and id = ?2",nativeQuery = true)
	void deleteByHolderIdAndId(Long holderId,Long id);

	HolderWallpaper findOneByHolderIdAndId(Long holderId, Long id);
}
