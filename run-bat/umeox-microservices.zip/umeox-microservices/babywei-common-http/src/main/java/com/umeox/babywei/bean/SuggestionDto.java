package com.umeox.babywei.bean;

import com.umeox.babywei.domain.SuggestionOperation;

import java.util.Date;
import java.util.List;

/**
 *
 */
public class SuggestionDto {

    private String clientId;

    /**
     * 会员账号
     */
    private String mobile;

    private String imei;

    private String suggestType;

    private String suggestContext;

    private String phoneSystem;

    private String systemVersion;

    private String phoneType;

    private Long id;

    /** 创建日期 */
    private Date createDate;

    /** 修改日期 */
    private Date modifyDate;

    private Integer deviceType;

    /**
     * APP版本号
     */
    private String appVersion;

    private List<SuggestionOperation> suggestionOperations;

    public List<SuggestionOperation> getSuggestionOperations() {
        return suggestionOperations;
    }

    public void setSuggestionOperations(List<SuggestionOperation> suggestionOperations) {
        this.suggestionOperations = suggestionOperations;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public Integer getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(Integer deviceType) {
        this.deviceType = deviceType;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getSuggestType() {
        return suggestType;
    }

    public void setSuggestType(String suggestType) {
        this.suggestType = suggestType;
    }

    public String getSuggestContext() {
        return suggestContext;
    }

    public void setSuggestContext(String suggestContext) {
        this.suggestContext = suggestContext;
    }

    public String getPhoneSystem() {
        return phoneSystem;
    }

    public void setPhoneSystem(String phoneSystem) {
        this.phoneSystem = phoneSystem;
    }

    public String getSystemVersion() {
        return systemVersion;
    }

    public void setSystemVersion(String systemVersion) {
        this.systemVersion = systemVersion;
    }

    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Date getModifyDate() {
        return modifyDate;
    }

    public void setModifyDate(Date modifyDate) {
        this.modifyDate = modifyDate;
    }
}
