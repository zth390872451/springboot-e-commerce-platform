package com.umeox.babywei.bean;

public class Mark {
	private Object ObjectId;
	private Type type;
	private Integer cmd;
	
	//K2,K1C,Candy2C协议一样
	public enum Type{
		K2,WETALK,K3
	}
	
	public Mark(Object ObjectId,Integer cmd) {
		this.ObjectId = ObjectId;
		this.cmd = cmd;
	}
	public Mark(Object ObjectId,Type type,Integer cmd) {
		this.ObjectId = ObjectId;
		this.type = type;
		this.cmd = cmd;
	}
	
	public Object getObjectId() {
		return ObjectId;
	}
	public void setObjectId(Object objectId) {
		ObjectId = objectId;
	}
	public Integer getCmd() {
		return cmd;
	}

	public void setCmd(Integer cmd) {
		this.cmd = cmd;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}
	
}
