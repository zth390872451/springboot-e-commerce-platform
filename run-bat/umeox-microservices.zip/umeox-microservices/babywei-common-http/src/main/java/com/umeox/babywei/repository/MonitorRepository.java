package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Monitor;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;

@Component("monitorRepository")
public interface MonitorRepository extends JpaRepository<Monitor, Long>{
	
	List<Monitor> findByHolderId(Long holderId);
	
	List<Monitor> findByMemberId(Long memberId);
	
	List<Monitor> findByMemberIdAndIsAdminTrue(Long memberId);
	
	Page<Monitor> findByMemberIdAndIsAdminTrue(Long memberId,Pageable page);
	
	Monitor findOneByIsAdminTrueAndHolder(Holder holder);
	
	//非管理员
	Monitor findFirstByIsAdminFalseAndMemberIdAndHolderId(Long memberId, Long holderId);
	
	//管理员
	Monitor findFirstByIsAdminTrueAndMemberIdAndHolderId(Long memberId, Long holderId);
	
	//关注者
	Monitor findFirstByMemberIdAndHolderId(Long memberId, Long holderId);
	
	Monitor findFirstByIsAdminTrueAndHolderImei(String imei);
	
	Monitor findFirstByIsAdminFalseAndMemberIdAndHolderImei(Long memberId, String imei);
	@Modifying
	@Transactional
	@Query(value = "delete from ux_monitor where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	List<Monitor> findByMemberIdAndDeviceType(Long memberId,String deviceType);
	
	List<Monitor> findByIsAdminTrueAndHolderIdIn(Collection<Long> holderIdList);
}
