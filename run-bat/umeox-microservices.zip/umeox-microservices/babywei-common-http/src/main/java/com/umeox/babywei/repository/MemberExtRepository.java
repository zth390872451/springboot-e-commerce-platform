package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.umeox.babywei.domain.MemberExt;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

public interface MemberExtRepository extends JpaRepository<MemberExt, Long>{
    @Transactional
    @Modifying
    @Query(value = "delete from ux_member_ext where member_id IN (?1)", nativeQuery = true)
    public void deleteByMemberIds(Long[] ids);
}
