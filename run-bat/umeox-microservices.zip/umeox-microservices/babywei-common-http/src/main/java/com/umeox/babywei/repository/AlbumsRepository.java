package com.umeox.babywei.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.umeox.babywei.domain.Albums;

public interface AlbumsRepository extends JpaRepository<Albums, Long>,
		JpaSpecificationExecutor<Albums> {
	Albums findOneByAlbumTitleAndEnabledIsFalse(String title);
	
	@Transactional
	@Modifying
	@Query(value = "delete from ux_albums where id IN (?1)", nativeQuery = true)
	public void deleteByIds(Long[] ids);
}
