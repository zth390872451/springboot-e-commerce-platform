package com.umeox.babywei.repository;

import java.util.List;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
	@Query(value ="SELECT * FROM sys_role WHERE id IN (?1)",nativeQuery = true)
	List<Role> findByIdIn(Long[] ids);
	
	@Transactional
	@Modifying
	@Query(value ="DELETE FROM sys_role WHERE id IN (?1)",nativeQuery = true)
	void deleteByIds(Long[] ids);
}
