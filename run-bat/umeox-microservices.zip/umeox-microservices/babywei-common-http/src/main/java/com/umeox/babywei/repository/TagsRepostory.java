package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.umeox.babywei.domain.Tags;

public interface TagsRepostory extends JpaRepository<Tags, Long> {

}
