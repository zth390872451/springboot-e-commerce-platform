package com.umeox.babywei.repository;

import com.umeox.babywei.domain.ChannelWh;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

public interface ChannelWhRepository extends JpaRepository<ChannelWh, Long>,JpaSpecificationExecutor<ChannelWh>{
	
	ChannelWh findOneByImei(String imei);
	
	@Query(value="delete from ux_channel_wh where id IN (?1)",nativeQuery= true)
	void deleteByIds(Long[] ids);
}
