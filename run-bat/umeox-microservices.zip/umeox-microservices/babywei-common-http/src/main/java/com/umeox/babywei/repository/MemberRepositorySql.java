package com.umeox.babywei.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

@Repository
public class MemberRepositorySql {

	@PersistenceUnit
	private EntityManagerFactory emf;
	
	@SuppressWarnings("unchecked")
	public List<String> queryMobileBySaleChannel(String saleChannel) {
			String sql = "SELECT mem.mobile FROM ux_member mem,ux_monitor mon "
					+ "WHERE mem.id = mon.member_id AND mon.holder_id "
					+ "IN (SELECT holder_id FROM ux_device WHERE sale_channel = ?)";
			EntityManager em = emf.createEntityManager();
			Query query = em.createNativeQuery(sql);
			query.setParameter(1, saleChannel);
			List<String> list = query.getResultList();
			return list;
		}
}
