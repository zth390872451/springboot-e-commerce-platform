package com.umeox.babywei.service;

public interface I18nService {
	
	public String findByLocaleAndKey(String locale,String key);
}
