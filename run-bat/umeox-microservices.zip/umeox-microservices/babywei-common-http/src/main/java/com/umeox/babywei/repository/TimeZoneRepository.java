package com.umeox.babywei.repository;

import com.umeox.babywei.domain.TimeZone;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TimeZoneRepository extends JpaRepository<TimeZone, Long>{
    
    TimeZone findOneByTimeZoneId(String timeZoneId);

}
