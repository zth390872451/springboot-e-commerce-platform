package com.umeox.babywei.service;

import com.umeox.babywei.domain.MailServer;

/**
 *
 */
public interface MailServerService {
    /**
     * 根据clientId，获取邮箱服务器
     * @param clientId
     * @return
     */
    MailServer findMailServerByClientId(String clientId);

    /**
     * 获取默认配置的邮箱服务器
     * @return
     */
    MailServer getDefaultMailServer();
}
