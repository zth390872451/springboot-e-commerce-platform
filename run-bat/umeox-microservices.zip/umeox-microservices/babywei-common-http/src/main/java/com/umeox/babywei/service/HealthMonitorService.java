package com.umeox.babywei.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;

/**
 * Created by Administrator on 2016/10/11.
 * 用于监控MySQL与redis
 */
@Service
@Transactional
public class HealthMonitorService {
    @Autowired
    private RedisService redisService;
    @Resource
    protected JdbcTemplate jdbcTemplate;

    private static final Logger logger = LoggerFactory.getLogger(HealthMonitorService.class);
    public static final String CURRENT_DATE = "SELECT CURDATE()";
    public boolean monitorMysql(){
        try {
           Date currentDate = jdbcTemplate.queryForObject(CURRENT_DATE, Date.class);
        }catch (Exception e){
            logger.error("健康监测Mysql服务器,exception={}",e.getMessage());
            return false;
        }
        return true;
    }

    public boolean monitorRedis(){
        try {
            redisService.set("testOpen","testOpen");
            redisService.del("testOpen");
        }catch (Exception e){
            logger.error("健康监测redis服务器,exception={}",e.getMessage());
            return false;
        }
        return true;
    }

}
