package com.umeox.babywei.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.HolderThumbup;

public interface HolderThumbupRepository extends JpaRepository<HolderThumbup, Long>{

	HolderThumbup findOneByHolderIdAndThumbupDate(Long holderId,Date thumbupDate);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_thumbup where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
}
