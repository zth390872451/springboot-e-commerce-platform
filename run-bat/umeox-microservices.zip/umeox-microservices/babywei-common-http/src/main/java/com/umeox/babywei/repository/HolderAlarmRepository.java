package com.umeox.babywei.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.HolderAlarm;

public interface HolderAlarmRepository extends JpaRepository<HolderAlarm, Long> {

	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_alarm where id = ?1", nativeQuery = true)
	void delete(Long id);

	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_alarm where holder_id = ?1", nativeQuery = true)
	void deleteByHolderId(Long holderId);

	List<HolderAlarm> findByHolderIdOrderByAlarmTimeStrAsc(Long holderId);

	List<HolderAlarm> findByHolderIdAndStatusOrderByAlarmTimeStrAsc(Long holderId, Boolean status);
}
