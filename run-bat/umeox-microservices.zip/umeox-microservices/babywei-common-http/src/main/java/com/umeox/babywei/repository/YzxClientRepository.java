package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import com.umeox.babywei.domain.YzxClient;

@Component("yzxClientRepository")
public interface YzxClientRepository extends JpaRepository<YzxClient, Long> {

	YzxClient findOneByAccountAndType(String account,Integer type);
}
