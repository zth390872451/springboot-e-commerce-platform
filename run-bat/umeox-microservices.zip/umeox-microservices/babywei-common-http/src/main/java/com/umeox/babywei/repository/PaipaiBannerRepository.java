package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Banner;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

/**
 * @author JT
 */

@Component("paipaiBannerRepository")
public interface PaipaiBannerRepository extends JpaRepository<Banner,Long> {
    
}
