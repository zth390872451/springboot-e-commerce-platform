package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderAlbums;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Administrator on 2017/2/22.
 */
public interface HolderAlbumsRepository extends JpaRepository<HolderAlbums, Long> {

    HolderAlbums findOneByHolderId(Long holderId);
}
