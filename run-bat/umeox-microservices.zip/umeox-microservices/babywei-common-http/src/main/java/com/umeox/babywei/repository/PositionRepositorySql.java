package com.umeox.babywei.repository;

import com.umeox.babywei.domain.ChannelCustomer;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Position;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Repository
public class PositionRepositorySql {

	@PersistenceUnit
	private EntityManagerFactory emf;
	@Autowired
	private HolderRepository holderRepository;
	private static final Logger log = LoggerFactory.getLogger(PositionRepositorySql.class);

	public Page<Position> findPosition(String imei, Date fromDate, Date toDate, Pageable pageable, ChannelCustomer channelCustomer) {
		Long holderid = null;
		if (!StringUtils.isEmpty(imei)) {
			Holder holder = holderRepository.findFirstByImei(imei);
			if (holder != null)
				holderid = holder.getId();
			else {
				List<Position> list = new ArrayList<Position>();
				Page<Position> pages = new PageImpl<Position>(list);
				return pages;
			}
		}
		List resutList = new ArrayList();
		Long totalCount = 0L;
		EntityManager em = emf.createEntityManager();
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			String tableName = "ux_position_" + df.format(fromDate).replaceAll("-", "_");
			String tableSql = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES as tableName " +
					"WHERE TABLE_NAME =?";
			Query searchTable = em.createNativeQuery(tableSql);
			searchTable.setParameter(1, tableName);
			List searchTableResult = searchTable.getResultList();
			String commonSql = commonSql(holderid, fromDate, channelCustomer);
			if (searchTableResult.size() == 0) {
				log.info("表不存在！查询结果为空!");
			} else {
				Query query = em.createNativeQuery(this.getPostionSql(commonSql, holderid, fromDate, toDate, pageable), Position.class);
				query.setParameter(1, fromDate, TemporalType.TIMESTAMP);
				query.setParameter(2, toDate, TemporalType.TIMESTAMP);
				log.info("query sql= {}，params = [holderid={},fromDate={},toDate={}]", commonSql, holderid, fromDate, toDate);
				resutList = query.getResultList();
				totalCount = this.getTotal(commonSql, holderid, fromDate, toDate);
			}
		} catch (Exception e) {
			log.error("Find position failure:", e);
		}finally {
			em.close();
		}
		Page<Position> list = new PageImpl<Position>(resutList, pageable, totalCount);
		return list;
	}


	private String getPostionSql(String sql, Long holderId, Date fromDate, Date toDate, Pageable pageable) {
		sql = sql + " ORDER BY p.report_time DESC  limit " + pageable.getPageNumber() * pageable.getPageSize() + "," + pageable.getPageSize();
		log.info("query sql= {}，params = [holderid={},fromDate={},toDate={}]", sql, holderId, fromDate, toDate);
		return sql;
	}

	/**
	 * @return 查询 实体与总数 共有的SQL
	 * 注：连接条件 ：根据 设备的渠道号去关联，不要根据位置的渠道号关联（第一代的设备渠道号可能有误）
	 */
	private String commonSql(Long holderId, Date fromDate, ChannelCustomer channelCustomer) {
		DateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
		StringBuffer table = new StringBuffer("select p.* from  ux_position_");
		table.append(df1.format(fromDate).replaceAll("-", "_"));

		table.append(" as p left join ux_device d on p.holder_id = d.holder_id WHERE 1=1 ");
		if (channelCustomer != null && channelCustomer.getSaleChannel() != null) {
			table.append("AND d.sale_channel = " + channelCustomer.getSaleChannel() + " ");
		}

		if (!StringUtils.isEmpty(holderId)) {
			table.append("AND p.holder_id = " + holderId);
		}
		table.append(" AND (d.last_activity_date is null or d.last_activity_date < p.location_time)  AND p.location_time between ? and ? ");
		return table.toString();
	}

	private Long getTotal(String sql, Long holderId, Date fromDate, Date toDate) {
		sql = sql.replace("p.*", "count(1)");
		EntityManager em = emf.createEntityManager();
		Query query = em.createNativeQuery(sql);
		query.setParameter(1, fromDate, TemporalType.TIMESTAMP);
		query.setParameter(2, toDate, TemporalType.TIMESTAMP);
		BigInteger total = (BigInteger) query.getSingleResult();
		return total.longValue();
	}
}
