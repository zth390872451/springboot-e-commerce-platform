package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.Position;

public interface PositionRepository extends GenericRepository<Position, Long>,PositionRepositoryCustom {
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_position where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	@Transactional
	@Modifying
	@Query(value = "delete from ux_position where id IN (?1)",nativeQuery = true)
	void deleteByIds(Long[] ids);
}
