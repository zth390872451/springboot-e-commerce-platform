package com.umeox.babywei.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.ImGroupMember;

public interface ImGroupMemberRepository extends JpaRepository<ImGroupMember, Long>{
	
	List<ImGroupMember> findByUserId(Long userId);
	
	List<ImGroupMember> findByImGroupId(Long imGroupId);
	
	ImGroupMember findOneByImGroupGroupIdAndUserId(String imGroupId,Long userId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_im_group_member where im_group_id = ?1 ",nativeQuery = true)
	void deleteByImGroupId(Long imGroupId);
	
/*	@Modifying
	@Transactional
	@Query(value = "delete from ux_im_group_member where im_group_id = ?1 and user_id = ?2",nativeQuery = true)
	void deleteByImGroupIdAndUserId(Long imGroupId,Long userId);*/
}
