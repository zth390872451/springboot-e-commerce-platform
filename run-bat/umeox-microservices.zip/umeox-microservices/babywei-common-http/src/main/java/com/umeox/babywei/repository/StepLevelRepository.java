package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.umeox.babywei.domain.StepLevel;

public interface StepLevelRepository extends JpaRepository<StepLevel, Long>{
	
	@Query(value = "select * from ux_step_level where start <= ?1 and end > ?1",nativeQuery = true)
	StepLevel findByStep(Long stepVal);
}
