package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderPaipaiSpace;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

/**
 * Created by Administrator on 2017/2/23.
 */
public interface HolderPaipaiSpaceRepository  extends JpaRepository<HolderPaipaiSpace, Long> {


    HolderPaipaiSpace findOneByHolderId(Long id);
    // 查询出 拍拍秀表中 按分享时间降序排列的 拍拍秀记录
    @Query(value = "SELECT *FROM ux_paipai_space ps   where last_share_file_id!=?3 and  last_share_time>0 and last_share_file_id is not null ORDER BY ps.last_share_time DESC limit ?1,?2" ,nativeQuery = true)
    List<HolderPaipaiSpace> findAllByFileIdOrderByLastShareTimeDesc(Integer page, Integer rows, Long lastShareFileId);

    @Query(value = "SELECT *FROM ux_paipai_space ps  where most_zan_file_id !=?3  and  zan_num>=0 and most_zan_file_id is not null ORDER BY ps.zan_num DESC limit ?1,?2" ,nativeQuery = true)
    List<HolderPaipaiSpace> findAllByFileIdOrderByZanNumDesc(Integer page, Integer rows, Long mostZanFileId);

}
