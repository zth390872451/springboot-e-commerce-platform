package com.umeox.babywei.service;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderSchedule;

public interface HolderScheduleService {

     void setClassTime(HolderSchedule holderSchedule);

     void setConcernTime(HolderSchedule holderSchedule);

    //此设备是否在上课期间
    public boolean isDuringClass(Holder holder);
}
