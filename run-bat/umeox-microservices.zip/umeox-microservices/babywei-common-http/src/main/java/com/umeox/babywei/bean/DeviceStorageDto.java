package com.umeox.babywei.bean;

import java.util.List;

/**
 * Created by Administrator on 2017/5/26.
 */
public class DeviceStorageDto {
    private List<String> imeis;
    private DeviceUploadInfoDto deviceUploadInfoDto;

    public DeviceStorageDto() {
    }

    public DeviceStorageDto(List<String> imeis, DeviceUploadInfoDto deviceUploadInfoDto) {
        this.imeis = imeis;
        this.deviceUploadInfoDto = deviceUploadInfoDto;
    }

    public List<String> getImeis() {
        return imeis;
    }

    public void setImeis(List<String> imeis) {
        this.imeis = imeis;
    }

    public DeviceUploadInfoDto getDeviceUploadInfoDto() {
        return deviceUploadInfoDto;
    }

    public void setDeviceUploadInfoDto(DeviceUploadInfoDto deviceUploadInfoDto) {
        this.deviceUploadInfoDto = deviceUploadInfoDto;
    }
}
