package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Barrier;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Component("barrierRepository")
public interface BarrierRepository extends JpaRepository<Barrier, Long>{
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_barrier where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	@Modifying
	@Transactional
	@Query("update Barrier b set b.open = ?1 where b.holder.id = ?2 and b.id = ?3")
	void setOpenFor(int open, Long holderId, Long id);
	
	@Modifying
	@Transactional
	@Query("update Barrier b set b.open = ?1 where b.holder.id = ?2")
	void setOpenFor(int open, Long holderId);
	
	List<Barrier> findByHolderId(Long holderId);
	
	List<Barrier> findByHolderIdAndOpen(Long holderId, int open);
}
