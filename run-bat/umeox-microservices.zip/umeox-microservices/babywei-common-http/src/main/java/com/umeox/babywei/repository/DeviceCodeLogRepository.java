package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.umeox.babywei.domain.DeviceCodeLog;

public interface DeviceCodeLogRepository extends JpaRepository<DeviceCodeLog, Long>,JpaSpecificationExecutor<DeviceCodeLog> {

}
