package com.umeox.babywei.service;

import com.umeox.babywei.domain.Community;

/**
 * Created by Administrator on 2016/10/18.
 */
public interface CommunityService {
    Community findCommunityBySaleChannel(String saleChannel);

    Community findCommunityById(Long id);
}
