package com.umeox.babywei.service;

import com.umeox.babywei.domain.OpenUser;

import java.util.Map;

public interface OpenUserService {

	OpenUser getOpenUserByMobile(String userId,String clientId);

	OpenUser getOpenUserByOpenId(String openId, String clientId);

}
