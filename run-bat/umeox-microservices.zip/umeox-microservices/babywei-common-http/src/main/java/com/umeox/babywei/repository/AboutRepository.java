package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.umeox.babywei.domain.About;

public interface AboutRepository extends JpaRepository<About, Long>{
	
	About findOneBySaleChannel(String saleChannel);
}
