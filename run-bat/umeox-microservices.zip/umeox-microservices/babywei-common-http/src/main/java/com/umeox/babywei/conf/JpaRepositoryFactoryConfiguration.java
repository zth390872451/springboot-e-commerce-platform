package com.umeox.babywei.conf;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * @author umeox
 */
@Configuration
@EnableJpaRepositories(basePackages = "com.umeox.babywei" ,repositoryFactoryBeanClass = com.umeox.babywei.repository.support.DefaultRepositoryFactoryBean.class)
public class JpaRepositoryFactoryConfiguration {
}
