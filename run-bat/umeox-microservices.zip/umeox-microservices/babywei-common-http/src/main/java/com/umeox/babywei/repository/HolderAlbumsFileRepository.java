package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderAlbumsFile;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by Administrator on 2017/2/22.
 */
public interface HolderAlbumsFileRepository extends CrudRepository<HolderAlbumsFile, Long> {
    //推荐照片
    @Query(value = "SELECT *FROM ux_holder_albums_file haf where haf.holder_albums_id=?1 and status = ?2 " +
            " ORDER BY haf.upload_time DESC  limit ?3" ,nativeQuery = true)
    List<HolderAlbumsFile> findRecommendFiles(Long holder_albums_id,Integer status,Integer size);
    //文件更新数量
    @Query(value = "SELECT count(1) FROM ux_holder_albums_file haf where haf.holder_albums_id=?1 and status = ?2 and haf.upload_time>?3" +
            " ORDER BY haf.upload_time DESC " ,nativeQuery = true)
    Long countFileUpdateNum(Long holder_albums_id,Integer status,Long uploadTime);

    //查询某天上传的图片，并且按降序排列
    @Query(value = "SELECT *FROM ux_holder_albums_file f where  FROM_UNIXTIME(f.upload_time/1000, '%Y-%m-%d') =?1 and f.holder_albums_id=?2 and status = ?3  ORDER BY upload_time DESC " ,nativeQuery = true)
    List<HolderAlbumsFile> findAllByDayAndHolderAlbumsId(String day, Long holderAlbumsId, Integer status);

    @Query(value = "SELECT *FROM ux_holder_albums_file f where  upload_time>=?1 and upload_time<= ?2 and f.holder_albums_id=?3 and status = ?4 ORDER BY upload_time DESC limit ?5" ,nativeQuery = true)
    List<HolderAlbumsFile> findAllByUploadTimeAndHolderAlbumsIdAndStatus(Long todayStart, Long endTime, Long holderAlbumsId, Integer status, Integer size);

    @Query(value = "select *from ux_holder_albums_file where holder_id = ?2 and status = ?3 and id in ?1 ",nativeQuery = true)
    List<HolderAlbumsFile> findAllIdIn(List<String> ids,Long holderId,Integer status);

    @Modifying
    @Transactional
    @Query(value = "delete from ux_holder_albums_file where holder_id = ?2 and id in ?1 ",nativeQuery = true)
    Long deleteHolderAlbumsFileByIdsAndHolderId(String ids,Long holderId);

    @Modifying
    @Transactional
    @Query(value = "update  ux_holder_albums_file  set status=?3 where holder_id = ?2 and id in ?1  ",nativeQuery = true)
    Integer updateHolderAlbumsFileByIdsAndHolderId(List<String> ids,Long holderId,Integer status);

    //照片存在 + 点赞数降序的列表
    @Query(value = "SELECT *FROM ux_holder_albums_file af where  af.status = 0 ORDER BY af.zan_num DESC LIMIT ?1,?2 " ,nativeQuery = true)
    List<HolderAlbumsFile> findAllByParamsOrderByZanNum(Integer page, Integer rows);
    //获取 拍拍空间内的文件(降序)
    @Query(value = "SELECT *FROM ux_holder_albums_file af where holder_id = ?1   and access_flag = ?2 ORDER BY af.share_date DESC LIMIT ?3,?4 " ,nativeQuery = true)
    List<HolderAlbumsFile> findAllByHolderIdAndAccessFlagOrderByShareDate(Long holderId, Integer accessFlag, Integer page, Integer size);

    @Query(value = "SELECT *FROM ux_holder_albums_file af where holder_id = ?1 and access_flag = ?2 ORDER BY af.zan_num DESC LIMIT ?3,?4  " ,nativeQuery = true)
    List<HolderAlbumsFile> findOneByHolderIdAndAccessFlagAndOrderByZanNumDesc(Long holderId, Integer accessFlag, Integer page, Integer size);

    @Query(value = "SELECT *FROM ux_holder_albums_file af where holder_id = ?1  and access_flag = ?2  ORDER BY af.view_num  DESC LIMIT ?3,?4 " ,nativeQuery = true)
    List<HolderAlbumsFile> findOneByHolderIdAndAccessFlagAndOrderByViewNumDesc(Long holderId, Integer accessFlag, Integer page, Integer size);

    @Query(value = "SELECT *FROM ux_holder_albums_file af where holder_id = ?1  and access_flag = ?2 ORDER BY af.share_date DESC LIMIT ?3,?4 " ,nativeQuery = true)
    List<HolderAlbumsFile> findOneByHolderIdAndAccessFlagAndStatusAndOrderByShareDateDesc(Long holderId, Integer accessFlag,Integer page,Integer size);

}
