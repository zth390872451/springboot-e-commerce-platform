package com.umeox.babywei.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.ImRelation;

public interface ImRelationRepository extends JpaRepository<ImRelation, Long>{
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_im_relation where user_id = ?1 and friend_id = ?2",nativeQuery = true)
	void deleteByUserIdAndFriendId(String userId,String friendId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_im_relation where user_id = ?1",nativeQuery = true)
	void deleteByUserId(String userId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_im_relation where friend_id = ?1",nativeQuery = true)
	void deleteByFriendId(String friendId);
	
	ImRelation findOneByUserIdAndFriendId(String userId,String friendId);
	
	List<ImRelation> findByFriendId(String friendId);
	
	List<ImRelation> findByUserId(String userId);
	
	@Modifying
	@Transactional
	@Query(value = "update ux_im_relation set nick = ?1,photo_flag = ?2 where user_id = ?3 and friend_id = ?4",nativeQuery = true)
	void setNickAndPhotoFlag(String nick,String photoFlag, String imUserID, String imFriendID);
}
