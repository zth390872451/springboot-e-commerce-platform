package com.umeox.babywei.bean;

/**
 * Created by Administrator on 2016/12/7.
 */
public class ReceiptResult {
    private String state;//状态，例如DELIVRD
    private String statusInt;//是否送达，1表示送达
    private String msgId;//短信发送平台的信息ID
    private String destId;//端口号
    private String srcTermId;//手机号码
    private String submitDate;//提交时间
    private String receiveDate;//接收时间

    private String sendTime;//上行时间
    private String msgContent;//上行内容

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getStatusInt() {
        return statusInt;
    }

    public void setStatusInt(String statusInt) {
        this.statusInt = statusInt;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getDestId() {
        return destId;
    }

    public void setDestId(String destId) {
        this.destId = destId;
    }

    public String getSrcTermId() {
        return srcTermId;
    }

    public void setSrcTermId(String srcTermId) {
        this.srcTermId = srcTermId;
    }

    public String getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(String submitDate) {
        this.submitDate = submitDate;
    }

    public String getReceiveDate() {
        return receiveDate;
    }

    public void setReceiveDate(String receiveDate) {
        this.receiveDate = receiveDate;
    }

    public String getSendTime() {
        return sendTime;
    }

    public void setSendTime(String sendTime) {
        this.sendTime = sendTime;
    }

    public String getMsgContent() {
        return msgContent;
    }

    public void setMsgContent(String msgContent) {
        this.msgContent = msgContent;
    }

    @Override
    public String toString() {
        return "ReceiptResult{" +
                "state='" + state + '\'' +
                ", statusInt='" + statusInt + '\'' +
                ", msgId='" + msgId + '\'' +
                ", destId='" + destId + '\'' +
                ", srcTermId='" + srcTermId + '\'' +
                ", submitDate='" + submitDate + '\'' +
                ", receiveDate='" + receiveDate + '\'' +
                ", sendTime='" + sendTime + '\'' +
                ", msgContent='" + msgContent + '\'' +
                '}';
    }
}
