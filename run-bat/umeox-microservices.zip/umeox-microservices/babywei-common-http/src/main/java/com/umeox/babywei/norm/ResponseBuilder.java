package com.umeox.babywei.norm;

public class ResponseBuilder {

    //success
    public static ResponseBody success() {
        return new ResponseBody(ResponseStatus._200);
    }

    //success with data
    public static ResponseBody success(Object result) {
        return new ResponseBody(ResponseStatus._200, result);
    }
    
    //success with data
    public static ResponseBody success(Integer status,String msg, Object result) {
        return new ResponseBody(status, msg, result);
    }

    
    //fail with HttpStatus
    public static ResponseBody fail() {
        return new ResponseBody(ResponseStatus._201);
    }
    
    //fail with HttpStatus
    public static ResponseBody fail(ResponseStatus responseStatus) {
        return new ResponseBody(responseStatus);
    }

    //fail with HttpStatus ,override msg
    public static ResponseBody fail(ResponseStatus responseStatus, String msg) {
        return new ResponseBody(responseStatus.getStatus(), msg);
    }

    //fail with Message
    public static ResponseBody fail(String message) {
        return new ResponseBody(ResponseStatus._201.getStatus(),message);
    }
    
}
