package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderWifi;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("holderWifiRepository")
public interface HolderWifiRepository extends JpaRepository<HolderWifi, Long>,JpaSpecificationExecutor<Holder>{
	List<HolderWifi> findAllByHolderId(Long holderId);

	HolderWifi findOneByIdAndHolderId(Long id,Long holderId);

}
