/*
package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Client;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientRepository extends JpaRepository<Client, Long>{

	Client findOneByToken(String token);

	
}
*/
