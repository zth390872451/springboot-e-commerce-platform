package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.umeox.babywei.domain.PluginConfig;

public interface PluginConfigRepository extends JpaRepository<PluginConfig,Long> {
		
}
