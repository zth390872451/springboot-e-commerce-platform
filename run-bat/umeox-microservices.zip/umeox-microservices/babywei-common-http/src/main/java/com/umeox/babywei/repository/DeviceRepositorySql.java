package com.umeox.babywei.repository;

import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;
import com.umeox.babywei.domain.Device;

@Repository
public class DeviceRepositorySql {
	@PersistenceUnit
	private EntityManagerFactory emf;
	
	public Page<Device> findBindAbnormal(String saleChannel,Pageable pageable){
		String sql = "SELECT * FROM ux_device WHERE STATUS = '1' AND activity_status = '1'  ";
		if(!StringUtils.isEmpty(saleChannel)){
			sql += "AND sale_channel = ? " ;
		}
		sql += "AND holder_id NOT IN (SELECT holder_id FROM ux_monitor WHERE holder_id IN (SELECT holder_id FROM ux_device WHERE STATUS = '1' AND activity_status = '1' ";
		if(!StringUtils.isEmpty(saleChannel)){
			sql += "AND sale_channel = ? " ;
		}
		sql += ")) limit "+pageable.getPageNumber()*pageable.getPageSize()+ ","+pageable.getPageSize() ;
		EntityManager em = emf.createEntityManager();
		Query query = em.createNativeQuery(sql, Device.class);
		if(!StringUtils.isEmpty(saleChannel)){
			query.setParameter(1, saleChannel);
            query.setParameter(2, saleChannel);
		}
		return new PageImpl<Device>(query.getResultList(), pageable, this.getBindAbnormalTotal(saleChannel));
	}
	
	private Long getBindAbnormalTotal(String saleChannel){
		String sql = "SELECT COUNT(1) FROM ux_device WHERE STATUS = '1' AND activity_status = '1' ";
		if(!StringUtils.isEmpty(saleChannel)){
			sql += "AND sale_channel = ? " ;
		}
		sql += "AND holder_id NOT IN (SELECT holder_id FROM ux_monitor WHERE holder_id IN (SELECT holder_id FROM ux_device WHERE STATUS = '1' AND activity_status = '1' ";
		if(!StringUtils.isEmpty(saleChannel)){
			sql += "AND sale_channel = ? " ;
		}
		sql += "))";
		EntityManager em = emf.createEntityManager();
		Query query = em.createNativeQuery(sql);
		if(!StringUtils.isEmpty(saleChannel)){
			query.setParameter(1, saleChannel);
            query.setParameter(2, saleChannel);
		}
		BigInteger total = (BigInteger)query.getSingleResult();
        return total.longValue();
	}
}
