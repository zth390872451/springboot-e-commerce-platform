package com.umeox.babywei.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.umeox.babywei.domain.Admin;

public interface AdminRepository extends JpaRepository<Admin,Long>{
	Admin findOneByUsername(String username);
	
	@Transactional
	@Modifying
	@Query(value="delete from sys_admin where id in (?1)",nativeQuery=true)
	void deleteByIds(List<Long> ids);
	
	@Transactional
	@Modifying
	@Query(value="delete from sys_admin_role where admins in (?1)",nativeQuery=true)
	void deleteAdminRoleByIds(List<Long> ids);
}
