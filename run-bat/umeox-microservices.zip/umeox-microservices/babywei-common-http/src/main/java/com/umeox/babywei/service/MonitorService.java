package com.umeox.babywei.service;

import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.domain.*;

import java.util.List;
import java.util.Map;


public interface MonitorService{

	/**
	 * 获取所有关注胶囊的用户
	 * @param holderId 主监护ID
	 * @return
	 */
	public Map<String,String> findMonitorsByHolder(Long holderId);
	
	/**
	 * 邀约答应设备监护人（激活白名单）
	 * @param monitor
	 * @param holder
	 */
	public List<Mark> accept(Device device, Holder holder, Member member,ImSendLog imSendLog);
	
	public void acceptPlus(Device device, Holder holder, Member member, Message message);
	
	/**
	 * 审核通过成为设备监护人
	 * @param device
	 * @param memberId
	 * @return
	 */
	public Monitor update(Device device, Member member);
	
	/**
	 * 删除关注者以及亲情号码
	 * @param monitorId
	 * @param holderId
	 * @param mobile
	 */
	public List<Mark> delete(Monitor monitor,String mobile);
	/**
	 * 审核通过成为设备监护人
	 * @param device
	 * @param member
	 * @param message
	 */
	public void pass(Device device, Member member, Message message);
	
	/**
	 * 移交管理员
	 * @param admin  管理员
	 * @param followers  关注者
	 */
	public void transferAdmin(Monitor admin,Monitor followers );
}
