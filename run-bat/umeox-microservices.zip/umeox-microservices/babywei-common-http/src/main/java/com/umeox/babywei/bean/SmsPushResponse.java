/*
package com.umeox.babywei.bean;

import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

*/
/**
 *  获取回执和上行接口（系统推送）的返回结果
 *  xml 转换的对象 (Spring mvc转换)
 *  参数名为response
 *//*

//@XmlRootElement(name = "xml")
public class SmsPushResponse {
    */
/*<response>
<apName>test1</apName> --用户名
<receiptCnt>回执数</receiptCnt>
<receiptResult>   --回执例子， 有state元素
<state>状态</state>   --回执文本，例如DELIVRD
<statusInt>1</statusInt>  --是否送达，1表示送达
<msgId>1380154827820433462</msgId>
<destId>端口号</destId>
<srcTermId>手机号码</srcTermId>
    <submitDate>提交时间</submitDate>
<receiveDate>接收时间</receiveDate>
</receiptResult>

<receiptResult>   --上行例子， 有msgContent元素
<destId>端口号<</destId>
<srcTermId>手机号码/srcTermId>
<sendTime>上行时间</sendTime>
<msgContent>上行内容</msgContent>
</receiptResult>
</response>

*//*

    private String apName;//用户名
    private String receiptCnt;//回执数
    private ReceiptResult receiptResult;//回执结果

    public String getApName() {
        return apName;
    }

    public void setApName(String apName) {
        this.apName = apName;
    }

    public String getReceiptCnt() {
        return receiptCnt;
    }

    public void setReceiptCnt(String receiptCnt) {
        this.receiptCnt = receiptCnt;
    }

    public ReceiptResult getReceiptResult() {
        return receiptResult;
    }

    public void setReceiptResult(ReceiptResult receiptResult) {
        this.receiptResult = receiptResult;
    }

    @Override
    public String toString() {
        return "SmsPushResponse{" +
                "apName='" + apName + '\'' +
                ", receiptResult=" + receiptResult +
                '}';
    }

}
*/
