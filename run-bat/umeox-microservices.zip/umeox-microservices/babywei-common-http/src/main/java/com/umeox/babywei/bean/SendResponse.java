package com.umeox.babywei.bean;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * 单条发送短信的响应结果(xml转换后的对象)
 */
@XmlRootElement(name = "response")
public class SendResponse {
    /*<response>
    <error>0</error> 0为正确，其他情况为异常
    <message>描叙信息</message>
    <successCnt>提交成功数</successCnt>
    <msgId>123456789</msgId>
            .....如果是长短信会有多个msgId
    <msgId>123456789</msgId>
    </response>
*/
    private String error;// 0为正确，其他情况为异常
    private String message;//描叙信息
    private String successCnt;//提交成功数
    private String[] msgId;//短信标识 (单条或多条)

    @Override
    public String toString() {
        return "SendResponse{" +
                "error='" + error + '\'' +
                ", message='" + message + '\'' +
                ", successCnt='" + successCnt + '\'' +
                ", msgId='" + msgId + '\'' +
                '}';
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSuccessCnt() {
        return successCnt;
    }

    public void setSuccessCnt(String successCnt) {
        this.successCnt = successCnt;
    }

    public String[] getMsgId() {
        return msgId;
    }

    public void setMsgId(String[] msgId) {
        this.msgId = msgId;
    }
}
