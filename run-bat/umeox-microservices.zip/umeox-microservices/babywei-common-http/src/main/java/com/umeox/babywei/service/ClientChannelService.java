package com.umeox.babywei.service;

import java.util.List;


public interface ClientChannelService {
	
	public List<String> findChannelCodeByClientId(String clientId);
}
