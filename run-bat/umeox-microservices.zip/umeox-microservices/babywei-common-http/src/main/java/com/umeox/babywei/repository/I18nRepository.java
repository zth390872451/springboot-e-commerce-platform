package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.umeox.babywei.domain.I18N;

public interface I18nRepository extends JpaRepository<I18N, Long>{
	
	I18N findOneByLocaleAndMapkey(String locale,String key);
}
