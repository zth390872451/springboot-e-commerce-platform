package com.umeox.babywei.service;

import java.util.List;

/**
 * Created by Administrator on 2017/3/29.
 */

public interface AppToDeviceTypeService {
    /**
     * 根据appid查询登录该APP应用的用户可以查看哪些设备类型关注或者(绑定)的手表。
     * 如：卫小宝的APP可以查看所有属于卫小宝系列的设备
     * @param appId
     * @return
     */
    List<String> getDeviceTypeList(String appId);

}
