package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.umeox.babywei.domain.DeviceType;

public interface DeviceTypeRepository extends JpaRepository<DeviceType, Long> {
	
}
