package com.umeox.babywei.service;

import com.umeox.babywei.domain.Content;

public interface ContentService {
	
	public Content updateViewCnt(Long id);
}
