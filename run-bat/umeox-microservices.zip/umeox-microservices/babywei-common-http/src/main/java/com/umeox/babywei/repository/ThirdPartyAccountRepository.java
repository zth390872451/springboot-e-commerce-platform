package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.ThirdPartyAccount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by Administrator on 2017/2/20.
 */
public interface ThirdPartyAccountRepository extends JpaRepository<ThirdPartyAccount, Long> {

    ThirdPartyAccount findFirstByOpenIdAndType(String openId, Integer type);

    List<ThirdPartyAccount> findAllByMember(Member member);
}
