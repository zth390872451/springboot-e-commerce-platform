package com.umeox.babywei.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.CallRecords;

public interface CallRecordsRepository extends JpaRepository<CallRecords, Long>,JpaSpecificationExecutor<CallRecords>{
	
	Page<CallRecords> findByHolderIdOrderByStartTimeDesc(Long holderId, Pageable pageable);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_call_records where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_call_records where family_number_id = ?1",nativeQuery = true)
	void deleteByFamilyNumberId(Long familyNumberId);
}
