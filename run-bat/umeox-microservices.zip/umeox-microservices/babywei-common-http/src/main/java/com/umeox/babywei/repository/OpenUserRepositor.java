package com.umeox.babywei.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.umeox.babywei.domain.OpenUser;

public interface OpenUserRepositor extends JpaRepository<OpenUser, Long> {
	
	@Query(value = "from OpenUser as u where u.userId=?")
	OpenUser findOneByUserId(String userId);
	
	OpenUser findOneByMemberId(Long memberId);
	
	List<OpenUser> findByMobileIn(List<String> mobile);

	/**
	 * 根据第三方平台的标识 或者 账号
     */
	OpenUser findOneByMobile(String mobile);
}
