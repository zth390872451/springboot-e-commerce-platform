package com.umeox.babywei.bean;

import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

public class BinDto {
	/**
	 * 持有者名称
	 */
	private String name;

	/**
	 * 生日
	 */
	private Date birthday;
	private MultipartFile file;
	private String imei;
	private String sim;
	private String code;
	private String command;
	/**
	 * 性别 男male 女 woman
	 */
	private String gender;
	/**
	 * base64加密后图片字符串(IOS)
	 */
	private String imgStr;
	
	private Long monitorId;
	/**
	 * 与设备持有人的关系
	 */
	private String relation;

	/**
	 * 身高
	 */
	private String height;
	
	/**
	 * 体重
	 */
	private String weight;

	/**
	 * 年级
	 */
	private String grade;
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file) {
		this.file = file;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getSim() {
		return sim;
	}
	public void setSim(String sim) {
		this.sim = sim;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCommand() {
		return command;
	}
	public void setCommand(String command) {
		this.command = command;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getImgStr() {
		return imgStr;
	}
	public void setImgStr(String imgStr) {
		this.imgStr = imgStr;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Long getMonitorId() {
		return monitorId;
	}
	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
}
