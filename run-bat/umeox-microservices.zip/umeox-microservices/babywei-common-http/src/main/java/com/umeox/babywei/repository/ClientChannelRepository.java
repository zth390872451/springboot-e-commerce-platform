/*
package com.umeox.babywei.repository;

import com.umeox.babywei.domain.ClientChannel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClientChannelRepository extends JpaRepository<ClientChannel, Long>{
	
	List<ClientChannel> findByClientId(String clientId);
}
*/
