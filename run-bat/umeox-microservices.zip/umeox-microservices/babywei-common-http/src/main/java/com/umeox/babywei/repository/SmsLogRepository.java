package com.umeox.babywei.repository;

import com.umeox.babywei.domain.SmsLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;

public interface SmsLogRepository extends JpaRepository<SmsLog, Long> {
    @Query(value = "select count(1) from ux_sms_log where mobile = ?1 and Date(create_date) = CURRENT_DATE()",nativeQuery = true)
    Long findAllByMobileCurrentDate(String mobile);

    @Query(value = "select count(1) from ux_sms_log where mobile = ?1 ",nativeQuery = true)
    Long findAllByMobile(String mobile);

}
