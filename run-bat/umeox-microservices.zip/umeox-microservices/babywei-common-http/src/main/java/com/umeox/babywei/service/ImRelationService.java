package com.umeox.babywei.service;

import java.util.List;

import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.ImRelation;

public interface ImRelationService {
	
	List<Mark> update(Holder userHolder,Holder friendHolder,FamilyNumber familyNumber);
	
	List<Mark> deleteRelation(Holder userHolder,Holder friendHolder);
	
	List<ImRelation> findDeviceFriendByUserId(String userId);
	
	List<Mark> add(Holder userHolder,Holder friendHolder);
	
	void delete(ImRelation userImRelation);
}
