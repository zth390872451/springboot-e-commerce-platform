package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderPaipaiZan;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Administrator on 2017/2/25.
 */
public interface HolderPaipaiZanRepository extends JpaRepository<HolderPaipaiZan, Long> {
    HolderPaipaiZan findOneByMemberIdAndZanFileId(Long memberId, Long zanfileId);
}
