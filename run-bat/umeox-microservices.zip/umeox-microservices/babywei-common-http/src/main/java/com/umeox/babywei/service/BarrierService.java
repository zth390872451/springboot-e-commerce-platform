package com.umeox.babywei.service;

public interface BarrierService {

	void open(Long holderId, Long barrierId);
}
