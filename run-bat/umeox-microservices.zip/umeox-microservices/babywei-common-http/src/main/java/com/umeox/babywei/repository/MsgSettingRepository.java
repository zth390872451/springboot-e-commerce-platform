package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.MsgSetting;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface MsgSettingRepository extends JpaRepository<MsgSetting, Long>{

	@Modifying
	@Transactional
	@Query("update MsgSetting m set m.whiteList = ?1 where m.holder = ?2")
	int setWhiteListFor(String whiteList, Holder holder);
	
	@Modifying
	@Transactional
	@Query("update MsgSetting m set m.sosNumber = ?1 where m.holder = ?2")
	int setSosNumberFor(String sosNumber, Holder holder);
	
	@Modifying
	@Transactional
	@Query("update MsgSetting m set m.reportingStrategy = ?1 where m.holder = ?2")
	int setReportingStrategyFor(String reportingStrategy, Holder holder);
	
	@Modifying
	@Transactional
	@Query("update MsgSetting m set m.audioProfiles = ?1 where m.holder = ?2")
	int setAudioProfilesFor(String audioProfiles, Holder holder);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_msg_setting where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	@Modifying
	@Transactional
	@Query("update MsgSetting m set m.answerMode = ?1 where m.holder = ?2")
	int setAnswerModeFor(String answerMode, Holder holder);
	
	public MsgSetting findOneByHolder(Holder holder);
}
