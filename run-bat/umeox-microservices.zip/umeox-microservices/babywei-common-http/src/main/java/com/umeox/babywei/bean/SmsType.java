package com.umeox.babywei.bean;

public enum SmsType {
	/**
	 * 注册发送短信
	 */
	REGIST,
	/**
	 * 修改密码发送短信
	 */
	FORGET
}
