package com.umeox.babywei.repository;

import java.util.Date;

public interface PositionRepositoryCustom {

    public long customMethod(Long holderId, Date fromDate, Date toDate);
    
}
