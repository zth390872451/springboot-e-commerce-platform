package com.umeox.babywei.repository;


import com.umeox.babywei.domain.Device;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Component("deviceRepository")
public interface DeviceRepository extends JpaRepository<Device, Long>,JpaSpecificationExecutor<Device>{
	
	public Device findOneByImei(String imei);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_device where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	public List<Device> findBySaleChannelInAndActivityDateBetween(List<String> saleChannel, Date fromDate, Date toDate);
	
	public Device findOneByBindCode(String bindCode);
}
