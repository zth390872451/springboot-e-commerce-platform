package com.umeox.babywei.service;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;

import java.util.List;
import java.util.Map;

public interface DeviceService{
	
	/**
	 * 后台管理手动解除绑定
	 * 
	 * @param device
	 * @return 
	 */
	public List<Mark> adminUbound(Device device);
	
	/**
	 * 通过IMEI值获取设备
	 * @param  imei
	 * @return
	 */
	public Device findOneByImei(String imei);
	
	public Device update(Device device);

	/**
	 * (1.设备绑定；2.同步设备参数；3.同步联系人；4.同步好友)
	 * @param device
	 * @param member
     * @return
     */
	public Holder bind2(Device device, Member member, String sim);

	/**
	 * 绑定设备：1、持有者holder、holderSet保存 2、holder与device的关系
	 * @param holder
     */
	public void bind(Holder holder);
	
	public void delete(List<Long> ids);
	
	public Integer insertDeviceByExecl(List<Device> list,Long serverId);
	
	public void updateByDeviceList(List<Device> list,String... args) throws Exception;

	/**
	 * 解除Sim卡
	 * @param device
	 * @return
     */
	boolean removeSim(Device device);

	Map<String,Object> getContractMachineInfo(Device device);
}
