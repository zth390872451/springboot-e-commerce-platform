package com.umeox.babywei.service;

import com.umeox.babywei.domain.ChannelWh;

public interface ChannelWhService {
	
	public ChannelWh findOneByImei(String imei);
}
