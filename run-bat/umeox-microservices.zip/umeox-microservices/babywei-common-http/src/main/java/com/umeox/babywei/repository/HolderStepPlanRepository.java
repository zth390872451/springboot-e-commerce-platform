package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.HolderStepPlan;

public interface HolderStepPlanRepository extends JpaRepository<HolderStepPlan, Long>{
	
	HolderStepPlan findOneByHolderId(Long holderId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_step_plan where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
}
