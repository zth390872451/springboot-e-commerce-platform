package com.umeox.babywei.service;

import java.util.Map;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.ImSendLog;

public interface ImService {
	
	Map<String, Object> save(ImSendLog imSendLog,Holder holder);
	
}
