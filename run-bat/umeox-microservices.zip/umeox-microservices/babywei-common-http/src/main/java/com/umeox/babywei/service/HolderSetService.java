package com.umeox.babywei.service;

import com.umeox.babywei.domain.HolderSet;

public interface HolderSetService {
	public void update(HolderSet holderSet, Integer itemFlag, String itemVal);
}
