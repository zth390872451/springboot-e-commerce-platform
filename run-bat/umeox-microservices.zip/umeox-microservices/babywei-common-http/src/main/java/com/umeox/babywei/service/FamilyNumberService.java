package com.umeox.babywei.service;

import java.util.List;

import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;

public interface FamilyNumberService{
	
	public List<Mark> add(FamilyNumber familyNumber);

	public List<Mark> addAndInviteMember(String mobile, FamilyNumber familyNumber,Member member);
	
	public void setSort(FamilyNumber familyNumber, Integer sort);
	
	public List<Mark> delete(FamilyNumber familyNumber, Member member, Holder holder);
	
	public void save(FamilyNumber familyNumber);
	
	public void update(FamilyNumber familyNumber);
	
	public List<FamilyNumber> appAddFamilyNumbers(Long holderId);
	
	public List<FamilyNumber> deviceAddFamilyNumbers(Long holderId);

}
