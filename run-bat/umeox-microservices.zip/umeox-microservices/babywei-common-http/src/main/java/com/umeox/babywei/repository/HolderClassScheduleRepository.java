package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderClassSchedule;
import com.umeox.babywei.domain.Holder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Component;

@Component("holderClassScheduleRepository")
public interface HolderClassScheduleRepository extends JpaRepository<HolderClassSchedule, Long>,JpaSpecificationExecutor<Holder>{


	HolderClassSchedule findOneByHolderId(Long holderId);
}
