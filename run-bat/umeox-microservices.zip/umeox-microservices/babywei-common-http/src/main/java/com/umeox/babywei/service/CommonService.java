package com.umeox.babywei.service;

import java.util.List;

import com.umeox.babywei.bean.Notice;
import com.umeox.babywei.domain.ImSendLog;

public interface CommonService {
	
	List<ImSendLog> findByMessageIdFlag(String key,Long messageId);

	List<ImSendLog> findByMessageIdFlag2(String key,Long messageId);
	
	List<ImSendLog> findGroupMessageById(String key,Long messageId);

	List<ImSendLog> findGroupMessageById2(String key,Long messageId);
	
	List<ImSendLog> findGroupMessageByCreateDate(String key,Long createDate);

	List<ImSendLog> findGroupMessageByCreateDate2(String key,Long createDate);
	
	List<Notice> findNoticeByMessageIdFlag(String key,Long messageId);
}
