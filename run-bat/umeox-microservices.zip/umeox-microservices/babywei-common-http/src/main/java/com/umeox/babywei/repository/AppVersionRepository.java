package com.umeox.babywei.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.umeox.babywei.domain.AppVersion;

public interface AppVersionRepository extends JpaRepository<AppVersion, Long>{
	
	@Query(value = "select * from sys_app_version where client_id = ?1 and type = 0 and app_version > ?2 and app_version <= ?3",nativeQuery = true)
	List<AppVersion> findByIosParam(String clientId,Double currentVersion,Double storeVersion);
	
	
	@Query(value = "select * from sys_app_version where client_id = ?1 and type = 1 and app_version > ?2",nativeQuery = true)
	List<AppVersion> findByAndroidParam(String clientId,Double currentVersion);


	//查找数据库中维护的AppId对应的最大版本号的记录
	@Query(value = "select * from sys_app_version where client_id = ?1 and type = ?2 order by app_version  desc Limit 1",nativeQuery = true)
	AppVersion findMaxByClientIdAndType(String clientId,int type);
}
