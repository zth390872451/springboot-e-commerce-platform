package com.umeox.babywei.bean;

public class BaseSim {
	private String sim;
	private int realnameStatus;
	
	
	public String getSim() {
		return sim;
	}
	public void setSim(String sim) {
		this.sim = sim;
	}
	public int getRealnameStatus() {
		return realnameStatus;
	}
	public void setRealnameStatus(int realnameStatus) {
		this.realnameStatus = realnameStatus;
	}
	
	
}
