package com.umeox.babywei.repository;

import com.umeox.babywei.domain.OpenChannel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OpenChannelRepository extends JpaRepository<OpenChannel, Long>{

	OpenChannel findOneByClientIdAndSaleChannel(String clientId, String saleChannel);

	List<OpenChannel> findAllByClientId(String clientId);
}
