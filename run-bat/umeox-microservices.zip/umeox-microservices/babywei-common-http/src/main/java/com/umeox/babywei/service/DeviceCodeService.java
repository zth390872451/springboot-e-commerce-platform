package com.umeox.babywei.service;

import java.util.List;
import java.util.Map;

public interface DeviceCodeService {
	public List<String> batch(List<Map<String, String>> list, String des,String lot);
}
