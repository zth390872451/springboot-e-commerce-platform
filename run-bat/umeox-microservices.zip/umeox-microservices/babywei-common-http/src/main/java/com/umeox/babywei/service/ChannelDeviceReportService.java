package com.umeox.babywei.service;

import com.umeox.babywei.bean.ChannelDeviceReportDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Date;
import java.util.List;

/**
 * Created by Administrator on 2016/5/31.
 */
public interface ChannelDeviceReportService {
    /**
     * @return 导出信息列表
     */
    List getReportListOrPage(Date begin, Date end, String channel, String deviceType);
    /**
     * @return 分页信息列表
     */
    Page<ChannelDeviceReportDto> getReportListOrPage(Date begin, Date end, String saleChannel, String deviceType, Pageable pageable);
}
