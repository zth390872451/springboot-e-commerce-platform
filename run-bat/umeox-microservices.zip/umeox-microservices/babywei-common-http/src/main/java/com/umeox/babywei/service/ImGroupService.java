package com.umeox.babywei.service;

import java.util.List;

import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.domain.ImGroup;
import com.umeox.babywei.domain.ImGroupMember;

public interface ImGroupService {
	
	List<Long> quit(ImGroupMember imGroupMember);
	
	List<Mark> updateGroupName(ImGroup imGroup);
}
