package com.umeox.babywei.norm;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.umeox.babywei.ApplicationSupport;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL) //Filter null field
public class ResponseBody {

    //response code, error code
    private Integer status;

    //response desc, error msg
    private String msg;

    //response data
    private Object result;

    //response time
    private Long timestamp;

    public ResponseBody(Integer status, String key, Object result) {
        this.status = status;
        this.msg = ApplicationSupport.getMessageByEnv(key);
        if (this.msg == null) {
            this.msg = key;
        }
        this.result = result;
        this.timestamp = System.currentTimeMillis();
    }


    public ResponseBody(ResponseStatus httpStatus, Object result) {
        this(httpStatus.getStatus(), httpStatus.getReasonPhrase(), result);
    }

    public ResponseBody(Integer status, String key) {
        this(status, key, null);
    }

    public ResponseBody(ResponseStatus httpStatus) {
        this(httpStatus.getStatus(), httpStatus.getReasonPhrase(), null);
    }


    public Integer getStatus() {
		return status;
	}


	public void setStatus(Integer status) {
		this.status = status;
	}


	public String getMsg() {
		return msg;
	}


	public void setMsg(String msg) {
		this.msg = msg;
	}


	public Object getResult() {
		return result;
	}


	public void setResult(Object result) {
		this.result = result;
	}


	public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }
}
