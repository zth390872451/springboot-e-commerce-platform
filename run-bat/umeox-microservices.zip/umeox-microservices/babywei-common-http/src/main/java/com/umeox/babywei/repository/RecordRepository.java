package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Record;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

public interface RecordRepository extends JpaRepository<Record, Long>{

	@Modifying
	@Transactional
	@Query(value = "delete from ux_record where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);
	
	@Query(value = "from Record r where r.holder.id = ?1 and r.createDate between ?2 and ?3 ")
	List<Record> findByHolderIdAndCreateDateBetween(Long holderId, Date beginDate, Date endDate);
}
