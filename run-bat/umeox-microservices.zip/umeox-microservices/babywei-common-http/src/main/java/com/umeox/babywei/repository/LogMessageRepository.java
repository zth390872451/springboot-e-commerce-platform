package com.umeox.babywei.repository;

import com.umeox.babywei.domain.LogMessage;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Component("logMessageRepository")
public interface LogMessageRepository extends JpaRepository<LogMessage, Long>{
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_log_message where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);

	@Query(value = "select m.* from ux_log_message m where m.holder_id = ?1 and m.member like ?2 and m.msg_time between ?3 and ?4 order by msg_time desc limit ?5,?6",nativeQuery = true)
	List<LogMessage> queryByHolderIdAndMobileAsPage(Long holderId, String mobile, Date dept, Date dest, Integer first, Integer count);

	@Query(value = "select m.* from ux_log_message m where m.holder_id = ?1 and m.member like ?2 and id > ?3   order by msg_time desc limit ?4",nativeQuery = true)
	List<LogMessage> findAllByMessageIdGrater(Long holderId, String mobile, Long messageId, Integer size);

	@Query(value = "select m.* from ux_log_message m where m.holder_id = ?1 and m.member like ?2 and id < ?3  order by id desc limit ?4",nativeQuery = true)
	List<LogMessage> findAllByMessageIdLess(Long holderId, String mobile, Long messageId, Integer size);

	@Query(value = "select m.* from ux_log_message m where m.holder_id = ?1 and m.member like ?2  order by id desc limit ?3",nativeQuery = true)
	List<LogMessage> findAllByHolderIdAndMobileAndOrderByIdDesc(Long holderId, String mobile, Integer size);
}
