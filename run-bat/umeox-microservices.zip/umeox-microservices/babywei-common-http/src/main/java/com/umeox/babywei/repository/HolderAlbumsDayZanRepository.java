package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderAlbumsDayZan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;

/**
 * Created by Administrator on 2017/2/23.
 */
public interface HolderAlbumsDayZanRepository extends JpaRepository<HolderAlbumsDayZan, Long> {

    HolderAlbumsDayZan findByMemberIdAndDayAndIsZan(Long memberId, Date day, Boolean b);

    @Query(value = "SELECT count(1) FROM ux_holder_albums_day_zan az WHERE az.holder_albums_id = ?1 and az.is_zan=?2",nativeQuery = true)
    Long countByHolderAlbumsAndDayAndIsZanAndIsZan(Long holderAlbumsId, Integer isZan);
}
