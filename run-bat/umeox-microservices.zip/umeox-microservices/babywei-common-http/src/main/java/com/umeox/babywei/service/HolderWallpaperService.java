package com.umeox.babywei.service;

import com.umeox.babywei.domain.HolderWallpaper;

/**
 * @creator ZTH
 * @modifier ZTH
 * @date 2017-08-15
 */
public interface HolderWallpaperService {

	void deleteByHolderIdAndIds(Long holderId,Long[] ids);

	HolderWallpaper updateByHolderIdAndId(Long holderId, Long id, String wallpaperUrl);
}
