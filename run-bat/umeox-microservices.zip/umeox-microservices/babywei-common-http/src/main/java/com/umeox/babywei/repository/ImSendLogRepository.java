package com.umeox.babywei.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.umeox.babywei.domain.ImSendLog;

public interface ImSendLogRepository extends JpaRepository<ImSendLog, Long>{
	
	@Query(value = "select s.* from ux_im_send_log s where s.friend_id = ?1 and s.user_id = ?2 order by s.id desc limit ?3 ",nativeQuery = true)
	List<ImSendLog> findNewRows(String mobile,String imei,Integer rows);
	
	@Query(value = "select s.* from ux_im_send_log s where s.friend_id = ?1 and s.user_id = ?2 and s.id > ?3 order by s.id asc limit ?4 ",nativeQuery = true)
	List<ImSendLog> findByMessageIdUpRows(String mobile,String imei,Long messageId,Integer rows);
	
	@Query(value = "select s.* from ux_im_send_log s where s.friend_id = ?1 and s.user_id = ?2 and s.id < ?3 order by s.id desc limit ?4 ",nativeQuery = true)
	List<ImSendLog> findByMessageIdDownRows(String mobile,String imei,Long messageId,Integer rows);
}
