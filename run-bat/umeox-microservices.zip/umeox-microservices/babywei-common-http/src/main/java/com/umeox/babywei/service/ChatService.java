package com.umeox.babywei.service;

import com.umeox.babywei.domain.ImSendLog;

public interface ChatService {
	
	public void friendChat(ImSendLog imSendLog);
	
	public void groupChat(ImSendLog imSendLog);
}
