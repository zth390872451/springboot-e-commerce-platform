package com.umeox.babywei.service;

public interface MessageQueueService {
	
	void addWeTalkSyncDataFlag(Object holderId,Integer cmdValue);
	
	void addSyncDataAndUpdateFlag(Object holderId,Integer cmdValue);
	
	void addImCmd(Long id, Integer cmdValue, String key);
	
	//添加定位命令
	void addLocationCmd(String reqUser,String toUser,String locationCode);
	
	//添加解绑命令
	void addUnboundCmd(String imei,String unboundCode);
	
	void addWeTalkUnboundCmd(String imei,String unboundCode);
	
	//远程监听
	void addRemoteMonitoringCmd(String holderId,String reqUser,String phone);
	
	void addTakePhotoCmd(String holderId,String reqUser);
	
}
