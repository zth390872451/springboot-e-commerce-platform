package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Server;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

public interface ServerRepository extends JpaRepository<Server, Long> ,JpaSpecificationExecutor<Server> {
	
	@Transactional
	@Modifying
	@Query(value = "delete from ux_server where id IN (?1)", nativeQuery= true)
	public void deleteByIds(Long[] ids);

}
