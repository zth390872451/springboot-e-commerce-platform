package com.umeox.babywei.repository;

import com.umeox.babywei.domain.AppToDeviceType;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Administrator on 2017/3/29.
 */
public interface AppToDeviceTypeRepository extends JpaRepository<AppToDeviceType, Long> {



}
