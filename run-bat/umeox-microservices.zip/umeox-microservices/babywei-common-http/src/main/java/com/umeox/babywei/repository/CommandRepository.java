package com.umeox.babywei.repository;

import com.umeox.babywei.domain.Command;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommandRepository extends JpaRepository<Command, Long>{

}
