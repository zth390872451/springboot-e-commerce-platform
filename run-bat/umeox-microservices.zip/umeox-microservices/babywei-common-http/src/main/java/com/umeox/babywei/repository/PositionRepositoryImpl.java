package com.umeox.babywei.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import java.util.Date;


@Repository
public class PositionRepositoryImpl implements PositionRepositoryCustom {

    private static final Logger log = LoggerFactory.getLogger(PositionRepositoryImpl.class);

    @Override
    public long customMethod(Long holderId, Date fromDate, Date toDate) {
        return 0;
    }
}
