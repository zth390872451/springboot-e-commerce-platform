package com.umeox.babywei.service;

import java.util.List;
import java.util.Map;

import com.umeox.babywei.bean.BinDto;
import com.umeox.babywei.bean.HolderDto;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Monitor;


public interface HolderService {

	/**
	 * 更新关注人与设备拥有者关系
	 * @param holder
	 * @param relation
	 */
	public List<Mark> improve(Holder holder, BinDto bin);
	
	public void update(Monitor monitor, Holder holder, HolderDto dto);
	
	public void sos(Long memberId, Long holderId, Long monitorId, List<String> sos, String soses);
	
	//设置频率
	public void setFrequency(Holder holder);
	
	public Long unbound(Device device, Holder holder,String monitors);
	
	public void setAudioTypes(Holder holder, String audiotype);
	
	//public Holder findFirstByImei(String imei);
	
	public Holder update(Holder holder);
	
	public void updateAnswer(Holder holder,Integer answer);
	
	public void delete(Holder holder);
	
	public void setTimeZone(Holder holder);
	
	public String getAttentionCode(Long holderId);
	public void updateHolder(Map<String,Object> map);
}
