package com.umeox.babywei.norm;

//用在OpenAPI,Charge,K3 Device
public enum ResponseStatus {
	// http://open.weibo.com/wiki/index.php?title=Error_code&oldid=5881
	// ##全局相关
	_200(0, "sys.success"), _201(1, "sys.fail"),
	_20001(20001, "设备是解绑状态"),//设备是解绑状态
	_20002(20002, "设备是绑定状态"),//设备是绑定状态
	// _300(300,"已经关注"),

	// ##400: 参数相关
	_400(400, "sys.invalid.parameters"),

	// ##401：授权相关
	_401(401, "sys.unauthorized"), _401_INVALID_APPKEY(40101, "sys.invalid.appkey"),
	// 40102
	_401_INVALID_TOKEN(40102, "sys.invalid.token"),

	_401_TOKEN_EXPIRED(40103, "sys.token.expired"),

	// ##404：xx不存在相关
	_404(404, "sys.not.found"), // 内容不存在
	_404_CLASS_TIME_DURING(40405,"Inclass time"),
	_404_DEVICE_NONENTITY(40401, "device.not.exist"),
	// _404_USER_NO_EXISTS(40402,"user.no.exists"),
	_404_CLIENT_NONENTITY(40403, "customer.not.exist"), _400_OKEN(40004, "缺少Token"),
	_409(409,"friends.failed"),
	_408(408,"sys.timeout"),
	_500(500, "sys.server.error"),
	_600(600, "sys.request.limit.outfrequency");


	private final int value;

	private final String reasonPhrase;

	private ResponseStatus(int value, String reasonPhrase) {
		this.value = value;
		this.reasonPhrase = reasonPhrase;
	}

	/**
	 * Return the reason phrase of this status code.
	 */
	public String getReasonPhrase() {
		return reasonPhrase;
	}

	public Integer getStatus() {
		return value;
	}

	/**
	 * Return the enum constant of this type with the specified numeric value.
	 *
	 * @param statusCode
	 *            the numeric value of the enum to be returned
	 * @return the enum constant with the specified numeric value
	 * @throws IllegalArgumentException
	 *             if this enum has no constant for the specified numeric value
	 */
	public static ResponseStatus valueOf(int statusCode) {
		for (ResponseStatus status : values()) {
			if (status.value == statusCode) {
				return status;
			}
		}
		throw new IllegalArgumentException("No matching constant for [" + statusCode + "]");
	}

	/**
	 * Return a string representation of this status code.
	 */
	@Override
	public String toString() {
		return Integer.toString(value);
	}

}
