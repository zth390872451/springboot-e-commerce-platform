package com.umeox.babywei.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.HolderStep;

public interface HolderStepRepository extends JpaRepository<HolderStep, Long>{

	HolderStep findOneByHolderIdAndStepDate(Long holderId,Date stepDate);

	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_step where holder_id = ?1",nativeQuery = true)
	void deleteByHolderId(Long holderId);


	@Query(value = "select sum(step_value) from ux_holder_step where holder_id = ?1",nativeQuery = true)
	Long findStepSumByHolderId(Long holderId);


	@Query(value = "SELECT sum(reach_goal) from ux_holder_step where holder_id = ?1 and reach_goal=1",nativeQuery = true)
	Long findReachGoalTimesSumByHolderId(Long holderId);

	@Query(value = "SELECT count(1) FROM ux_holder_step hs where hs.step_value>=?1 and hs.step_date=DATE(?2)",nativeQuery = true)
	Long findCountByStepValueAndStepDate(Integer stepValue,Date stepDate);

	@Query(value = "SELECT count(1) from ux_holder_step hs where hs.step_date=DATE(?1)",nativeQuery = true)
	Long findCountByStepDate(Date stepDate);

	@Query(value = "select * from ux_holder_step where holder_id = ?1 and step_date between ?2 and ?3 order by step_date",nativeQuery = true)
	List<HolderStep> findByStepDate(Long holderId,Date fromDate,Date toDate);

	@Query(value = "select count(1) from ux_holder_step where holder_id = ?1 and reach_goal=1 and step_date between ?2 and ?3",nativeQuery = true)
	Long findReachGoalTimesByStepDate(Long holderId,Date fromDate,Date toDate);
}
