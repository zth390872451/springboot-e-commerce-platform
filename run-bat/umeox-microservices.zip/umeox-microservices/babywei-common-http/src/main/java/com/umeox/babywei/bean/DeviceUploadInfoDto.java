package com.umeox.babywei.bean;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * Created by Administrator on 2017/6/6.
 */
public class DeviceUploadInfoDto {
    /**
     *二维码来源【0：自己生成 1：一号专线的微信公众号的二维码】
     */
    private String qrCodeFlag;

    /**
     * 终端类型
     */
    private String deviceType;

    /**
     * 硬件版本号
     */
    private String version;

    /**
     * 出厂日期
     */
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date exFactoryDate;

    /**
     * 销售国家
     */
    private String saleCountry;
    /**
     * 销售渠道
     */
    private String saleChannel;
    /**
     * 0：非合约机 ; 1：联通合约设备【合约机】标记
     */
    private Integer flag = 0;


    /**
     * 是否需要绑定码【k1设备无需绑定码】,默认1：需要
     */
    private Integer needBindCode = 1;
    /**
     * imei所属的服务器标识
     */
    private Long serverId;

    public Long getServerId() {
        return serverId;
    }

    public void setServerId(Long serverId) {
        this.serverId = serverId;
    }

    public Integer getNeedBindCode() {
        return needBindCode;
    }

    public void setNeedBindCode(Integer needBindCode) {
        this.needBindCode = needBindCode;
    }

    public String getQrCodeFlag() {
        return qrCodeFlag;
    }

    public void setQrCodeFlag(String qrCodeFlag) {
        this.qrCodeFlag = qrCodeFlag;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public Date getExFactoryDate() {
        return exFactoryDate;
    }

    public void setExFactoryDate(Date exFactoryDate) {
        this.exFactoryDate = exFactoryDate;
    }

    public String getSaleCountry() {
        return saleCountry;
    }

    public void setSaleCountry(String saleCountry) {
        this.saleCountry = saleCountry;
    }

    public String getSaleChannel() {
        return saleChannel;
    }

    public void setSaleChannel(String saleChannel) {
        this.saleChannel = saleChannel;
    }

    public Integer getFlag() {
        return flag;
    }

    public void setFlag(Integer flag) {
        this.flag = flag;
    }
}
