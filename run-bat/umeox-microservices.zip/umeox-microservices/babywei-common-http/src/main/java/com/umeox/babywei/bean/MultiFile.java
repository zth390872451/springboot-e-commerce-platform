package com.umeox.babywei.bean;

import org.springframework.web.multipart.MultipartFile;

public class MultiFile {
	private MultipartFile file;

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
	
	
}
