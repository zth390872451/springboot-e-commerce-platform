/*
package com.umeox.babywei.service;

import com.umeox.babywei.domain.Client;

public interface ClientService {

	public Client findOneByToken(String token);


}
*/
