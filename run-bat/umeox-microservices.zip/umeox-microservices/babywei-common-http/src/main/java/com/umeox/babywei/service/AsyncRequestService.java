package com.umeox.babywei.service;

import java.util.HashMap;
import java.util.Map;

import com.umeox.babywei.domain.Device;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.umeox.babywei.bean.Notice;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.plugin.PushClient;
import com.umeox.babywei.util.HttpRequestUtil;

/**
 * 异步请求服务
 * 推送：
 * clientId 弃用（手机APP，oauth2认证的clientId）
 * 改用 设备类型和渠道号
 */
@Service
public class AsyncRequestService {
	
	/**
	 * 推送
	 */
	/**
	 * @param from mobile(手机或者邮箱) Member.getMobile
	 * @param params 大体结构：{
			monitors ：mobile(手机或者邮箱),
			mobile(手机或者邮箱) : Member.getToken();
			Push.KEY + mobile(手机或者邮箱):PushType(推送方式 null或0走默认的推送，1走极光推送),
			Push.CLIENT_ID + mobile(手机或者邮箱) : CLIENT_ID(Member对象的client_id字段~~oauth2认证的clientId)
			}
	 * @param body 发送的主体信息
     * @param param 大体结构：{
			cmd : 指令,
			frmobile : mobile(发送方 手机或者邮箱) ,
			tomobile : mobile(接收方 手机或者邮箱) ,
			name : (设备持有者~宝宝的名字,Holder.getName ) ,
			sim : Holder.getSim() ,
			holderId :Holder.getId()
			}
	 @param deviceType
	 @param saleChannel
     */
	@Async
	public void post(String from,Map<String, String> params,String body,Map<String, String> param,String deviceType,String saleChannel) {
		HttpRequestUtil.post(from, params, body, param,deviceType,saleChannel);
	}
	
	/**
	 * 推送群聊消息，不区分平台
	 * clientId : 为member的clientId字段（手机APP，oauth2认证的clientId）
	 */
	@Async
	public void pushTagMessge(String title,String tagValue,String msgContent,Map<String, String> extras, String deviceType,String saleChannel){
		PushClient.sendTagPushMessage(title, tagValue, msgContent, extras ,deviceType,saleChannel);
	}
	
	/**
	 * 别名推送消息，不区分平台
	 */
	@Async
	public void pushAliasMessge(String title,String alias,String msgContent,Map<String, String> extras, String deviceType,String saleChannel){
		PushClient.sendTitlePushMessage(title, alias, msgContent, extras, deviceType,saleChannel);
	}
	/**
	 * 推送Android通知
	 */
	/*	@Async
		public void pushTitleAndroidMessge(String alias,String title,Map<String, String> extras, String deviceType,String saleChannel){
			PushClient.sendTitlePushAndroidNotification(alias, title, extras, deviceType,saleChannel);
		}*/

	/**
	 * 推送Android通知
	 */
	@Async
	public void pushAndroidMessge(String alias,String alert,Map<String, String> extras, String deviceType,String saleChannel){
		PushClient.sendPushAndroidNotification(alias, alert, extras, deviceType, saleChannel);
	}

	@Async
	public static void pushToAndroidAndIos(String alias,String title,String msgContent,Map<String, String> extras, String deviceType,String saleChannel){
		PushClient.sendTitlePushMessage(title,alias,msgContent,extras,deviceType,saleChannel);
		
	}
	
	/**
	 * 推送iOS通知
	 */
	@Async
	public void pushIosMessge(String alias,String alert,Map<String, String> extras, String deviceType,String saleChannel){
		PushClient.sendPushIosNotification(alias, alert, extras, deviceType,saleChannel);
	}

	/**
	 * 根据持有者holder 获取设备Device，根据设备的类型和渠道号，获取客户端进行推送
	 * @param holder
	 * @param params
     */
	public void pushMessage(Holder holder,Map<String,String>  params){
		Map<String, String> extras = new HashMap<String, String>();
		extras.put("cmd", Push.UNBOUND +"");
		extras.put("holderId", holder.getId().toString());
		Device device = holder.getDevice();
		String deviceType = device.getDeviceType();
		String saleChannel = device.getSaleChannel();

		String title = holder.getName()+" (device) unbound";
		String monitors = params.get("monitors");
		if(monitors.contains(",")) {
			String[] mobileArray = monitors.split(",");
			for (int i = 0; i < mobileArray.length; i++) {
				String mobile = mobileArray[i];//关注者
				String token = params.get(mobile);
				if (!StringUtils.isEmpty(token)) {
					this.pushIosMessge(mobile, title, extras ,deviceType,saleChannel);
				}else {
					this.pushAndroidMessge(mobile, title, extras, deviceType, saleChannel);
				}
			}
		}else {
			String token = params.get(monitors);
			String clientId = params.get(Push.CLIENT_ID+monitors);
			if (!StringUtils.isEmpty(token)) {
				this.pushIosMessge(monitors, title, extras,deviceType,saleChannel);
			}else {
				this.pushAndroidMessge(monitors, title, extras, deviceType, saleChannel);
			}
		}
	}
}
