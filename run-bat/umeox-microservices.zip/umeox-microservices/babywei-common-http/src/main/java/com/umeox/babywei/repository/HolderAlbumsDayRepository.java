package com.umeox.babywei.repository;

import com.umeox.babywei.domain.HolderAlbumsDay;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

/**
 *
 */
public interface HolderAlbumsDayRepository extends JpaRepository<HolderAlbumsDay, Long> {
    //    大于指定日期 = 最新照片
    List<HolderAlbumsDay> findAllByDayGreaterThanAndDayNumGreaterThanAndHolderAlbumsIdOrderByDayDesc(Date lastViewDate, Integer dayNum,Long holderAlbumsId);
    //    小于指定日期 = 历史照片
    List<HolderAlbumsDay> findAllByDayLessThanAndHolderAlbumsIdOrderByDayDesc(Date lastViewDate, Long holderAlbumsId);
    //查询 某天的照片记录(拍了多少照片)
    HolderAlbumsDay findOneByDayAndHolderAlbumsId(Date day, Long holderAlbumsId);

    List<HolderAlbumsDay> findAllByHolderAlbumsId(Long holderAlbumId);
}
