package com.umeox.babywei.service;

import java.util.List;

public interface AdminService {
	void delete(List<Long> ids);
	boolean  existByUsername(String username);
}
