package com.umeox.babywei.repository;

import com.umeox.babywei.domain.SmsResult;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SmsResultRepository extends JpaRepository<SmsResult, Long> {
   /* @Query(value = "select count(1) from ux_sms_log where mobile = ?1 and Date(create_date) = CURRENT_DATE()",nativeQuery = true)
    Long findAllByMobileCurrentDate(String mobile);

    @Query(value = "select count(1) from ux_sms_log where mobile = ?1 ",nativeQuery = true)
    Long findAllByMobile(String mobile);*/
    //根据手机号码和验证码查找短信记录

    @Query(value = "select * from ux_sms_result where mobile = ?1 and code=?2 order by create_date desc limit 1",nativeQuery = true)
    SmsResult findSmsResultByMobileAndCode(String mobile,String code);

    SmsResult findSmsResultByMsgId(String msgId);
}
