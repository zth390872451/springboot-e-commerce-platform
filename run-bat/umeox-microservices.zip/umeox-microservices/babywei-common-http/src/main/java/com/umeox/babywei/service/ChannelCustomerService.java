package com.umeox.babywei.service;

import com.umeox.babywei.domain.Admin;
import com.umeox.babywei.domain.ChannelCustomer;


public interface ChannelCustomerService {
	void update(ChannelCustomer channelCustomer, Admin admin);
}
