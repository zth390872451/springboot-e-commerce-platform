package com.umeox.babywei.repository;

import com.umeox.babywei.domain.SosEventProcess;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by Administrator on 2016/10/18.
 */
public interface SosEventProcessRepository extends JpaRepository<SosEventProcess, Long> {
    List<SosEventProcess> findAllBySosEventId(Long sosEventId);
}
