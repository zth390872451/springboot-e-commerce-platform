package com.umeox.babywei.repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.umeox.babywei.domain.ImGroup;

public interface ImGroupRepository extends JpaRepository<ImGroup, Long>{

	List<ImGroup> findByGroupIdIn(Collection<String> groupIds);
	
	ImGroup findOneByGroupId(String groupId);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_im_group where group_id = ?1",nativeQuery = true)
	void deleteImGroupByGroupId(String groupId);
}
