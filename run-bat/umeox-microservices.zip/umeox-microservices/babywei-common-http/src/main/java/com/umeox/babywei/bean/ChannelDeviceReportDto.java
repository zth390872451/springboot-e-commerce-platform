package com.umeox.babywei.bean;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by Administrator on 2016/5/31.
 */
public class ChannelDeviceReportDto implements Serializable {

    private String imei; 
    private String adminPhone;
    private String email;
    private String mobileArea;
    private String childSex;

    private Date activeTime;
    private String deviceType;
    private String deviceDescr;
    private String mobileType;
    private String saleChannel;
    private String saleChannelName;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDeviceDescr() {
        return deviceDescr;
    }

    public void setDeviceDescr(String deviceDescr) {
        this.deviceDescr = deviceDescr;
    }

    public String getSaleChannelName() {
        return saleChannelName;
    }

    public void setSaleChannelName(String saleChannelName) {
        this.saleChannelName = saleChannelName;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getAdminPhone() {
        return adminPhone;
    }

    public void setAdminPhone(String adminPhone) {
        this.adminPhone = adminPhone;
    }

    public String getMobileArea() {
        return mobileArea;
    }

    public void setMobileArea(String mobileArea) {
        this.mobileArea = mobileArea;
    }

    public String getChildSex() {
        return childSex;
    }

    public void setChildSex(String childSex) {
        this.childSex = childSex;
    }

    public Date getActiveTime() {
        return activeTime;
    }

    public void setActiveTime(Date activeTime) {
        this.activeTime = activeTime;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getMobileType() {
        return mobileType;
    }

    public void setMobileType(String mobileType) {
        this.mobileType = mobileType;
    }

    public String getSaleChannel() {
        return saleChannel;
    }

    public void setSaleChannel(String saleChannel) {
        this.saleChannel = saleChannel;
    }
}
