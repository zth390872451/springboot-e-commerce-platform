package com.umeox.babywei.repository;

import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Holder.Frequency;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("holderRepository")
public interface HolderRepository extends JpaRepository<Holder, Long>,JpaSpecificationExecutor<Holder>{
	
	Holder findFirstBySim(String sim);
	
	Holder findFirstByImei(String imei);
	
	List<Holder> findByIdIn(Collection<Long> idArr);
	
	@Modifying
	@Transactional
	@Query(value = "delete from ux_holder_sos where holder = ?1",nativeQuery = true)
	void deleteHolderSosByHolderId(Long holderId);
	
	@Modifying
	@Transactional
	@Query("update Holder h set h.frequency = ?1 where id = ?2")
	void setFrequencyFor(Frequency frequency, Long holderId);
	
	Long countByCreateDateBetween(Date beginDate,Date endDate);
	
	Long countByCreateDateLessThanEqual(Date date);
	@Query(value = "select count(*) from ux_holder holder inner join "
			+ "ux_device device on device.holder_id = holder.id  "
			+ "where device.sale_channel = ?1 and holder.create_date >= ?2 and holder.create_date <= ?3" ,nativeQuery = true)
	Long countBySaleChannelAndCreateDateBetween(String channelNumber, Date beginDate, Date endDate);
	
	@Query(value="SELECT * FROM ux_holder WHERE id IN "
			+ "(SELECT holder_id FROM ux_monitor WHERE is_admin IS TRUE AND member_id IN "
			+ "(SELECT id FROM ux_member WHERE mobile = ?1))",nativeQuery = true)
	List<Holder> queryBindByMobile(String mobile);
	
	@Query(value = "SELECT * FROM ux_holder WHERE id IN (SELECT holder_id FROM "
			+ "ux_monitor WHERE member_id = ?1 AND device_type = ?2)",nativeQuery = true)
	List<Holder> queryByMemberIdAndDeviceType(Long memberId,String deviceType);
}
