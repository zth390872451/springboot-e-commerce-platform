package com.umeox.babywei.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.umeox.babywei.domain.DeviceCode;

public interface DeviceCodeRepository extends JpaRepository<DeviceCode, Long> ,JpaSpecificationExecutor<DeviceCode>{
	List<DeviceCode> findByLot(String lot);
	
	DeviceCode findOneByImei(String imei);
}
