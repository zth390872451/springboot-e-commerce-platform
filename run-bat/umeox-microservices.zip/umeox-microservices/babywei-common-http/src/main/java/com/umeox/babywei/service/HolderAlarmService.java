package com.umeox.babywei.service;

import com.umeox.babywei.domain.HolderAlarm;

public interface HolderAlarmService {

	HolderAlarm save(HolderAlarm holderAlarm);
	
	void delete(HolderAlarm holderAlarm);
	
}
