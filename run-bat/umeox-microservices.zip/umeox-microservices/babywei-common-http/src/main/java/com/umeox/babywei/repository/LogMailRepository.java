package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.umeox.babywei.domain.LogMail;

public interface LogMailRepository extends JpaRepository<LogMail, Long> {

}
