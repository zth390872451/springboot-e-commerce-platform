package com.umeox.babywei.service;

import java.util.Date;

import com.umeox.babywei.bean.HomeDto;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;


public interface HomeService {

	public HomeDto getBaseData(Member member,Holder holder,Date currentDate);
	
	public HomeDto getBaseData(Member member,Holder holder,Date currentDate,String locationCode);

	public HomeDto getCurrentInfo(Member member,Holder holder,Date currentDate);

	public void locationCmd(Member member, Holder holder,String locationCode, Integer lp);
}
