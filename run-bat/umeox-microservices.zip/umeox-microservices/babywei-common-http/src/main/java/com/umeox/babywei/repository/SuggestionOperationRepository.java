package com.umeox.babywei.repository;

import com.umeox.babywei.domain.SuggestionOperation;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Administrator on 2017/5/24.
 */
public interface SuggestionOperationRepository extends JpaRepository<SuggestionOperation,Long> {

    SuggestionOperation findFirstBySuggestionIdOrderByCreateDateDesc(Long suggestionId);

}
