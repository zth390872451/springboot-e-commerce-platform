package com.umeox.babywei.repository;

import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.JpaEntityInformationSupport;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

/**
 * @author umeox
 *  
 *  Custom repository base class
 *
 */
public class GenericRepositoryImpl<T, ID extends Serializable> extends SimpleJpaRepository<T,ID> implements GenericRepository<T,ID> {
   
    private static final Logger log = LoggerFactory.getLogger(GenericRepositoryImpl.class);
    

    private final EntityManager em;

    public GenericRepositoryImpl(JpaEntityInformation entityInformation, EntityManager entityManager) {
        super(entityInformation, entityManager);
        
        // Keep the EntityManager around to used from the newly introduced methods.
        this.em = entityManager;
    }

    public GenericRepositoryImpl(Class domainClass, EntityManager em) {
        this(JpaEntityInformationSupport.getMetadata(domainClass, em), em);
    }

    private void setQueryParams(Query query, Object... params){
        if (params != null){
            for (int i = 0;i < params.length;i++){
                query.setParameter(i + 1, params[i]);
            }
        }
    }

    @Override
    public long countBySqL(String sqlString, Object... params) {
        Query query = em.createNativeQuery(sqlString);
        setQueryParams(query,params);
        return ((BigInteger)query.getSingleResult()).longValue();
    }

    @Override
    public List<T> findAllBySql(String sqlString, Class cls,Object... params) {
        Query query = em.createNativeQuery(sqlString);
        query.unwrap(SQLQuery.class).setResultTransformer(Transformers.aliasToBean(cls));
        setQueryParams(query,params);
        return query.getResultList();
    }

	
	@Override
	@SuppressWarnings("unchecked")
	public T findOneBySql(String sqlString, Class<?> cls, Object... params) {
		List<T> list = this.findAllBySql(sqlString, cls, params);
		if (list != null && list.size() > 0) {
			return list.get(0);
		} else {
			return null;
		}
	}
    
}
