package com.umeox.babywei.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.io.Serializable;
import java.util.List;

/**
 * @author umeox
 *         *
 *         针对spring data jpa所提供的接口{@link org.springframework.data.jpa.repository.JpaRepository}扩展
 */
@NoRepositoryBean
public interface GenericRepository<T, ID extends Serializable> extends JpaRepository<T, ID> {

    public long countBySqL(final String sqlString, final Object... params);

    public List<T> findAllBySql(final String sqlString, Class cls, final Object... params);
    
    public T findOneBySql(final String sqlString, Class<?> cls, final Object... params);

}
