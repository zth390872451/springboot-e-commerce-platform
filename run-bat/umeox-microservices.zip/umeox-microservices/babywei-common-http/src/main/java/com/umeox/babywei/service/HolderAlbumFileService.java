package com.umeox.babywei.service;

import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.domain.HolderAlbumsDay;
import com.umeox.babywei.domain.HolderAlbumsFile;
import com.umeox.babywei.domain.HolderPaipaiSpace;
import com.umeox.babywei.repository.HolderAlbumsDayRepository;
import com.umeox.babywei.repository.HolderAlbumsFileRepository;
import com.umeox.babywei.repository.HolderPaipaiSpaceRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/2/23.
 */
@Service
@Transactional
public class HolderAlbumFileService {

    public static Logger logger = LoggerFactory.getLogger(HolderAlbumFileService.class);

    @Autowired
    private HolderAlbumsFileRepository holderAlbumsFileRepository;
    @Autowired
    private HolderPaipaiSpaceRepository holderPaipaiSpaceRepository;
    @Autowired
    private HolderAlbumsDayRepository holderAlbumsDayRepository;
    /**
     * 删除图片标识 (只是更新了 status , 在本地存储的信息，远程图片存储服务器未删除)
     *
     * @param holderId
     * @param ids ("1","2")
     */
    public void updateLocalFileRecords(Long  holderId, List<String> ids){
//        holderAlbumsFileRepository.deleteHolderAlbumsFileByIdsAndHolderId(ids,holderId);
        holderAlbumsFileRepository.updateHolderAlbumsFileByIdsAndHolderId(ids,holderId, HolderAlbumsFile.DELETED);
    }

    /**
     * 删除 指定远程图片
     */
    @Async
    public void deleteRemoteFilesByUrls(List<String> fileUrlList){
        for (String url: fileUrlList){
            try {
//                HttpUtil.httpDelete(null,url);
            }catch (Exception e){
                logger.error("删除远程图片，出现异常:{},url={}"+e.getMessage(),url);
            }
        }
    }

    /**
     * 文件被删除后，拍拍空间相关操作的更新,返回更新后的 HolderPaipaiSpace
     */
    public HolderPaipaiSpace deletePaipaiShowFile(Long holderId, Long holderAlbumsFileId) {
        HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOneByHolderId(holderId);
        HolderAlbumsFile mostViewFile = holderPaipaiSpace.getMostViewFile();
        if (mostViewFile!=null && mostViewFile.getId().equals(holderAlbumsFileId)){//最多查看的文件更新
            //查询出此拍拍空间内被分享的文件 最多查看的是哪个
            List<HolderAlbumsFile> viewFileDescList = holderAlbumsFileRepository.findOneByHolderIdAndAccessFlagAndOrderByViewNumDesc(holderId, 1,0,10);
            //第一个被删除，第二个将前移成为最多查看数文件
            if (!StringUtils.isEmpty(viewFileDescList) &&  viewFileDescList.size()<2){//只有一个分享的文件,删除拍拍空间
                holderPaipaiSpace.setMostViewFile(null);
                holderPaipaiSpace.setViewNum(0);
//                return null;
            }else {//此人的拍拍空间有2个以上的分享文件
                for (HolderAlbumsFile file:viewFileDescList){//最好不用List.get(1) 因为有可能查看数量相等，导致排序第二个文件仍然是自身
                    if (!file.getId().equals(mostViewFile.getId())){
                        holderPaipaiSpace.setMostViewFile(file);
                        holderPaipaiSpace.setViewNum(file.getViewNum());
                        break;
                    }
                }
            }
        }
        HolderAlbumsFile mostZanFile = holderPaipaiSpace.getMostZanFile();
        if (mostZanFile!=null && mostZanFile.getId().equals(holderAlbumsFileId)){//最多点赞的文件更新
            List<HolderAlbumsFile> zanFileDescList = holderAlbumsFileRepository.findOneByHolderIdAndAccessFlagAndOrderByZanNumDesc(holderId, 1,0,10);
            //第一个将被删除，第二个将前移成为最多点赞数文件
            if (!StringUtils.isEmpty(zanFileDescList) && zanFileDescList.size()<2){//只有一个分享的文件,删除拍拍空间
                holderPaipaiSpace.setMostZanFile(null);
                holderPaipaiSpace.setZanNum(0);
            }else {//此人的拍拍空间有2个以上的分享文件
                for (HolderAlbumsFile file : zanFileDescList){//最好不用List.get(1) 因为有可能查看数量相等，导致排序第二个文件仍然是自身
                    if (!file.getId().equals(mostZanFile.getId())){
                        holderPaipaiSpace.setMostZanFile(file);
                        holderPaipaiSpace.setZanNum(file.getZanNum());
                        break;
                    }
                }
            }
        }

        //查询出该holder 拍拍空间中按分享时间降序排列的文件。
        List<HolderAlbumsFile> shareDateFileDescList = holderAlbumsFileRepository.findOneByHolderIdAndAccessFlagAndStatusAndOrderByShareDateDesc(holderId, 1, 0, 10);
        HolderAlbumsFile lastShareFile = holderPaipaiSpace.getLastShareFile();
        if (lastShareFile!=null && lastShareFile.getId().equals(holderAlbumsFileId)) {//最后分享的文件被删除
            //第一个将被删除，第二个将前移成为最后分享文件
            if (!StringUtils.isEmpty(shareDateFileDescList) &&   shareDateFileDescList.size()<2){//只有一个分享的文件,删除拍拍空间
                holderPaipaiSpace.setLastShareFile(null);
                holderPaipaiSpace.setLastShareTime(0L);
            }else {//此人的拍拍空间有2个以上的分享文件
                for (HolderAlbumsFile file : shareDateFileDescList){// .get(1) 因为有可能查看数量相等，导致排序第二个文件仍然是自身
                    if (!file.getId().equals(lastShareFile.getId())){
                        holderPaipaiSpace.setLastShareFile(file);
                        holderPaipaiSpace.setLastShareTime(file.getShareDate().getTime());
                        break;
                    }
                }
            }
        }
        holderPaipaiSpace = holderPaipaiSpaceRepository.save(holderPaipaiSpace);//拍拍空间关联文件更新(点赞、分享、查看)
        return holderPaipaiSpace;
    }

    /**
     收到点赞后 需要给设备端发通知
     * @return 消息内容
     */
    public Map<String,Object> sendHolderAlbumsDayZan(String userId, String imei, Long dayZanSum){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("cmd", RedisCommand.CMD_CHAT);
        map.put("userId", userId);
        map.put("friendId", imei);
        map.put("msgType", 2);
        map.put("msgTime", new Date().getTime());
        map.put("msg", "1"+"#"+dayZanSum);//1代表点赞
        return map;
    }

    /**
     * 删除相册日集
     */
    public void deleteHolderAlbumsDayById(Long id) {
        holderAlbumsDayRepository.delete(id);
    }

    /**
     *
     * @param holderAlbumsFiles 删除文件
     * @param emptyAlbumsDays 删除空的(dayNum=0)
     * @param notEmptyAlbumsDays 更新
     */
    public void updateAlbumFileAndDays(List<HolderAlbumsFile> holderAlbumsFiles, List<HolderAlbumsDay> emptyAlbumsDays, List<HolderAlbumsDay> notEmptyAlbumsDays) {
        //正常 变为 删除 状态
        holderAlbumsFileRepository.save(holderAlbumsFiles);
        //删除记录
        holderAlbumsDayRepository.delete(emptyAlbumsDays);
        //修改数量
        holderAlbumsDayRepository.save(notEmptyAlbumsDays);

    }
}


