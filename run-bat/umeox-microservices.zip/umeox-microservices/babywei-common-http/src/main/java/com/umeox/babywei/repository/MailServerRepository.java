package com.umeox.babywei.repository;

import com.umeox.babywei.domain.MailServer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 * Created by Administrator on 2016/10/14.
 */
public interface MailServerRepository extends JpaRepository<MailServer, Long> {

    @Query(value = "select * from sys_mail sm where find_in_set(:clientId,sm.client_id)", nativeQuery = true)
    MailServer findByClientId(@Param("clientId") String clientId);

}
