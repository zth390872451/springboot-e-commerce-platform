一、que:api2socket:im 即时消息队列
---
---

		键名： que:api2socket:im
		类型:  list
		用途： API通知SOCKET消息队列，即时要求高
		内容： 
			{"cmd":0x01,reqUser:"手机号",toUser:"imei号",locationCode:"定位码"} 请求定位
			{"cmd":0x02,userId:"",friendId:"",msgType:"消息类型",msg:"消息类容",msgTime:"发送时间"}   语聊消息
			{"cmd":0x04,"holderId":1} 设备绑定(bind2)
			{"cmd":0x08,imei:"imei号","unboundCode":解绑码} 设备解绑
			

二、que:api2socket:data 同步数据消息队列
---
---

		键名： que:api2socket:data
		类型:  list
		用途： API通知SOCKET消息队列，有延迟,例15秒延迟
		消息：
			{"cmd":0x100,"holderId":1} 设备参数修改
			{"cmd":0x200,"holderId":1} 同步联系人列表（绑定、关注者bind2、自己取消关注、管理员修改家庭成员，管理员修改手表好友）
			{"cmd":0x400,"holderId":1} 同步好友列表
			{"cmd":0x800,"holderId":1} 同步特殊关爱时段设置
			{"cmd":0x1000,"holderId":1} 同步上课禁用设置
			{"cmd":0x2000,"holderId":1} 同步闹钟设置
			{"cmd":0x4000,"holderId":1} 同步时区


三、usr:holder:id 同步状态标记位
---
---

		键名： user:holder:id
		类型:  hash
		用途： 设备需要同步的数据标记
		内容： 见q:api2socket:data中cmd,cmd或运算组成。例0x13表示Ox10,Ox02，0x01表示的数据需要更新
		key-value:
			syncDataFlag 见q:api2socket:data中cmd,cmd或运算组成。例0x13表示Ox10,Ox02，0x01表示的数据需要更新
			locationData 缓存最近位置对象，包括经伟度，地址，时间戳
			
			

