版本定义
---
---

基本版0.1：一代国内外所有功能
基本版一代Tag： 返回修改，错误码修改



各Module介绍：
---
---

### umeox-oauth2:  oauth2资源访问授权服务
### babywei-common：卫小宝公用模块, 实体类，数据库访问类,共用工具类
### babywei-common-http：卫小宝http访问公用模块
### babywei-app-api: 卫小宝APP接口服务
### babywei-open-api: 卫小宝开放给第三方接口服务
### babywei-web:  卫小宝后台管理系统
### babywei-socket-server： 卫小宝终端socket服务


各Module存在依赖关系
---
---

umeox-microservices [parent]

    ---umeox-oauth2
    
    ---babywei-common
    
        ---babywei-socket-server 
           
    ---babywei-common babywei-common-http  
              
        ---babywei-app-api
        
        ---babywei-open-api
        
        ---babywei-web
                
       
    
    注意 其中babywei-common，babywei-common-http 不需要依赖spring-boot-maven-plugin
    
功能重构说明：
---
---

### API接口重新定义，查看：APP接口协议说明文档

### 后端管理系统和APP API分离开

### 图片存储分离开，使用Nginx作为代理访问

### 缓存由Memcached改为Redis实现

### 每个api访问对参数签名和访问权限检查

### 国内和国外版本统一管理，由部署配置文件加标记区分


    国内和国外功能区分：
    1.注册：国内用的是手机号码注册，国际用的是邮箱注册。
    2.后台转码地图服务：GPS国内用的是百度Map、国际用的是GoogleMap。LBS和国内一样都是用miniGPS。
    3.时区：国际版本有时区配置功能。
    4.静止提醒：国内静止1小时以上有静止提醒，国际是静止1分钟有静止提醒。
    5.国外版本的有一些专门为客户开发的服务，如：比如你刚来公司的时候说要做的那个泰国的付费才能使用的接口。
    6.国外：泰国订单需求Admin可编辑  意大利订单需求 ios两套推送证书     国内：芜湖移动需求：冒号处理，锁卡 ，锁号
    7.国外：管理员手机号码变成亲情号的逻辑
    8.国外：设备的激活时间


重构日志
---
---

API请求地址使用域名
推送服务器地址由服务返回
API 返回JSON数据结构: { "status": 0,"msg":"提示","result":xxxx,"timestamp":111111}
日期时期参数为长整型， 其值为距1970年1月1日0时的毫秒数