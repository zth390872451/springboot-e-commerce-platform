package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.conf.CommonMapConfiguration;
import com.umeox.babywei.appapi.web.rest.dto.*;
import com.umeox.babywei.bean.*;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.domain.Device.Status;
import com.umeox.babywei.domain.Holder.Frequency;
import com.umeox.babywei.repository.*;
import com.umeox.babywei.service.*;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.app.PushPayload;
import com.umeox.babywei.thrift.app.ThriftAppClient;
import com.umeox.babywei.thrift.app.Wtow;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.RuleSupport;
import com.umeox.babywei.util.StringToolUtil;
import com.umeox.babywei.util.UploadUtil;
import com.umeox.babywei.web.rest.BaseController;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.regex.Pattern;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * @author umeox
 */
@RestController
@RequestMapping({"/api/holder"})
public class HolderController extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(HolderController.class);

	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private HolderService holderService;
	@Autowired
	private ChannelCustomerRepository channelCustomerRepository;
	@Autowired
	private MonitorService monitorService;
	@Autowired
	private DeviceService deviceService;
	@Autowired
	private ChannelWhService channelWhService;
	@Autowired
	private DeviceRepository deviceRepository;
	@Autowired
	private AsyncRequestService asyncRequestService;
	@Autowired
	private RedisQueueService redisQueueService;
	@Autowired
	private RedisService redisService;
	@Autowired
	private CommonMapConfiguration commonMap;
	@Autowired
	private I18nService i18nService;
	@Autowired
	private RemoteService remoteService;
	@Autowired
	private SmsNotificationService smsNotificationService;
	@Autowired
	private SettingProperties setting;
	@Autowired
	private AppToDeviceTypeService appToDeviceTypeService;


	private boolean doWhFileter(String imei, String sim) {
		ChannelWh channelWh = channelWhService.findOneByImei(imei);
		if (channelWh != null && !channelWh.getPhone().equals(sim)) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * 获取关注码
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/getAttentionCode", method = RequestMethod.GET)
	public MyResponseBody getAttentionCode(@RequestParam(value = "holderId") Long holderId,
										   @RequestHeader(value = "client_id") String clientId) {
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		String attentionCode = holderService.getAttentionCode(holderId);
		Map<String, Object> map = new HashMap<String, Object>();
		String downloadUrl = commonMap.getDownloadUrl().get(clientId);
		map.put("attentionCode", attentionCode);
		map.put("downloadUrl", downloadUrl);
		map.put("expires", 24);
		return success(map);
	}

	/**
	 * 获取设备二维码
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER) //TODO Permission
	@RequestMapping(value = {"/getQrCode"}, method = {RequestMethod.GET})
	public MyResponseBody getQrCode(@RequestParam(value = "holderId") Long holderId) {
		Holder holder = holderRepository.getOne(holderId);
		Device device = holder.getDevice();
		String qrCode = null;
		if (device.getDeviceType().equals("1") || device.getDeviceType().equals("2")) {
			qrCode = device.getImei();
		} else {
			qrCode = setting.getQrCodePreUrl() + device.getBindCode();
		}

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("holderId", holderId);
		map.put("qrCode", qrCode);
		map.put("imei", device.getImei());
		map.put("deviceType", device.getDeviceType());
		map.put("bindCode", device.getBindCode());
		map.put("sim", holder.getSim());
		return success(map);
	}


	/**
	 * bind 设备绑定 ：设备与持有者之间的关系绑定
	 *
	 * @param memberId 会员编号
	 * @param imei     IMEI号
	 * @param code     验证码
	 */
	@RequestMapping(value = {"/bind"}, method = {RequestMethod.POST})
	public MyResponseBody bind(@RequestParam(value = "memberId") Long memberId,
							   @RequestParam(value = "imei") String imei,
							   @RequestParam(value = "sim") String sim,
							   @RequestParam(value = "code") String code) {

		Device device = deviceRepository.findOneByImei(imei);
		if (StringUtils.isEmpty(device.getCaptcha()) || !device.getCaptcha().equals(code)) {
			return fail("sys.code.error");
		}

		Member member = memberRepository.findOne(memberId);
		String mobile = member.getMobile();
		if (device.getSaleChannel() != null && device.getSaleChannel().equals("10553")) {
			if (!Pattern.matches("(134|135|136|137|138|139|150|151|152|158|159|182|183|184|157|187|188|147|178)\\d{8}", mobile)) {
				return fail(MyHttpStatus._40005);
			}
			if (doWhFileter(imei, sim)) {
				return fail(MyHttpStatus._40001);
			}
		}

		Holder holder = holderRepository.findFirstByImei(imei);
		if (holder == null) {// 生成Holder信息
			holder = new Holder();
			holder.setDevice(device);
			holder.setImei(imei);
		} else {
			Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imei);
			if (monitor != null) {
				return fail("device.not.found");
			}
		}

		holder.setSim(sim);
		holder.setName(sim);
		List<String> sos = new ArrayList<String>();
		sos.add(mobile);
		holder.setSos(sos);
		deviceService.bind(holder);

		return success(holder.getId());
	}

	/**
	 * bind2 设备绑定 ：持有者与APP用户之间的关系绑定：管理员|关注者
	 *
	 * @Desc 设备绑定2(CII, WII)
	 */
	@DataPermission
	@RequestMapping(value = {"/bind2"}, method = {RequestMethod.POST})
	public MyResponseBody bind2(@RequestParam(value = "memberId") Long memberId,
								@RequestParam(value = "bindCode") String bindCode,
								@RequestHeader(value = "client_id", required = false) String clientId) {

		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404_USER_NO_EXISTS);
		}
		//关注码与绑定码找设备，关注码长度为6位，存入缓存中，使用一次
		//绑定码存在数据库
		Device device = null;
		if (bindCode.length() == 6) {//邀请关注码只能使用一次
			Long holderId = (Long) redisService.get(RedisKeyPre.ATTENTION_CODE + bindCode);
			if (holderId == null) {
				return fail(MyHttpStatus._401_INVALID_ATTENTION_CODE);
			}
			Holder holder = holderRepository.getOne(holderId);
			device = holder.getDevice();
			if (Status.UN_REGIST.equals(device.getStatus())) {
				return fail(MyHttpStatus._404_DEVICE_INACTIVE);
			}
			redisService.del(RedisKeyPre.ATTENTION_CODE + bindCode);
		} else {
			device = deviceRepository.findOneByBindCode(bindCode);
		}

		if (device == null) {
			return fail(MyHttpStatus._404_DEVICE_NONENTITY);
		}
		if (!StringUtils.isEmpty(clientId)) {//使用对应的app绑定，目前判断设备类型7,10
			if (AppDetails.WXB_DOKI_CLIENT_IDS.contains(clientId) || AppDetails.WHERECOM_DOKI_CLIENT_IDS.contains(clientId)) {
				if (!AppDetails.DOKI_DEVICE_TYPE.equals(device.getDeviceType())) {
					return fail(MyHttpStatus._404_APP_NOT_MATCH);
				}
			} else if (AppDetails.K3_CLIENT_IDS.contains(clientId)) {
				if (!AppDetails.K3_DEVICE_TYPE.equals(device.getDeviceType())) {
					return fail(MyHttpStatus._404_APP_NOT_MATCH);
				}
			}
		}

		Monitor admin = monitorRepository.findFirstByIsAdminTrueAndHolderImei(device.getImei());
		if (admin != null) {
			Member adminMember = admin.getMember();
			String adminMobile = adminMember.getMobile();
			if (adminMember.getId() == memberId) {//admin已经绑定
				return fail(MyHttpStatus._30003);
			} else {
				Monitor monitor = monitorRepository.findFirstByIsAdminFalseAndMemberIdAndHolderImei(memberId, device.getImei());
				if (monitor != null) {
					return fail(MyHttpStatus._30001);
				}
				Holder holder = device.getHolder();

				ImSendLog imSendLog = null;
				String msg = null;
				if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(device.getDeviceType())) {
					imSendLog = new ImSendLog();
					/*String pattern = i18nService.findByLocaleAndKey(adminMember.getLocale(), I18NField.k3_add_attention_content);
					msg = MessageFormat.format(pattern, member.getNickName(),holder.getName());*/
					msg = RuleSupport.getMsgByLocale(adminMember.getLocale(), "k3.add.attention.content", new String[]{member.getNickName(), holder.getName()});
					imSendLog.setImType(AppDetails.FRIEND_TYPE);
					imSendLog.setUserId(member.getMobile());
					imSendLog.setMsg(msg);
					imSendLog.setMsgTime((new Date()).getTime());
					imSendLog.setMsgType(12);
					imSendLog.setFriendId(holder.getImei());
				}

				List<Mark> markList = monitorService.accept(device, holder, member, imSendLog);
				if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(device.getDeviceType())) {
					String key = RedisKeyPre.FRIEND_CHAT + RedisKeyPre.MEMBER_CHAT + adminMember.getId() + ":" + RedisKeyPre.HOLDER_CHAT + holder.getId();
					redisService.rightPush(key, imSendLog);
					ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(device.getImei(), (Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
				} else {
					redisQueueService.handleMarkList(markList);
				}

				// 消息推送
				String postBody = RuleSupport.getMsgByLocale(adminMember.getLocale(), "device.attention.new.binder", new String[]{holder.getName()});
				;
				
				/*if(ApplicationSupport.isChinaEnv()){
					postBody = "您的宝贝("+holder.getName()+")有新的关注人";
				}else{
					postBody = "The tracker ("+holder.getName()+") has new invitation";
				}
				*/

				if (AppDetails.WE_TALK_DEVICE_TYPE.equals(device.getDeviceType())) {
					Map<String, String> extras = new HashMap<String, String>();
					extras.put("cmd", Push.FOLLOWER_ADD + "");
					extras.put("holderId", holder.getId().toString());
					extras.put("groupId", AppDetails.GROUP_PRE + holder.getId());

					redisQueueService.insertGroupChatListForNotify(holder.getId(), member.getMobile(), ApplicationSupport.getMessageByEnv("sys.join.familyGroup", new String[]{member.getNickName()}), System.currentTimeMillis());

					asyncRequestService.pushTagMessge(ApplicationSupport.getMessageByEnv("sys.familyGroup"), AppDetails.GROUP_PRE + holder.getId(),
							ApplicationSupport.getMessageByEnv("sys.join.familyGroup", new String[]{member.getNickName()}), extras, holder.getDevice().getDeviceType(), holder.getDevice().getSaleChannel());

				} else if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(device.getDeviceType())) {
					Map<String, String> extras = new HashMap<String, String>();
					extras.put("cmd", Push.FOLLOWER_ADD + "");
					extras.put("holderId", holder.getId().toString());
					//extras.put("groupId", AppDetails.GROUP_PRE + holder.getId());
					//String title = i18nService.findByLocaleAndKey(adminMember.getLocale(), I18NField.k3_add_attention_title);
					String title = RuleSupport.getMsgByLocale(adminMember.getLocale(), "k3.add.attention.title");
					asyncRequestService.pushAliasMessge(title, adminMobile, msg, extras, holder.getDevice().getDeviceType(), holder.getDevice().getSaleChannel());
					/*if (!StringUtils.isEmpty(adminMember.getToken())) {
						asyncRequestService.pushIosMessge(adminMobile, title, extras, adminMember.getClientId());
					}else {
						asyncRequestService.pushTitleAndroidMessge(adminMobile, title, extras, adminMember.getClientId());
					}*/
				} else {
					Map<String, String> param = new HashMap<String, String>();
					param.put("cmd", Integer.toString(Push.NOTIFICATION));
					param.put("frmobile", member.getMobile());
					param.put("tomobile", adminMobile);
					param.put("name", holder.getName());
					param.put("sim", holder.getSim());
					param.put("holderId", holder.getId().toString());

					Map<String, String> toParam = new HashMap<String, String>();
					toParam.put("monitors", adminMobile);
					toParam.put(adminMobile, adminMember.getToken());
					if (StringUtils.isEmpty(adminMember.getToken())) {
						param.put("msg", postBody);
					}
					toParam.put(Push.KEY + adminMobile, StringToolUtil.toString(adminMember.getPushType()));
					toParam.put(Push.CLIENT_ID + adminMobile, adminMember.getClientId());

					asyncRequestService.post(member.getMobile(), toParam, postBody, param, holder.getDevice().getDeviceType(), holder.getDevice().getSaleChannel());

					if (ApplicationSupport.isDevEnv()) {
						PushPayload pushPayload = new PushPayload();
						pushPayload.setWtow(Wtow.DeviceToApp);
						pushPayload.setSender(device.getImei());
						pushPayload.setReceiver(adminMobile);
						pushPayload.setTitle("新增关注人");
						pushPayload.setAlert(postBody);
						pushPayload.setExtras(param);
						ThriftAppClient.push(pushPayload);
					}
				}
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("id", holder.getId());
				map.put("imei", holder.getImei());
				map.put("deviceType", device.getDeviceType());
				map.put("isAdmin", Boolean.FALSE);
				map.put("flag", 0);
				map.put("sim", null);
				return success(map);
			}
		}
		int flag = 0;
		String sim = null;
		if (!StringUtils.isEmpty(device.getFlag()) && device.getFlag() == 1) {//是否为合约机
			flag = 1;
			if (StringUtils.isEmpty(device.getIccid())) {//检查是否有iccid
				return fail(MyHttpStatus._404_DEVICE_NEED_UP);
			}
			BaseSim baseSim = remoteService.getSim(device.getImei());
			sim = baseSim.getSim();
		}
		Holder holder = deviceService.bind2(device, member, sim);
		redisQueueService.redisBind2(holder.getImei(), holder.getDevice().getDeviceType(), holder.getId());

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", holder.getId());
		map.put("imei", holder.getImei());
		map.put("deviceType", device.getDeviceType());
		map.put("isAdmin", Boolean.TRUE);
		map.put("flag", flag);
		map.put("sim", sim);
		return success(map);
	}

	/**
	 * 设置持有者信息
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/setInfo"}, method = {RequestMethod.POST})
	public MyResponseBody setInfo(@RequestParam(value = "holderId") Long holderId,
								  @RequestParam(value = "memberId") Long memberId,
								  MultiFile multiFile,
								  @RequestParam(value = "name") String name,
								  @RequestParam(value = "birthday") Date birthday,
								  @RequestParam(value = "gender") String gender,
								  @RequestParam(value = "sim") String sim,
								  @RequestParam(value = "height") String height,
								  @RequestParam(value = "weight") String weight) {
		//如果只能管理员修改，可以再更换查询语句
		/*Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, holderId);
		if (monitor == null) {
			return fail(MyHttpStatus._404);
		}*/

		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		//boolean isPush = false;
		if (multiFile.getFile() != null && multiFile.getFile().getSize() > 0) {
			String filePath = UploadUtil.saveMartipartFile(null, multiFile.getFile());
			if (!StringUtils.isEmpty(filePath)) {
				//isPush = true;
				holder.setAvatar(filePath);
			}
		}
		/*if (!name.equals(holder.getName())) {
			isPush = true;
		}*/
		holder.setName(name);
		holder.setBirthday(birthday);
		holder.setGender(gender);

		Device device = holder.getDevice();
		int flag = 0;
		if (!StringUtils.isEmpty(device.getFlag()) && device.getFlag() == 1) {
			if (StringUtils.isEmpty(holder.getSim())) {//第一次绑定才设置 --下面流程不会执行了，在绑定的时候就设置sim号了
				BaseSim baseSim = remoteService.getSim(device.getImei());
				if (baseSim.getRealnameStatus() == 0) {
					flag = 1;
				}
				holder.setSim(baseSim.getSim());
			}
		} else {
			holder.setSim(sim);
		}
		holder.setHeight(height);
		holder.setWeight(weight);
		holderRepository.save(holder);
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(device.getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_UPDATE_CONFIG + ""));
		}

		if (ApplicationSupport.isChinaEnv()) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("holderId", holder.getId());
			map.put("flag", flag);
			return success(map);
		} else {
			return success(holder.getId());
		}

	}

	/**
	 * 上传持有者信息
	 * * 取消管理员权限检查，因为K1管理员关系是设备收到短信后触发。 此接口提交可能没有生成管理员关系
	 */
	//@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/improve"}, method = {RequestMethod.POST})
	public MyResponseBody improve(@RequestParam(value = "holderId") Long holderId,
								  BinDto dto, HttpServletRequest request) {

		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			fail("sys.holder.notexists");
		}
		if (dto.getFile() != null && dto.getFile().getSize() > 0) {
			holder.setAvatar(UploadUtil.saveMartipartFile(request, dto.getFile()));
		}

		List<Mark> markList = holderService.improve(holder, dto);
		String key = RedisKeyPre.HOLDER_IMEI_KEY + holder.getImei();
		redisService.del(key);
		redisQueueService.wetalkHandleMarkList(markList);

		return success(holder.getId());

	}

	/**
	 * ios版上传持有者信息
	 * 取消管理员权限检查，因为K1管理员关系是设备收到短信后触发。 此接口提交可能没有生成管理员关系
	 */
	//@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/ios_improve"}, method = {RequestMethod.POST})
	public MyResponseBody ios_improve(@RequestParam(value = "holderId") Long holderId,
									  BinDto dto, HttpServletRequest request) {

		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			fail("sys.holder.notexists");
		}
		if (dto.getImgStr() != null && dto.getImgStr().length() > 0) {
			holder.setAvatar(UploadUtil.generateImage(request, dto.getImgStr()));
		}

		List<Mark> markList = holderService.improve(holder, dto);
		String key = RedisKeyPre.HOLDER_IMEI_KEY + holder.getImei();
		redisService.del(key);
		redisQueueService.wetalkHandleMarkList(markList);

		return success(holder.getId());
	}

	/**
	 * 功能机系列
	 * 1. 根据用户获取设备持有者列表
	 */
	@DataPermission
	@RequestMapping(value = {"/list"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
							   HttpServletRequest request) {
		//---------------版本升级控制
		if (ApplicationSupport.isChinaEnv()) {
			Member member = memberRepository.findOne(memberId);
			if (member == null) {
				return fail(MyHttpStatus._404);
			}

			if (member.getPushType() == null || member.getPushType() == 0) {
				logger.error("获取设备持有者列表失败，因Android APP版本过旧,MemberId:{}", member.getId());
				//针对国内用户 登录的短信通知服务
				boolean loginPermit = smsNotificationService.toMember(member);
				if (!loginPermit) {//提示版本过低，升级提示
					return success(new ArrayList<MemberHoldersDto>());
				}
			}

		}
		//---------------版本升级控制
		String appId = request.getHeader(AppDetails.APP_ID);//APP应用的包名或者说是BundleId
		/*List<String> deviceTypeList;
		//之前旧版本App及微信调用open api接口都没有传appid
		if (StringUtils.isEmpty(appId) || AppDetails.ANDROID_PACKAGE_BABYWEI.equals(appId) ||
				AppDetails.IOS_PACKAGE_BABYWEI.equals(appId) ) {
			//卫小宝系列的包名 (国内的卫小宝=海外的wherecom+wherecomk2)
			deviceTypeList = AppDetails.DEVICE_TYPE_BABYWEI;
		} else if(AppDetails.PACKAGE_WHERECOM_K2.equals(appId) || AppDetails.PACKAGE_WHERECOM_K2_POMO.equals(appId) ||
				AppDetails.PACKAGE_WHERECOM_K2_IRIST.equals(appId)){
			deviceTypeList = AppDetails.K2_SERIES_DEVICE_TYPE;
		} else if(AppDetails.PACKAGE_WHERECOM_K3.equals(appId) || AppDetails.PACKAGE_WHERECOM_K3_DOKI.equals(appId)){
			deviceTypeList = new ArrayList<String>(Arrays.asList("7"));
		} else if(AppDetails.PACKAGE_WATCH_KIDWATCH.contains(appId)){
			deviceTypeList = AppDetails.DEVICE_TYPE_BABYWEI;
//			deviceTypeList = AppDetails.WATCH_KIDWATCH_DEVICE_TYPE;
		}else {
			deviceTypeList = AppDetails.DEVICE_TYPE_BABYWEI;
		}*/
		//根据 app_Id 返回需要的设备类型列表
		List<String> deviceTypeList = appToDeviceTypeService.getDeviceTypeList(appId);

		List<Monitor> monitorList = monitorRepository.findByMemberId(memberId);
		List<ChannelCustomer> channelCustomerList = channelCustomerRepository.findBySmsFlag(1);

		List<String> saleChannelList = new ArrayList<String>();
		for (ChannelCustomer bean : channelCustomerList) {
			saleChannelList.add(bean.getSaleChannel());
		}
		MemberHoldersDtoBuilder builder = new MemberHoldersDtoBuilder();
		List<MemberHoldersDto> dtoList = builder.build(monitorList, saleChannelList, deviceTypeList);

		return success(dtoList);
	}

	/**
	 * 智能机系列
	 * 获取关注持有者列表 v3代表第三代协议：k3和Doki使用该协议
	 */
	@DataPermission
	@RequestMapping(value = {"/v3/list"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody v3list(@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "currentDate") Date currentDate,
								 @RequestHeader(value = "client_id") String clientId,
								 HttpServletRequest request) {
		logger.info("请求首页数据(设备和位置), memberId:{}，currentDate:{}",memberId,currentDate);
		List<Monitor> monitorList = monitorRepository.findByMemberId(memberId);
		MemberHoldersDtoBuilder builder = new MemberHoldersDtoBuilder();
		/*List<String> deviceTypeList = null;
		if (AppDetails.K3_CLIENT_IDS.contains(clientId)) {
			deviceTypeList =  new ArrayList<String>(Arrays.asList(AppDetails.K3_DEVICE_TYPE));
		} else if (AppDetails.S3_CLIENT_IDS.contains(clientId)) {
			deviceTypeList =  new ArrayList<String>(Arrays.asList(AppDetails.S3_DEVICE_TYPE,AppDetails.S600_DEVICE_TYPE));
		} else {
			deviceTypeList = new ArrayList<String>(Arrays.asList(AppDetails.DOKI_DEVICE_TYPE));
		}*/
		String appId = request.getHeader(AppDetails.APP_ID);//APP应用的包名或者说是BundleId
		List<String> deviceTypeList = appToDeviceTypeService.getDeviceTypeList(appId);

		List<MemberHoldersV3Dto> respList = builder.buildv3(monitorList, currentDate, deviceTypeList);

		return success(respList);
	}

	/**
	 * 2. 根据编号获取持有者的信息
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/detail"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody detail(@RequestParam(value = "monitorId") Long monitorId,
								 @RequestParam(value = "holderId") Long holderId,
								 HttpServletRequest request) {

		//Long currentMemberId = (Long) request.getAttribute("memberId");
		//Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(currentMemberId, holderId);
		Monitor monitor = monitorRepository.findOne(monitorId);
		//Holder holder = holderRepository.findOne(holderId);

		//---------------版本升级控制
		if (ApplicationSupport.isChinaEnv()) {
			Member member = monitor.getMember();
			if (member == null) {
				return fail(MyHttpStatus._404);
			}
			if (member.getPushType() != Member.PUSH_TYPE_JPUSH && StringUtils.isEmpty(member.getToken())) {
				logger.error("获取持有者的信息，因Android APP版本过旧,MemberId:{}", member.getId());
				return fail(MyHttpStatus._401_APP_NEEDS_UPDATED);
			}
		}
		//---------------版本升级控制


		Holder holder = monitor.getHolder();
		Device device = holder.getDevice();
		if (device == null) {//如果设备为空需要进行一个提示
			fail("device.not.exists");
		}

		ChannelCustomer channelCustomer = channelCustomerRepository.findOneBySaleChannel(device.getSaleChannel());
		String channelSms = channelCustomer != null ? (channelCustomer.getSmsFlag() + "") : "0";

		HolderDetailDtoBuilder builder = new HolderDetailDtoBuilder();
		HolderDetailDto dto = builder.build(monitor, holder, channelSms);

		return success(dto);
	}

	/**
	 * 3. 修改持有者信息（只有管理者才能修改头像信息）
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/update", "/v2/update"}, method = {RequestMethod.POST})
	public MyResponseBody update(@RequestParam(value = "id") Long holderId,
								 @RequestParam(value = "monitorId") Long monitorId,//TODO 参数到时候去掉，根据当前用户id和holderId来获取
								 String avatar, HolderDto dto, HttpServletRequest request) {
		Monitor monitor = monitorRepository.findOne(monitorId);
		Holder holder = holderRepository.findOne(holderId);
		if (monitor.getIsAdmin()) {
			if (dto.getFile() != null && dto.getFile().getSize() > 0) {
				String temp = UploadUtil.saveMartipartFile(request, dto.getFile());
				if (temp != null) {
					if (avatar != null) {
						UploadUtil.deleteMartipartFile(avatar);
					}
					holder.setAvatar(temp);
				}
			}
		}

		holderService.update(monitor, holder, dto);

		if (request.getRequestURI().contains("/v2/update")) {
			if (!StringUtils.isEmpty(holder.getAvatar())) {
				return success(setting.getSiteUrl() + holder.getAvatar());
			} else {
				return success(null);
			}
		} else {
			return success(holder.getAvatar());
		}

	}

	/**
	 * 3. 针对IOS接口 修改持有者信息（只有管理者才能修改头像信息）
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/ios_update", "/v2/ios_update"}, method = {RequestMethod.POST})
	public MyResponseBody ios_update(@RequestParam(value = "id") Long holderId,
									 @RequestParam(value = "monitorId") Long monitorId,//TODO 参数到时候去掉，根据当前用户id和holderId来获取
									 String avatar, HolderDto dto, HttpServletRequest request) {

		Monitor monitor = monitorRepository.findOne(monitorId);
		Holder holder = holderRepository.findOne(holderId);
		if (monitor.getIsAdmin() == true) {
			if (dto.getImgStr() != null && dto.getImgStr().length() > 0) {
				String temp = UploadUtil.generateImage(request, dto.getImgStr());
				if (temp != null) {
					if (avatar != null) {
						UploadUtil.deleteMartipartFile(avatar);
					}
					holder.setAvatar(temp);
				}
			}
		}
		holderService.update(monitor, holder, dto);

		if (StringUtils.isEmpty(dto.getImgStr())) {//更新个人资料返回
			return success(null);
		} else {//更新图象返回
			if (request.getRequestURI().contains("/v2/ios_update")) {
				return success(setting.getSiteUrl() + holder.getAvatar());
			} else {
				return success(holder.getAvatar());
			}

		}

	}

	/**
	 * 4. 设定SOS（未使用）
	 */
	@Deprecated
	@RequestMapping(value = {"/sos"}, method = {RequestMethod.POST})
	public MyResponseBody sos(@RequestParam(value = "memberId") Long memberId,
							  @RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "monitorId") Long monitorId,
							  @RequestParam(value = "sos") List<String> sos,
							  @RequestParam(value = "soses", required = false) String soses) {

		Monitor monitor = monitorRepository.findOne(monitorId);
		if (monitor == null) {
			return fail("sys.illegality.operation");
		}
		holderService.sos(memberId, holderId, monitorId, sos, soses);

		return success();
	}

	/**
	 * 4. 设置定位频率
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/frequency"}, method = {RequestMethod.POST})
	public MyResponseBody frequency(//@RequestParam(value = "monitorId") Long monitorId,
									@RequestParam(value = "holderId") Long holderId,
									@RequestParam(value = "frequency") int frequency) {

		/*Monitor monitor = monitorRepository.findOne(monitorId);
		if(monitor == null){
			return fail("sys.illegality.operation");
		}*/
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}

		//1.当前设备没有设置频率；2.当前设备频率和设置的频率不等
		if (holder.getFrequency() == null || frequency != holder.getFrequency().ordinal()) {
			holder.setFrequency(Frequency.values()[frequency]);
			holderService.setFrequency(holder);

			String key = RedisKeyPre.HOLDER_IMEI_KEY + holder.getImei();
			redisService.del(key);

			if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {
				redisQueueService.k2HandleMark(new Mark(holder.getId(), RedisCommand.CMD_CONCERN_TIME));
			}
		}
		return success();
	}


	/**
	 * 5. holder sos列表（未使用）
	 */
	@Deprecated
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/sos_list"}, method = {RequestMethod.POST})
	public MyResponseBody sosList(@RequestParam(value = "holderId") Long holderId) {

		Holder holder = holderRepository.findOne(holderId);
		StringBuilder sb = new StringBuilder();
		if (holder != null) {
			for (int i = 0; i < 3 && holder.getSos().size() > i; i++) {
				sb.append(holder.getSos().get(i));
				if (i < 2) {
					sb.append(",");
				}

			}
		}
		return success(sb.toString());
	}

	/**
	 * 生成设备注册随机码(用于socket通讯)
	 */
	@RequestMapping(value = {"/genRegistCode"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody genRegistCode(@RequestParam(value = "imei") String imei) {

		Device device = deviceRepository.findOneByImei(imei);
		if (device == null) {
			return fail("sys.invalid.imei");
		}
		device.setRegistCode(RandomStringUtils.random(6, "0123456789").toUpperCase());
		deviceService.update(device);

		return success(device.getRegistCode());
	}

	/**
	 * 生成设备解除绑定随机码(用于socket通讯)(未使用)
	 */
	@Deprecated
	@RequestMapping(value = {"/genUnboundCode"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody genUnboundCode(@RequestParam(value = "imei") String imei) {

		Device device = deviceRepository.findOneByImei(imei);
		if (device == null) {
			return fail("sys.invalid.imei");
		}
		device.setUnboundCode(RandomStringUtils.random(6, "0123456789").toUpperCase());
		deviceService.update(device);

		return success(device.getUnboundCode());
	}

	/**
	 * 设备解除绑定
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/unbound"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody unbound(//@RequestParam(value = "imei") String imei,
								  @RequestParam(value = "holderId") Long holderId) {
		Holder holder = holderRepository.findOne(holderId);
		//Device device = deviceRepository.findOneByImei(imei);
		Device device = holder.getDevice();
		Map<String, String> params = monitorService.findMonitorsByHolder(holder.getId());

		Long messageId = holderService.unbound(device, holder, params.get("monitors"));


		//推送消息到APP
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			//Doki&K3设备解绑取消推送,推送逻辑也有问题
			asyncRequestService.pushMessage(holder, params);
		} else {
			//卫小宝1和K2系列
			Map<String, String> param = new HashMap<String, String>();
			param.put("cmd", Integer.toString(Push.UNBOUND));
			param.put("holderId", holder.getId().toString());
			param.put("name", holder.getName());
			param.put("logMessageId", messageId.toString());
			asyncRequestService.post("admin", params, ApplicationSupport.getMessageByEnv("device.unbound.success"), param, holder.getDevice().getDeviceType(), holder.getDevice().getSaleChannel());

			if (ApplicationSupport.isDevEnv()) {
				PushPayload pushPayload = new PushPayload();
				pushPayload.setWtow(Wtow.DeviceToApp);
				pushPayload.setSender(device.getImei());
				List<String> receiverList = new ArrayList<>();
				String[] mobiles = params.get("monitors").split(",");
				for (int i = 0; i < mobiles.length; i++) {
					receiverList.add(mobiles[i]);
				}
				pushPayload.setReceiverList(receiverList);
				pushPayload.setTitle("新增关注人");
				pushPayload.setAlert(ApplicationSupport.getMessageByEnv("device.unbound.success"));
				pushPayload.setExtras(param);
				ThriftAppClient.push(pushPayload);
			}
		}

		return success();
	}

	/**
	 * 设置运动提醒
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/set_move"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody setMoveRemind(@RequestParam(value = "holderId") Long holderId,
										@RequestParam(value = "moveRemind") Boolean moveRemind) {

		Holder holder = holderRepository.findOne(holderId);
		holder.setIsMoveRemind(moveRemind);
		holderService.update(holder);

		return success();
	}

	/**
	 * 设置静止提醒开关,和开始结束时间
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/set_static"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody setStaticOpen(@RequestParam(value = "holderId") Long holderId,
										@RequestParam(value = "staticOpen") Boolean staticOpen,
										@RequestParam(value = "startHours", required = false) String startHours,
										@RequestParam(value = "endHours", required = false) String endHours) {

		Holder holder = holderRepository.findOne(holderId);
		holder.setStaticOpen(staticOpen);
		if (startHours != null) {
			holder.setStartHours(startHours);
		}
		if (endHours != null) {
			holder.setEndHours(endHours);
		}
		holderService.update(holder);

		return success();
	}

	/**
	 * 获取铃声类型--情景模式
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/getAudioTypes"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody getAudioTypes(@RequestParam(value = "holderId") Long holderId) {
		Holder holder = holderRepository.findOne(holderId);
		Map<String, Object> object = new HashMap<String, Object>();
		object.put("holderId", holder.getId());
		object.put("audioTypes", holder.getAudioTypes());
		return success(object);
	}

	/**
	 * 设置铃声类型--情景模式
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/setAudioTypes"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody setAudioTypes(@RequestParam(value = "holderId") Long holderId,
										@RequestParam(value = "audioType", required = false) String audioType,
										@RequestParam(value = "audioTypes", required = false) String audioTypes) {
		Holder holder = holderRepository.findOne(holderId);
		if (!StringUtils.isEmpty(audioType)) {
			holderService.setAudioTypes(holder, audioType);
		} else if (!StringUtils.isEmpty(audioTypes)) {
			holderService.setAudioTypes(holder, audioTypes);
		} else {
			return fail(MyHttpStatus._400);
		}
		if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {
			redisQueueService.k2HandleMark(new Mark(holder.getId(), RedisCommand.CMD_AUDIO_TYPE));
		} else {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_UPDATE_AUDIO_TYPES + ""));
		}
		return success();
	}

	/**
	 * 设置设备时区
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/setTimeZone"}, method = {RequestMethod.POST})
	public MyResponseBody setTimeZone(@RequestParam(value = "holderId") Long holderId,
									  //@RequestParam(value = "monitorId") Long monitorId,
									  @RequestParam(value = "timeZone") String timeZone) {
		
		/*Monitor monitor = monitorRepository.findOne(monitorId);
		if(null == monitor){
			return fail(MyHttpStatus._404_USER_NO_EXISTS);
		}*/

		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404_USER_NO_EXISTS);
		}
		holder.setTimeZone(timeZone);
		holderService.setTimeZone(holder);
		redisQueueService.setTimeZone(holder);

		return success();
	}

	/**
	 * 设置接听方式
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/updateAnswer"}, method = {RequestMethod.POST})
	public MyResponseBody updateAnswer(@RequestParam(value = "holderId") Long holderId,
									   @RequestParam(value = "memberId") Long memberId,
									   @RequestParam(value = "answer") Integer answer) {

		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404_DEVICE_NONENTITY);
		}
		
		/*Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndMemberIdAndHolderId(memberId, holderId);
		if(monitor == null){
			return fail(MyHttpStatus._404);
		}*/
		holderService.updateAnswer(holder, answer);
		if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {
			redisQueueService.k2HandleMark(new Mark(holder.getId(), RedisCommand.CMD_ANSWER_MODE));
		}

		return success();
	}

	/**
	 * 修改持有者Sim卡 已废弃
	 */
	@Deprecated
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/updateSim"}, method = {RequestMethod.POST})
	public MyResponseBody updateSim(@RequestParam(value = "holderId") Long holderId,
									@RequestParam(value = "sim") String sim) {

		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404_DEVICE_NONENTITY);
		}

		holder.setSim(sim);
		holderService.update(holder);

		return success();
	}



}
