package com.umeox.babywei.appapi.web.rest.dto;

public class HolderStepDto {
	private Integer planValue;
	private Integer stepValue;
	private Double percent;
	private Integer distance;
	private Integer calory;
	
	public Integer getPlanValue() {
		return planValue;
	}
	public void setPlanValue(Integer planValue) {
		this.planValue = planValue;
	}
	public Integer getStepValue() {
		return stepValue;
	}
	public void setStepValue(Integer stepValue) {
		this.stepValue = stepValue;
	}
	public Double getPercent() {
		return percent;
	}
	public void setPercent(Double percent) {
		this.percent = percent;
	}
	public Integer getDistance() {
		return distance;
	}
	public void setDistance(Integer distance) {
		this.distance = distance;
	}
	public Integer getCalory() {
		return calory;
	}
	public void setCalory(Integer calory) {
		this.calory = calory;
	}
	
	
	
}
