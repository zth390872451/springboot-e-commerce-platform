package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.ApiLimit;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.repository.*;
import com.umeox.babywei.service.HolderAlbumFileService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.DateTimeUtils;
import com.umeox.babywei.web.rest.BaseController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.net.URLEncoder;
import java.util.*;

import static com.umeox.babywei.domain.HolderAlbumsFile.SHARED;
import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * Created by Administrator on 2017/2/23.
 */
@RestController
@RequestMapping("/api/paipai")
public class HolderPaipaiSpaceController extends BaseController{

    @Autowired
    private HolderPaipaiSpaceRepository holderPaipaiSpaceRepository;
    @Autowired
    private HolderAlbumsFileRepository holderAlbumsFileRepository;
    @Autowired
    private HolderAlbumsRepository holderAlbumsRepository;
    @Autowired
    private HolderPaipaiZanRepository holderPaipaiZanRepository;
    @Autowired
    private SettingProperties setting;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private MonitorRepository monitorRepository;
    @Autowired
    private HolderAlbumFileService holderAlbumFileService;
    @Autowired
    private PaipaiBannerRepository paipaiBannerRepository;

    /**
     * 9.1	获取置顶页
     * @param memberId
     * @return
     */
    @RequestMapping(value = { "/top" }, method = { RequestMethod.GET })
    public MyResponseBody top(@RequestParam(value = "memberId",required = false) Long memberId) {
        List<Banner> rtnList = paipaiBannerRepository.findAll();
        if(rtnList == null){
            rtnList = Collections.emptyList();
        }
        return success(rtnList);
    }

    /**
     * 9.2	获取拍拍列表
     * @param memberId
     * @return
     */
    @RequestMapping(value = { "/list" }, method = { RequestMethod.GET })
    public MyResponseBody list(@RequestParam(value = "memberId",required = false) Long memberId,
                               @RequestParam(value = "holderId",required = false) Long holderId,
                               @RequestParam(value = "paipaiId",required = false) String paipaiId,
                               @RequestParam(value = "viewFlag",defaultValue = "0") Integer viewFlag,
                               @RequestParam(value = "page") Integer   page,
                               @RequestParam(value = "rows",required = false,defaultValue = "20") Integer rows
                               ) {
        if (rows>100)
            rows = 100;
        if (page<=0)
            page = 1;
        if (!StringUtils.isEmpty(memberId)){
            Member member = memberRepository.findOne(memberId);
            if (member==null)
                return fail(MyHttpStatus._400);
        }
        List<Map<String,Object>> resultList = new ArrayList<>();
        HolderPaipaiSpace firstHolderPaipaiSpace = null;
//        可能传入 holderId 和 paipaiId 只要任一 传入，则列表第一个存放当前用户对应的相关记录
        if (!StringUtils.isEmpty(holderId))
            firstHolderPaipaiSpace = holderPaipaiSpaceRepository.findOneByHolderId(holderId);
        else if (!StringUtils.isEmpty(paipaiId)){
            try {
                Long paiId = Long.parseLong(paipaiId);
                firstHolderPaipaiSpace = holderPaipaiSpaceRepository.findOne(paiId);
            }catch (Exception e){
                return fail(MyHttpStatus._400);
            }
        }
        Long fileId = 0L;
        if (firstHolderPaipaiSpace!=null){//放第一个位置
            Holder holder = firstHolderPaipaiSpace.getHolder();
            HolderAlbumsFile firstFile = null;
            HolderAlbums holderAlbums = holderAlbumsRepository.findOneByHolderId(holder.getId());

            if (viewFlag.equals(1)) {//按照点赞数，查看自己点赞数最高的拍拍秀文件
                firstFile = firstHolderPaipaiSpace.getMostZanFile();
            }else  if (viewFlag.equals(2)|| viewFlag.equals(0)){//按照发布时间(2) 【viewFlag=0 距离最近先默认使用发布时间的查询】 查看自己最新发布(分享)的拍拍秀文件
                firstFile = firstHolderPaipaiSpace.getLastShareFile();
            }
            if (firstFile!=null){
                fileId = firstFile.getId();
                Map<String, Object> firstResult = getResultMap(firstFile, holder, holderAlbums, firstHolderPaipaiSpace,memberId);
                if (page==1)//只在第一页才把自己的记录放在第一条，翻页的时候不放
                {
                    firstResult.put("isUserSpace",true);
                    resultList.add(0,firstResult);//添加到第一个
                }
            }
        }

        List<HolderPaipaiSpace>  holderPaipaiSpaceList = new ArrayList<>();

        if (viewFlag.equals(1)){//按照点赞数降序 找 文件
            holderPaipaiSpaceList = holderPaipaiSpaceRepository.findAllByFileIdOrderByZanNumDesc((page-1)*rows, rows,fileId);
            // 查询出 拍拍秀表中
            for (HolderPaipaiSpace holderPaipaiSpace: holderPaipaiSpaceList){
                HolderAlbumsFile holderAlbumsFile = holderPaipaiSpace.getMostZanFile();
                if (holderAlbumsFile.getAccessFlag().equals(1)){//公开
                    Map<String, Object> result= getResultByHolderAlbumsFile(holderAlbumsFile,memberId);
                    resultList.add(result);
                }
            }
        }else if (viewFlag.equals(2)|| viewFlag.equals(0)){//按照发布时间(分享时间)降序 找拍拍分享记录
            // 查询出 拍拍秀表中
            holderPaipaiSpaceList = holderPaipaiSpaceRepository.findAllByFileIdOrderByLastShareTimeDesc((page-1)*rows, rows,fileId);
            for (HolderPaipaiSpace holderPaipaiSpace: holderPaipaiSpaceList){
                HolderAlbumsFile holderAlbumsFile = holderPaipaiSpace.getLastShareFile();
                if (holderAlbumsFile.getAccessFlag().equals(1)){//公开
                    Map<String, Object> result= getResultByHolderAlbumsFile(holderAlbumsFile,memberId);
                    resultList.add(result);
                }
            }
        }
        //当多余rows条记录时【】，移除最后一条
       /* if (resultList.size()>rows){
            resultList.remove(resultList.size()-1);
        }*/
        return success(resultList);
    }



    /**
     *
     * @param holderAlbumsFile
     * @return
     */
    private Map<String, Object> getResultByHolderAlbumsFile(HolderAlbumsFile holderAlbumsFile,Long memberId) {
        Holder holder = holderAlbumsFile.getHolder();
        HolderAlbums holderAlbums = holderAlbumsRepository.findOneByHolderId(holder.getId());
        HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOneByHolderId(holder.getId());
        return getResultMap(holderAlbumsFile, holder, holderAlbums, holderPaipaiSpace,memberId);
    }

    /**
     * @return 综合信息
     */
    private Map<String, Object> getResultMap(HolderAlbumsFile holderAlbumsFile, Holder holder, HolderAlbums holderAlbums, HolderPaipaiSpace holderPaipaiSpace,Long memeberId) {
        Map<String,Object> result = new HashMap<>();
        result.put("paipaiId",holderPaipaiSpace.getId());
        result.put("name",holder.getName());
        result.put("age",DateTimeUtils.getAge(holder.getBirthday()));
        if(!StringUtils.isEmpty(holder.getAvatar())){
            result.put("avatar", setting.getSiteUrl()+holder.getAvatar());
        }
        result.put("title",holderAlbumsFile.getShareTitle());
        result.put("desc",holderAlbumsFile.getShareDesc());
        result.put("fileId",holderAlbumsFile.getId());
        result.put("uploadTime",holderAlbumsFile.getUploadTime());

        String domain = holderAlbums.getDomain();
        String bucket = holderAlbums.getBucket();
        
        String fileUrl =  ApplicationSupport.getCloudStorageURL(domain,bucket,holderAlbumsFile.getFileName());
        String thumbnailUrl = fileUrl;// + "?x-oss-process=image/resize,m_lfit,h_100,w_100";//将图缩略成宽度为100，高度为100，按长边优先
        result.put("url",fileUrl);
        result.put("thumbnailUrl",thumbnailUrl);
        result.put("viewNum",holderAlbumsFile.getViewNum());
        result.put("zanNum",holderAlbumsFile.getZanNum());
        result.put("isUserSpace",false);
        if (StringUtils.isEmpty(memeberId)){
            result.put("isUpvote",false);
        }else {
            HolderPaipaiZan holderPaipaiZan = holderPaipaiZanRepository.findOneByMemberIdAndZanFileId(memeberId, holderAlbumsFile.getId());
            if (StringUtils.isEmpty(holderPaipaiZan)){
                result.put("isUpvote",false);
            }else {
                result.put("isUpvote",true);
            }
        }
        return result;
    }



    /**
     * 9.3	获取个人置顶页
     * @param memberId
     * @return
     */
    @RequestMapping(value = { "/space/top" }, method = { RequestMethod.GET })
    public MyResponseBody spaceTop(@RequestParam(value = "memberId",required = false) Long memberId,
                               @RequestParam(value = "paipaiId") String paipaiId,
                               @RequestParam(value = "fileId",required = false) String fileId) {
        Map<String, Object> result =  new HashMap<>();
        Long paiId =0L;
        try {
            paiId = Long.parseLong(paipaiId);
        }catch (Exception e){
            return fail(MyHttpStatus._400);
        }
        if (StringUtils.isEmpty(fileId)){//默认获取最新分享的文件(使用paipaiId指定的最新分享文件文件)
            HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOne(paiId);
            HolderAlbumsFile holderAlbumsFile = holderPaipaiSpace.getLastShareFile();
            if (holderAlbumsFile.getAccessFlag().equals(1)){//公开、存在
                result= getResultByHolderAlbumsFile(holderAlbumsFile,memberId);
            }
        }else { //优先使用指定文件
            HolderAlbumsFile holderAlbumsFile = holderAlbumsFileRepository.findOne(Long.parseLong(fileId));
            if (holderAlbumsFile.getAccessFlag().equals(1)){//公开、存在
                result= getResultByHolderAlbumsFile(holderAlbumsFile,memberId);
            }
        }
        return success(result);
    }


    /**
     * 9.4	获取个人空间列表
     * @param memberId
     * @return
     */
    @RequestMapping(value = { "/space/list" }, method = { RequestMethod.GET })
    public MyResponseBody spaceList(@RequestParam(value = "memberId",required = false) Long memberId,
                               @RequestParam(value = "paipaiId") String paipaiId,
                               @RequestParam(value = "page") Integer   page,
                               @RequestParam(value = "rows",required = false,defaultValue = "20") Integer rows
    ) {
        if (page<=0)
            page = 1;
        Long paiId = 0L;
        try {
            paiId = Long.parseLong(paipaiId);
            if (!StringUtils.isEmpty(memberId)){
                Member member = memberRepository.findOne(memberId);
                if (member==null)
                    return fail(MyHttpStatus._400);

            }
        }catch (Exception e){
            return fail(MyHttpStatus._400);
        }
        boolean isSpaceAdmin = false;
        List<Map<String,Object>> fileInfoList = new ArrayList<>();
        HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOne(paiId);
        if (holderPaipaiSpace==null)
        {
            return success(fileInfoList);
        }
        Holder holder = holderPaipaiSpace.getHolder();
        if (memberId!=null){
            Monitor admin = monitorRepository.findFirstByIsAdminTrueAndMemberIdAndHolderId(memberId, holder.getId());
            if (!StringUtils.isEmpty(admin)){
                isSpaceAdmin = true;//是管理员
            }
        }
        List<HolderAlbumsFile> holderAlbumsFiles = holderAlbumsFileRepository.findAllByHolderIdAndAccessFlagOrderByShareDate(holder.getId(),1,(page-1)*rows,rows);
        Map<String,Object> map = null;
        for (HolderAlbumsFile holderAlbumsFile : holderAlbumsFiles){
            map= getResultByHolderAlbumsFile(holderAlbumsFile,memberId);
            map.remove("name");
            map.remove("age");
            map.remove("avatar");
            map.remove("isUserSpace");
            map.put("isSpaceAdmin",isSpaceAdmin);
            fileInfoList.add(map);
        }
        return success(fileInfoList);
    }



    /**
     * 9.5	浏览照片
     * @param memberId
     * @return
     */
    @RequestMapping(value = { "/view" }, method = { RequestMethod.POST })
    public MyResponseBody view(@RequestParam(value = "memberId",required = false) Long memberId,
                               @RequestParam(value = "paipaiId") String paipaiId,
                               @RequestParam(value = "fileId") String fileId
    ) {
        Long paiId = 0L;
        Long fileIdL = 0L;
        try {
            paiId = Long.parseLong(paipaiId);
            fileIdL = Long.parseLong(fileId);
        }catch (Exception e){
            return fail(MyHttpStatus._400);
        }
        HolderAlbumsFile holderAlbumsFile = holderAlbumsFileRepository.findOne(fileIdL);
        Holder holder = holderAlbumsFile.getHolder();
        if (holderAlbumsFile==null || holder==null)
            return fail(MyHttpStatus._400);
        holderAlbumsFile.setViewNum(holderAlbumsFile.getViewNum()+1);//查看数+1
        holderAlbumsFileRepository.save(holderAlbumsFile);
        HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOneByHolderId(holder.getId());
        if (holderPaipaiSpace==null){//数据库里没有 任何拍拍秀记录
            holderPaipaiSpace = new HolderPaipaiSpace();
            holderPaipaiSpace.setHolder(holder);
            holderPaipaiSpace.setMostViewFile(holderAlbumsFile);
            holderPaipaiSpace.setViewNum(holderAlbumsFile.getViewNum());
            holderPaipaiSpaceRepository.save(holderPaipaiSpace);
        }else {
            Integer viewNum = holderPaipaiSpace.getViewNum();
            if (viewNum==null || viewNum<=holderAlbumsFile.getViewNum()){
                holderPaipaiSpace.setMostViewFile(holderAlbumsFile);
                holderPaipaiSpace.setViewNum(holderAlbumsFile.getViewNum());
                holderPaipaiSpaceRepository.save(holderPaipaiSpace);
            }
        }
        Map<String, Object> result= getResultByHolderAlbumsFile(holderAlbumsFile,memberId);
        result.remove("name");
        result.remove("age");
        result.remove("avatar");
        result.remove("thumbnailUrl");
        result.remove("isUserSpace");
        return success(result);
    }


    /**
     * 9.6	点赞照片
     *
     * @param memberId
     * @return
     */
    @RequestMapping(value = { "/zan" }, method = { RequestMethod.POST })
    @ApiLimit(times_max = 10000,suffixKeyFrom="mobile",timeToLive = 60,limitLevel= ApiLimit.LimitLevel.API_LEVEL)
    public MyResponseBody zan(@RequestParam(value = "memberId",required = false) Long memberId,
                               @RequestParam(value = "paipaiId") String paipaiId,
                               @RequestParam(value = "fileId") String fileId) {

        Long zanfileId = null;
        Long paipaiIdLong = null;
        try {
            zanfileId = Long.parseLong(fileId);
            paipaiIdLong = Long.parseLong(paipaiId);
        }catch (Exception e){
            return fail(MyHttpStatus._400);
        }
        Map<String,Object> result = new HashMap<>();
        HolderAlbumsFile holderAlbumsFile = holderAlbumsFileRepository.findOne(zanfileId);
        HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOne(paipaiIdLong);
        Holder holder = holderAlbumsFile.getHolder();

        if (holderAlbumsFile==null || holderPaipaiSpace==null|| holder==null)
            return fail(MyHttpStatus._400);

        if (holderAlbumsFile.getAccessFlag().equals(HolderAlbumsFile.INDIVIDUAL)){//点赞的文件私有
            return fail(MyHttpStatus._404);
        }
        if (StringUtils.isEmpty(memberId)){//未认证的用户，可以任意点赞
            //被点赞的文件点赞计数累加
            holderAlbumsFile.setZanNum(holderAlbumsFile.getZanNum()+1);//点赞数+1
            holderAlbumsFileRepository.save(holderAlbumsFile);
        }else {///认证登录成功的用户，点赞数+1
            Member member = memberRepository.findOne(memberId);
            if (member == null)
                return fail(MyHttpStatus._400);
            //被点赞的文件点赞计数累加
            holderAlbumsFile.setZanNum(holderAlbumsFile.getZanNum() + 1);//点赞数+1
            holderAlbumsFileRepository.save(holderAlbumsFile);
            // 对于同一个文件，每个人点赞记录唯一，但是点赞数依然+1
            HolderPaipaiZan holderPaipaiZan = holderPaipaiZanRepository.findOneByMemberIdAndZanFileId(memberId, zanfileId);
            if (holderPaipaiZan == null) {//未点赞
                holderPaipaiZan = new HolderPaipaiZan();
                holderPaipaiZan.setMember(member);
                holderPaipaiZan.setPaipaiSpace(holderPaipaiSpace);
                holderPaipaiZan.setZanFile(holderAlbumsFile);
                holderPaipaiZan.setZanTime(new Date());
                holderPaipaiZanRepository.save(holderPaipaiZan);
            } else {//已点赞，更新点赞时间
                holderPaipaiZan.setZanTime(new Date());
                holderPaipaiZanRepository.save(holderPaipaiZan);
            }
        }
             //点赞后，拍拍秀的点赞记录数更新
         Integer zanNum = holderPaipaiSpace.getZanNum();
         if (zanNum==null || zanNum<=holderAlbumsFile.getZanNum()){
                holderPaipaiSpace.setMostZanFile(holderAlbumsFile);
                holderPaipaiSpace.setZanNum(holderAlbumsFile.getZanNum());
                holderPaipaiSpaceRepository.save(holderPaipaiSpace);
         }
            result.put("paipaiId",paipaiId);
            result.put("fileId",fileId);
            result.put("viewNum",holderAlbumsFile.getViewNum());
            result.put("zanNum",holderAlbumsFile.getZanNum());
            return success(result);
    }

    /**
     * 9.7	删除照片
     *
     * @param memberId
     * @return
     */
    @RequestMapping(value = { "/delete" }, method = { RequestMethod.POST })
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    public MyResponseBody delete(@RequestParam(value = "memberId",required = false) Long memberId,
                              @RequestParam(value = "paipaiId") String paipaiId,
                              @RequestParam(value = "fileId") String fileId) {

        Long deleteFileId = null;
        Long paipaiIdLong = null;
        try {
            deleteFileId = Long.parseLong(fileId);
            paipaiIdLong = Long.parseLong(paipaiId);
        }catch (Exception e){
            return fail(MyHttpStatus._400);
        }

        Map<String,Object> result = new HashMap<>();
        HolderAlbumsFile holderAlbumsFile = holderAlbumsFileRepository.findOne(deleteFileId);
        HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOne(paipaiIdLong);
        Holder holder = holderAlbumsFile.getHolder();
        if(holderAlbumsFile==null ||holderPaipaiSpace ==null)
            return fail(MyHttpStatus._400);

        if (holderAlbumsFile.getAccessFlag().equals(SHARED)){//文件依旧是公开的
            //更新拍拍空间信息
            holderAlbumFileService.deletePaipaiShowFile(holder.getId(), holderAlbumsFile.getId());

            holderAlbumsFile.setViewNum(0);
            holderAlbumsFile.setZanNum(0);
            holderAlbumsFile.setAccessFlag(HolderAlbumsFile.INDIVIDUAL);//私有
            holderAlbumsFile.setShareDesc(null);
            holderAlbumsFile.setShareTitle(null);
            holderAlbumsFile.setShareDate(null);
            holderAlbumsFileRepository.save(holderAlbumsFile);

            return success();

        }else {
            return fail(MyHttpStatus._404);
        }

    }

}
