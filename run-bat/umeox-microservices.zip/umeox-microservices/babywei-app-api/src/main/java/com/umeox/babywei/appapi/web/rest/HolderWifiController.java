package com.umeox.babywei.appapi.web.rest;


import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderWifiDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderWifiDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderWifi;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.HolderWifiRepository;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


/**
 * 设备WiFi接口
 *
 */
@RestController
@RequestMapping( { "/api/holderWifi" })
public class HolderWifiController {
	
	@Autowired
	private HolderWifiRepository holderWifiRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private RedisQueueService redisQueueService;
	/**
	 * 添加WiFi
	 * @param holderId  持有人编号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/add" }, method = { RequestMethod.POST })	
	public MyResponseBody set(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "ssid") String ssid,
							  @RequestParam(value = "password",required = false,defaultValue = "") String password
							 ) {
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._400);
		}
		List<HolderWifi> holderWifiList = holderWifiRepository.findAllByHolderId(holderId);
		if (holderWifiList.size()>=HolderWifi.WIFI_MAX_SIZE){
			return fail(MyHttpStatus._406_MAX_LIMIT);
		}
		HolderWifi holderWifi = new HolderWifi(ssid,password,holder);
		holderWifi = holderWifiRepository.save(holderWifi);

		if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {//服务器下发命令给功能机设备
			redisQueueService.k2HandleMark(new Mark(holder.getId(), RedisCommand.CMD_WIFI));
		}else{//智能机系列
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_WIFI_SYNC + ""));
		}
		return success(holderWifi.getId());
	}

	/**
	 * 修改WiFi
	 * @param holderId  持有人编号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/update" }, method = { RequestMethod.POST })	
	public MyResponseBody set(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "wifiId") Long wifiId,
							  @RequestParam(value = "ssid") String ssid,
							  @RequestParam(value = "password",required = false,defaultValue = "") String password) {
		Holder holder = holderRepository.findOne(holderId);
		HolderWifi holderWifi = holderWifiRepository.findOne(wifiId);
		if (holder == null ||holderWifi==null || holderWifi.getHolder()==null || !holderId.equals(holderWifi.getHolder().getId())){
			return fail(MyHttpStatus._400);
		}
		holderWifi.setSsid(ssid);
		holderWifi.setPassword(password);
		holderWifiRepository.save(holderWifi);
		if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {//服务器下发命令给功能机设备
			redisQueueService.k2HandleMark(new Mark(holder.getId(), RedisCommand.CMD_WIFI));
		}else{//智能机系列
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_WIFI_SYNC + ""));
		}
		return success(holderWifi.getId());
	}

	/**
	 * 获取WiFi配置列表
	 * @param holderId  持有人编号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = {RequestMethod.GET })
	public MyResponseBody update(@RequestParam(value = "holderId") Long holderId){
		List<HolderWifi> holderWifiList = holderWifiRepository.findAllByHolderId(holderId);
		List<HolderWifiDto> holderWifiDtoList = HolderWifiDtoBuilder.build(holderWifiList);
		return success(holderWifiDtoList);
	}

	/**
	 * 删除WiFi
	 * @param holderId  持有人编号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/delete" }, method = { RequestMethod.POST})	
	public MyResponseBody update(@RequestParam(value = "holderId") Long holderId,
								 @RequestParam(value = "wifiId") Long wifiId){
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null){
			return fail(MyHttpStatus._404);
		}
		HolderWifi holderWifi = holderWifiRepository.findOneByIdAndHolderId(wifiId,holderId);
		if (holderWifi!=null){
			holderWifiRepository.delete(holderWifi);
			if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {//服务器下发命令给功能机设备
				redisQueueService.k2HandleMark(new Mark(holder.getId(), RedisCommand.CMD_WIFI));
			}else{//智能机系列
				ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_WIFI_SYNC + ""));
			}
		}
		return success();
	}

}
