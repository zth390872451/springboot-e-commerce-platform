package com.umeox.babywei.appapi.web.rest.dto;

/**
 * 安全区域DTO
 * @author Yan
 *
 */
public class HolderBarrierDto {
	
	/**
	 * 编号
	 */
	private Long barrierId;
	
	/**
	 * 地址
	 */
	private String address;
	
	/**
	 * 经度
	 */
	private Double longitude;
	
	/**
	 * 纬度
	 */
	private Double latitude;
	
	/**
	 * 区域范围
	 */
	private Double radius;

	/**
	 * 关系
	 */
	private String relation;
	
	/**
	 * 启用
	 */
	private int open = 1;
	
	private String railName;
	
	/**
	 * 星期选择项
	 */
	private String weekTime;
	

	/**
	 * 围栏开始时间
	 */
	private String startHours;
	
	/**
	 * 围栏结束时间
	 */
	private String endHours;
	
	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getRadius() {
		return radius;
	}

	public void setRadius(Double radius) {
		this.radius = radius;
	}

	public Long getBarrierId() {
		return barrierId;
	}

	public void setBarrierId(Long barrierId) {
		this.barrierId = barrierId;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public int getOpen() {
		return open;
	}

	public void setOpen(int open) {
		this.open = open;
	}

	public String getRailName() {
		return railName;
	}

	public void setRailName(String railName) {
		this.railName = railName;
	}

	public String getWeekTime() {
		return weekTime;
	}

	public void setWeekTime(String weekTime) {
		this.weekTime = weekTime;
	}

	public String getStartHours() {
		return startHours;
	}

	public void setStartHours(String startHours) {
		this.startHours = startHours;
	}

	public String getEndHours() {
		return endHours;
	}

	public void setEndHours(String endHours) {
		this.endHours = endHours;
	}
	
}
