package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderStepDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderStepDtoBuilder;
import com.umeox.babywei.appapi.web.rest.dto.SportDto;
import com.umeox.babywei.appapi.web.rest.dto.SportDtoBuilder;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.repository.*;
import com.umeox.babywei.service.SportService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.DateTimeUtils;
import com.umeox.babywei.util.StepUtils;
import com.umeox.babywei.web.rest.BaseController;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * 运动
 */
@RestController
@RequestMapping("/api/sport")
public class SportController extends BaseController{
	
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private HolderStepRepository holderStepRepository;
	@Autowired
	private StepLevelRepository stepLevelRepository;
	@Autowired
	private HolderStepPlanRepository holderStepPlanRepository;
	@Autowired
	private SportService sportService;
	@Autowired
	private MemberRepository memberRepository;
	
	/**
	 * 获取运动信息
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/info",method = RequestMethod.GET)
	public MyResponseBody getInfo(@RequestParam(value = "holderId") Long holderId,
								  @RequestParam(value = "currentDate") Date currentDate){
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		Long totalStepVal = holderStepRepository.findStepSumByHolderId(holderId);
		totalStepVal = totalStepVal != null ? totalStepVal : 0;
		HolderStep holderStep = holderStepRepository.findOneByHolderIdAndStepDate(holder.getId(), currentDate);
		SportDto sportDto = SportDtoBuilder.build(holder, holderStep);
		sportDto.setTotalStepValue(totalStepVal);
		
		StepLevel stepLevel = stepLevelRepository.findByStep(totalStepVal);
		sportDto.setLevel(stepLevel.getLevel());
		Long stepVal = totalStepVal - stepLevel.getStart();
		Long totalVal = stepLevel.getEnd() - stepLevel.getStart();
		sportDto.setPercent((double) stepVal/totalVal);
		
		return success(sportDto);
	}
	

	/**
	 * 修改计划值
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/updateGoal",method = RequestMethod.POST)
	public MyResponseBody setGoal(@RequestParam(value = "holderId") Long holderId,
								  @RequestParam(value = "planValue") Integer planValue,
								  @RequestParam(value = "prize") String prize){
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}

		HolderStepPlan holderStepPlan = holderStepPlanRepository.findOneByHolderId(holderId);
		if (holderStepPlan == null) {
			 holderStepPlan = new HolderStepPlan();	
			 holderStepPlan.setHolder(holder);
		}
		holderStepPlan.setPlanValue(planValue);
		holderStepPlan.setPrize(prize);
		sportService.update(holderStepPlan);
		
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holderStepPlan.getHolder().getDevice().getDeviceType())) {
			//智能机推送到设备上
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holderStepPlan.getHolder().getImei(), Push.K3_DEVICE_UPDATE_STEP + ""));			
		}
		
		return success();
	}
	
	/**
	 * 获取计划值
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/getGoal",method = RequestMethod.GET)
	public MyResponseBody getGoal(@RequestParam(value = "holderId") Long holderId){
		HolderStepPlan holderStepPlan = holderStepPlanRepository.findOneByHolderId(holderId);
		double stepValue = 0;
		if(holderStepPlan==null){
			stepValue = 0;
		}else {
			HolderStep holderStep = sportService.getStep(holderStepPlan.getHolder());
			stepValue = holderStep != null ? holderStep.getStepValue() : 0;
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if(holderStepPlan != null){
			map.put("planValue", holderStepPlan.getPlanValue());
			map.put("percent", (stepValue / holderStepPlan.getPlanValue()));
		}else{
			map.put("planValue", 0);
			map.put("percent",0);
		}
		
		return success(map);
	}

	/**
	 * 获取每日期设备计步数据
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/getHisStep"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody getHome(@RequestParam(value = "memberId") Long memberId,
								  @RequestParam(value = "holderId") Long holderId,
								  @RequestParam(value = "hisDate") Date hisDate){
		Holder holder = holderRepository.findOne(holderId);
		Member member = memberRepository.findOne(memberId);
		if (holder == null || member == null) {
			return fail(MyHttpStatus._404);
		}
		HolderStep holderStep = holderStepRepository.findOneByHolderIdAndStepDate(holder.getId(), hisDate);
		HolderStepDto respDto = HolderStepDtoBuilder.build(holder, holderStep);
		return success(respDto);
	}

	/**
	 * 计步数据统计，根据时间段，按日、周、月、年统计计步数据
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/step/count"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody getStepCount(@RequestParam(value = "memberId") Long memberId,
									   @RequestParam(value = "holderId") Long holderId,
									   @RequestParam(value = "type", required = false, defaultValue = "0") Integer type,
									   @RequestParam(value = "fromDate", required = false) Date fromDate,
									   @RequestParam(value = "toDate", required = false) Date toDate) {
		Holder holder = holderRepository.findOne(holderId);
		Member member = memberRepository.findOne(memberId);
		if (holder == null || member == null) {
			return fail(MyHttpStatus._404);
		}

		if (fromDate == null || toDate ==null) {
			Calendar calendar1 = Calendar.getInstance();
			calendar1.set(Calendar.HOUR_OF_DAY, 0);
			calendar1.set(Calendar.MINUTE, 0);
			calendar1.set(Calendar.SECOND, 0);
			Calendar calendar2 = Calendar.getInstance();
			calendar2.set(Calendar.HOUR_OF_DAY, 23);
			calendar2.set(Calendar.MINUTE, 59);
			calendar2.set(Calendar.SECOND, 59);
			//设置默认值
			switch (type) {
				case 0:
					fromDate = calendar1.getTime();
					toDate = calendar2.getTime();
					break;
				case 1:
					fromDate = DateTimeUtils.getWeekFirstDay(calendar1, 0);
					toDate = DateTimeUtils.getWeekLastDay(calendar2, 0);
					break;
				case 2:
					fromDate = DateTimeUtils.getMonthFirstDay(calendar1, 0);
					toDate = DateTimeUtils.getMonthLastDay(calendar2, 0);
					break;
				case 3:
					fromDate = DateTimeUtils.getYearFirstDay(calendar1);
					toDate = DateTimeUtils.getYearLastDay(calendar2);
					break;
				case 4:
					fromDate = holder.getDevice().getActivityDate();//总：开始日期为设备激活日期
					toDate = calendar2.getTime(); //总：结束日期为当天
					break;
			}

		}

		Map<String, Object> rtnMap = new LinkedHashMap<String, Object>();
		rtnMap.put("holderId", holderId);

		//设置计划值
		HolderStepPlan holderStepPlan = holderStepPlanRepository.findOneByHolderId(holderId);
		if (holderStepPlan != null) {
			rtnMap.put("planValue", holderStepPlan.getPlanValue());
		} else {
			rtnMap.put("planValue", 0);
		}
		//设置开始和结束日期
		rtnMap.put("fromDate", DateTimeUtils.getFormatDate(fromDate, DateTimeUtils.PART_DATE_FORMAT));
		rtnMap.put("toDate", DateTimeUtils.getFormatDate(toDate, DateTimeUtils.PART_DATE_FORMAT));

		int stepValue = 0, cday = 0; //累计计步数，参与平均值计算的天数
		List<String> stepData = new LinkedList<String>();

		List<HolderStep> holderStepList = holderStepRepository.findByStepDate(holderId, fromDate, toDate);

		if (holderStepList != null) {
			for (HolderStep holderStep : holderStepList) {
				stepValue += holderStep.getStepValue();
				cday++;
				stepData.add(holderStep.getStepDate() + "," + holderStep.getStepValue());
			}
		}
		rtnMap.put("stepValue", stepValue);
		rtnMap.put("stepData", stepData);
		rtnMap.put("dailyValue", 0);
		rtnMap.put("distance", 0);
		rtnMap.put("dailyDistance", 0);
		rtnMap.put("calory", 0);

		if (cday != 0) {
			rtnMap.put("dailyValue", (int) stepValue / cday);
			int distance = (int) (stepValue * StepUtils.getDistance(!StringUtils.isEmpty(holder.getHeight()) ? Double.parseDouble(holder.getHeight()) : 0));
			rtnMap.put("distance", distance/100);
			rtnMap.put("dailyDistance", (int) (distance / cday));
			rtnMap.put("calory", StepUtils.getKcal(!StringUtils.isEmpty(holder.getWeight()) ? Double.parseDouble(holder.getWeight()) : 0, distance / 100000d));
		}
		rtnMap.put("goals",holderStepRepository.findReachGoalTimesByStepDate(holderId,fromDate,toDate));
		return success(rtnMap);
	}
	
}
