package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderStep;
import com.umeox.babywei.domain.HolderStepPlan;
import com.umeox.babywei.repository.HolderStepPlanRepository;
import com.umeox.babywei.util.StepUtils;
import org.springframework.util.StringUtils;

public class HolderStepDtoBuilder {
	
	public static HolderStepDto build(Holder holder,HolderStep holderStep) {
		HolderStepDto respBean = new HolderStepDto();
		if(holderStep == null){
			return respBean;
		}
		HolderStepPlanRepository holderStepPlanRepository = (HolderStepPlanRepository) ApplicationSupport.getBean("holderStepPlanRepository");
		HolderStepPlan holderStepPlan = holderStepPlanRepository.findOneByHolderId(holder.getId());
		holderStep.setPlanValue(holderStepPlan.getPlanValue());
		respBean.setPlanValue(holderStep.getPlanValue());
		respBean.setStepValue(holderStep.getStepValue());
		respBean.setPercent((double)holderStep.getStepValue()/holderStep.getPlanValue());
		if (!StringUtils.isEmpty(holder.getHeight())) {
			if (holder.getHeight()!=null&&holder.getHeight().contains("cm")){//清除以cm或者空格+cm 结尾的字符
				String height = holder.getHeight();
				height = height.replace("cm","").replace(" ","");
				holder.setHeight(height);
			}
			double distance = StepUtils.getDistance(Double.parseDouble(holder.getHeight()));//单位：厘米
			double m = distance * holderStep.getStepValue() / 100.0;//单位：米
			respBean.setDistance((int)m);
			double km = m / 1000.0;
			if (!StringUtils.isEmpty(holder.getWeight())) {
				if (holder.getWeight()!=null&&holder.getWeight().contains("kg")){//清除以kg或者空格+kg 结尾的字符
					String weight = holder.getWeight();
					weight = weight.replace("kg","").replace(" ","");
					holder.setWeight(weight);
				}
				respBean.setCalory((int)StepUtils.getKcal(Double.parseDouble(holder.getWeight()), km));
			}
		}
		return respBean;
	}
}
