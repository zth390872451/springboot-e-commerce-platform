package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderStepDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderStepDtoBuilder;
import com.umeox.babywei.bean.HomeDto;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderStep;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.HolderStepRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.HomeService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.web.rest.BaseController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * @author umeox
 */
@RestController
@RequestMapping({"/api/home"})
public class HomeController extends BaseController{

	private static final Logger LOGGER = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private HomeService homeService;
	@Autowired
	private HolderStepRepository holderStepRepository;
	
	
	/**
	 * 获取首页数据
	 * 获取定位信息：设备位置信息(设备上报地理位置的消息逻辑)
	 * 此接口假设设备和APP用户是同一个时区。
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    @RequestMapping(value = {"/get"}, method = {RequestMethod.GET, RequestMethod.POST})
    public MyResponseBody get(@RequestParam(value = "memberId") Long memberId,
                              @RequestParam(value = "holderId") Long holderId,
                              @RequestParam(value = "currentDate") Date currentDate) {
		LOGGER.info("home.get, memberId:{},holderId:{},currentDate:{}", memberId, holderId, currentDate);
		if (StringUtils.isEmpty(currentDate)){
			currentDate = new Date();
		}
		Holder holder = holderRepository.findOne(holderId);
    	Member member = memberRepository.findOne(memberId);
    	if (holder == null || member == null) {
			return fail(MyHttpStatus._404);
		}
		//Modified By JT on 2016-08-22, 注释下面代码，将产生定位匹配码移到公用部分
    	/*String locationCode = CommonUtils.getRandomNumber();
		member.setLocationCode(locationCode);
		memberRepository.save(member);*/
		HomeDto respData = homeService.getBaseData(member, holder, currentDate);
		if (respData==null || respData.getStepValue()==null || respData.getStepValue()==0){//当天没有计步数据
			respData.setRank(0);
		}else {//有
			
			//因计步排行榜数据APP端暂未使用，先去掉以下逻辑
			/*//查找当天计步的人数
			Long sumNumber = holderStepRepository.findCountByStepDate(currentDate);
			//查询计步数大于等于自己的人数
			Long outNumber = holderStepRepository.findCountByStepValueAndStepDate(respData.getStepValue(), currentDate);
			if (outNumber==0 || sumNumber ==0){
				respData.setRank(0);
			}else {
				BigDecimal result = new BigDecimal(outNumber).divide(new BigDecimal(sumNumber), 2, BigDecimal.ROUND_HALF_UP);
				Float floatValue = result.floatValue()==0? 1: (1-result.floatValue())*100;
				int rank = floatValue.intValue();
				respData.setRank(rank);//击败了多少百分比
			}*/
			respData.setRank(0);
		}
        return success(respData);
    }



	/**
	 * 获取首页数据:地理位置信息，但是不发送定位命令
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/getWithoutCmd"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody getCurrentInfo(@RequestParam(value = "memberId") Long memberId,
										 @RequestParam(value = "holderId") Long holderId,
										 @RequestParam(value = "currentDate") Date currentDate) {
		Holder holder = holderRepository.findOne(holderId);
		Member member = memberRepository.findOne(memberId);
		if (holder == null || member == null) {
			return fail(MyHttpStatus._404);
		}
		//Modified By JT on 2016-08-22, 注释下面代码，因不需要产生定位码
	/*	String locationCode = CommonUtils.getRandomNumber();
		member.setLocationCode(locationCode);
		memberRepository.save(member);*/
		HomeDto respData = homeService.getCurrentInfo(member, holder, currentDate);
		return success(respData);
	}

	
	/**
	 * 获取指定日期设备历史记步数据
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    @RequestMapping(value = {"/getHome"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody getHome(@RequestParam(value = "memberId") Long memberId,
					            @RequestParam(value = "holderId") Long holderId,
					            @RequestParam(value = "hisDate") Date hisDate){
		Holder holder = holderRepository.findOne(holderId);
    	Member member = memberRepository.findOne(memberId);
    	if (holder == null || member == null) {
			return fail(MyHttpStatus._404);
		}
    	HolderStep holderStep = holderStepRepository.findOneByHolderIdAndStepDate(holder.getId(), hisDate);
    	HolderStepDto respDto = HolderStepDtoBuilder.build(holder, holderStep);
		return success(respDto);
	}
}
