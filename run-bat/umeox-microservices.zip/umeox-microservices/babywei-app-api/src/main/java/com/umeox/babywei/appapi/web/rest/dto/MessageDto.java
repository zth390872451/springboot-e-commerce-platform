package com.umeox.babywei.appapi.web.rest.dto;

public class MessageDto {
	private Long messageId;
	/**
	 * 消息类型
	 * 4：申请关注
	 * 5：邀请关注
	 */
	private int type;
	
	
	/**
	 * 附加信息
	 */
	private String remark;
	
	
	/**
	 * 地址
	 */
	private String address;
	
	/**
	 * 经度
	 */
	private Double longitude;
	
	/**
	 * 纬度
	 */
	private Double latitude;
	
	/**
	 * 区域范围
	 */
	private Double radius;
	
	/**
	 * 编号
	 */
	private Long barrierId;
	
	private Long memberId;
	
	private Long adminId;
	
	private String memberMobile;
	private String adminMobile;
	
	/**
	 * 时间
	 */
	private String date;
	/**
	 * 胶囊的IMEI
	 */
	private String imei;
	
	private Integer state;//默认状态0未处理 1 已同意或者已接受 -1 已拒绝忽略

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getRadius() {
		return radius;
	}

	public void setRadius(Double radius) {
		this.radius = radius;
	}

	public Long getBarrierId() {
		return barrierId;
	}

	public void setBarrierId(Long barrierId) {
		this.barrierId = barrierId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public Long getAdminId() {
		return adminId;
	}

	public void setAdminId(Long adminId) {
		this.adminId = adminId;
	}

	public String getMemberMobile() {
		return memberMobile;
	}

	public void setMemberMobile(String memberMobile) {
		this.memberMobile = memberMobile;
	}

	public String getAdminMobile() {
		return adminMobile;
	}

	public void setAdminMobile(String adminMobile) {
		this.adminMobile = adminMobile;
	}
	
	
	
	
	
}
