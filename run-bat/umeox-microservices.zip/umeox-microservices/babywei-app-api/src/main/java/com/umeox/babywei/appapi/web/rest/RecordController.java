package com.umeox.babywei.appapi.web.rest;


import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.appapi.web.rest.dto.RecordDto;
import com.umeox.babywei.appapi.web.rest.dto.RecordDtoBuilder;
import com.umeox.babywei.domain.Record;
import com.umeox.babywei.repository.RecordRepository;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.DateTimeUtils;
import com.umeox.babywei.web.rest.BaseController;

/**
 * 录音(未使用)
 */
@RestController
@RequestMapping( { "/api/record" })
public class RecordController extends BaseController{
	
	@Autowired
	private RecordRepository recordRepository;

	
	/**
	 * 查询
	 */
	@RequestMapping(value = { "/list" }, method = { RequestMethod.GET })
	public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
							   @RequestParam(value = "holderId") Long holderId,
							   @RequestParam(value = "date") Date date) {
		
		List<Record> recordList = recordRepository.findByHolderIdAndCreateDateBetween(holderId, DateTimeUtils.addDays(date, 1), date);
		
		RecordDtoBuilder builder = new RecordDtoBuilder();
		List<RecordDto> dtoList = builder.build(recordList);
		
		return success(dtoList);
	}
	
	
	/**
	 * 删除记录
	 */
	@RequestMapping(value = { "/delete" }, method = { RequestMethod.POST })
	public MyResponseBody delete(@RequestParam(value = "recordId") Long recordId) {
		
		recordRepository.delete(recordId);
		
		return success();
	}	

}
