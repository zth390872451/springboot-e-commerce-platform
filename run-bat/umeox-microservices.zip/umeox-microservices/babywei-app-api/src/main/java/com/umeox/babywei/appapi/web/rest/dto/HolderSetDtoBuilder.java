package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderSchedule;
import com.umeox.babywei.domain.HolderSet;
import com.umeox.babywei.repository.HolderScheduleRepository;

public class HolderSetDtoBuilder {
	private static HolderScheduleRepository holderScheduleRepository;
	static{
		holderScheduleRepository = (HolderScheduleRepository) ApplicationSupport.getBean("holderScheduleRepository");
	}
	
	public static HolderSetDto build(Holder holder,HolderSet holderSet){
		HolderSetDto respData = new HolderSetDto();
		respData.setHolderId(holder.getId());
		if (holderSet != null) {
			respData.setAnswer(holderSet.getAnswer());
			respData.setCallLocation(holderSet.getCallLocation());
			respData.setElectricProtect(holderSet.getElectricProtect());
			respData.setPowerOffLocation(holderSet.getPowerOffLocation());
			respData.setRefusePhone(holderSet.getRefusePhone());
			respData.setClassTimeProtect(holderSet.getClassTimeProtect());
			respData.setConcernTimeProtect(holderSet.getConcernTimeProtect());
			respData.setDeviceOffAlarm(holderSet.getDeviceOffAlarm());
			respData.setBluetoothAccompanyState(holderSet.getBluetoothAccompanyState());
			respData.setDeviceWorkModel(holderSet.getDeviceWorkModel()!=null?holderSet.getDeviceWorkModel():0);
		}
		respData.setFrequency(holder.getFrequency().label());//k1 频率
		Boolean isMoveRemind = holder.getIsMoveRemind() != null ? holder.getIsMoveRemind() : false;
		Boolean staticOpen = holder.getStaticOpen() != null ? holder.getStaticOpen() : false;
		respData.setIsMoveRemind(isMoveRemind);
		respData.setStaticOpen(staticOpen);
		respData.setStartHours(holder.getStartHours());
		respData.setEndHours(holder.getEndHours());
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			HolderSchedule holderSchedule = 
					holderScheduleRepository.findFirstByHolderIdAndScheduleType(holder.getId(), HolderSchedule.SCHEDULE_TYPE_CONCERN);
			if (holderSchedule != null) {
				respData.setFrequency(holderSchedule.getFrequency());//k3 频率
				respData.setAmSec(holderSchedule.getAmSec());
			}
		}
		
		return respData;
	}
}
