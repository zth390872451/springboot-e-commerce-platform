package com.umeox.babywei.appapi.web.rest.dto;

public class TimeZoneDto {
	
	private String timeZoneId;
	
	private String name;
	
	private String gmt;
	
	private long val;

	
	
	

	public long getVal() {
		return val;
	}

	public void setVal(long val) {
		this.val = val;
	}

	public String getTimeZoneId() {
		return timeZoneId;
	}

	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGmt() {
		return gmt;
	}

	public void setGmt(String gmt) {
		this.gmt = gmt;
	}
	
}
