package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.HolderWallpaper;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.List;

public class HolderWallpaperDtoBuilder {

	public static HolderWallpaperDto build(HolderWallpaper holderWallpaper) {
		HolderWallpaperDto holderWallpaperDto = new HolderWallpaperDto();
		SettingProperties setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
		String prefix = setting.getSiteUrl();
		if (holderWallpaper!=null){
			holderWallpaperDto.setId(holderWallpaper.getId());
			if (!StringUtils.isEmpty(holderWallpaper.getWallpaperUrl())){
				holderWallpaperDto.setWallpaperUrl(prefix +holderWallpaper.getWallpaperUrl());
			}
		}
		return holderWallpaperDto;
	}

	public static List<HolderWallpaperDto> build(List<HolderWallpaper> holderWallpapers) {
		List<HolderWallpaperDto> dtos = new ArrayList<HolderWallpaperDto>();
		for (HolderWallpaper dao : holderWallpapers) {
			dtos.add(build(dao));
		}
		return dtos;
	}
}
