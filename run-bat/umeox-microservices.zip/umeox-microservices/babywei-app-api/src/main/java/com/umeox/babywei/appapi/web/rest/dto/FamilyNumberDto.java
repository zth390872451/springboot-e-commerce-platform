package com.umeox.babywei.appapi.web.rest.dto;

public class FamilyNumberDto {
	private Long familyNumberId;
	private String name;
	private String mobile;
	private String email;
	private Integer sort;
	private Integer origin;//0:自己新增 1：自己的号码 2：关注者的号码
	private String relation;//0 爸爸-1妈妈-2爷爷-3奶奶-4其他
	private Integer photoFlag;
	private Integer type;
	private String photoUrl;
/*	private String imUserID;
	private String imFriendID;*/
	
	
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Long getFamilyNumberId() {
		return familyNumberId;
	}
	public void setFamilyNumberId(Long familyNumberId) {
		this.familyNumberId = familyNumberId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getOrigin() {
		return origin;
	}
	public void setOrigin(Integer origin) {
		this.origin = origin;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public Integer getPhotoFlag() {
		return photoFlag;
	}
	public void setPhotoFlag(Integer photoFlag) {
		this.photoFlag = photoFlag;
	}
	
}
