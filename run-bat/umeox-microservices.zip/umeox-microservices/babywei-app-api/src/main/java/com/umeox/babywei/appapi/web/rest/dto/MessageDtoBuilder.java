package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import com.umeox.babywei.domain.Message;
import com.umeox.babywei.util.DateTimeUtils;


public class MessageDtoBuilder {

	public MessageDto build(Message message) {
		MessageDto dto = new MessageDto();
		
		/*if(message.getType() == 4 && message.getBarrier() != null){
			dto.setAddress(message.getBarrier().getAddress());
			dto.setLatitude(message.getBarrier().getLatitude());
			dto.setLongitude(message.getBarrier().getLongitude());
			dto.setBarrierId(message.getBarrier().getId());
			dto.setRadius(message.getBarrier().getRadius());
		}*/
		dto.setMemberId(message.getMember().getId());
		dto.setAdminId(message.getAdmin().getId());
		dto.setMemberMobile(message.getMember().getMobile());
		dto.setAdminMobile(message.getAdmin().getMobile());
		dto.setMessageId(message.getId());
		dto.setImei(message.getHolder().getImei());
		dto.setDate(DateTimeUtils.getFormatDate(message.getCreateDate(), DateTimeUtils.FULL_DATE_FORMAT));
		dto.setType(message.getType());
		dto.setRemark(message.getRemark());
		dto.setState(message.getState()==null?0:message.getState());
		return dto;
	}

	public List<MessageDto> build(List<Message> messages) {
		List<MessageDto> dtos = new ArrayList<MessageDto>();
		for (Message message : messages) {
				dtos.add(build(message));
		}
		return dtos;
	}

}
