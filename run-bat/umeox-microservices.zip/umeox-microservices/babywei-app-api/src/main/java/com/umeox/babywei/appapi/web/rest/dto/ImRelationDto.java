package com.umeox.babywei.appapi.web.rest.dto;

public class ImRelationDto {
	
	private String imUserID;
	private String imFriendID;
	private String mobile;
	private String nick;
	private Integer photoFlag;
	private String photoUrl;
	private String gender;
	
	
	public String getImUserID() {
		return imUserID;
	}
	public void setImUserID(String imUserID) {
		this.imUserID = imUserID;
	}
	public String getImFriendID() {
		return imFriendID;
	}
	public void setImFriendID(String imFriendID) {
		this.imFriendID = imFriendID;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getNick() {
		return nick;
	}
	public void setNick(String nick) {
		this.nick = nick;
	}
	public Integer getPhotoFlag() {
		return photoFlag;
	}
	public void setPhotoFlag(Integer photoFlag) {
		this.photoFlag = photoFlag;
	}
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
}
