package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderWallpaperDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderWallpaperDtoBuilder;
import com.umeox.babywei.bean.MultiFile;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderWallpaper;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.HolderWallpaperRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.HolderWallpaperService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.UploadUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

import static com.umeox.babywei.support.MyHttpStatus._400;
import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * @creator ZTH
 * @modifier ZTH
 * @date 2017-08-14
 */
@RestController
@RequestMapping({"/api/wallpaper"})
public class HolderWallpaperController {
	private static final Logger logger = LoggerFactory.getLogger(HolderWallpaperController.class);

	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private HolderWallpaperRepository holderWallpaperRepository;
	@Autowired
	private HolderWallpaperService holderWallpaperService;
	/**
	 * 管理员给设备添加开机壁纸，上传壁纸
	 */
	@DataPermission(DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/add"}, method = {RequestMethod.POST})
	public MyResponseBody addWallpaper(@RequestParam(value = "memberId") Long memberId,
									   @RequestParam(value = "holderId") Long holderId,
									   HttpServletRequest request) {
		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findOne(holderId);
		if (member == null || holder == null) {
			return fail(MyHttpStatus._404);
		}
		List<MultipartFile> multipartFiles = ((MultipartHttpServletRequest) request)
				.getFiles("files");
		if (StringUtils.isEmpty(multipartFiles)){
			return fail(_400);
		}
		List<HolderWallpaper> holderWallpapers = new ArrayList<HolderWallpaper>();
		for (MultipartFile multipartFile : multipartFiles) {
			String wallpaperUrl = UploadUtil.saveMartipartFile(null, multipartFile);
			if (wallpaperUrl != null) {
				HolderWallpaper holderWallpaper = new HolderWallpaper();
				holderWallpaper.setHolder(holder);
				holderWallpaper.setWallpaperUrl(wallpaperUrl);
				holderWallpapers.add(holderWallpaper);
			}else {//失败一个那就当做全部失败处理
				return fail();
			}
		}
		if (!CollectionUtils.isEmpty(holderWallpapers)) {
			holderWallpaperRepository.save(holderWallpapers);
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_WALLPAPER + ""));
			return success();
		} else {//文件上传失败
			return fail();
		}
	}

	/**
	 * 查看设备的所有的开机壁纸列表
	 */
	@DataPermission(DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = {"/get"}, method = {RequestMethod.GET})
	public MyResponseBody listWallpaper(@RequestParam(value = "memberId") Long memberId,
									   @RequestParam(value = "holderId") Long holderId) {
		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findOne(holderId);
		if (member == null || holder == null) {
			return fail(MyHttpStatus._404);
		}
		List<HolderWallpaper> holderWallpapers = holderWallpaperRepository.findAllByHolderId(holderId);
		List<HolderWallpaperDto> dtos = HolderWallpaperDtoBuilder.build(holderWallpapers);
		return success(dtos);
	}


	/**
	 * 替换指定的开机壁纸
	 */
	@DataPermission(DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/update"}, method = {RequestMethod.POST})
	public MyResponseBody updateWallpaper(@RequestParam(value = "memberId") Long memberId,
										  @RequestParam(value = "holderId") Long holderId,
										  @RequestParam(value = "id") Long id,
										  MultiFile multiFile) {
		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findOne(holderId);
		if (member == null || holder == null) {
			return fail(MyHttpStatus._404);
		}
		String wallpaperUrl = UploadUtil.saveMartipartFile(null, multiFile.getFile());
		if (!StringUtils.isEmpty(wallpaperUrl)){
			HolderWallpaper holderWallpaper = holderWallpaperService.updateByHolderIdAndId(holderId, id, wallpaperUrl);
			if (holderWallpaper!=null){
				ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_WALLPAPER + ""));
				return success();
			}
		}
		return fail();
	}

	/**
	 * 删除指定的开机壁纸
	 */
	@DataPermission(DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = {"/delete"}, method = {RequestMethod.POST})
	public MyResponseBody deleteWallpaper(@RequestParam(value = "memberId") Long memberId,
									   @RequestParam(value = "holderId") Long holderId,
										  @RequestParam(value = "ids") Long[] ids) {
		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findOne(holderId);
		if (member == null || holder == null) {
			return fail(MyHttpStatus._404);
		}
		holderWallpaperService.deleteByHolderIdAndIds(holderId,ids);
		ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_WALLPAPER + ""));
		return success();
	}
}
