package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.MemberRepository;


public class FamilyNumberDtoBuilder {
	
	private final static MemberRepository memberRepository;
	private final static SettingProperties setting;
	
	
	
	static{
		memberRepository = (MemberRepository) ApplicationSupport.getBean("memberRepository");
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}
	
	public FamilyNumberDto build(FamilyNumber familyNumber) {
		FamilyNumberDto dto = new FamilyNumberDto();
		dto.setFamilyNumberId(familyNumber.getId());
		dto.setName(familyNumber.getName());
		dto.setMobile(familyNumber.getMobile());
		if (!StringUtils.isEmpty(familyNumber.getEmail())) {
			dto.setEmail(familyNumber.getEmail().replace("$", "@"));
		}
		
		if(familyNumber.getSort() != null) {
			if(familyNumber.getSort()==10) {
				dto.setSort(2);
			} else if(familyNumber.getSort()==20) {
				dto.setSort(1);
			} 
		}
		
		dto.setOrigin(familyNumber.getOrigin());
		if(familyNumber.getRelation() == null){
			dto.setRelation("4");
		}else {
			dto.setRelation(familyNumber.getRelation());
		}
		if (StringUtils.isEmpty(familyNumber.getPhotoFlag())) {
			dto.setPhotoFlag(0);
		}else {
			dto.setPhotoFlag(Integer.parseInt(familyNumber.getPhotoFlag()));
		}
		dto.setType(familyNumber.getType());
		if (FamilyNumber.TYPE_ALL.equals(familyNumber.getType()) && 
				AppDetails.WE_TALK_DEVICE_TYPE.equals(familyNumber.getHolder().getDevice().getDeviceType())) {//微话饼头像获取
			Member member = memberRepository.findOneByMobile(familyNumber.getMobile());
			if (member != null && !StringUtils.isEmpty(member.getAvatar())) {
				dto.setPhotoUrl(setting.getSiteUrl()+member.getAvatar());
			}
		}else if(AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(familyNumber.getHolder().getDevice().getDeviceType())){
			String moblie = "";
			if(ApplicationSupport.isChinaEnv()){
				moblie = familyNumber.getMobile();
			}else {
				moblie = familyNumber.getEmail();
			}
			Member member = memberRepository.findOneByMobile(moblie);
			if (member != null && !StringUtils.isEmpty(member.getAvatar())) {
				dto.setPhotoUrl(setting.getSiteUrl()+member.getAvatar());
			}else {
				dto.setPhotoUrl(setting.getSiteUrl()+familyNumber.getAvatar());
			}
		}
		
		return dto;
	}

	public List<FamilyNumberDto> build(List<FamilyNumber> familyNumbers) {
		List<FamilyNumberDto> dtos = new ArrayList<FamilyNumberDto>();
		for (FamilyNumber familyNumber : familyNumbers) {
				dtos.add(build(familyNumber));
		}
		return dtos;
	}

}
