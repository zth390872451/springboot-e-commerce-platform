package com.umeox.babywei.appapi.web.rest;


import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderBarrierDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderBarrierDtoBuilder;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.Barrier;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.repository.BarrierRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.MonitorRepository;
import com.umeox.babywei.service.BarrierService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.CommonUtils;
import com.umeox.babywei.util.CoordinateConvert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;



/**
 * 围栏接口
 * 关注者只能查看围栏列表
 */
@RestController
@RequestMapping( { "/api/barrier" })
@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
public class BarrierController {
	
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private BarrierRepository barrierRepository;
	@Autowired
	private BarrierService barrierService;
	
	/**
	 * 设定围栏
	 * @param holderId  持有人编号
	 * @param longitude 经度
	 * @param latitude  纬度
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/set" }, method = { RequestMethod.POST,RequestMethod.GET })
	public MyResponseBody set(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "memberId") Long memberId,
							  @RequestParam(value = "longitude", required = false) Double longitude,
							  @RequestParam(value = "latitude", required = false) Double latitude,
							  @RequestParam(value = "address", required = false) String address,
							  @RequestParam(value = "radius", required = false) Double radius,
							  @RequestParam(value = "railName", required = false) String railName,
							  @RequestParam(value = "weekTime", required = false) String weekTime,
							  @RequestParam(value = "startHours", required = false) String startHours,
							  @RequestParam(value = "endHours", required = false) String endHours,
							  @RequestHeader(value = "client_id",required = false) String clientId) {
		//String clientId = request.getHeader(AppDetails.CLIENT_ID);
		
		/*Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, holderId);
		if(monitor == null){
			return fail("sys.illegality.operation");
		}*/
		
		//Holder holder = holderRepository.findOne(holderId);
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		
		String deviceType = holder.getDevice().getDeviceType();
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(deviceType)) {
			List<Barrier> barrierList = barrierRepository.findByHolderId(holderId);
			if (barrierList.size() >= 5) {
				return fail(MyHttpStatus._300_BARRIER_NOT_ADD);
			}
		}
		//国内doki坐标转换 由于APP端和设备端使用的地图不一致，标准不一致。APP端使用高德地图
		if (AppDetails.WXB_DOKI_CLIENT_IDS.contains(clientId)) {
			double[] location = CoordinateConvert.bd092GCJ(latitude, longitude);
			latitude = location[0];
			longitude = location[1];
		}
		
		Barrier barrier = new Barrier(holder, address, longitude, latitude,radius,new Member(memberId),1);
		barrier.setRailName(railName);
		barrier.setWeekTime(CommonUtils.getConvertWeek(clientId,weekTime));
		barrier.setStartHours(startHours);
		barrier.setEndHours(endHours);
		barrierRepository.save(barrier);
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(deviceType)) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_UPDATE_BARRIER + ""));
		}
		return success(barrier.getId());
	}
	/**
	 * 更新围栏
	 * @param holderId  持有人编号
	 * @param longitude 经度
	 * @param latitude  纬度
	 */
	@DataPermission(value = DataPermissionType.BARRIER_ADMIN)
	@RequestMapping(value = { "/update" }, method = { RequestMethod.POST,RequestMethod.GET })
	public MyResponseBody update(@RequestParam(value = "barrierId") Long barrierId,
								 @RequestParam(value = "longitude", required = false) Double longitude,
								 @RequestParam(value = "latitude", required = false) Double latitude,
								 @RequestParam(value = "address", required = false) String address,
								 @RequestParam(value = "radius", required = false) Double radius,
								 @RequestParam(value = "railName", required = false) String railName,
								 @RequestParam(value = "weekTime", required = false) String weekTime,
								 @RequestParam(value = "startHours", required = false) String startHours,
								 @RequestParam(value = "endHours", required = false) String endHours,
								 @RequestHeader(value = "client_id",required = false) String clientId){
		//String clientId = request.getHeader(AppDetails.CLIENT_ID);
		
		Barrier barrier = barrierRepository.findOne(barrierId);
		if (barrier == null) {
			return fail(MyHttpStatus._404);
		}
		//国内doki坐标转换
		if (AppDetails.WXB_DOKI_CLIENT_IDS.contains(clientId)) {
			double[] location = CoordinateConvert.bd092GCJ(latitude, longitude);
			latitude = location[0];
			longitude = location[1];
		}
		
		barrier.setLatitude(latitude);
		barrier.setLongitude(longitude);
		barrier.setRadius(radius);
		barrier.setAddress(address);
		barrier.setRailName(railName);
		barrier.setWeekTime(CommonUtils.getConvertWeek(clientId,weekTime));
		barrier.setStartHours(startHours);
		barrier.setEndHours(endHours);
		
		barrierRepository.save(barrier);
		
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(barrier.getHolder().getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(barrier.getHolder().getImei(), Push.K3_DEVICE_UPDATE_BARRIER + ""));
		}
		return success(barrier.getId());
	}
	
	/**
	 * 删除围栏
	 * @param holderId   持有人编号
	 * @param barrierId  围栏编号
	 */
	@DataPermission(value = DataPermissionType.BARRIER_ADMIN)
	@RequestMapping(value = { "/delete" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody delete(//@RequestParam(value = "holderId") Long holderId,
								 //@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "barrierId") Long barrierId) {
		
		/*Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, holderId);
		if(monitor == null){
			return fail("sys.illegality.operation");
		}*/
		
		/*Barrier barrier = barrierRepository.findOne(barrierId);
		if(barrier.getHolder() == null || !holderId.equals(barrier.getHolder().getId())){//注意此处是Long对象
			return fail("sys.illegality.operation");
		}*/
		Barrier barrier = barrierRepository.findOne(barrierId);
		if (barrier == null) {
			return fail(MyHttpStatus._404);
		}
		barrierRepository.delete(barrierId);
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(barrier.getHolder().getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(barrier.getHolder().getImei(), Push.K3_DEVICE_UPDATE_BARRIER + ""));
		}
		return success();
	}
	
	
	/**
	 * 开启围栏(是否使用？？)
	 * @param holderId   持有人编号
	 * @param barrierId  围栏编号
	 */
	@Deprecated
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/open" }, method = { RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody open(@RequestParam(value = "holderId") Long holderId,
			  				   @RequestParam(value = "barrierId") Long barrierId) {
		barrierService.open(holderId, barrierId);
		return success();
	}
	
	/**
	 * 开启围栏
	 * @param holderId   持有人编号
	 * @param barrierId  围栏编号
	 * @param open 1:开启； 0:未开启
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/operate" }, method = { RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody operate(@RequestParam(value = "holderId") Long holderId,
								  @RequestParam(value = "barrierId") Long barrierId,
								  @RequestParam(value = "open") int open) {
		Barrier barrier = barrierRepository.findOne(barrierId);
		if (barrier == null) {
			return fail(MyHttpStatus._404);
		}
		
		barrierRepository.setOpenFor(open, holderId, barrierId);
		
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(barrier.getHolder().getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(barrier.getHolder().getImei(), Push.K3_DEVICE_UPDATE_BARRIER + ""));
		}
		return success();
	}
	
	/**
	 * 围栏列表
	 * @param holderId	持有人编号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody list(@RequestParam(value = "holderId") Long holderId,
							   @RequestParam(value = "memberId") Long memberId,
							   @RequestHeader(value = "client_id",required = false) String clientId) {
		Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, holderId);
		if(monitor == null){
			return fail("sys.illegality.operation");
		}
		
		List<Barrier> barrierList = barrierRepository.findByHolderId(holderId);
		
		HolderBarrierDtoBuilder builder = new HolderBarrierDtoBuilder();
		List<HolderBarrierDto> dtoList = builder.build(barrierList,monitor,clientId);
		
		return success(dtoList);
	}

}
