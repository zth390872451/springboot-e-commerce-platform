package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.HolderSchedule;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ZHL on 2017-10-13.
 */
public class HolderScheduleVolumeTimeDtoBuilder {

    public static List<HolderScheduleVolumeTimeDto> build(List<HolderSchedule> holderScheduleList, Long holderId) {

       List<HolderScheduleVolumeTimeDto>  dtoList = new ArrayList<>();
        for (HolderSchedule holderSchedule : holderScheduleList) {
            HolderScheduleVolumeTimeDto dto=new HolderScheduleVolumeTimeDto();
            dto.setHolderId(holderId);
            dto.setId(holderSchedule.getId());
            String startTime = holderSchedule.getAmSec().substring(0, 5);
            String endTime = holderSchedule.getAmSec().substring(6, 11);
            dto.setStartTime(startTime);
            dto.setEndTime(endTime);
            dto.setRepeatExpression(holderSchedule.getRepeatExpression());
            dto.setStatus(holderSchedule.getStatus());
            dto.setVolumeNum(holderSchedule.getVolumeNum());
            dtoList.add(dto);
        }
        return dtoList;
    }
}
