package com.umeox.babywei.appapi.web.rest;

import java.io.*;

import sun.misc.*;

import javax.crypto.*;

import java.security.*;
import java.util.UUID;

import javax.crypto.spec.*;

/**
 * funpark公司提供的加密工具类
 */
public class AESTool {

	static String k = "0e593a458fd04d81807692ee91";

	public static String getencrypt(String p) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException  {
		//加密
		String encrypted = "";
		KeyGenerator kgen = KeyGenerator.getInstance("AES");
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
		random.setSeed(k.getBytes());
		kgen.init(128, random);
		SecretKey skey = kgen.generateKey();
		byte[] raw = skey.getEncoded();
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypt = cipher.doFinal(p.getBytes("UTF-8"));
		//直接將密文由byte轉成16進位碼
		encrypted = parseByte2HexStr(encrypt);
		return encrypted; // return 密文
	}

	public static String getdecrypt(String en) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException  {
		String decrypted = "";
		//直接將密文由16進位碼轉成byte
		byte[] b = parseHexStr2Byte(en);

		//解密
		KeyGenerator kgen2 = KeyGenerator.getInstance("AES");
		SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
		random.setSeed(k.getBytes());
		kgen2.init(128, random);
		SecretKey skey2 = kgen2.generateKey();
		byte[] raw2 = skey2.getEncoded();
		SecretKeySpec skeySpec2 = new SecretKeySpec(raw2, "AES");
		Cipher cipher2 = Cipher.getInstance("AES");
		cipher2.init(Cipher.DECRYPT_MODE, skeySpec2);
		byte[] decrypt = cipher2.doFinal(b);

		decrypted = new String(decrypt,"UTF-8");

		return decrypted;
	}

	/**将二进制转换成16进制
	 * @param buf
	 * @return
	 */
	public static String parseByte2HexStr(byte buf[]) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < buf.length; i++) {
			String hex = Integer.toHexString(buf[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			sb.append(hex.toUpperCase());
		}
		return sb.toString();
	}

	/**将16进制转换为二进制
	 * @param hexStr
	 * @return
	 */
	public static byte[] parseHexStr2Byte(String hexStr) {
		if (hexStr.length() < 1)
			return null;
		byte[] result = new byte[hexStr.length()/2];
		for (int i = 0;i< hexStr.length()/2; i++) {
			int high = Integer.parseInt(hexStr.substring(i*2, i*2+1), 16);
			int low = Integer.parseInt(hexStr.substring(i*2+1, i*2+2), 16);
			result[i] = (byte) (high * 16 + low);
		}
		return result;
	}



	/*public static void main(String[] args) throws Exception{

		String plain = "390872451@qq.com0A80E187817F20DA766F2B1A47DE53EE76801150192712800";
		System.out.println("原文 - " +plain);
		// 加密
		String en = getencrypt(plain);
		String encryptd = new String(en);

		System.out.println("\n密文:" + encryptd);

		// 解密
		String de = getdecrypt(encryptd);
		String decryptd = new String(de);
		System.out.println("\n明文:" + decryptd);

	}*/


}
