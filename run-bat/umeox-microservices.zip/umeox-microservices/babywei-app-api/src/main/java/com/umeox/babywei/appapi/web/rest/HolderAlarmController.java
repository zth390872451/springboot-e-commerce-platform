package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderAlarmDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderAlarmDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderAlarm;
import com.umeox.babywei.repository.HolderAlarmRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.service.HolderAlarmService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * @Desc 闹钟
 * @author umeox
 * @version II
 */
@RestController
@RequestMapping("/api/holderAlarm")
public class HolderAlarmController {

	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private HolderAlarmRepository holderAlarmRepository;
	@Autowired
	private HolderAlarmService holderAlarmService;
	@Autowired
	private RedisQueueService redisQueueService;
	
	/**
	 * 添加闹钟
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public MyResponseBody create(@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "holderId") Long holderId,
								 @RequestParam(value = "alarmName") String alarmName,
								 @RequestParam(value = "alarmTime", required = false) Long alarmTime,
								 @RequestParam(value = "alarmTimeStr", required = false) String alarmTimeStr,
								 @RequestParam(value = "repeatFlag") Integer repeatFlag,
								 @RequestParam(value = "repeatExpression", required = false) String repeatExpression,
								 @RequestParam(value = "status") Boolean status,
								 @RequestParam(value = "ringType",required = false,defaultValue = "0") Integer ringType,
								 @RequestParam(value = "icon",required = false,defaultValue = "0") String icon){

		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		
		HolderAlarm holderAlarm = new HolderAlarm();
		holderAlarm.setHolder(holder);
		holderAlarm.setAlarmName(alarmName);
		holderAlarm.setAlarmTime(alarmTime);
		if (!StringUtils.isEmpty(alarmTimeStr) && alarmTimeStr.length() != 5) {
			return fail(MyHttpStatus._400);
		}
		holderAlarm.setAlarmTimeStr(alarmTimeStr);
		holderAlarm.setRepeatFlag(repeatFlag);
		holderAlarm.setRepeatExpression(repeatExpression);
		holderAlarm.setStatus(status);
		holderAlarm.setRingType(ringType);
		holderAlarm.setIcon(icon);
		HolderAlarm alarm = holderAlarmService.save(holderAlarm);
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(),Push.K3_DEVICE_ALARM + ""));
		} else {			
			redisQueueService.k2HandleMark(new Mark(holderAlarm.getHolder().getId(),RedisCommand.CMD_ALARM));
		}
		
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("alarmId", alarm.getId());
		
		return success(map);
	}
	
	/**
	 * 修改闹钟
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public MyResponseBody update(@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "holderId") Long holderId,
								 @RequestParam(value = "alarmId") Long alarmId,
								 @RequestParam(value = "alarmName") String alarmName,
								 @RequestParam(value = "alarmTime", required = false) Long alarmTime,
								 @RequestParam(value = "alarmTimeStr", required = false) String alarmTimeStr,
								 @RequestParam(value = "repeatFlag") Integer repeatFlag,
								 @RequestParam(value = "repeatExpression", required = false) String repeatExpression,
								 @RequestParam(value = "status") Boolean status,
								 @RequestParam(value = "ringType",required = false,defaultValue = "0") Integer ringType,
								 @RequestParam(value = "icon",required = false,defaultValue = "0") String icon){
		HolderAlarm holderAlarm = holderAlarmRepository.findOne(alarmId);
		if (holderAlarm == null || !holderAlarm.getHolder().getId().equals(holderId)) {
			return fail(MyHttpStatus._404);
		}
		holderAlarm.setAlarmName(alarmName);
		holderAlarm.setAlarmTime(alarmTime);
		if (!StringUtils.isEmpty(alarmTimeStr) && alarmTimeStr.length() != 5) {
			return fail(MyHttpStatus._400);
		}
		holderAlarm.setAlarmTimeStr(alarmTimeStr);
		holderAlarm.setRepeatFlag(repeatFlag);
		holderAlarm.setRepeatExpression(repeatExpression);
		holderAlarm.setStatus(status);
		holderAlarm.setRingType(ringType);
		holderAlarm.setIcon(icon);
		holderAlarmService.save(holderAlarm);
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holderAlarm.getHolder().getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holderAlarm.getHolder().getImei(),Push.K3_DEVICE_ALARM + ""));
		}else {			
			redisQueueService.k2HandleMark(new Mark(holderAlarm.getHolder().getId(),RedisCommand.CMD_ALARM));
		}
		
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("alarmId", holderAlarm.getId());
		
		return success(map);
	}
	
	/**
	 * 删除闹钟
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public MyResponseBody delete(@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "holderId") Long holderId,
								 @RequestParam(value = "alarmId") Long alarmId){
		HolderAlarm holderAlarm = holderAlarmRepository.findOne(alarmId);
		if (holderAlarm == null || !holderAlarm.getHolder().getId().equals(holderId)) {
			return fail(MyHttpStatus._404);
		}
		holderAlarmService.delete(holderAlarm);
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holderAlarm.getHolder().getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holderAlarm.getHolder().getImei(),Push.K3_DEVICE_ALARM + ""));
		}else {				
			redisQueueService.k2HandleMark(new Mark(holderAlarm.getHolder().getId(),RedisCommand.CMD_ALARM));
		}
		return success();
	}
	
	/**
	 * 列表
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
							   @RequestParam(value = "holderId") Long holderId){
		List<HolderAlarm> list = holderAlarmRepository.findByHolderIdOrderByAlarmTimeStrAsc(holderId);
		List<HolderAlarmDto> repoList = HolderAlarmDtoBuilder.build(list);
		return success(repoList);
	}
	
	/**
	 * 开/关设置
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/updateStatus", method = RequestMethod.POST)
	public MyResponseBody updateStatus(@RequestParam(value = "memberId") Long memberId,
			 						   @RequestParam(value = "holderId") Long holderId,
		 							   @RequestParam(value = "alarmId") Long alarmId,
		 							   @RequestParam(value = "status") Boolean status){
		HolderAlarm holderAlarm = holderAlarmRepository.findOne(alarmId);
		if (holderAlarm == null || !holderAlarm.getHolder().getId().equals(holderId)) {
			return fail(MyHttpStatus._404);
		}
		holderAlarm.setStatus(status);
		holderAlarmService.save(holderAlarm);
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holderAlarm.getHolder().getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holderAlarm.getHolder().getImei(),Push.K3_DEVICE_ALARM + ""));
		}else {	
			redisQueueService.k2HandleMark(new Mark(holderAlarm.getHolder().getId(),RedisCommand.CMD_ALARM));
		}
		return success();
	}
}
