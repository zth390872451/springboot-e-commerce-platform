package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.ImRelationDto;
import com.umeox.babywei.appapi.web.rest.dto.ImRelationDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.ImRelation;
import com.umeox.babywei.repository.FamilyNumberRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.ImRelationRepository;
import com.umeox.babywei.service.FamilyNumberService;
import com.umeox.babywei.service.ImRelationService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;

/**
 * @Desc 手表好友
 * @author umeox
 * @version II
 */
@RestController
@RequestMapping("/api/im")
public class ImRelationController {
	
	@Autowired
	private FamilyNumberService familyNumberService;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private FamilyNumberRepository familyNumberRepository;
	@Autowired
	private ImRelationService ImRelationService;
	@Autowired
	private ImRelationRepository imRelationRepository;
	@Autowired
	private RedisQueueService redisQueueService;
	
	/**
	 * 获取设备好友
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/friend/list",method = {RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
								@RequestParam(value = "holderId") Long holderId,
								@RequestParam(value = "friendType", required = false) Integer friendType){
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		List<ImRelation> imRelationList = ImRelationService.findDeviceFriendByUserId(holder.getImei());
		List<ImRelationDto> respList = ImRelationDtoBuilder.build(imRelationList);
		return success(respList);
	}
	
	/**
	 * 修改设备好友信息
	 */
	@DataPermission(value = DataPermissionType.IMEI_ADMIN)
	@RequestMapping(value = "/friend/update",method = RequestMethod.POST)
	public MyResponseBody update(@RequestParam(value = "imUserID") String imUserID,
									@RequestParam(value = "imFriendID") String imFriendID,
									@RequestParam(value = "nick") String nick,
									@RequestParam(value = "photoFlag") Integer photoFlag){
		Holder userHolder = holderRepository.findFirstByImei(imUserID);
		Holder friendHolder = holderRepository.findFirstByImei(imFriendID);
		if (userHolder == null || friendHolder == null) {
			return fail(MyHttpStatus._404);
		}
		
		FamilyNumber familyNumber = familyNumberRepository.findOneByMobileAndHolderId(friendHolder.getSim(), userHolder.getId());
		if (familyNumber == null) {
			return fail(MyHttpStatus._404);
		}
		
		familyNumber.setName(nick);
		familyNumber.setPhotoFlag(photoFlag.toString());
		List<Mark> markList = ImRelationService.update(userHolder, friendHolder, familyNumber);
		
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(userHolder.getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(imUserID,(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {
			redisQueueService.k2HandleMarkList(markList);
		}
		
		
		return success();
	}
	
	/**
	 * 删除设备好友
	 */
	@DataPermission(value = DataPermissionType.IMEI_ADMIN)
	@RequestMapping(value = "/friend/delete",method = RequestMethod.POST)
	public MyResponseBody delete(@RequestParam(value = "imUserID") String imUserID,
								 @RequestParam(value = "imFriendID") String imFriendID){
		Holder userHolder = holderRepository.findFirstByImei(imUserID);
		Holder friendHolder = holderRepository.findFirstByImei(imFriendID);
		if (userHolder == null || friendHolder == null) {
			return fail(MyHttpStatus._404);
		}
		List<Mark> markList = ImRelationService.deleteRelation(userHolder, friendHolder);
		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(userHolder.getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(imUserID,(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(imFriendID,(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {
			redisQueueService.k2HandleMarkList(markList);
		}
		return success();
	}
}
