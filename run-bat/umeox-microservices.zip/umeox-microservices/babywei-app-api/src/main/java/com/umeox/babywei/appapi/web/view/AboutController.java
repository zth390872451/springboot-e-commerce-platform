package com.umeox.babywei.appapi.web.view;

import com.umeox.babywei.ApplicationSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.umeox.babywei.domain.About;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.repository.AboutRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.service.I18nService;

@Controller
@RequestMapping("/api/about")
public class AboutController {
	
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private AboutRepository aboutRepository;
	@Autowired
	private I18nService i18nService;

	@RequestMapping("/gotoPage")
	public String gotoPage(@RequestParam(value = "holderId", required = false) Long holderId,
						   @RequestParam(value = "lang", required = false) String lang,
						   @RequestParam(value = "type") Integer type){
		String url = null;
		if (About.statementType == type) {//注册
			String value = i18nService.findByLocaleAndKey(lang, "about.statement.url");
			url = value != null ? value : ApplicationSupport.getParamVal("about.url.statementDefault");
		}else {
			About about = null;
			if (!StringUtils.isEmpty(holderId)) {
				Holder holder = holderRepository.findOne(holderId);
				if (holder != null) {
					about = aboutRepository.findOneBySaleChannel(holder.getDevice().getSaleChannel());
				}
			}
			
			if (about != null) {
				if (About.websiteType == type) {
					url = about.getWebsiteUrl() != null ? about.getWebsiteUrl() : ApplicationSupport.getParamVal("about.url.websiteDefault");
				}else if (About.facebookType == type) {
					url = about.getFacebookUrl() != null ? about.getFacebookUrl() : ApplicationSupport.getParamVal("about.url.facebookDefault");
				}else if (About.faqType == type) {
					url = about.getFaqUrl() != null ? about.getFaqUrl() : ApplicationSupport.getParamVal("about.url.faqDefault");
				}else if (About.licenseType == type) {
					url = about.getLicense() != null ? about.getLicense() : ApplicationSupport.getParamVal("about.url.licenseDefault");
				}
			} else {
				if (About.websiteType == type) {
					url = ApplicationSupport.getParamVal("about.url.websiteDefault");
				}else if (About.facebookType == type) {
					url = ApplicationSupport.getParamVal("about.url.facebookDefault");
				}else if (About.faqType == type) {
					url = ApplicationSupport.getParamVal("about.url.faqDefault");
				}else if (About.licenseType == type) {
					url = ApplicationSupport.getParamVal("about.url.licenseDefault");
				}
			}
		}
		return "redirect:"+url;
	}
}
