package com.umeox.babywei.appapi.web.rest;


import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderClassSchedule;
import com.umeox.babywei.repository.HolderClassScheduleRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


/**
 * 课程表接口
 *
 */
@RestController
@RequestMapping( { "/api/holderClassSchedule" })
public class HolderClassScheduleController {
	
	@Autowired
	private HolderClassScheduleRepository holderClassScheduleRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private RedisQueueService redisQueueService;
	/**
	 * 设定课程表
	 * @param holderId  持有人编号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/set" }, method = { RequestMethod.POST})	
	public MyResponseBody set(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "w1") String w1,
							  @RequestParam(value = "w2") String w2,
							  @RequestParam(value = "w3") String w3,
							  @RequestParam(value = "w4") String w4,
							  @RequestParam(value = "w5") String w5) {
		HolderClassSchedule holderClassSchedule = holderClassScheduleRepository.findOneByHolderId(holderId);
		if (holderClassSchedule ==null){
			Holder holder = holderRepository.findOne(holderId);
			if (holder == null) {
				return fail(MyHttpStatus._400);
			}
			holderClassSchedule = new HolderClassSchedule(holder,w1,w2,w3,w4,w5);
		}else {
			holderClassSchedule.setW1(w1);
			holderClassSchedule.setW2(w2);
			holderClassSchedule.setW3(w3);
			holderClassSchedule.setW4(w4);
			holderClassSchedule.setW5(w5);
		}
		holderClassScheduleRepository.save(holderClassSchedule);
		redisQueueService.k2HandleMark(new Mark(holderId, RedisCommand.CMD_CLASS_SCHEDULE));
		return success();
	}
	/**
	 * 获取课程表
	 * @param holderId  持有人编号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = {RequestMethod.GET })
	public MyResponseBody list(@RequestParam(value = "holderId") Long holderId){
		HolderClassSchedule holderClassSchedule = holderClassScheduleRepository.findOneByHolderId(holderId);
		Map<Object,Object> result = new HashMap<Object, Object>();
		String[] nullList = {"","","","", "","","",""};
		if (holderClassSchedule ==null){
			result.put("w1",nullList);
			result.put("w2",nullList);
			result.put("w3",nullList);
			result.put("w4",nullList);
			result.put("w5",nullList);
		}
		else {
			result.put("w1",JsonUtils.toObject(holderClassSchedule.getW1(),List.class));
			result.put("w2",JsonUtils.toObject(holderClassSchedule.getW2(),List.class));
			result.put("w3",JsonUtils.toObject(holderClassSchedule.getW3(),List.class));
			result.put("w4",JsonUtils.toObject(holderClassSchedule.getW4(),List.class));
			result.put("w5",JsonUtils.toObject(holderClassSchedule.getW5(),List.class));
		}
		result.put("holderId",holderId);
		result.put("courseList", HolderClassSchedule.courseList);
		return success(result);
	}

}
