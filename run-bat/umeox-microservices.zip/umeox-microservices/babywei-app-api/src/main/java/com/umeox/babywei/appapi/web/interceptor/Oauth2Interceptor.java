package com.umeox.babywei.appapi.web.interceptor;

import com.alibaba.druid.pool.DruidDataSource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.bean.Oauth2;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.repository.*;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.MyHttpServlet;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.util.Oauth2Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

public class Oauth2Interceptor implements HandlerInterceptor {

    private static RedisService redisService = (RedisService) ApplicationSupport.getBean("redisServiceImpl");
    private static DruidDataSource dataSource = (DruidDataSource) ApplicationSupport.getBean("druidDataSource");
    private static MonitorRepository monitorRepository = (MonitorRepository) ApplicationSupport.getBean("monitorRepository");
    private static BarrierRepository barrierRepository = (BarrierRepository) ApplicationSupport.getBean("barrierRepository");
    private static FamilyNumberRepository familyNumberRepository = (FamilyNumberRepository) ApplicationSupport.getBean("familyNumberRepository");
    private static LogMessageRepository logMessageRepository = (LogMessageRepository) ApplicationSupport.getBean("logMessageRepository");
    private static HolderRepository holderRepository = (HolderRepository) ApplicationSupport.getBean("holderRepository");
    private static MemberRepository memberRepository = (MemberRepository) ApplicationSupport.getBean("memberRepository");

    public static final String INNER_INVOKE = "1h38qg5uoxfhze4rdsn58c2s49tn465a";

    private static final Logger log = LoggerFactory.getLogger(Oauth2Interceptor.class);
    private static PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    private static RedisConnectionFactory redisConnectionFactory = (RedisConnectionFactory) ApplicationSupport.getBean("redisConnectionFactory");
    ;

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {
        String version = request.getHeader("version");
        String authorization = request.getHeader("Authorization");
        String client_id = request.getHeader("client_id");
        String clienst_id = request.getHeader("clienst_id");//为了支持iOS"client_id"拼写错误
        String lang = request.getHeader("lang");
        String timezone = request.getHeader("timezone");
        boolean resultStatus = true;

        String appMemberIdStr = request.getParameter("memberId");
        Long memberId = !StringUtils.isEmpty(appMemberIdStr) ? Long.parseLong(appMemberIdStr) : null;
        String holderIdStr = request.getParameter("holderId");
        Long holderId = !StringUtils.isEmpty(holderIdStr) ? Long.parseLong(holderIdStr) : null;
        Long currentMemberId = null;
        Oauth2 oauth2 = null;
        if (!StringUtils.isEmpty(client_id) || !StringUtils.isEmpty(clienst_id)) {//需要认证
            try {
                String[] tokenArr = authorization.split(" ");
                if (tokenArr.length < 2) {
                    return false;
                }
                String token = tokenArr[1];
                Map<String, Object> oauthInfo = Oauth2Utils.getOauthInfoInOauth2Client(token);
                if (oauthInfo != null && !oauthInfo.isEmpty()) {
                    if (oauthInfo.get("ConnectException")!=null){//redis连接不上的时候，就不再校验了，否则会导致用户在APP端登出
                        return true;
                    }
                    String oauthInfoToken = (String) oauthInfo.get("accessToken");
                    Boolean isExpired = (Boolean) oauthInfo.get("isExpired");

                    String userName = (String) oauthInfo.get("userName");
                    if (StringUtils.isEmpty(oauthInfoToken)) {
                        log.error("oauthInfoToken is null");
                        MyHttpServlet.response(response, MyHttpStatus._401);
                        return false;
                    } else if (isExpired) {
                        log.error("oauthInfoToken isExpired");
                        MyHttpServlet.response(response, MyHttpStatus._401_INVALID_TOKEN);
                        return false;
                    } else if (StringUtils.isEmpty(userName)) {
                        log.error("userName is null");
                        MyHttpServlet.response(response, MyHttpStatus._401_INVALID_TOKEN);
                        return false;
                    }
                    String grant_type = (String) oauthInfo.get("grant_type");
                    if (grant_type.equals("client_credentials")) {//客户端认证，不再进行权限控制【没办法获取当前Token对应的memberId，客户端认证方式不存储member信息】
                        return true;
                    }
                    Member member = memberRepository.findOneByMobile(userName);
                    if (member == null) {
                        log.error("member = null，认证信息中的userName对应的Member不存在！userName={}", userName);
                        MyHttpServlet.response(response, MyHttpStatus._401_INVALID_TOKEN);
                        return false;
                    } else {
                        currentMemberId = member.getId();
                    }
                } else {
                    log.error("http request result  oauthInfo = {}", oauthInfo);
                    MyHttpServlet.response(response, MyHttpStatus._401_INVALID_TOKEN);
                    return false;
                }

            } catch (Exception e) {
                e.printStackTrace();
                resultStatus = false;
            }
            if (!resultStatus) {
                MyHttpServlet.response(response, MyHttpStatus._401_INVALID_TOKEN);
                return false;
            }

            if (openApiHandle(request, response, handler, memberId, holderId, currentMemberId))
                return false;
            return true;
        } else {
            if (ApplicationSupport.isChinaEnv()) {
                MyHttpServlet.response(response, MyHttpStatus._401_INVALID_TOKEN);
                return false;
            }
            return true;
        }

    }

    private boolean openApiHandle(HttpServletRequest request, HttpServletResponse response, Object handler, Long memberId, Long holderId, Long currentMemberId) throws JsonProcessingException {
        String innerInvokeEncoded = request.getHeader("innerInvokeEncoded");
        if (!StringUtils.isEmpty(innerInvokeEncoded)) {// 可能是 open-api 的请求，继续 验证是否是open-api的请求
            boolean matches = passwordEncoder.matches(INNER_INVOKE, innerInvokeEncoded);
            if (matches) {//验证成功
            } else {
                log.error("签名错误,innerInvokeEncoded 匹配有误!");
                MyHttpServlet.response(response, MyHttpStatus._401);
                return true;
            }
        } else {//私有app-api则进行 权限校验
            //注解反射判断
            if (ApplicationSupport.isChinaEnv()) {
                if (!HandlerMethod(handler, memberId, holderId, currentMemberId, request)) {
                    MyHttpServlet.response(response, MyHttpStatus._401);
                    return true;
                }
            }
        }
        return false;
    }

    private boolean HandlerMethod(Object handler, Long memberId, Long holderId, Long currentMemberId, HttpServletRequest request) {
        if (handler instanceof HandlerMethod) {
            HandlerMethod hm = (HandlerMethod) handler;
            //Object target = hm.getBean();
            Class<?> clazz = hm.getBeanType();
            Method m = hm.getMethod();
            if (clazz != null && m != null) {
                boolean isClzAnnotation = clazz.isAnnotationPresent(DataPermission.class);
                boolean isMethodAnnotation = m.isAnnotationPresent(DataPermission.class);
                if (isClzAnnotation || isMethodAnnotation) {
                    DataPermission dataPermission = null;
                    //如果方法和类中同时声明这个注解，那么方法中的注解会覆盖类中的设定
                    if (isMethodAnnotation) {
                        dataPermission = m.getAnnotation(DataPermission.class);
                    } else if (isClzAnnotation) {
                        dataPermission = clazz.getAnnotation(DataPermission.class);
                    }
                    DataPermissionType type = dataPermission.value();
                    if (DataPermissionType.HOLDER_FOLLOWER.equals(type)) {
                        //存在id参数替代holderId的情形
                        if (holderId == null) {
                            String idStr = request.getParameter("id");
                            if (idStr != null) {
                                holderId = Long.parseLong(idStr);
                            }
                        }
                        if (holderId == null) {
                            return false;
                        }
                        if (!isFollower(currentMemberId, holderId)) {
                            return false;
                        }

                    } else if (DataPermissionType.HOLDER_ADMIN.equals(type)) {
                        if (holderId == null) {
                            return false;
                        }
                        if (!isAdmin(currentMemberId, holderId)) {
                            return false;
                        }
                    } else if (DataPermissionType.BARRIER_ADMIN.equals(type)) {
                        String barrierIdStr = request.getParameter("barrierId");
                        if (barrierIdStr == null) {
                            return false;
                        }
                        Long barrierId = Long.parseLong(barrierIdStr);
                        Barrier barrier = barrierRepository.findOne(barrierId);
                        if (barrier == null) {
                            return false;
                        }
                        if (!isAdmin(currentMemberId, barrier.getHolder().getId())) {
                            return false;
                        }
                    } else if (DataPermissionType.CHAT_FOLLOWER.equals(type)) {
                        String appTypeStr = request.getParameter("type");
                        if (appTypeStr == null) {
                            return false;
                        }
                        Integer appType = Integer.parseInt(appTypeStr);
                        String friendId = request.getParameter("friendId");//holderId or 'gf'+holderId
                        if (!appType.equals(AppDetails.FRIEND_TYPE)) {
                            friendId = friendId.substring(2);
                        }
                        if (!isFollower(currentMemberId, Long.parseLong(friendId))) {
                            return false;
                        }
                    } else if (DataPermissionType.FAMILYNUMBER_ADMIN.equals(type)) {
                        String familyNumberIdStr = request.getParameter("familyNumberId");
                        if (familyNumberIdStr == null) {
                            return false;
                        }
                        Long familyNumberId = Long.parseLong(familyNumberIdStr);
                        FamilyNumber familyNumber = familyNumberRepository.findOne(familyNumberId);
                        if (familyNumber == null) {
                            return false;
                        }
                        if (!isAdmin(currentMemberId, familyNumber.getHolder().getId())) {
                            return false;
                        }
                    } else if (DataPermissionType.LOG_MESSAGE_FOLLOWER.equals(type)) {
                        String logMessageIdStr = request.getParameter("logMessageId");
                        if (logMessageIdStr == null) {
                            logMessageIdStr = request.getParameter("messageId");
                        }
                        if (logMessageIdStr == null) {
                            return false;
                        }
                        Long logMessageId = Long.parseLong(logMessageIdStr);

                        LogMessage logMessage = logMessageRepository.findOne(logMessageId);
                        if (logMessage == null) {
                            return false;
                        }
                        if (!isFollower(currentMemberId, logMessage.getHolder().getId())) {
                            return false;
                        }
                    } else if (DataPermissionType.IMEI_ADMIN.equals(type)) {
                        String imei = request.getParameter("imUserID");
                        Holder holder = holderRepository.findFirstByImei(imei);
                        if (holder == null) {
                            return false;
                        }
                        if (!isAdmin(currentMemberId, holder.getId())) {
                            return false;
                        }
                    }
                    if (memberId != null) {
                        if (!memberId.equals(currentMemberId)) {
                            return false;
                        }
                    }
                    request.setAttribute("memberId", currentMemberId);
                }

            }
        }
        return true;
    }

    private boolean isFollower(Long currentMemberId, Long holderId) {
        Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(currentMemberId, holderId);
        if (monitor == null) {
            return false;
        }
        return true;
    }

    private boolean isAdmin(Long currentMemberId, Long holderId) {
        Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndMemberIdAndHolderId(currentMemberId, holderId);
        if (monitor == null) {
            return false;
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request,
                           HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest request,
                                HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
    }

    protected static String extractTokenKey(String value) {
        if (value == null) {
            return null;
        }
        MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("MD5 algorithm not available.  Fatal (should be in the JDK).");
        }

        try {
            byte[] bytes = digest.digest(value.getBytes("UTF-8"));
            return String.format("%032x", new BigInteger(1, bytes));
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException("UTF-8 encoding not available.  Fatal (should be in the JDK).");
        }
    }
}
