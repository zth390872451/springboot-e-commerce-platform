package com.umeox.babywei.appapi.web.rest.dto;


public class MemberHoldersV3Dto {
	private Long holderId;
	private Long monitorId;
	private String name;
	private String avatar;
	private String gender;
	private String imei;
	private String bindCode;
	private String sim;
	private Integer locationMode;
	private Double latitude;
	private Double longitude;
	private Integer radius;
	private String address;
	private Long reportTime;
	private Integer electricity;
	private Boolean isAdmin;
	private Long lastActivityDate;
	/**
	 * 是否为合约机
	 * 1：是
	 * 0：不是
	 */
	private Integer flag;
	/**
	 * 实名认证状态
	 */
	private Integer realnameStatus = 0;
	
	
	public Integer getLocationMode() {
		return locationMode;
	}
	public void setLocationMode(Integer locationMode) {
		this.locationMode = locationMode;
	}
	public String getBindCode() {
		return bindCode;
	}
	public void setBindCode(String bindCode) {
		this.bindCode = bindCode;
	}
	public Long getHolderId() {
		return holderId;
	}
	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}
	public Long getMonitorId() {
		return monitorId;
	}
	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getImei() {
		return imei;
	}
	public void setImei(String imei) {
		this.imei = imei;
	}
	public String getSim() {
		return sim;
	}
	public void setSim(String sim) {
		this.sim = sim;
	}
	public Double getLatitude() {
		return latitude;
	}
	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getReportTime() {
		return reportTime;
	}
	public void setReportTime(Long reportTime) {
		this.reportTime = reportTime;
	}
	public Integer getElectricity() {
		return electricity;
	}
	public void setElectricity(Integer electricity) {
		this.electricity = electricity;
	}
	public Boolean getIsAdmin() {
		return isAdmin;
	}
	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	public Long getLastActivityDate() {
		return lastActivityDate;
	}
	public void setLastActivityDate(Long lastActivityDate) {
		this.lastActivityDate = lastActivityDate;
	}
	public Integer getRadius() {
		return radius;
	}
	public void setRadius(Integer radius) {
		this.radius = radius;
	}
	public Integer getFlag() {
		return flag;
	}
	public void setFlag(Integer flag) {
		this.flag = flag;
	}
	public Integer getRealnameStatus() {
		return realnameStatus;
	}
	public void setRealnameStatus(Integer realnameStatus) {
		this.realnameStatus = realnameStatus;
	}

	@Override
	public String toString() {
		return "MemberHoldersV3Dto{" +
				"holderId=" + holderId +
				", monitorId=" + monitorId +
				", name='" + name + '\'' +
				", avatar='" + avatar + '\'' +
				", gender='" + gender + '\'' +
				", imei='" + imei + '\'' +
				", bindCode='" + bindCode + '\'' +
				", sim='" + sim + '\'' +
				", locationMode=" + locationMode +
				", latitude=" + latitude +
				", longitude=" + longitude +
				", radius=" + radius +
				", address='" + address + '\'' +
				", reportTime=" + reportTime +
				", electricity=" + electricity +
				", isAdmin=" + isAdmin +
				", lastActivityDate=" + lastActivityDate +
				", flag=" + flag +
				", realnameStatus=" + realnameStatus +
				'}';
	}
}
