package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.ApiLimit;
import com.umeox.babywei.bean.SmsType;
import com.umeox.babywei.conf.Constants;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.IhuyiSms;
import com.umeox.babywei.support.KinglangSms;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.signature.Signature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

import java.util.HashMap;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * 短信控制器
 *
 * @author jiangtao
 * @since 2017-08-28
 */
@RestController
@RequestMapping({"/api/sms"})
public class SmsController {
    private static final Logger LOGGER = LoggerFactory.getLogger(SmsController.class);
    @Autowired
    private MemberRepository memberRepository;

    @Autowired
    private RedisService redisService;

    private static final Map<String,String> signClientSecretMap =  new HashMap<>();
    static {
        signClientSecretMap.put("wxb_api_android","0693691e83e17f1b8bfb437c98d136a6");//卫小宝 Android
        signClientSecretMap.put("wxb_api_ios","268ba12224ba0ffa022c87b1b982fbe8"); //卫小宝 iOS
        signClientSecretMap.put("wxb_doki_api_ios","d6aa439cd5ba201a19fb4363579df54f"); //卫小宝Doki iOS
        signClientSecretMap.put("wxb_doki_api_android","d6aa439cd5ba201a19fb4363579df54f"); //卫小宝Doki Android
        signClientSecretMap.put("watch_kidwatch_api_ios","1szhfhzltexipwgulzranqybrlgnh5i2"); //卫小宝小超人iOS
        signClientSecretMap.put("watch_kidwatch_api_android","1szhfhzltexipwgulzranqybrlgnh5i2");//卫小宝小超人Android
        signClientSecretMap.put("wherecom_api_ios","e4eeff1ef2443e799863be62d5b8f1bb");//Fix: 因卫小宝iOS版第一次注册时使用Wherecom Client
        signClientSecretMap.put("umeox_babywei_app_api","k2appabc7893d34");//Fix: 因卫小宝Android版还会存在老的Client ID
    }

    @RequestMapping(value = {"/sendSms"}, method = {RequestMethod.GET})
    @ApiLimit(times_max = 3, suffixKeyFrom = "mobile", timeToLive = 3600, limitLevel = ApiLimit.LimitLevel.USER_LEVEL)
    public MyResponseBody sendSms(@RequestParam(value = "mobile") String mobile,
                                  @RequestParam(value = "type") int type,
                                  HttpServletRequest request) {
        String client_id = request.getHeader("client_id");
        String timestamp = request.getHeader("timestamp");
        String method = request.getMethod();
        String sign = request.getParameter("sign");
        LOGGER.info("请求参数,client_id:{},method:{},timestamp:{},sign:{},mobile:{},type:{}", client_id, method, timestamp, sign, mobile, type);
        if (client_id == null || sign == null || timestamp == null) {
            LOGGER.info("非法请求参数");
            return fail(MyHttpStatus._400);
        }

        //Fix: 卫小宝iOS APP 首次安装后，调用短信请求头Client ID是错误： wherecom_api_ios , 但短信签名中使用的client ID 却是正确的: wxb_api_ios
        if(client_id.equals("wherecom_api_ios")) {
            client_id = "wxb_api_ios";
        }

        String secret = signClientSecretMap.get(client_id);
        if (secret == null) {
            LOGGER.info("非法请求参数: client id 不正确");
            return fail(MyHttpStatus._400);
        }

        String serverSign = Signature.newBuilder()
                .method(method)
                .secret(secret)
                .parameter("client_id", client_id)
                .parameter("timestamp", timestamp)
                .parameter("mobile", mobile)
                .parameter("type", type + "")
                .build()
                .get();

        if (!sign.equals(serverSign)) {
            LOGGER.info("非法签名,服务端签名为:{}", serverSign);
            return fail(MyHttpStatus._401_ILLEGALITY);
        }

        Member member = memberRepository.findOneByMobile(mobile);
        if (type == 0 && member != null) {
            return fail(MyHttpStatus._20001);
        }

        String key = mobile + "-" + SmsType.values()[type].name();
        String code = redisService.getCode(key);

        String content = "";

        if (ApplicationSupport.isEnv(Constants.SPRING_PROFILE_PRODUCTION_CHINA_LONLIV)) {
            //使用互忆的短信接口
            if (type == 0) {
                content = String.format(ApplicationSupport.getParamVal("thirdparty.ihuyisms.regMsg"), code);
            } else if (type == 1) {
                content = String.format(ApplicationSupport.getParamVal("thirdparty.ihuyisms.findPasswordMsg"), code);
            }
            IhuyiSms.SendAndLog(mobile, content, type);
        } else {
            //使用金伦短信接口
            if (type == 0) {
                content = String.format(ApplicationSupport.getParamVal("thirdparty.kinglandsms.regMsg"), code);
            } else if (type == 1) {
                content = String.format(ApplicationSupport.getParamVal("thirdparty.kinglandsms.findPasswordMsg"), code);
            }
            String sendStatus = KinglangSms.sendSmsHttpAndSave(mobile, content, type);//调用短信接口
            if (sendStatus.equals("0")) {//发送成功
                return success();
            } else if (sendStatus.equals("1")) {//被叫连续下单限制(短信平台限制)
                return fail(MyHttpStatus._600);
            } else {
                LOGGER.error("KinglangSms error status:{}", sendStatus);
                return fail();
            }
        }
        return success();
    }

}
