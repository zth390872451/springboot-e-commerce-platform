package com.umeox.babywei.appapi.web.rest.dto;

/**
 * Created by Administrator on 2017/2/22.
 */
public class FileDto {
    private String fileId;
    private Long uploadTime;
    private String url;//原始url
    private String thumbnailUrl;//缩略图url

    public FileDto() {
    }

    public FileDto(Long uploadTime, String fileId, String url, String thumbnailUrl) {
        this.uploadTime = uploadTime;
        this.fileId = fileId;
        this.url = url;
        this.thumbnailUrl = thumbnailUrl;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Long getUploadTime() {
        return uploadTime;
    }

    public void setUploadTime(Long uploadTime) {
        this.uploadTime = uploadTime;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }
}
