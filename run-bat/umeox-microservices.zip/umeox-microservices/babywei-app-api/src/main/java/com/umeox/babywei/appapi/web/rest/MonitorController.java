package com.umeox.babywei.appapi.web.rest;


import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import com.umeox.babywei.util.RuleSupport;
import com.umeox.babywei.util.TimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderMembersDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderMembersDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.Message;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.repository.DeviceRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.MessageRepository;
import com.umeox.babywei.repository.MonitorRepository;
import com.umeox.babywei.service.AsyncRequestService;
import com.umeox.babywei.service.HolderService;
import com.umeox.babywei.service.MonitorService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.ApiResultUtil;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.StringToolUtil;


/**
 * @author umeox
 */
@RestController
@RequestMapping( { "/api/monitor" })
public class MonitorController{
	
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private MonitorService monitorService;
	@Autowired
	private MessageRepository messageRepository;
	@Autowired
	private HolderService holderService;
	@Autowired
	private DeviceRepository deviceRepository;
	@Autowired
	private AsyncRequestService asyncRequestService;
	@Autowired
	private RedisQueueService redisQueueService;
	
	/**
	 * 1. 根据持有者获取监护人列表（亲人圈子）
	 * 又名--家庭成员
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody list(@RequestParam(value = "holderId") Long holderId) {
		
		List<Monitor> monitorList = monitorRepository.findByHolderId(holderId);
		
		HolderMembersDtoBuilder builder = new HolderMembersDtoBuilder();
		List<HolderMembersDto> dtoList = builder.build(monitorList);
		
		return success(dtoList);
	}
	
	/**
	 * 2. 审核通过成为设备监护人
	 */
	@RequestMapping(value = { "/pass" }, method = { RequestMethod.POST })
	public MyResponseBody check(//@RequestParam(value = "memberId") Long memberId,
								//@RequestParam(value = "imei") String imei,
								@RequestParam(value = "messageId") Long messageId,
								HttpServletRequest request) {
		
		//Device device = deviceRepository.findOneByImei(imei);
		//Member member = memberRepository.findOne(memberId);
		//Long currentMemberId = (Long) request.getAttribute("memberId");
		Message message = messageRepository.findOne(messageId);
		//TODO 检查当前用户是否为管理员
		if (message == null || message.getType() != Push.APPLY || message.getState() != 0 
				//|| !message.getAdmin().getId().equals(currentMemberId)
				) {//是否为申请关注 || 是否已经处理 || 当前用户是否为admin
			return fail(MyHttpStatus._404);
		}
		Member member = message.getMember();
		Holder holder = message.getHolder();
		Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(member.getId(), holder.getId());
		if(monitor != null){//已关注
			return fail(MyHttpStatus._30001);
		}
		Member adminMember = message.getAdmin();
		//Holder holder = device.getHolder();
		/*Monitor admin = monitorRepository.findOneByIsAdminTrueAndHolder(holder);
		if(admin == null){//此设备已解绑了
			return fail(MyHttpStatus._404);
		}*/
		
		monitorService.pass(holder.getDevice(), member, message);
		
		//消息推送
		String body = RuleSupport.getMsgByLocale(member.getLocale(), "device.attention.admin.agree", new String[]{holder.getName()});
		/*if(ApplicationSupport.isChinaEnv()){
			boby = "已关注"+holder.getName()+"，现在可以查看他的活动情况了。";
		}else{
			boby = "You are following "+holder.getName()+"  now.";
		}*/
		Map<String,String> to = new HashMap<String,String>();
		Map<String,String> param = new HashMap<String,String>();
		to.put("monitors",member.getMobile());
		to.put(member.getMobile(), member.getToken());
		to.put(Push.KEY + member.getMobile(), StringToolUtil.toString(member.getPushType()));
		to.put(Push.CLIENT_ID+member.getMobile(), member.getClientId());
		param.put("cmd", Integer.toString(Push.ACCEPT));
		param.put("holderId", holder.getId().toString());
		asyncRequestService.post(adminMember.getMobile(), to, body, param,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
		
		return success();
	}
	
	/**
	 * 3. 被邀请人答应成为监护人(暂不使用)
	 */
	@Deprecated
	@RequestMapping(value = { "/accept" }, method = { RequestMethod.POST })
	public MyResponseBody accept(@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "imei") String imei,
								 @RequestParam(value = "messageId") Long messageId) {
		
		Device device = deviceRepository.findOneByImei(imei);
		Member member = memberRepository.findOne(memberId);
		Message message = messageRepository.findOne(messageId);
		if (device == null || member == null || message == null) {
			return fail(MyHttpStatus._404);
		}
		
		Holder holder = device.getHolder();
		Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(member.getId(), holder.getId());
		if(monitor != null) {
			return fail(MyHttpStatus._30002);
		}
		
		message.setState(1);
		monitorService.acceptPlus(device, holder, member, message);
		
		return success();
		
	}
	
	/**
	 * 3. 申请关注设备--输入imei号判断是否已有admin,如有才变为申请关注
	 *
	 */
	@DataPermission
	@RequestMapping(value = { "/apply" }, method = { RequestMethod.POST })
	public MyResponseBody apply(@RequestParam(value = "memberId") Long memberId,
								@RequestParam(value = "imei") String imei) {

		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findFirstByImei(imei);
		Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imei);//管理员
		if(member == null || holder == null || monitor == null) {//判断会员和设备是否都存在
			return fail(MyHttpStatus._404);
		}
		
		Monitor pesisent = monitorRepository.findFirstByMemberIdAndHolderId(member.getId(), holder.getId());
		if(pesisent != null) {//判断是否已经关注 
			return fail(MyHttpStatus._30001);
		}
		
		Device tempDevice = holder.getDevice();
		if(tempDevice.getSaleChannel() != null && tempDevice.getSaleChannel().equals("10553")){
			if(!Pattern.matches("(134|135|136|137|138|139|150|151|152|158|159|182|183|184|157|187|188|147|178)\\d{8}", member.getMobile())){
				return fail(MyHttpStatus._40002);
			}
		}

		//发送信息给管理员：申请成为关注者
		Message message = new Message();
		message.setMember(member);
		message.setAdmin(monitor.getMember());
		message.setType(Push.APPLY);
		message.setHolder(holder);
		String nickName = !StringUtils.isEmpty(holder.getName())?holder.getName():imei;
		if(member.getMobile().contains("$")){//暂时不跳转 ，需要占位符
			message.setRemark(RuleSupport.getMsgByLocale(monitor.getMember().getLocale(), "device.attention.apply", new String[]{member.getMobile().replace("$", "@"), nickName}));
			//message.setRemark(ApiResultUtil.user_header_en + member.getMobile().replace("$","@") + ApiResultUtil.apply_add_en + nickName+".");
		}else {
			message.setRemark(RuleSupport.getMsgByLocale(monitor.getMember().getLocale(), "device.attention.apply", new String[]{member.getMobile(),nickName}));
			//message.setRemark(ApiResultUtil.user_header_cn+"："+member.getMobile()+" ，"+ApiResultUtil.apply_add_cn+nickName+"。");
		}
		
		Date now = new Date();
		
		//申请时间转换： 根据时区和设备所在国家
		//注意: 但是管理员同意和拒绝使用的更新时间不能自定义时区化,获取消息列表使用的申请创建时间
		//String timeZoneStr = holder.getTimeZone();
		String mcc = holder.getDevice().getMcc();
		if (!StringUtils.isEmpty(mcc)) {
			mcc = Integer.toHexString(Integer.parseInt(mcc));//十进制转十六进制
		}
		String timeZoneStr = TimeUtils.getTimezoneId(holder.getTimeZone(),mcc);
		if(!StringUtils.isEmpty(timeZoneStr)){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			//timeZoneStr = timeZoneStr.substring(timeZoneStr.indexOf('(')+1, timeZoneStr.indexOf(')'));
			sdf.setTimeZone(TimeZone.getTimeZone(timeZoneStr));
			String dateStr = sdf.format(now);
			try {
				now = sdf1.parse(dateStr);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		message.setCreateDate(now);
		message.setModifyDate(now);
		messageRepository.save(message);
		
		// 消息推送
		Member adminMember = monitor.getMember();
		Map<String, String> param = new HashMap<String, String>();
		param.put("cmd", Integer.toString(Push.APPLY));
		param.put("frmobile", member.getMobile().replace("$", "@"));
		param.put("tomobile", adminMember.getMobile().replace("$","@"));
		param.put("name", holder.getName());
		param.put("sim", holder.getSim());
		param.put("holderId",holder.getId().toString());
		param.put("messageId",message.getId().toString());
		
		Map<String,String> toParam = new HashMap<String, String>();	
		toParam.put("monitors", adminMember.getMobile());
		toParam.put(adminMember.getMobile(), adminMember.getToken());	
		toParam.put(Push.KEY+adminMember.getMobile(), StringToolUtil.toString(adminMember.getPushType()));
		toParam.put(Push.CLIENT_ID+adminMember.getMobile(), adminMember.getClientId());
		String msgbody = message.getRemark();
		if(member.getMobile().contains("$")){
			msgbody = holder.getName()+" has a new follower.";
		}
		asyncRequestService.post(member.getMobile(), toParam, msgbody, param,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
		
		return success();
	}
	
	/**
	 *
	 * 检查设备是否有管理员
	 */
	@RequestMapping(value = { "/is_admin" }, method = { RequestMethod.POST })
	public MyResponseBody isAdmin(@RequestParam(value = "imei") String imei) {
		Device device = deviceRepository.findOneByImei(imei);
		if (device != null && !device.getDeviceType().equals("1") && !device.getDeviceType().equals("2")) {
			return fail(MyHttpStatus._30004);
		}
		
		Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imei);
		if (monitor == null) {
			return fail();
		}
		return success();
	}
	
	/**
	 * 5.取消关注
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/cancelAttention" }, method = { RequestMethod.POST })
	public MyResponseBody cancelAttention(@RequestParam(value = "holderId") Long holderId,
										  @RequestParam(value = "memberId") Long memberId) {

		Monitor monitor = monitorRepository.findFirstByIsAdminFalseAndMemberIdAndHolderId(memberId, holderId);
		if(monitor == null) {
			return fail();
		}
		List<Mark> markList = monitorService.delete(monitor,monitor.getMember().getMobile());

		if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(monitor.getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(monitor.getHolder().getImei(),(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {
			redisQueueService.redisDelAttention(markList);
		}
		
		if (AppDetails.WE_TALK_DEVICE_TYPE.equals(monitor.getDeviceType())) {
			redisQueueService.insertGroupChatListForNotify(holderId, monitor.getMember().getMobile(), ApplicationSupport.getMessageByEnv("sys.left.familyGroup", new String[]{monitor.getMember().getNickName()}), System.currentTimeMillis());
			Holder holder = holderRepository.getOne(holderId);

			//推送
			Map<String, String> extras = new HashMap<String, String>();
			extras.put("cmd", Push.FOLLOWER_CANCEL + "");
			extras.put("holderId", holderId + "");
			extras.put("groupId", AppDetails.GROUP_PRE + holderId);

			asyncRequestService.pushTagMessge("家庭群组", AppDetails.GROUP_PRE + holderId,
					ApplicationSupport.getMessageByEnv("sys.left.familyGroup", new String[]{monitor.getMember().getNickName()}), extras ,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());

		}
		return success();
	}
	
	/**
	 * 5.管理员删除关注者
	 * @param holderId 持有者Id
	 * @param memberId 管理员Id
	 * @param mobile 关注人mobile--会员账号
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/admincancelAttention" }, method = { RequestMethod.POST })
	public MyResponseBody admincancelAttention(@RequestParam(value = "holderId") Long holderId,
											   @RequestParam(value = "memberId") Long memberId,
											   @RequestParam(value = "mobile") String mobile) {
		
		Member memberMobile = memberRepository.findOneByMobile(mobile);
		Holder holder = holderRepository.findOne(holderId);
		Monitor monitor = monitorRepository.findFirstByIsAdminFalseAndMemberIdAndHolderId(memberMobile.getId(), holder.getId());
		if(monitor == null) {
			return fail();
		}
		
		List<Mark> markList = monitorService.delete(monitor,mobile);
		redisQueueService.redisDelAttention(markList);
		
		//消息推送
		Member member = memberRepository.findOne(memberId);//管理员
		Map<String, String> param = new HashMap<String, String>();
		param.put("cmd", Integer.toString(Push.UNBOUND));
		param.put("frmobile", member.getMobile().replace("$", "@"));
		param.put("tomobile", mobile.replace("$","@"));
		param.put("name", holder.getName());
		param.put("sim", holder.getSim());//sim卡号
		param.put("holderId",holder.getId().toString());//设备ID
		Map<String,String> toParam = new HashMap<String, String>();	
		toParam.put("monitors", mobile);
		toParam.put(mobile, memberMobile.getToken());
		toParam.put(Push.KEY+mobile, StringToolUtil.toString(memberMobile.getPushType()));
		toParam.put(Push.CLIENT_ID+mobile, memberMobile.getClientId());
		String postBody = RuleSupport.getMsgByLocale(member.getLocale(), "device.attention.admin.cancel", new String[]{ holder.getName()});;
		/*if(ApplicationSupport.isChinaEnv()){
			postBody = "设备名称为："+holder.getName()+"的管理者(" + member.getNickName() + ")已经取消了您对该设备的关注！";
		}else{
			postBody = "The Device :"+holder.getName()+" administrator(" + member.getNickName() + ")cancel Attention about you！";
		}*/
		asyncRequestService.post(mobile, toParam, postBody, param,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
		
		return success();
	}
	
	/**
	 * 6. 邀请关注(管理员直接让用户成为设备的关注者)
	 * mobile:被邀请关注的app用户手机号码
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/invitation" }, method = { RequestMethod.POST })
	public MyResponseBody invitation(@RequestParam(value = "mobile") String mobile,
									 @RequestParam(value = "holderId") Long holderId) {
		Member member = memberRepository.findOneByMobile(mobile);
		if(member == null) {//账号是否存在
			return fail(MyHttpStatus._20002);
		}
		
		Holder holder = holderRepository.findOne(holderId);
		if(holder == null) {//持有者是否存在
			return fail(MyHttpStatus._404);
		} 
		
		Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(member.getId(), holderId);
		if(monitor != null) {//判断用户是否关注了 
			return fail(MyHttpStatus._30002);
		}

		if(holder.getDevice().getSaleChannel() != null && holder.getDevice().getSaleChannel().equals("10553")){
			if(!Pattern.matches("(134|135|136|137|138|139|150|151|152|158|159|182|183|184|157|187|188|147|178)\\d{8}", member.getMobile())){
				fail(MyHttpStatus._40003);
			}
		}
		
		Monitor admin = monitorRepository.findFirstByIsAdminTrueAndHolderImei(holder.getImei());

		monitorService.accept(holder.getDevice(), holder, member, null);
		
		// 消息推送
		Map<String, String> param = new HashMap<String, String>();
		param.put("cmd", Integer.toString(Push.INVITATION));
		param.put("frmobile", admin.getMember().getMobile().replace("$","@"));
		param.put("tomobile", member.getMobile().replace("$","@"));
		param.put("name", holder.getName());
		param.put("sim", holder.getSim());
		param.put("holderId",holder.getId().toString());

		String postBody = RuleSupport.getMsgByLocale(member.getLocale(), "device.attention.invite", new String[]{admin.getMember().getNickName(), holder.getName()});
		/*if(ApplicationSupport.isChinaEnv()){
			postBody = admin.getMember().getNickName()+"邀请你关注了"+holder.getName();
		}else{
			postBody = admin.getMember().getNickName() + " invites you attention" + holder.getName()+"'s.";
		}*/
		
		Map<String,String> toParam = new HashMap<String, String>();	
		toParam.put("monitors", member.getMobile());
		toParam.put(member.getMobile(), member.getToken());	
		toParam.put(Push.KEY + member.getMobile(), StringToolUtil.toString(member.getPushType()));
		toParam.put(Push.CLIENT_ID+member.getMobile(), member.getClientId());

		asyncRequestService.post(admin.getMember().getMobile(), toParam, postBody, param,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
		
		return success();
	}
	
	/**
	 * 3. 拒绝请求(申请关注和别人邀请关注)
	 * 目前只有管理员拒绝的情况
	 */
	@RequestMapping(value = { "/refuse" }, method = { RequestMethod.POST })
	public MyResponseBody refuse(@RequestParam(value = "messageId") Long messageId,
								 HttpServletRequest request) {
		
		Message message = messageRepository.findOne(messageId);
		//TODO 检查当前用户是管理员
		//Long currentMemberId = (Long) request.getAttribute("memberId");
		if(message == null || message.getType() != Push.APPLY || message.getState() != 0 
				//|| !message.getAdmin().getId().equals(currentMemberId)
				){
			return fail(MyHttpStatus._404);
		}
		message.setState(-1);
		messageRepository.save(message);
		
		// 推送消息
		Member member = message.getMember();
		Holder holder = message.getHolder();
		Member admin = message.getAdmin();
		
		String postBoby = RuleSupport.getMsgByLocale(member.getLocale(), "device.attention.admin.reject", new String[]{holder.getName()});;
		/*if(ApplicationSupport.isChinaEnv()){
			postBoby = "管理员拒绝您关注"+holder.getName() +"的请求。";
		}else{
			postBoby = "The administrator reject your invitation.";
		}*/
		
		String fromMobile = admin.getMobile();
		Map<String,String> to = new HashMap<String,String>();
		Map<String,String> param = new HashMap<String,String>();
		to.put("monitors",member.getMobile());
		to.put(member.getMobile(), member.getToken());
		to.put(Push.KEY + member.getMobile(), StringToolUtil.toString(member.getPushType()));
		to.put(Push.CLIENT_ID+member.getMobile(), member.getClientId());
		param.put("cmd", Integer.toString(Push.REFUSE));
		param.put("holderId", holder.getId().toString());
		asyncRequestService.post(fromMobile, to, postBoby, param,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
		
		return success();
	}
	
}
