package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.Contact;
import com.umeox.babywei.appapi.web.rest.dto.FamilyNumberDto;
import com.umeox.babywei.appapi.web.rest.dto.FamilyNumberDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.bean.MultiFile;
import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.domain.Device.Status;
import com.umeox.babywei.repository.*;
import com.umeox.babywei.service.*;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.app.PushPayload;
import com.umeox.babywei.thrift.app.ThriftAppClient;
import com.umeox.babywei.thrift.app.Wtow;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.JsonUtils;
import com.umeox.babywei.util.RuleSupport;
import com.umeox.babywei.util.StringToolUtil;
import com.umeox.babywei.util.UploadUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


/**
 * 家庭成员
 */
@RestController
@RequestMapping( {"/api/family_number","/api/familyNumber"})
public class FamilyNumberController{
	
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private FamilyNumberRepository familyNumberRepository;
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private FamilyNumberService familyNumberService;
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private AsyncRequestService asyncRequestService;
	@Autowired
	private RedisQueueService redisQueueService;
	@Autowired
	private MonitorService monitorService;
	@Autowired
	private RedisService redisService;
	@Autowired
	private MsgSettingRepository msgSettingRepository;

	
	//------------------------------卫2 start-----------------------------------------------//
	/**
	 * 添加亲情号码 持有者的管理员才能有的权限，所以 添加的都是非管理员角色
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/v2/add" }, method = { RequestMethod.POST })
	public MyResponseBody v2add(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "name") String name,
							  @RequestParam(value = "mobile",required = false) String mobile,
							  @RequestParam(value = "email",required = false) String email,
							  @RequestParam(value = "photoFlag",required = false,defaultValue = "0") Integer photoFlag,
							  @RequestParam(value = "type") Integer type,
							  MultiFile multiFile) {
		if (mobile!=null){
			mobile = mobile.replace(" ","");//将手机号码中的空格去除
		}
		//1.检查Holder是否存在
		Holder holder = holderRepository.findOne(holderId);
		if(holder == null){
			return fail("sys.holder.notexists");
		}
		
		if (!Status.REGIST.equals(holder.getDevice().getStatus())) {
			return fail(MyHttpStatus._404);//应该描述设备已解绑
		}
		
		//2.渠道编码10553只能添加对应的号码段
		String saleChannel = holder.getDevice().getSaleChannel();
		if(saleChannel != null && saleChannel.equals("10553")){
			if(!Pattern.matches("(134|135|136|137|138|139|150|151|152|158|159|182|183|184|157|187|188|147|178)\\d{8}", mobile)){
				return fail(MyHttpStatus._40004);
			}
		}	
		if (type > 1 || type < 0) {
			return fail(MyHttpStatus._400);
		}

		Member member = null;
		List<Mark> markList = new ArrayList<Mark>();
		if(ApplicationSupport.isChinaEnv()){
			if (type == FamilyNumber.TYPE_ALL) {
				member = memberRepository.findOneByMobile(mobile);
				//3.类型为0的手机号码必须为会员
				if (member == null) {
					return fail(MyHttpStatus._20002);
				}
			}
			//4.检查此号码是否已添
			FamilyNumber familyNumberPresident = familyNumberRepository.findOneByMobileAndHolderId(mobile, holderId);
			if(familyNumberPresident != null) {
				 return fail(MyHttpStatus._300_FM_ADDED);
			}
			
			FamilyNumber familyNumber = new FamilyNumber();
			if (type == FamilyNumber.TYPE_ALL) {
				//关注者类型
				familyNumber.setOrigin(FamilyNumber.ORIGIN_TYPE_FOLLOWER);
			}
			if (multiFile.getFile() != null && multiFile.getFile().getSize() > 0) {
				String filePath = UploadUtil.saveMartipartFile(null, multiFile.getFile());
				if (!StringUtils.isEmpty(filePath)) {
					familyNumber.setAvatar(filePath);
				}
			}
			familyNumber.setHolder(holder);
			familyNumber.setMobile(mobile);
			if (AppDetails.WE_TALK_DEVICE_TYPE.equals(holder.getDevice().getDeviceType())) {
				familyNumber.setName(member.getNickName());
			}else {
				familyNumber.setName(name);
			}
			familyNumber.setPhotoFlag(photoFlag.toString());
			familyNumber.setType(type);
			
			if(member!=null){
				markList = familyNumberService.addAndInviteMember(mobile, familyNumber, member);				
			}else{
				markList = familyNumberService.add(familyNumber);
			}
						
		}else {
			if (type == FamilyNumber.TYPE_ALL) {
				if (StringUtils.isEmpty(email)) {
					return fail(MyHttpStatus._400);
				}
				email = email.replace("@", "$");
				member = memberRepository.findOneByMobile(email);
				if (member == null) {
					return fail(MyHttpStatus._20002);
				}
				FamilyNumber familyNumberPresident = familyNumberRepository.findOneByEmailAndHolderId(email, holderId);
				if(familyNumberPresident != null) {
					 return fail(MyHttpStatus._300_FM_ADDED);
				}

				if (StringUtils.isEmpty(mobile)) {//只添加关注
					markList = monitorService.accept(holder.getDevice(), holder, member,null);
				} else {//添加关注和联系人

					familyNumberPresident = familyNumberRepository.findOneByMobileAndHolderId(mobile, holderId);
					if(familyNumberPresident != null) {
						 return fail(MyHttpStatus._300_FM_ADDED);
					}
					FamilyNumber familyNumber = new FamilyNumber();
					//关注者类型
					familyNumber.setOrigin(FamilyNumber.ORIGIN_TYPE_FOLLOWER);
					familyNumber.setHolder(holder);
					familyNumber.setMobile(mobile);
					familyNumber.setEmail(email);
					familyNumber.setName(name);
					familyNumber.setPhotoFlag(photoFlag.toString());
					familyNumber.setType(type);


					markList = familyNumberService.addAndInviteMember(email, familyNumber, member);

				}
			} else {//添加联系人
				if (StringUtils.isEmpty(mobile)) {
					return fail(MyHttpStatus._400);
				}

				FamilyNumber familyNumberPresident = familyNumberRepository.findOneByMobileAndHolderId(mobile, holderId);
				if(familyNumberPresident != null) {
					 return fail(MyHttpStatus._300_FM_ADDED);
				}
				FamilyNumber familyNumber = new FamilyNumber();
				if (multiFile.getFile() != null && multiFile.getFile().getSize() > 0) {
					String filePath = UploadUtil.saveMartipartFile(null, multiFile.getFile());
					if (!StringUtils.isEmpty(filePath)) {
						familyNumber.setAvatar(filePath);
					}
				}
				familyNumber.setHolder(holder);
				familyNumber.setMobile(mobile);
				familyNumber.setName(name);
				familyNumber.setPhotoFlag(photoFlag.toString());
				familyNumber.setType(type);

				markList = familyNumberService.add(familyNumber);
				/*familyNumberRepository.save(familyNumber);
				markList.add(new Mark(holder.getId(),Type.K2,RedisCommand.CMD_FAMILY_NUMBER));*/
			}
		}
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(),(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {			
			redisQueueService.redisAddFamilyNumber(markList);
		}


		// 消息推送
		pushAppAfterAdd(holderId, holder, member);
		return success();
	}




	/**
	 * 添加家庭成员后，APP通知推送
     */
	private void pushAppAfterAdd(Long holderId, Holder holder, Member member) {
		// 消息推送
		if (member != null) {
			Monitor admin = monitorRepository.findFirstByIsAdminTrueAndHolderImei(holder.getImei());
			String postBody = "";
			if(ApplicationSupport.isChinaEnv()){
				postBody = admin.getMember().getNickName()+"邀请你关注了"+holder.getName();
			}else{
				postBody = admin.getMember().getNickName() + " invites you attention" + holder.getName()+"'s.";
			}
			if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
				//添加通知
			/*	String key = RedisKeyPre.NOTICE + member.getId();
				Notice notice = new Notice();
				Long time = System.currentTimeMillis();
				notice.setMessageId(time);
				notice.setNoticeTime(time);
				notice.setNoticeContent(postBody);
				redisService.rightPush(key, notice);*/

				//redisQueueService.insertGroupChatListForNotify(holderId, member.getMobile(), ApplicationSupport.getMessageByEnv("sys.join.familyGroup",new String[]{member.getNickName()}), System.currentTimeMillis());

				//推送
				Map<String, String> extras = new HashMap<String, String>();
				extras.put("cmd", Push.INVITATION + "");
				extras.put("holderId", holder.getId().toString());
				extras.put("from",admin.getMember().getMobile());
				extras.put("to",member.getMobile());
				//extras.put("groupId",AppDetails.GROUP_PRE + holder.getId());
				/*if (!StringUtils.isEmpty(member.getToken())) {
					asyncRequestService.pushIosMessge(member.getMobile(), postBody, extras, member.getClientId());
				}else {
					asyncRequestService.pushTitleAndroidMessge(member.getMobile(), postBody, extras, member.getClientId());
				}*/

				/*asyncRequestService.pushTagMessge(ApplicationSupport.getMessageByEnv("sys.familyGroup"), AppDetails.GROUP_PRE + holder.getId(),
						ApplicationSupport.getMessageByEnv("sys.join.familyGroup",new String[]{member.getNickName()}), extras,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel() );*/
				asyncRequestService.pushAliasMessge(ApplicationSupport.getMessageByEnv("sys.join.attention"), member.getMobile(),
						postBody, extras, holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());

			} else {
				Map<String, String> param = new HashMap<String, String>();
				param.put("cmd", Integer.toString(Push.INVITATION));
				param.put("frmobile", admin.getMember().getMobile().replace("$","@"));
				param.put("tomobile", member.getMobile().replace("$","@"));
				param.put("name", holder.getName());
				param.put("sim", holder.getSim());
				param.put("holderId",holder.getId().toString());

				Map<String,String> toParam = new HashMap<String, String>();
				toParam.put("monitors", member.getMobile());
				toParam.put(member.getMobile(), member.getToken());
				toParam.put(Push.KEY + member.getMobile(), StringToolUtil.toString(member.getPushType()));
				toParam.put(Push.CLIENT_ID+member.getClientId(), member.getClientId());

				asyncRequestService.post(admin.getMember().getMobile(), toParam, postBody, param,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());

				if (ApplicationSupport.isDevEnv()) {
					PushPayload pushPayload = new PushPayload();
					pushPayload.setWtow(Wtow.DeviceToApp);
					pushPayload.setSender(holder.getImei());
					pushPayload.setReceiver(member.getMobile());
					pushPayload.setTitle("新增联系人");
					pushPayload.setAlert(postBody);
					pushPayload.setExtras(param);
					ThriftAppClient.push(pushPayload);
				}
			}
		}
	}

	/**
	 * 修改家庭成员信息
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/v2/update",method = RequestMethod.POST)
	public MyResponseBody v2update(@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "holderId") Long holderId,
								 @RequestParam(value = "familyNumberId") Long familyNumberId,
								 @RequestParam(value = "name") String name,
								 @RequestParam(value = "mobile") String mobile,
								 @RequestParam(value = "photoFlag",required = false,defaultValue = "0")Integer photoFlag,
								 MultiFile multiFile){
		mobile = mobile.replace(" ","");//将手机号码中的空格去除
		FamilyNumber familyNumber = familyNumberRepository.findOne(familyNumberId);
		if (familyNumber == null) {
			return fail(MyHttpStatus._404);
		}
		
		FamilyNumber fn = familyNumberRepository.findOneByMobileAndHolderId(mobile, holderId);
		//判断持有者联系人号码是否重复
		if (fn != null) {
			if (!fn.getId().equals(familyNumberId)) {
				return fail(MyHttpStatus._300_FM_ADDED); 
			}
		}
		Device device = familyNumber.getHolder().getDevice();
		if(ApplicationSupport.isChinaEnv()){
			//国内环境只能修改联系人号码（不是关注者）
			if (!familyNumber.getType().equals(FamilyNumber.TYPE_ALL)) {
				//k3联系人可以修改头像电话号码及昵称；关注者只能修改昵称
				if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(device.getDeviceType())) {
					if (multiFile.getFile() != null && multiFile.getFile().getSize() > 0) {
						String filePath = UploadUtil.saveMartipartFile(null, multiFile.getFile());
						if (!StringUtils.isEmpty(filePath)) {
							familyNumber.setAvatar(filePath);
						}
					}
				}
				familyNumber.setMobile(mobile);
			}
		} else {
			//k3联系人可以修改头像电话号码和昵称；关注者只能修改昵称
			if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(device.getDeviceType())) {
				if (!familyNumber.getType().equals(FamilyNumber.TYPE_ALL)) {
					if (multiFile.getFile() != null && multiFile.getFile().getSize() > 0) {
						String filePath = UploadUtil.saveMartipartFile(null, multiFile.getFile());
						if (!StringUtils.isEmpty(filePath)) {
							familyNumber.setAvatar(filePath);
						}
					}
					familyNumber.setMobile(mobile);
				}
			}else {				
				familyNumber.setMobile(mobile);
			}
		}
		
		familyNumber.setName(name);
		familyNumber.setPhotoFlag(photoFlag.toString());
		familyNumberService.update(familyNumber);
		
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(device.getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(device.getImei(),(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {			
			redisQueueService.redisUpdateFamilyNumber(familyNumber);
		}
		
		return success();
	}
	
	/**
	 * 亲情号码查询
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/v2/list" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody v2list(@RequestParam(value = "holderId") Long holderId) {
		
		/*Holder holder = holderRepository.findOne(holderId);
		if(holder == null){
			return fail("sys.holder.notexists");
		}*/
		List<FamilyNumber> familyNumberList = familyNumberService.appAddFamilyNumbers(holderId);
		
		FamilyNumberDtoBuilder builder = new FamilyNumberDtoBuilder();
		List<FamilyNumberDto> dtoList = builder.build(familyNumberList);
		
		return success(dtoList);
	}
	//------------------------------卫2 end-----------------------------------------------//
	
	/**
	 * 亲情号码查询
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody list(@RequestParam(value = "holderId") Long holderId) {
		
		/*Holder hpresident = holderRepository.findOne(holderId);
		if(hpresident == null){
			return fail("sys.holder.notexists");
		}*/
		List<FamilyNumber> familyNumberList = familyNumberRepository.findByHolderId(holderId);
		
		FamilyNumberDtoBuilder builder = new FamilyNumberDtoBuilder();
		List<FamilyNumberDto> dtoList = builder.build(familyNumberList);
		
		return success(dtoList);
	}
	
	/**
	 * 添加亲情号码
	 * 一代协议添加亲情号，海外环境只添加联系人，国内环境如果手机号是注册账号添加联系人同时添加成关注者
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/add" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody add(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "name", required = false) String name,
							  @RequestParam(value = "mobile") String mobile) {
		mobile = mobile.replace(" ","");//将手机号码中的空格去除
		//1.检查Holder是否存在
		Holder holder = holderRepository.findOne(holderId);
		if(holder == null){
			return fail("sys.holder.notexists");
		}
		
		//2.渠道编码10553只能添加对应的号码段
		String saleChannel = holder.getDevice().getSaleChannel();
		if(saleChannel != null && saleChannel.equals("10553")){
			if(!Pattern.matches("(134|135|136|137|138|139|150|151|152|158|159|182|183|184|157|187|188|147|178)\\d{8}", mobile)){
				return fail(MyHttpStatus._40004);
			}
		}	
		
		Member member = memberRepository.findOneByMobile(mobile);
		
		FamilyNumber familyNumber = familyNumberRepository.findOneByMobileAndHolderId(mobile, holderId);
		if(familyNumber != null) {
			 return fail("familyNumber.mobler.already.added");
		}
		
		familyNumber = new FamilyNumber();
		familyNumber.setMobile(mobile);
		familyNumber.setName(name);
		familyNumber.setHolder(holder);

		List<Mark> markList = null;
		//List<Mark> markList = familyNumberService.add(mobile, familyNumber,member);
		if(ApplicationSupport.isChinaEnv() && member!=null){
			markList = familyNumberService.addAndInviteMember(mobile, familyNumber, member);
		}else{
			markList = familyNumberService.add(familyNumber);
		}
		
		redisQueueService.redisAddFamilyNumber(markList);
		
		return success();
	}
	
	
	/**
	 * 亲情号码设置亲情号码1,亲情号码2
	 *sort : 参数值为1：为亲情号码1 参数值为2：为亲情号码2
	 */
	@DataPermission(value = DataPermissionType.FAMILYNUMBER_ADMIN)
	@RequestMapping(value = { "/set_sort" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody setSort(@RequestParam(value = "familyNumberId") Long familyNumberId,
								  @RequestParam(value = "sort") Integer sort) {
		FamilyNumber familyNumber = familyNumberRepository.findOne(familyNumberId);
		if (familyNumber == null) {
			return fail(MyHttpStatus._404);
		}
		if(sort < 1 || sort > 2) {
			return fail("sys.sort.not.correct");
		}
		familyNumberService.setSort(familyNumber, sort);
		
		Holder holder = familyNumber.getHolder();
		if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {
			redisQueueService.k2HandleMark(new Mark(holder.getId(),RedisCommand.CMD_FAMILY_NUMBER));
		}
		return success();
	}
	
	/**
	 * 删除亲情号码 familyNumberId:需要删除的好友id
	 */
	@DataPermission(value = DataPermissionType.FAMILYNUMBER_ADMIN)
	@RequestMapping(value = { "/delete","/v2/delete" }, method = { RequestMethod.POST })
	public MyResponseBody delete(@RequestParam(value = "familyNumberId") Long familyNumberId) {
		FamilyNumber familyNumber = familyNumberRepository.findOne(familyNumberId);
		if(null == familyNumber){
			return fail(MyHttpStatus._404);
		}
		if (familyNumber.getOrigin() == 1) {//不能删除管理员
			return fail(MyHttpStatus._401_NOT_DEL_ADMIN_FM);
		}
		
		String mobile;
		if(ApplicationSupport.isChinaEnv()){
			mobile = familyNumber.getMobile();
		}else {
			mobile = familyNumber.getEmail();
		}
		
		
		Holder holder = familyNumber.getHolder();
		Monitor monitorAdmin = monitorRepository.findOneByIsAdminTrueAndHolder(holder);
		Member admin = monitorAdmin.getMember();
		
		Member member = memberRepository.findOneByMobile(mobile);
		
		List<Mark> markList = familyNumberService.delete(familyNumber, member,holder);
		//设备端的同步
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(),(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {
			redisQueueService.redisAddFamilyNumber(markList);
		}
		//APP的推送
		this.pushMemberAfterDelete(mobile, holder, admin, member, markList);
		return success();
	}


	/**
	 * 批量导入号码 持有者的管理员才能有的权限
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/addBatch" }, method = { RequestMethod.POST })
	public MyResponseBody v2addBatch(@RequestParam(value = "holderId") Long holderId,
									 @RequestParam(value = "contacts") String contacts) {
		Contact[] contactTotal = null;
		try {
			contactTotal = JsonUtils.toObject(contacts, Contact[].class);
			if (contactTotal.length>100)
				return fail(MyHttpStatus._401_NOT_MAX_ADD_FM);
		}catch (Exception e){
			return fail(MyHttpStatus._400);
		}
		List<Contact> validContacts = new ArrayList<Contact>();
		//1.检查Holder是否存在
		Holder holder = holderRepository.findOne(holderId);
		String deviceType = holder.getDevice().getDeviceType();
		if(holder == null){
			return fail("sys.holder.notexists");
		}

		for (int i=0;i<contactTotal.length; i++){
			Contact contact = contactTotal[i];
			String name = contact.getName();
			String mobile = contact.getMobile();
			if (!StringToolUtil.isNumber(mobile) || StringUtils.isEmpty(name)){
				continue;
			}
			//2.渠道编码10553只能添加对应的号码段
			String saleChannel = holder.getDevice().getSaleChannel();
			if(saleChannel != null && saleChannel.equals("10553")){
				if(!Pattern.matches("(134|135|136|137|138|139|150|151|152|158|159|182|183|184|157|187|188|147|178)\\d{8}", mobile)){
					continue;
				}
			}
			//4.检查此号码是否已添
			FamilyNumber familyNumberPresident = familyNumberRepository.findOneByMobileAndHolderId(mobile, holder.getId());
			if(familyNumberPresident != null) {
				continue;
			}
			validContacts.add(contact);//真正需要添加的号码
		}

		List<FamilyNumber> familyNumberList = getFNList(holder, validContacts);
		familyNumberList =  familyNumberRepository.save(familyNumberList);

		List<Mark> markList = new ArrayList<Mark>();
		if(AppDetails.DEVICE_TYPE_SYNC_MARK.contains(deviceType)){
			//设置同步标记，不需要添加到markList
			msgSettingRepository.setSosNumberFor("0", holder);
		}else{
			//k3不会用到marklist，微会饼没有联系人添加到marklist，但不会用到了
			markList.add(new Mark(holder.getId(), Mark.Type.K2,RedisCommand.CMD_FAMILY_NUMBER));
		}
		//推送到设备
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(),(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {
			redisQueueService.redisAddFamilyNumber(markList);
		}

		Map<String,Object> result = new HashMap<String,Object>();
		result.put("totalNum",contactTotal.length);
		result.put("successNum",familyNumberList.size());
		return success(result);
	}

	//构造待添加的联系人列表
	private List<FamilyNumber> getFNList(Holder holder, List<Contact> contacts) {
		List<FamilyNumber> familyNumberList = new ArrayList<FamilyNumber>();
		for (Contact contact : contacts){
			FamilyNumber familyNumber = new FamilyNumber();
			familyNumber.setHolder(holder);
			familyNumber.setMobile(contact.getMobile());
			familyNumber.setName(contact.getName());
			familyNumber.setType(1);//联系人权限
			familyNumberList.add(familyNumber);
		}
		return  familyNumberList;
	}


	/**
	 * 批量删除亲情号码 familyNumberId:需要删除的好友id
	 * 关注者不允许批量删除
	 * 管理员不允许删除
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/deleteBatch" }, method = { RequestMethod.POST })
	public MyResponseBody deleteBatch(@RequestParam(value = "familyNumberIds") List<Long> familyNumberIds,@RequestParam(value = "holderId") Long holderId) {
		List<Long>  validIds = new ArrayList<Long>(familyNumberIds);
		for (Long familyNumberId : familyNumberIds) {
			FamilyNumber familyNumber = familyNumberRepository.findOne(familyNumberId);
			if (null == familyNumber) {
				validIds.remove(familyNumberId);
			}else {
				if (familyNumber.getOrigin() == 1) {//不能删除管理员
					validIds.remove(familyNumberId);
				}
				if (familyNumber.getOrigin() == 2) {//不能批量删除关注者
					validIds.remove(familyNumberId);
				}
			}
		}
		List<FamilyNumber> familyNumberList = new ArrayList<FamilyNumber>();
		for(Long familyNumberId : validIds){
			FamilyNumber familyNumber = familyNumberRepository.findOne(familyNumberId);
			familyNumberList.add(familyNumber);
		}
		//批量删除联系人
		familyNumberRepository.delete(familyNumberList);
		Holder holder = holderRepository.findOne(holderId);
		if (holder==null)
			return fail(MyHttpStatus._400);
		String deviceType = holder.getDevice().getDeviceType();

		//推送
		List<Mark> markList = new ArrayList<Mark>();
		if(AppDetails.DEVICE_TYPE_SYNC_MARK.contains(deviceType)){
			//设置同步标记，不需要添加到markList
			msgSettingRepository.setSosNumberFor("0", holder);
		}else{
			//k3不会用到marklist，微会饼没有联系人添加到marklist，但不会用到了
			markList.add(new Mark(holder.getId(), Mark.Type.K2,RedisCommand.CMD_FAMILY_NUMBER));
		}
		//设备端信息同步
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(),(Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
		}else {
			redisQueueService.redisDelFamilyNumber(markList);
		}
		return success();
	}
	/*
	 家庭成员身份被删除后推送给被删除的用户(关注者收到推送通知)
	 */
	private void pushMemberAfterDelete(String mobile, Holder holder, Member admin, Member member, List<Mark> markList) {
		if(member != null){
			if(AppDetails.WE_TALK_DEVICE_TYPE.equals(holder.getDevice().getDeviceType())){
				redisQueueService.insertGroupChatListForNotify(holder.getId(), member.getMobile(), ApplicationSupport.getMessageByEnv("sys.left.familyGroup",new String[]{member.getNickName()}), System.currentTimeMillis());
				//推送
				Map<String, String> extras = new HashMap<String, String>();
				extras.put("cmd", Push.ADMIN_DEL_FOLLOWER + "");
				extras.put("holderId", holder.getId().toString());
				extras.put("from", admin.getMobile());
				extras.put("to",member.getMobile());
				extras.put("groupId",AppDetails.GROUP_PRE + holder.getId());

				asyncRequestService.pushTagMessge(ApplicationSupport.getMessageByEnv("sys.familyGroup"), AppDetails.GROUP_PRE + holder.getId(),
						ApplicationSupport.getMessageByEnv("sys.left.familyGroup",new String[]{member.getNickName()}), extras ,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
			}else if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
				//推送
				Map<String, String> extras = new HashMap<String, String>();
				extras.put("cmd", Push.ADMIN_DEL_FOLLOWER + "");
				extras.put("holderId", holder.getId().toString());
				/*extras.put("from", admin.getMobile());
				extras.put("to",member.getMobile());
				extras.put("groupId",AppDetails.GROUP_PRE + holder.getId());*/

				asyncRequestService.pushAliasMessge(ApplicationSupport.getMessageByEnv("sys.cancel.attention"), member.getMobile(),
						ApplicationSupport.getMessageByEnv("sys.cancel.attention.content",new String[]{holder.getName()}), extras ,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
			}else{
				String postBody = holder.getName()+"的管理者(" + admin.getNickName() + ")已经取消了您对该设备的关注！";
				Map<String, String> param = new HashMap<String, String>();
				param.put("cmd", Integer.toString(Push.UNBOUND));
				param.put("frmobile", admin.getMobile());
				param.put("tomobile", mobile);
				param.put("name", holder.getName());
				param.put("sim", holder.getSim());
				param.put("holderId",holder.getId().toString());
				Map<String,String> toParam = new HashMap<String, String>();
				toParam.put("monitors", mobile);
				toParam.put(mobile, member.getToken());
				toParam.put(Push.KEY+mobile, StringToolUtil.toString(member.getPushType()));
				toParam.put(Push.CLIENT_ID+member.getMobile(), member.getClientId());
				asyncRequestService.post(admin.getMobile(), toParam, postBody, param ,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());


				if (ApplicationSupport.isDevEnv()) {
					PushPayload pushPayload = new PushPayload();
					pushPayload.setWtow(Wtow.DeviceToApp);
					pushPayload.setSender(holder.getImei());
					pushPayload.setReceiver(member.getMobile());
					pushPayload.setTitle("删除联系人");
					pushPayload.setAlert(postBody);
					pushPayload.setExtras(param);
					ThriftAppClient.push(pushPayload);
				}

			}

		}
	}

	/**
	 * 管理员修改自己的名称和电话号码（amazon）
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = { "/edit_admin" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody edit(@RequestParam(value = "holderId") Long holderId,
								@RequestParam(value = "newName") String newName,
								@RequestParam(value = "oldMobile") String oldMobile,
								@RequestParam(value = "newMobile") String newMobile,
								HttpServletRequest request){
		oldMobile = oldMobile.replace(" ","");//将手机号码中的空格去除
		newMobile = newMobile.replace(" ","");//将手机号码中的空格去除
		Holder holder = holderRepository.findOne(holderId);
		if(holder == null){
			return fail(MyHttpStatus._404_DEVICE_NONENTITY);
		}
		
		FamilyNumber familyNumber = familyNumberRepository.findOneByMobileAndHolderId(oldMobile, holderId);
		if(familyNumber == null) {
			return fail(MyHttpStatus._404);
		}
		//限制管理员修改的号码和其他亲情号不相同
		FamilyNumber fm = familyNumberRepository.findOneByMobileAndHolderId(newMobile, holderId);
		if (fm != null && !familyNumber.getId().equals(fm.getId())) {
			return fail(RuleSupport.getMsgByLocale(request.getHeader("lang"),"familyNumber.mobler.already.added"));
		}
		
		familyNumber.setMobile(newMobile);
		familyNumber.setName(newName);
		familyNumberService.save(familyNumber);
		
		if (AppDetails.DEVICE_TYPE_SEND_MARK.contains(holder.getDevice().getDeviceType())) {
			redisQueueService.k2HandleMark(new Mark(holder.getId(),RedisCommand.CMD_FAMILY_NUMBER));
		}
		
		return success();
	}
	
}
