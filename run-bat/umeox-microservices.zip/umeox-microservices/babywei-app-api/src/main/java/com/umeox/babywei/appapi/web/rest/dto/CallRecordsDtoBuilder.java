package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Page;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.CallRecords;
import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.MemberRepository;

public class CallRecordsDtoBuilder {
	
	private static MemberRepository memberRepository;
	private static SettingProperties setting;
	static{
		memberRepository = (MemberRepository) ApplicationSupport.getBean("memberRepository");
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}
	
	public static CallRecordsDto build(CallRecords callRecords) {
		CallRecordsDto dto = new CallRecordsDto();
		FamilyNumber familyNumber = callRecords.getFamilyNumber();
		if (FamilyNumber.TYPE_ALL.equals(familyNumber.getType())) {//账号
			String moblie = null;
			if (ApplicationSupport.isChinaEnv()) {
				moblie = familyNumber.getMobile();
			}else {
				moblie = familyNumber.getEmail();
			}
			Member member = memberRepository.findOneByMobile(moblie);
			dto.setAvatar(setting.getSiteUrl() + member.getAvatar());
		}else {
			dto.setAvatar(setting.getSiteUrl() + familyNumber.getAvatar());
		}
		dto.setName(familyNumber.getName());
		dto.setCallType(callRecords.getCallType());
		dto.setCallTime(callRecords.getCallTime());
		dto.setStartTime(callRecords.getStartTime());
		dto.setType(callRecords.getType());
		return dto;
	}

	public static PageDto<CallRecordsDto> build(Page<CallRecords> page) {
		PageDto<CallRecordsDto> respPage = new PageDto<CallRecordsDto>();
		List<CallRecordsDto> dtoList = new ArrayList<CallRecordsDto>();
		for (CallRecords callRecords : page) {
			dtoList.add(build(callRecords));
		}
		respPage.setContent(dtoList);
		respPage.setNumber(page.getNumber());
		respPage.setSize(page.getSize());
		respPage.setTotalPages(page.getTotalPages());
		return respPage;
	}
}
