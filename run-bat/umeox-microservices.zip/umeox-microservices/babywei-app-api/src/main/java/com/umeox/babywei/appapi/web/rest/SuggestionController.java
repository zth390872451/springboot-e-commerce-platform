package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Suggestion;
import com.umeox.babywei.repository.DeviceRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.SuggestionRepository;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.success;


/**
 * 反馈意见
 * @author umeox
 */
@RestController
@RequestMapping( { "/api/suggestion" })
public class SuggestionController{
	
	@Autowired
	private SuggestionRepository suggestionRepository;
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private DeviceRepository deviceRepository;
	/**
	 * 意见反馈
	 */
	@RequestMapping(value = { "/addsuggest" }, method = { RequestMethod.POST })
	public MyResponseBody addsuggest(@RequestParam(value = "mobile") String mobile,//TODO 可以根据当前用户账户来设置
							 @RequestParam(value = "imei",required = false) String imei,
							 @RequestParam(value = "suggestType") String suggestType,
							 @RequestParam(value = "suggestContext") String suggestContext,
							 @RequestParam(value = "phoneSystem") String phoneSystem,
							 @RequestParam(value = "systemVersion") String systemVersion,
							 @RequestParam(value = "phoneType",required = false) String phoneType,
							 @RequestHeader(value = "client_id",required = false) String clientId,
							@RequestHeader(value = "version",required = false) String version,
							 HttpServletRequest request) {
		Suggestion suggestion = new Suggestion();
		suggestion.setClientId(clientId);
		suggestion.setImei(imei);
		suggestion.setMobile(mobile);
		suggestion.setPhoneSystem(phoneSystem);
		suggestion.setPhoneType(phoneType);
		suggestion.setSystemVersion(systemVersion);
		suggestion.setSuggestContext(suggestContext);
		suggestion.setSuggestType(suggestType);
		suggestion.setAppVersion(version);
		suggestionRepository.save(suggestion);
		if (AppDetails.FUNPARK_APP.contains(clientId)){
			Device device = deviceRepository.findOneByImei(imei);
			Map<String,String> params = new HashMap<String, String>();
			params.put("account",mobile.replace("$","@"));
			if (device!=null){
				params.put("imei",imei);
			}
			if (device!=null){
				params.put("device_type",device.getDeviceType());
			}
			params.put("suggest_type",suggestType);
			params.put("suggest_content",suggestContext);
			params.put("app_version",version);
			params.put("phone_system_system_version",phoneSystem);
			params.put("phone_type",phoneType);
			params.put("submit_date", DateTimeUtils.getFormatDate(suggestion.getCreateDate(),DateTimeUtils.PART_DATE_FORMAT));
			FunparkService.suggest(params);
		}
		return success();
	}
}
