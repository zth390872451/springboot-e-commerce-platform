package com.umeox.babywei.appapi.web.rest.dto;

import org.springframework.util.StringUtils;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.util.DateTimeUtils;



public class HolderDetailDtoBuilder {

	private static SettingProperties setting;

	static{
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}

	public HolderDetailDto build(Monitor monitor,Holder holder) {
		HolderDetailDto dto = new HolderDetailDto();
		dto.setAvatar(holder.getAvatar()); //以前头像Path,需要客户端拼接主机名
		if (!StringUtils.isEmpty(holder.getAvatar())) {
			dto.setFullAvatar(setting.getSiteUrl()+holder.getAvatar());
		}
		dto.setBirthday(DateTimeUtils.getFormatDate(holder.getBirthday(), DateTimeUtils.PART_DATE_FORMAT));
		dto.setGrade(holder.getGrade());
		dto.setImei(holder.getImei());
		dto.setSim(holder.getSim());
		dto.setIsAdmin(monitor.getIsAdmin());
		dto.setHolderId(holder.getId());
		dto.setMonitorId(monitor.getId());
		dto.setName(holder.getName());
		dto.setDeviceId(holder.getDevice().getId());
		dto.setQrcode(setting.getSiteUrl()+holder.getDevice().getQrCode());
		dto.setSos(holder.getSos());
		dto.setGender(holder.getGender());
		dto.setHeight(holder.getHeight());
		dto.setWeight(holder.getWeight());
		dto.setRelation(monitor.getRelation());
		dto.setIsMoveRemind(holder.getIsMoveRemind());
		if(holder.getFrequency()!=null)
			dto.setFrequency(holder.getFrequency().ordinal());
		dto.setAudioTypes(holder.getAudioTypes());
		dto.setTimeZone(holder.getTimeZone());
		dto.setAnswer(holder.getAnswer() == null?0:holder.getAnswer());
		return dto;
	}

	public HolderDetailDto build(Monitor monitor,Holder holder ,String channelSms) {
		HolderDetailDto dto = new HolderDetailDto();
		Device device = holder.getDevice();
		dto.setAvatar(holder.getAvatar());
		if (!StringUtils.isEmpty(holder.getAvatar())) {
			dto.setFullAvatar(setting.getSiteUrl()+holder.getAvatar());
		}
		dto.setBirthday(DateTimeUtils.getFormatDate(holder.getBirthday(), DateTimeUtils.PART_DATE_FORMAT));
		dto.setGrade(holder.getGrade());
		dto.setImei(holder.getImei());
		dto.setSim(holder.getSim());
		dto.setIsAdmin(monitor.getIsAdmin());
		dto.setHolderId(holder.getId());
		dto.setMonitorId(monitor.getId());
		dto.setName(holder.getName());
		dto.setDeviceId(device.getId());
		dto.setQrcode(setting.getSiteUrl()+device.getQrCode());
		dto.setSos(holder.getSos());
		dto.setGender(holder.getGender());
		dto.setHeight(holder.getHeight());
		dto.setWeight(holder.getWeight());
		dto.setRelation(monitor.getRelation());
		dto.setIsMoveRemind(holder.getIsMoveRemind());
		dto.setChannelSms(channelSms);
		dto.setTimeZone(holder.getTimeZone());
		dto.setAnswer(holder.getAnswer() == null?0:holder.getAnswer());
		if (!StringUtils.isEmpty(device.getFlag()) && device.getFlag() == 1) {
			dto.setFlag(1);
		}
		if(holder.getFrequency()!=null)
			dto.setFrequency(holder.getFrequency().ordinal());
		dto.setAudioTypes(holder.getAudioTypes());
		return dto;
	}

}
