package com.umeox.babywei.appapi.web.rest.dto;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.LogMessage;
import com.umeox.babywei.util.DateTimeUtils;
import org.springframework.util.StringUtils;

import static com.umeox.babywei.appapi.web.rest.dto.ImSendLogDtoBuilder.OSS_URL;

public class LogMessageDtoBuilder {

	private final static SettingProperties setting;
	static{
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}
	public LogMessageDto build(LogMessage message,boolean isOss) {
		LogMessageDto dto = new LogMessageDto();
		/*if(message.getType() == 3 && message.getBarrier() != null){
			dto.setAddress(message.getBarrier().getAddress());
			dto.setLatitude(message.getBarrier().getLatitude());
			dto.setLongitude(message.getBarrier().getLongitude());
			dto.setBarrierId(message.getBarrier().getId());
			dto.setRadius(message.getBarrier().getRadius());
		} */
		dto.setAddress(message.getAddress());
		dto.setLatitude(message.getLatitude());
		dto.setLongitude(message.getLongitude());
		dto.setMessageId(message.getId());
		dto.setImei(message.getHolder().getImei());
		dto.setSim(message.getHolder().getSim());
		dto.setNickName(message.getHolder().getName());
		dto.setDate(DateTimeUtils.getFormatDate(message.getMsgTime(), DateTimeUtils.FULL_DATE_FORMAT));
		dto.setType(message.getType());
		dto.setMsg(message.getMsg());
		dto.setTapurl(message.getRecordpath());
		if (isOss && !StringUtils.isEmpty(message.getRecordpath())){
			dto.setFullTapUrl(ApplicationSupport.getCloudStorageURL("oss-cn-hangzhou.aliyuncs.com","wxb01",message.getRecordpath()));
			//dto.setFullTapUrl(OSS_URL+ URLEncoder.encode(message.getRecordpath()));
		}else{
			dto.setFullTapUrl(setting.getSiteUrl()+message.getRecordpath());
		}
		return dto;
	}

	/**
	 *
	 * @param isOss 判断语聊文件是否存储于 阿里云的oss
     * @return
     */
	public List<LogMessageDto> build(List<LogMessage> messages,boolean isOss) {
		List<LogMessageDto> dtos = new ArrayList<LogMessageDto>();
		for (LogMessage message : messages) {
				dtos.add(build(message,isOss));
		}
		return dtos;
	}

}
