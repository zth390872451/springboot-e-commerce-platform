package com.umeox.babywei.appapi.web.rest.dto;

/**
 * 
 * umeox
 *
 */
public class HolderMembersDto {
	
	/**
	 * 持有者名字
	 */
	private String holderName;

	/**
	 * 昵称
	 */
	private String nickName;

	/**
	 * 关系
	 */
	private String relation;
	
	/**
	 * 手机
	 */
	private String mobile;

	/**
	 * 是否是管理员 1,0
	 */
	private String isAdmin;
	

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(String isAdmin) {
		this.isAdmin = isAdmin;
	}

}
