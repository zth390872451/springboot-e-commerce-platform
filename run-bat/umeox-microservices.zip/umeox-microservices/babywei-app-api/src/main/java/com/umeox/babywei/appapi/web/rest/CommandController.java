package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Command;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.CommandRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.HomeService;
import com.umeox.babywei.service.MessageQueueService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.OfflineMode;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.CommonUtils;
import com.umeox.babywei.util.RuleSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.*;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


@RestController
@RequestMapping({"/api/cmd"})
public class CommandController {

    private static final Logger log = LoggerFactory.getLogger(CommandController.class);

    @Autowired
    private CommandRepository commandRepository;
    @Autowired
    private MessageQueueService messageQueueService;
    @Autowired
    private HolderRepository holderRepository;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private SettingProperties setting;
    private RestTemplate restTemplate = new RestTemplate();
    @Autowired
    private HomeService homeService;
    @Autowired
    private RedisQueueService redisQueueService;

    @Deprecated
    @RequestMapping(value = {"/save"}, method = {RequestMethod.POST})
    public MyResponseBody save(@RequestParam(value = "mobile") String mobile,
                               @RequestParam(value = "imei") String imei,
                               @RequestParam(value = "code") String code,
                               @RequestParam(value = "type") int type,
                               @RequestParam(value = "remark", required = false) String remark) {

        Command command = new Command();
        command.setMobile(mobile);
        command.setImei(imei);
        command.setCode(code);
        command.setType(type);
        command.setRemark(remark);

        commandRepository.save(command);

        return success();
    }

    /**
     * 实时定位接口
     * 1.产生定位随机码
     * 2.发送定位命令
     */
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    @RequestMapping(value = {"/getLocation"}, method = {RequestMethod.GET, RequestMethod.POST})
    public MyResponseBody getLocation(@RequestParam(value = "memberId") Long memberId,
                                      @RequestParam(value = "holderId") Long holderId,
                                      @RequestParam(value = "locationPriority", required = false, defaultValue = "0") Integer lp,
                                      HttpServletRequest request) {

        log.info("getLocation,memberId={},holderId={},client={}", memberId, holderId, request.getHeader("client_id"));

        Holder holder = holderRepository.findOne(holderId);
        Member member = memberRepository.findOne(memberId);
        if (holder == null || member == null) {
            return fail(MyHttpStatus._404);
        }

        //海外K3和Doki定位问题临时处理,待删除
        /*if( ApplicationSupport.isEnv(Constants.SPRING_PROFILE_PRODUCTION_AMAZON) && !ApplicationSupport.isEnv(Constants.SPRING_PROFILE_PRODUCTION_AMAZON_DOLLYPHIN) &&
				!"46692".equals(holder.getDevice().getSaleChannel())){
			if("10".equals(holder.getDevice().getDeviceType())){
				return  fail(MyHttpStatus._1000);
			}
		}*/


        if (holder.getLocationFlag() != null && holder.getLocationFlag() == 0) {//设备关闭了定位
            return fail(MyHttpStatus._405_LOCATION_CLOSED);
        }
        try {
            Map<String, Integer> map = null;
            if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
                map = restTemplate.getForObject(setting.getDeviceOnlineUrl() + holder.getImei(), Map.class);
            } else if (AppDetails.G2_DEVICE_ONLINE_SEARCH.contains(holder.getDevice().getDeviceType())) {
                map = restTemplate.getForObject(String.format(setting.getG2DeviceOnlineUrl(), "26a53930be7e89ce7f8906609a1ab829", holder.getImei()), Map.class);
            }
            if (map != null && "0".equals(map.get("status"))) {
                if(ApplicationSupport.isChinaEnv()){
                    return fail(MyHttpStatus._404_DEVICE_NOT_ONLINE);
                }else {
                    return fail(MyHttpStatus._404_DEVICE_NOT_ONLINE, RuleSupport.getMsgByLocale(member.getLocale(),MyHttpStatus._404_DEVICE_NOT_ONLINE.getReasonPhrase()));
                }
            }
        } catch (Exception e) {
            log.error("设备在线状态查询失败", e);
        }

        //Modified By JT on 2016-08-22, 调用公用部分代码
	/*	member.setLocationCode(CommonUtils.getRandomNumber());
		memberRepository.save(member);
		locationCmd(holder, member);*/
        homeService.locationCmd(member, holder, null, lp);
        return success();
    }


    /**
     * 发送定位命令
     * @param holder
     * @param member
     */
	/*private void locationCmd(Holder holder, Member member) {
		if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
			Map<String,String> ext = new HashMap<String, String>();
			ext.put("syncFlag", Push.K3_DEVICE_LOCATION + "");
			ext.put("reqUser", member.getMobile());
			ext.put("locationCode", member.getLocationCode());
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(),ext));
		}else {
			messageQueueService.addLocationCmd(member.getMobile(), holder.getImei(), member.getLocationCode());
		}
	}*/

    /**
     * 多个持有者实时定位接口(K3)
     * 1.产生定位随机码
     * 2.发送定位命令
     */
    @DataPermission
    @RequestMapping(value = {"/getMultiLocation"}, method = {RequestMethod.GET, RequestMethod.POST})
    public MyResponseBody getMultiLocation(@RequestParam(value = "memberId") Long memberId,
                                           @RequestParam(value = "holderIds") String holderIds,
                                           HttpServletRequest request) {
        log.info("getMultiLocation,memberId={},holderId={},client={}", memberId, holderIds, request.getHeader("client_id"));
        Member member = memberRepository.findOne(memberId);
        if (member == null) {
            return fail(MyHttpStatus._404);
        }
        String[] holderIdList = holderIds.split(",");
        List<Long> list = new ArrayList<Long>();
        for (String string : holderIdList) {
            list.add(Long.parseLong(string));
        }
        List<Holder> holderList = holderRepository.findByIdIn(list);


        //海外K3和Doki定位问题临时处理,待删除
		/*if(ApplicationSupport.isEnv(Constants.SPRING_PROFILE_PRODUCTION_AMAZON) && !ApplicationSupport.isEnv(Constants.SPRING_PROFILE_PRODUCTION_AMAZON_DOLLYPHIN)
				){
			Holder holder = holderList.get(0);
			if(!"46692".equals(holder.getDevice().getSaleChannel())){
				if("10".equals(holder.getDevice().getDeviceType())){
					return  fail(MyHttpStatus._1000);
				}
			}
		}*/


        //Modified By JT on 2016-08-22,调用公用部分
		/*member.setLocationCode(CommonUtils.getRandomNumber());
		memberRepository.save(member);*/
        String locationCode = CommonUtils.getRandomNumber();
        for (Holder h : holderList) {
            homeService.locationCmd(member, h, locationCode, null);
			/*Map<String,String> ext = new HashMap<String, String>();
			ext.put("syncFlag", Push.K3_DEVICE_LOCATION + "");
			ext.put("reqUser", member.getMobile());
			ext.put("locationCode", member.getLocationCode());
			ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(h.getImei(),ext));*/
        }
        return success();
    }


    /**
     * 自动监听接口
     * app用户 在app上指定手表拨打phone
     *
     * @param memberId app用户
     * @param phone    指定手表拨打的号码
     * @return
     */
    @RequestMapping(value = {"callPhone"}, method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public MyResponseBody callPhone(@RequestParam(value = "memberId") Long memberId,
                                    @RequestParam(value = "holderId") Long holderId,
                                    @RequestParam(value = "phone") String phone) {
        Holder holder = holderRepository.findOne(holderId);
        Member member = memberRepository.findOne(memberId);
        if (member == null || holder == null) {
            return fail(MyHttpStatus._400);
        }

        try {
            Map<String, Integer> map = null;
            if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
                map = restTemplate.getForObject(setting.getDeviceOnlineUrl() + holder.getImei(), Map.class);
            } else if (AppDetails.G2_DEVICE_ONLINE_SEARCH.contains(holder.getDevice().getDeviceType())) {
                map = restTemplate.getForObject(String.format(setting.getG2DeviceOnlineUrl(), "26a53930be7e89ce7f8906609a1ab829", holder.getImei()), Map.class);
            }
            if (map != null && "0".equals(map.get("status"))) {
                if (ApplicationSupport.isChinaEnv()) {
                    return fail(MyHttpStatus._404_DEVICE_NOT_ONLINE);
                } else {
                    return fail(MyHttpStatus._404_DEVICE_NOT_ONLINE, RuleSupport.getMsgByLocale(member.getLocale(), MyHttpStatus._404_DEVICE_NOT_ONLINE.getReasonPhrase()));
                }
            }
        } catch (Exception e) {
            log.error("设备在线状态查询失败", e);
        }

        //推送到设备端
        Map<String, String> ext = new HashMap<String, String>();
        ext.put("syncFlag", Push.K3_DEVICE_CALL_PHONE + "");
        ext.put("from", member.getMobile());//下发拨打电话命令的用户
        ext.put("phone", phone);//手表将拨打的号码
        ext.put("timestamp", new Date().getTime() + "");//命令下发的时间戳

        if (AppDetails.THRIFT_ISSUE_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
            ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), ext, OfflineMode.Ignore.ordinal()));
        } else {
            messageQueueService.addRemoteMonitoringCmd(holderId + "", member.getMobile(), phone);
        }

        return success();
    }


    /**
     * 5.12	远程拍照-
     * 此接口用于关注者远程拍照。
     *
     * @param memberId app用户
     * @return
     */
    @RequestMapping(value = {"takePhoto"}, method = {RequestMethod.POST, RequestMethod.GET})
    @ResponseBody
    public MyResponseBody takePhoto(@RequestParam(value = "memberId") Long memberId,
                                    @RequestParam(value = "holderId") Long holderId) {
        Holder holder = holderRepository.findOne(holderId);
        Member member = memberRepository.findOne(memberId);
        if (member == null || holder == null)
            return fail(MyHttpStatus._400);

        try {
            if (AppDetails.G2_DEVICE_ONLINE_SEARCH.contains(holder.getDevice().getDeviceType())) {
                Map<String, Integer> map = restTemplate.getForObject(String.format(setting.getG2DeviceOnlineUrl(), "26a53930be7e89ce7f8906609a1ab829", holder.getImei()), Map.class);
                if (map != null && "0".equals(map.get("status"))) {
                    if (ApplicationSupport.isChinaEnv()) {
                        return fail(MyHttpStatus._404_DEVICE_NOT_ONLINE);
                    } else {
                        return fail(MyHttpStatus._404_DEVICE_NOT_ONLINE, RuleSupport.getMsgByLocale(member.getLocale(), MyHttpStatus._404_DEVICE_NOT_ONLINE.getReasonPhrase()));
                    }
                }
            }
        } catch (Exception e) {
            log.error("设备在线状态查询失败", e);
        }

        messageQueueService.addTakePhotoCmd(holderId + "", member.getMobile());
        return success();
    }

}
