package com.umeox.babywei.appapi.web.rest.dto;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.ImSendLog;

public class ImSendLogDtoBuilder {
	private final static SettingProperties setting;
	public static final String OSS_URL = "http://wxb01.oss-cn-hangzhou.aliyuncs.com/";
	static{
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}
	
	public static ImSendLogDto build(ImSendLog sendLog,boolean isOss) {
		ImSendLogDto dto = new ImSendLogDto();
		dto.setFrom(sendLog.getUserId());
		dto.setFromName(sendLog.getUserName());
		if (!StringUtils.isEmpty(sendLog.getUserAvatar())) {
			dto.setFromAvatar(setting.getSiteUrl()+sendLog.getUserAvatar());
		}
		dto.setMessageId(sendLog.getId());
		//dto.setUrl(setting.getNginxUrl() + sendLog.getFilePath());
		//dto.setUrl(QiniuClient.getImDownLoadToken(QiniuClient.imDomain + sendLog.getMsg()));
		if (sendLog.getMsgType() == 1 || sendLog.getMsgType() == 3 || sendLog.getMsgType() == 6) {
			if (isOss){
				//使用云存储服务,这样处理问题没问题： 因为海外都是Full Path,只要保证国内兼容消息队列中的相对路径，后续可以去掉
				dto.setUrl(ApplicationSupport.getCloudStorageURL("oss-cn-hangzhou.aliyuncs.com","wxb01",sendLog.getMsg()));
				//dto.setUrl(OSS_URL + URLEncoder.encode(sendLog.getMsg()));
			}else {
				dto.setUrl(setting.getNginxUrl()+sendLog.getMsg());
			}
				
		}
		dto.setMsgTime(sendLog.getMsgTime());
		dto.setMsgType(sendLog.getMsgType());
		dto.setMsg(sendLog.getMsg());
		return dto;
	}

	/**
	 * @param isOss 判断 语聊文件地址是否来自 阿里云Oss服务器 true：是
     * @return
     */
	public static List<ImSendLogDto> build(List<ImSendLog> list,boolean isSort,boolean isOss) {
		List<ImSendLogDto> dtoList = new ArrayList<ImSendLogDto>();
		if (isSort) {
			for (int i = list.size()-1; i > -1; i--) {
				dtoList.add(build(list.get(i),isOss));
			}
		}else {
			for (ImSendLog sendLog : list) {
				dtoList.add(build(sendLog,isOss));
			}
		}
		
		return dtoList;
	}
}
