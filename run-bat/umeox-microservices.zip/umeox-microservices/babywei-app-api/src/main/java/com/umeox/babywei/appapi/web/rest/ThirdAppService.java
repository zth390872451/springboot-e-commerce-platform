package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.util.HttpUtil;
import com.umeox.babywei.util.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * Created by Administrator on 2017/3/4.
 */
public class ThirdAppService {
    private static final Logger logger = LoggerFactory.getLogger(ThirdAppService.class);

    public static final String WEXIN_LOGIN = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code";
    public static final String QQ_LOGIN = "https://graph.qq.com/oauth2.0/token?grant_type=authorization_code&client_id=APPID&client_secret=SECRET&code=CODE&state=STATE&redirect_uri=REDIRECTURL";
    public static final String WEIBO_LOGIN ="https://api.weibo.com/oauth2/access_token?client_id=APPID&client_secret=SECRET&grant_type=authorization_code&redirect_uri=REDIRECTURL&code=CODE";
    //微信用户AccessToken认证：errorCode =0 代表 认证成功; "errcode":40003,"errmsg":"invalid openid"
    public static final String WEXIN_USER_AUTH = "https://api.weixin.qq.com/sns/auth?access_token=ACCESSTOKEN&openid=OPENID";
    //微信RefreshToken 刷新
    public static final String WEIXIN_REFRESHTOKEN = "https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=APPID&grant_type=refresh_token&refresh_token=REFRESHTOKEN";
    //获取用户信息
    public static final String WEIXIN_USER_INFO = "https://api.weixin.qq.com/sns/userinfo?access_token=ACCESSTOKEN&openid=OPENID";
    //qq获取openId 返回格式： {"client_id":"YOUR_APPID","openid":"YOUR_OPENID"}
    public static final String QQ_OPENID = "https://graph.qq.com/oauth2.0/me?access_token=";
    /**
     *
     * 服务端做第三方登录(向第三方发送请求：获取access_token的相关信息)
     * 不同的第三方 返回的json内容不一致
     新浪微博：
     {
     "access_token": "ACCESS_TOKEN",
     "expires_in": 1234,
     "remind_in":"798114",
     "uid":"12341234"
     }
     微信：
     {
     "access_token":"ACCESS_TOKEN",
     "expires_in":7200,
     "refresh_token":"REFRESH_TOKEN",
     "openid":"OPENID",
     "scope":"SCOPE",
     "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
     }
    qq：
     access_token=FE04************************CCE2&expires_in=7776000
     * @return
     */
    public static  Map<String, String> thirdLogin(String code,int type) {
        try {
            String url = "";
            if (type==0) {
                    url = WEXIN_LOGIN.replace("CODE", code);
                    String result = HttpUtil.httpGet(null, url);
                    Map<String, String> map = JsonUtils.toObject(result, Map.class);
                    return map;
            }else if (type==1){//qq 分两步：1、获取AccessToken 2、根据AccessToken获取openid
                url = QQ_LOGIN.replace("CODE",code);
                String result = HttpUtil.httpGet(null, url);//返回格式： access_token=FE04************************CCE2&expires_in=7776000
                logger.info("通过 QQ_LOGIN 获取 openid的结果:{}",result);
                String[] strings = result.split("&");
                String[] access_token = strings[0].split("=");
                String[] expires_in = strings[1].split("=");
                url = QQ_OPENID + access_token[1];//获取 qq的openid

                result = HttpUtil.httpGet(null, url);//返回格式：{"client_id":"YOUR_APPID","openid":"YOUR_OPENID"}
                logger.info("通过 QQ_OPENID 获取 openid的结果:{}",result);
                Map<String, String> map = JsonUtils.toObject(result, Map.class);
                map.put("access_token",access_token[1]);
                map.put("expires_in",expires_in[1]);
                return map;
            }else {
                url = WEIBO_LOGIN.replace("CODE",code);
                String result = HttpUtil.httpGet(null, url);
                Map<String, String> map = JsonUtils.toObject(result, Map.class);
                map.put("openid",map.get("uid"));
                return map;
            }
        }catch (Exception e){
            logger.error("exception:e{}",e.getMessage());
            return null;
        }
        /*String accessToken = map.get("access_token");
        String openId = map.get("openid");
        String refreshToken = map.get("refresh_token");
        String expires_in = map.get("expires_in");*/
    }

    /**
     * 获取用户信息
     * @param openId
     * @param accessToken
     * @return
     */
    private Map<String, String> getUserInfo(String openId,String accessToken) {
        try {
            String url = WEIXIN_USER_INFO.replace("ACCESSTOKEN",accessToken).replace("OPENID",openId);
            String result = HttpUtil.httpGet(null, url);
            Map<String, String> map = JsonUtils.toObject(result, Map.class);
            return map;
        }catch (Exception e){
            return null;
        }
    }

    /**
     * 获取微信用户信息
     * @param openId
     * @param accessToken
     * @return
     */
    private boolean weixinUserAuth(String openId,String accessToken) {
        try {
            String url = WEXIN_USER_AUTH.replace("ACCESSTOKEN",accessToken).replace("OPENID",openId);
            String result = HttpUtil.httpGet(null, url);
            Map<String, String> map = JsonUtils.toObject(result, Map.class);
            if (map.get("errcode").equals("0")){
                return true;
            }else {
                logger.error("userAuth failed:errcode = {}, errmsg : {}",map.get("errcode"),map.get("errmsg"));
                return false;
            }
        }catch (Exception e){
            logger.error("userAuth failed:{}",e.getMessage());
            return false;
        }
    }

    /**
     * 微信RefreshToken
     * @param refreshToken
     * @return
     */
    private Map<String, String>  weixinRefreshToken(String refreshToken) {
        try {
            String url = WEIXIN_REFRESHTOKEN.replace("REFRESHTOKEN",refreshToken);
            String result = HttpUtil.httpGet(null, url);
            Map<String, String> map = JsonUtils.toObject(result, Map.class);
            /*String accessToken = map.get("access_token");
            String refreshToken = map.get("refresh_token");
            String openID = map.get("openid");
            String expires_in = map.get("expires_in");*/

          /*  if (map.get("errcode").equals(0)){
                return true;
            }else {
                logger.error(" weixinRefreshToken failed:errcode = {}, errmsg : {}",map.get("errcode"),map.get("errmsg"));
                return false;
            }*/
            return map;
        }catch (Exception e){
            logger.error(" weixinRefreshToken failed:{}",e.getMessage());
            return null;
        }
    }

}
