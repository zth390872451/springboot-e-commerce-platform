package com.umeox.babywei.appapi.web.rest.dto;

/**
 * @creator ZTH
 * @modifier ZTH
 * @date 2017-08-15
 */
public class HolderWallpaperDto {

	private Long id;

	private String wallpaperUrl;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWallpaperUrl() {
		return wallpaperUrl;
	}

	public void setWallpaperUrl(String wallpaperUrl) {
		this.wallpaperUrl = wallpaperUrl;
	}
}
