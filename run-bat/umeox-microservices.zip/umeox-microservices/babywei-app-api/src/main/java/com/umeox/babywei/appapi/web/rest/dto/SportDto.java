package com.umeox.babywei.appapi.web.rest.dto;

public class SportDto {
	private Integer level;
	private Double percent;
	private Integer stepValue;
	private Long totalStepValue; 
	
	private Integer calory;
	//当天运动距离：单位米
	private Integer distance;
	
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public Double getPercent() {
		return percent;
	}
	public void setPercent(Double percent) {
		this.percent = percent;
	}
	
	public Integer getStepValue() {
		return stepValue;
	}
	public void setStepValue(Integer stepValue) {
		this.stepValue = stepValue;
	}
	
	public Long getTotalStepValue() {
		return totalStepValue;
	}
	public void setTotalStepValue(Long totalStepValue) {
		this.totalStepValue = totalStepValue;
	}
	public Integer getCalory() {
		return calory;
	}
	public void setCalory(Integer calory) {
		this.calory = calory;
	}
	public Integer getDistance() {
		return distance;
	}
	public void setDistance(Integer distance) {
		this.distance = distance;
	}
	
	
	
}
