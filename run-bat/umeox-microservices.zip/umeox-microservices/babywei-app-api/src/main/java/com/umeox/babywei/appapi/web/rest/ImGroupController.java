package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.web.rest.dto.GroupMemberDto;
import com.umeox.babywei.appapi.web.rest.dto.GroupMemberDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.ImGroup;
import com.umeox.babywei.domain.ImGroupMember;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.ImGroupMemberRepository;
import com.umeox.babywei.repository.ImGroupRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.MonitorRepository;
import com.umeox.babywei.service.ImGroupService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;


@RestController
@RequestMapping("/api/imGroup")
public class ImGroupController {

    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private MonitorRepository monitorRepository;
    @Autowired
    private ImGroupRepository imGroupRepository;
    @Autowired
    private ImGroupMemberRepository imGroupMemberRepository;
    @Autowired
    private ImGroupService imGroupService;
    @Autowired
    private HolderRepository holderRepository;
    @Autowired
    private RedisQueueService redisQueueService;


    /**
     * 修改群名称-仅微话
     */
    @DataPermission //修改设备群组名没检查
    @RequestMapping(value = "/update", method = {RequestMethod.POST})
    public MyResponseBody update(@RequestParam(value = "memberId") Long memberId,
                                 @RequestParam(value = "groupId") String groupId,
                                 @RequestParam(value = "groupName") String groupName) {
        /*Member member = memberRepository.findOne(memberId);
        if (member == null) {
            return fail(MyHttpStatus._404);
        }*/
        if (groupId.startsWith(AppDetails.GROUP_PRE)) {//家庭群组
            Long holderId = Long.parseLong(groupId.substring(2));
            Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndMemberIdAndHolderId(memberId, holderId);//管理员
            if (monitor == null) {
                return fail(MyHttpStatus._404);
            }
        }
        ImGroup imGroup = imGroupRepository.findOneByGroupId(groupId);
        if (imGroup == null) {
            return fail(MyHttpStatus._404);
        }
        imGroup.setGroupName(groupName);
        List<Mark> markList = imGroupService.updateGroupName(imGroup);
        redisQueueService.wetalkHandleMarkList(markList);
        return success();
    }


    /**
     * 获取群组成员-仅微话
     */
    @DataPermission
    @RequestMapping(value = "/list", method = {RequestMethod.GET, RequestMethod.POST})
    public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
                               @RequestParam(value = "groupId") String groupId) {
        /*Member member = memberRepository.findOne(memberId);
        if (member == null) {
            return fail(MyHttpStatus._404);
        }*/

        ImGroup imGroup = imGroupRepository.findOneByGroupId(groupId);
        if (imGroup == null) {
            return fail(MyHttpStatus._404);
        }

        List<ImGroupMember> imGroupMembers = imGroupMemberRepository.findByImGroupId(imGroup.getId());

        List<GroupMemberDto> dtos = new ArrayList<GroupMemberDto>();

        if (imGroupMembers != null && !imGroupMembers.isEmpty()) {
            List<Long> ids = new ArrayList<Long>();
            for (ImGroupMember imGroupMember : imGroupMembers) {
                ids.add(imGroupMember.getUserId());
            }

            //TODO 改成本地sql，减少查询次数
            List<Holder> holderList = holderRepository.findAll(ids);

            GroupMemberDtoBuilder builder = new GroupMemberDtoBuilder();
            dtos = builder.build(holderList);
        }

        return success(dtos);
    }


}
