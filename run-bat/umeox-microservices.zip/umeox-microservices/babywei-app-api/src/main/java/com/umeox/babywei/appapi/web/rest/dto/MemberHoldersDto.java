package com.umeox.babywei.appapi.web.rest.dto;

import java.util.List;


/**
 * 用户持有者列表
 *
 * 
 */
public class MemberHoldersDto {
	
	/**
	 * 头像
	 */
	private String avatar;

	/**
	 * 头像(URL)
	 */
	private String fullAvatar;
	
	/**
	 * 持有者编号
	 */
	private Long holderId;

	/**
	 * 监护编号
	 */
	private Long monitorId;

	/**
	 * 持有者名字
	 */
	private String holderName;
	
	/**
	 * 持有者姓(未使用)
	 */
	private String holderFamilyName;
	/**
	 * SIM卡号
	 */
	private String sim;
	/**
	 * 性别
	 */
	private String gender;
	
	/**
	 * 是否为主监护人
	 */
	private Integer isAdmin;
	
	private int frequency;
	
	private String imei;
	/**
	 * 生日
	 */
	private String birthday;
	
	/**
	 * 设备类型
	 */
	private String deviceType;
	/**
	 * 身高
	 */
	private String height;
	
	/**
	 * 体重
	 */
	private String weight;
	/**
	 * 运动提醒
	 * 是否接收运动静止状态改变的推送，叫做运动提醒；
	       如果APP打开了开关，服务器需要记录状态，以备推送状态信息判断
	 */
	private Boolean isMoveRemind;
	/**
	 * 年级
	 */
	private String grade;
	/**
	 * 关系
	 */
	private String relation;
	/**
	 * 静止提醒开关
	 */
	private Boolean staticOpen;
	/**
	 * 静止提醒开始时间
	 */
	private String startHours;
	
	/**
	 * 静止提醒结束时间
	 */
	private String endHours;
	
	private String audioTypes;
	/**
	 * 渠道短信标志位
	 */
	private String channelSms;
	private Integer answer;
	private String timeZone;
	
	/**
	 * 渠道编号
	 */
	private String saleChannel;
	
	private List<HolderPositionDto> holderPositionDtoList;

	

	
	public String getHolderFamilyName() {
		return holderFamilyName;
	}

	public void setHolderFamilyName(String holderFamilyName) {
		this.holderFamilyName = holderFamilyName;
	}

	public String getSaleChannel() {
		return saleChannel;
	}

	public void setSaleChannel(String saleChannel) {
		this.saleChannel = saleChannel;
	}

	public List<HolderPositionDto> getHolderPositionDtoList() {
		return holderPositionDtoList;
	}

	public void setHolderPositionDtoList(
			List<HolderPositionDto> holderPositionDtoList) {
		this.holderPositionDtoList = holderPositionDtoList;
	}

	public MemberHoldersDto() {
	}

	public MemberHoldersDto(Long holderId, Long monitorId, String holderName, String holderFamilyName, String avatar,String sim
			,Boolean isAdmin,int frequency,String imei,String deviceType,String gender) {
		super();
		this.holderId = holderId;
		this.monitorId = monitorId;
		this.holderName = holderName;
		this.holderFamilyName = holderFamilyName;
		this.avatar = avatar;
		this.sim = sim;
		if(isAdmin)
			this.isAdmin = 1;
		else 
			this.isAdmin = 0;
		this.frequency = frequency;
		this.imei = imei;
		this.deviceType = deviceType;
		this.gender = gender;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}

	public Long getMonitorId() {
		return monitorId;
	}

	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getSim() {
		return sim;
	}

	public void setSim(String sim) {
		this.sim = sim;
	}

	public Integer getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Integer isAdmin) {
		this.isAdmin = isAdmin;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public Boolean getIsMoveRemind() {
		return isMoveRemind;
	}

	public void setIsMoveRemind(Boolean isMoveRemind) {
		this.isMoveRemind = isMoveRemind;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public Boolean getStaticOpen() {
		return staticOpen;
	}

	public void setStaticOpen(Boolean staticOpen) {
		this.staticOpen = staticOpen;
	}

	public String getStartHours() {
		return startHours;
	}

	public void setStartHours(String startHours) {
		this.startHours = startHours;
	}

	public String getEndHours() {
		return endHours;
	}

	public void setEndHours(String endHours) {
		this.endHours = endHours;
	}

	public String getAudioTypes() {
		return audioTypes;
	}

	public void setAudioTypes(String audioTypes) {
		this.audioTypes = audioTypes;
	}
	public String getChannelSms() {
		return channelSms;
	}

	public void setChannelSms(String channel) {
		this.channelSms = channel;
	}

	public Integer getAnswer() {
		return answer;
	}

	public void setAnswer(Integer answer) {
		this.answer = answer;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getFullAvatar() {
		return fullAvatar;
	}

	public void setFullAvatar(String fullAvatar) {
		this.fullAvatar = fullAvatar;
	}
}
