package com.umeox.babywei.appapi.web.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.umeox.babywei.bean.Oauth2;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.repository.*;
import com.umeox.babywei.service.AsyncRequestService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.KinglangSms;
import com.umeox.babywei.util.RSAEncryption;
import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author xmc
 * 供充值系统调用，RSA签名校验
 */
@RestController
@RequestMapping("/api/charge")
public class ChargeController {
	@Autowired private MonitorRepository monitorRepository;
	@Autowired private RedisService redisService;
	@Autowired private MemberRepository memberRepository;
	@Autowired private HolderRepository holderRepository;
	@Autowired private AsyncRequestService asyncRequestService;
	@Autowired private ImSendLogRepository imSendLogRepository;
	@Autowired private FamilyNumberRepository familyNumberRepository;
	protected static Logger logger = LoggerFactory.getLogger(ChargeController.class);
	//获取联系人昵称
	/*@RequestMapping(value = "/getFnName",method = RequestMethod.GET,produces="text/html;charset=UTF-8")
	public String getFnName(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "mobile") String mobile,
							  @RequestParam(value = "sign") String sign){
		String params = "wherecom:holderId="+holderId+"&mobile="+mobile;
		try {
			boolean bool = RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign));
			if (!bool) {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		FamilyNumber familyNumber = familyNumberRepository.findOneByMobileAndHolderId(mobile, holderId);
		if (familyNumber == null) {
			return null;
		}
		return familyNumber.getName();
	}*/
	
	@RequestMapping(value = "/isFollower",method = RequestMethod.GET)
	public boolean isFollower(@RequestParam(value = "holderId") Long holderId,
							  @RequestParam(value = "memberId") Long memberId,
							  @RequestParam(value = "sign") String sign){
		String params = "wherecom:holderId="+holderId+"&memberId="+memberId;
		try {
			boolean bool = RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign));
			if (!bool) {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, holderId);
		if (monitor == null) {
			return false;
		}
		return true;
	}
	
	@RequestMapping(value = "/getOauth",method = RequestMethod.GET)
	public Oauth2 getOauth(@RequestParam(value = "token") String token,
							@RequestParam(value = "sign") String sign){
		try {
			String params = "wherecom:token="+token;
			boolean bool = RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign));
			if (!bool) {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return (Oauth2) redisService.get(RedisKeyPre.OAUTH2_TOKEN+token);
	}
	
	@RequestMapping(value = "/getFamilyNumber",method = RequestMethod.GET)
	public Map<String, String> getFamilyNumber(@RequestParam(value = "holderId") Long holderId,
								@RequestParam(value = "memberId") Long memberId,
								@RequestParam(value = "sign") String sign){
		String params = "wherecom:holderId="+holderId+"&memberId="+memberId;
		try {
			if (RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign))) {
				Member member = memberRepository.findOne(memberId);
				if (member == null) {
					return  null;
				}
				FamilyNumber fm = familyNumberRepository.findOneByMobileAndHolderId(member.getMobile(), holderId);
				if (fm == null) {
					return null;
				}
				Map<String, String> map = new HashMap<String, String>();
				map.put("mobile", fm.getMobile());
				map.put("name", fm.getName());
				return map;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/getHolder",method = RequestMethod.GET)
	public Map<String, String> getHolder(@RequestParam(value = "holderId") Long holderId,
							@RequestParam(value = "sign") String sign){
		String params = "wherecom:holderId="+holderId;
		boolean bool;
		try {
			bool = RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign));
			if (!bool) {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return null;
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("imei", holder.getImei());
		map.put("sim", holder.getSim());
		return map;
	}
	
	@RequestMapping(value = "/push",method = RequestMethod.GET)
	public void push(@RequestParam(value = "imei") String imei,
					 @RequestParam(value = "sign") String sign,
					 @RequestParam(value = "content") String content,
					 @RequestParam(value = "cmd") int cmd,
					 @RequestParam(value = "title") String title,
					 @RequestParam(value = "msgContent") String msgContent){
		String params = "wherecom:imei="+imei;
		try {
			if (RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign))) {
				Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imei);
				if (monitor != null) {
					Holder holder = monitor.getHolder();
					Member member = monitor.getMember();
					ImSendLog imSendLog = new ImSendLog();
					imSendLog.setImType(AppDetails.FRIEND_TYPE);
					imSendLog.setUserId(imei);
					String msg = mapToJson(title, content);
					imSendLog.setMsg(msg);
					imSendLog.setMsgTime((new Date()).getTime());
					imSendLog.setMsgType(20);
					imSendLog.setFriendId(imei);
					imSendLogRepository.save(imSendLog);
					String key = RedisKeyPre.FRIEND_CHAT+RedisKeyPre.MEMBER_CHAT+member.getId()+":"+ RedisKeyPre.HOLDER_CHAT+holder.getId();
					redisService.rightPush(key, imSendLog);
					
					Map<String, String> extras = new HashMap<String, String>();
					extras.put("cmd", "35");
					extras.put("holderId", holder.getId().toString());
					asyncRequestService.pushAliasMessge(title, member.getMobile(), msgContent, extras,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 充值，购买套餐推送
	 */
	@RequestMapping(value = "/rechargePush",method = RequestMethod.GET)
	public void rechargePush(@RequestParam(value = "mobile") String mobile,
					 @RequestParam(value = "imei") String imei,
					 @RequestParam(value = "cmd") int cmd,
					 @RequestParam(value = "title") String title,
					 @RequestParam(value = "content") String content,
					 @RequestParam(value = "msgContent") String msgContent,
					 @RequestParam(value = "sign") String sign){
		String params = "wherecom:imei="+imei;
		try {
			if (RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign))) {
				Holder holder = holderRepository.findFirstByImei(imei);
				Member member = memberRepository.findOneByMobile(mobile);
				if (holder != null && member != null) {
					FamilyNumber familyNumber = familyNumberRepository.findOneByMobileAndHolderId(mobile, holder.getId());
					if (familyNumber != null) {
						ImSendLog imSendLog = new ImSendLog();
						imSendLog.setImType(AppDetails.FRIEND_TYPE);
						imSendLog.setUserId(imei);
						content = familyNumber.getName() + "给" + holder.getName() + content;//xx给xx
						String msg = mapToJson(title, content);
						imSendLog.setMsg(msg);
						imSendLog.setMsgTime((new Date()).getTime());
						imSendLog.setMsgType(20);
						imSendLog.setFriendId(imei);
						imSendLogRepository.save(imSendLog);
						String key = RedisKeyPre.FRIEND_CHAT+RedisKeyPre.MEMBER_CHAT+member.getId()+":"+ RedisKeyPre.HOLDER_CHAT+holder.getId();
						redisService.rightPush(key, imSendLog);
						
						Map<String, String> extras = new HashMap<String, String>();
						extras.put("cmd", "35");
						extras.put("holderId", holder.getId().toString());
						asyncRequestService.pushAliasMessge(title, member.getMobile(), msgContent, extras,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@RequestMapping(value = "/dataStreamPush",method = RequestMethod.GET)
	public void dataStreamPush(@RequestParam(value = "imei") String imei,
					 @RequestParam(value = "sign") String sign,
					 @RequestParam(value = "cmd") int cmd,
					 @RequestParam(value = "title") String title,
					 @RequestParam(value = "msgContent") String msgContent){
		String params = "wherecom:imei="+imei;
		try {
			boolean verify = RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign));
			if (verify) {
				Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imei);
				if (monitor != null) {
					Holder holder = monitor.getHolder();
					Member member = monitor.getMember();
					if (holder==null || member==null)
					{
						logger.error("holder ={},member={}",holder,member);
					}

					ImSendLog imSendLog = new ImSendLog();
					imSendLog.setImType(AppDetails.FRIEND_TYPE);
					imSendLog.setUserId(imei);
					String msg = mapToJson(title, msgContent);
					imSendLog.setMsg(msg);
					imSendLog.setMsgTime((new Date()).getTime());
					imSendLog.setMsgType(20);
					imSendLog.setFriendId(imei);
					imSendLogRepository.save(imSendLog);
					String key = RedisKeyPre.FRIEND_CHAT+RedisKeyPre.MEMBER_CHAT+member.getId()+":"+ RedisKeyPre.HOLDER_CHAT+holder.getId();
					redisService.rightPush(key, imSendLog);

					Map<String, String> extras = new HashMap<String, String>();
					extras.put("cmd", "35");
					extras.put("holderId", holder.getId().toString());
					String saleChannel = holder.getDevice().getSaleChannel();
					String deviceType = holder.getDevice().getDeviceType();
					asyncRequestService.pushAliasMessge(title, member.getMobile(), msgContent, extras,deviceType,saleChannel);
				}else {
					logger.error("流量监控,待推送的imei= {} 对应的monitor(管理员)不存在",imei);
				}
			}else {
				logger.error("签名校验,错误");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 极光推送：通知管理员(监护人暂时不需要) 套餐即将到期
	 * @param imeiList 即将到期的套餐对应的 imei号(代表设备：手表)
	 * @param sign
	 * @param cmd
	 * @param title
     * @param msgContent
     */
	@RequestMapping(value = "/soonExpire",method = RequestMethod.GET)
	public void soonExpire(@RequestParam(value = "imeiList") String imeiList,
							   @RequestParam(value = "sign") String sign,
							   @RequestParam(value = "cmd") int cmd,
							   @RequestParam(value = "title") String title,
							   @RequestParam(value = "msgContent") String msgContent){
 	String params = "wherecom:imeiList="+imeiList;
		logger.debug("签名 prams = {}",params);
		try {
			boolean verify =  RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign));
			if (verify) {
				String[] imeis = imeiList.split(",");
				for (int i = 0; i < imeis.length ; i++) {
					String imei = imeis[i];
					Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imei);
					if (monitor != null) {
						Holder holder = monitor.getHolder();
						Member member = monitor.getMember();
						if (holder==null || member==null)
						{
							logger.error("holder ={},member={}",holder,member);
							continue;
						}

						ImSendLog imSendLog = new ImSendLog();
						imSendLog.setImType(AppDetails.FRIEND_TYPE);
						imSendLog.setUserId(imei);
						String msg = mapToJson(title, msgContent);
						imSendLog.setMsg(msg);
						imSendLog.setMsgTime((new Date()).getTime());
						imSendLog.setMsgType(20);
						imSendLog.setFriendId(imei);
						imSendLogRepository.save(imSendLog);
						String key = RedisKeyPre.FRIEND_CHAT+RedisKeyPre.MEMBER_CHAT+member.getId()+":"+ RedisKeyPre.HOLDER_CHAT+holder.getId();
						redisService.rightPush(key, imSendLog);

						Map<String, String> extras = new HashMap<String,String>();
						extras.put("cmd", "35");
						extras.put("holderId", holder.getId().toString());
						logger.debug("推送开始,管理员为 {},msgContent = {}",member.getMobile(),msgContent);
						//TestPush.testPush(); 测试极光推送
						String saleChannel = holder.getDevice().getSaleChannel();
						String deviceType = holder.getDevice().getDeviceType();
						asyncRequestService.pushAliasMessge(title, member.getMobile(), msgContent, extras,deviceType,saleChannel);
					}else {
						logger.error("即将到期通知,待推送的imei= {} 对应的monitor(管理员)不存在",imei);
					}
				}
			}else {
				logger.error("签名校验,错误");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 短信发送接口
	 * @param imei
	 * @param content
	 * @param sign
     */
	@RequestMapping(value = "/smsNotification",method = RequestMethod.GET)
	public void smsNotification(@RequestParam(value = "imei") String imei,
							   @RequestParam(value = "content") String content,
								@RequestParam(value = "type") Integer type,
							   @RequestParam(value = "sign") String sign
							  ) {
		String params = "wherecom:imei=" + imei;
		logger.debug("签名 prams = {}",params);
		try {
			boolean verify = RSAEncryption.verify(params.getBytes(), Base64.decodeBase64(sign));
			if (verify){
				Monitor monitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imei);
				if (monitor != null) {
					Holder holder = monitor.getHolder();
					Member member = monitor.getMember();
					if (holder==null || member==null){
						logger.error("签名发送短信错误，imei={}，holder={},member={}",imei,holder,member);
						return;
					}

					KinglangSms.sendSmsHttpAndSave(member.getMobile(), content, type);
				}
			}else {
				logger.error("签名校验,错误");
			}
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	private String mapToJson(String title,String content){
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("title", title);
		map.put("content", content);
		map.put("target", false);
		map.put("url", "");
		try {
			String json = mapper.writeValueAsString(map);
			return json;
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return null;
	}
}
