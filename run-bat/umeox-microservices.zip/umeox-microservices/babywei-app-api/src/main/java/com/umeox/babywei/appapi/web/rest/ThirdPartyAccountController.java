package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.bean.Oauth2;
import com.umeox.babywei.bean.SmsType;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.ThirdPartyAccount;
import com.umeox.babywei.repository.MemberExtRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.ThirdPartyAccountRepository;
import com.umeox.babywei.service.MemberService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.Oauth2Utils;
import com.umeox.babywei.util.RandomUtils;
import com.umeox.babywei.util.StringToolUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.token.DefaultAccessTokenRequest;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * 第三方账户 相关接口.
 */
@RestController
@RequestMapping("/api/thirdParty")
public class ThirdPartyAccountController {

    private static final Logger log = LoggerFactory.getLogger(ThirdPartyAccountController.class);

    /*@Autowired
    private ResourceOwnerPasswordResourceDetails resource;*///自动注入 OAuth2认证服务器的地址 oauth2/oauth/token
    @Autowired
    private MemberService memberService;
    @Autowired
    private MemberExtRepository memberExtRepository;
    @Autowired
    private RedisService redisService;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private ThirdPartyAccountRepository thirdPartyAccountRepository;
    @Autowired
    private SettingProperties setting;
    /**
     * 第三方sdk 登录:
     *
     */
    @RequestMapping(value = "/sdkAccessToken",method = RequestMethod.POST)
    public MyResponseBody login(@RequestParam(value = "client_id") String client_id,
                                @RequestParam(value = "client_secret") String client_secret,
                                @RequestParam(value = "third_openid") String third_openid,
                                @RequestParam(value = "third_access_token",required = false) String third_access_token,
                                @RequestParam(value = "third_expires_in",required = false) Long third_expires_in,
                                @RequestParam(value = "type") Integer type,
                                @RequestParam(value ="loginInfo",required = false) String loginInfo

    ) {
        if (StringUtils.isEmpty(client_id)|| StringUtils.isEmpty(client_secret)
                ||StringUtils.isEmpty(third_openid)|| StringUtils.isEmpty(third_expires_in)||
                StringUtils.isEmpty(type))
            return fail(MyHttpStatus._400);

        ThirdPartyAccount thirdPartyAccount = this.getThirdPartyAccount(client_id, type, third_access_token, third_openid, third_expires_in);
        Member member = memberRepository.findOne(thirdPartyAccount.getMember().getId());
        if (member == null) {
            log.error("数据异常");
            return fail(MyHttpStatus._401);
        }
        if (client_id != null && client_id.startsWith("wherecom_watchk2c_api")) {
            client_id = "wherecom_watchk2c_api";
        }
        OAuth2AccessToken accessToken = geAuth2AccessToken(client_id,client_secret,"password", member.getMobile(),member.getPassword());
        if (accessToken==null)
            return fail(MyHttpStatus._401);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("access_token", accessToken.getValue());
        map.put("token_type", accessToken.getTokenType());
        map.put("expires_in", accessToken.getExpiresIn());
        map.put("memberId", member.getId());
        map.put("fileUrl", setting.getFileServerUrl());
        String avatar = !StringUtils.isEmpty(member.getAvatar()) ? (setting.getSiteUrl() + member.getAvatar()) : "";
        map.put("avatar", avatar);
        map.put("alias", member.getMobile());//别名,别名返回给手机端，用来进行极光推送
        map.put("mobile", member.getMobile());
        if (!StringUtils.isEmpty(loginInfo)){//小米还是华为的安卓手机登录
            member.setLoginInfo(loginInfo);
            member.setToken(null);//ios标识位为null
        }else {
            member.setLoginInfo(null);
        }
        memberRepository.save(member);

        Oauth2 oauth2 = new Oauth2();
        oauth2.setClient_id(client_id);
        oauth2.setUser_id(member.getMobile());
        oauth2.setMemberId(member.getId());

        redisService.set(RedisKeyPre.OAUTH2_TOKEN + accessToken.getValue(), oauth2, accessToken.getExpiresIn());
        return success(map);
    }


    /**
     * 绑定手机号码
     * @return
     */
    @RequestMapping(value = "/bindMobile",method = RequestMethod.POST)
    public MyResponseBody bindMobile(@RequestParam(value = "third_openid") String third_openid,
                                     @RequestParam(value = "type") Integer type,
                                     @RequestParam(value = "mobile") String mobile){
        ThirdPartyAccount thirdPartyAccount = thirdPartyAccountRepository.findFirstByOpenIdAndType(third_openid, type);
        if (thirdPartyAccount==null)
            return fail(MyHttpStatus._400);
        Member member = thirdPartyAccount.getMember();
        if (StringToolUtil.isNumber(member.getMobile()))
            return fail("账号已经绑定手机号码，请先解绑后再绑定");
        Member oneByMobile = memberRepository.findOneByMobile(mobile);
        if (oneByMobile!=null)
            return fail("手机号码已被绑定，请更换手机号码");
        member.setMobile(mobile);
        memberRepository.save(member);
        return success();
    }


    /**
     * 绑定第三方账号
     * @return
     */
    @RequestMapping(value = "/bindThirdParty",method = RequestMethod.POST)
    public MyResponseBody bindThirdParty(@RequestParam(value = "third_openid") String third_openid,
                                         @RequestParam(value = "third_access_token") String third_access_token,
                                         @RequestParam(value = "third_expires_in") Long third_expires_in,
                                         @RequestParam(value = "type") Integer type,
                                        @RequestParam(value = "memberId") Long memberId){
        ThirdPartyAccount thirdPartyAccount = thirdPartyAccountRepository.findFirstByOpenIdAndType(third_openid, type);
        if (thirdPartyAccount!=null)
            return fail("该第三方账号已经绑定会员");
        Member member = memberRepository.getOne(memberId);
        if (member==null)
            return fail(MyHttpStatus._400);
        thirdPartyAccount = new ThirdPartyAccount();
        thirdPartyAccount.setMember(member);
        thirdPartyAccount.setThirdToken(third_access_token);
        thirdPartyAccount.setExpire(third_expires_in);
        thirdPartyAccount.setOpenId(third_openid);
        thirdPartyAccount.setType(type);
        thirdPartyAccountRepository.save(thirdPartyAccount);
        return success();
    }


    /**
     * 解绑第三方账号
     * @return
     */
    @RequestMapping(value = "/unbound",method = RequestMethod.POST)
    public MyResponseBody unbound(@RequestParam(value = "third_openid") String third_openid,
                                     @RequestParam(value = "type") Integer type,
                                     @RequestParam(value = "memberId") Long memberId){
        ThirdPartyAccount thirdPartyAccount = thirdPartyAccountRepository.findFirstByOpenIdAndType(third_openid, type);
        if (thirdPartyAccount==null)
            return fail(MyHttpStatus._400);
        Member member = thirdPartyAccount.getMember();
        if (!memberId.equals(member.getId())){
            return fail(MyHttpStatus._400);
        }
         if (StringToolUtil.isNumber(member.getMobile()))//已绑定手机号码
        {
            thirdPartyAccountRepository.delete(thirdPartyAccount);//删除第三方记录
        }else {
             List<ThirdPartyAccount> thirdPartyAccounts = thirdPartyAccountRepository.findAllByMember(member);
            if (thirdPartyAccounts.size()>1){//存在其他的第三方账号,则可以解绑
                thirdPartyAccountRepository.delete(thirdPartyAccount);//删除第三方记录
            }else {
                return fail("请先绑定手机号码或者其他第三方，再解绑");
            }
        }
        thirdPartyAccountRepository.save(thirdPartyAccount);
        return success();
    }

    /**
     * 更改手机号码(不允许解绑手机号码)
     */
    @RequestMapping(value = { "/changeMobile" }, method = { RequestMethod.POST })
    public MyResponseBody changeMobile(@RequestParam(value = "mobile") String mobile,
                                       @RequestParam(value = "newMobile") String newMobile,
                                         @RequestParam(value = "code") String code) {
        String mobileCode = (String) redisService.get(mobile+"-"+ SmsType.FORGET.name());
        if (mobileCode == null) {
            return fail("sys.code.invalid");
        }
        if (!mobileCode.toString().equals(code)) {
            return fail("sys.code.error");
        }
        //标记该验证码已经被使用了
//        smsResultService.updateSmsResultStatus(mobile,code);
        Member member = memberRepository.findOneByMobile(mobile);
        if (member != null ) {
            member.setMobile(newMobile);
        }else {
           return fail(MyHttpStatus._400);
        }
        memberRepository.save(member);
        return success(member.getMobile());//修改成功，需要返回别名，注册到极光
    }



    /**
     *
     * 此种为 客户端得到第三方应用授权成功后，发送请求到服务器(服务器内部获取第三方的AccessToken)
     */
    @RequestMapping(value = "/webAccessToken",method = RequestMethod.POST)
    public MyResponseBody accessToken(@RequestParam(value = "client_id") String client_id,
                                      @RequestParam(value = "client_secret") String client_secret,
                                      @RequestParam(value = "grant_type") String grant_type,
                                      @RequestParam(value = "type") int type,
                                      @RequestParam(value = "code") String code
                                      ) {
        Map<String, String> thirdLogin = ThirdAppService.thirdLogin(code, type);
        if (thirdLogin != null) {//登录成功
            String third_access_token = thirdLogin.get("access_token");
            String third_openid = thirdLogin.get("openid");
            String third_expires_in = thirdLogin.get("expires_in");
            String third_refresh_token = thirdLogin.get("refresh_token");

            ThirdPartyAccount thirdPartyAccount = getThirdPartyAccount(client_id, type, third_access_token, third_openid, Long.parseLong(third_expires_in));

            Member member = memberRepository.findOne(thirdPartyAccount.getMember().getId());
            if (member == null) {
                log.error("数据异常");
                return fail(MyHttpStatus._401);
            }
            if (client_id != null && client_id.startsWith("wherecom_watchk2c_api")) {
                client_id = "wherecom_watchk2c_api";
            }
            OAuth2AccessToken accessToken = geAuth2AccessToken(client_id,client_secret,grant_type, member.getMobile(),member.getPassword());
            if (accessToken==null)
                return fail(MyHttpStatus._401);
            String token = accessToken.getValue();
            int expiresIn = accessToken.getExpiresIn();
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("access_token", token);
            map.put("token_type", accessToken.getTokenType());
            map.put("expires_in", expiresIn);
            map.put("alias",  member.getMobile());//别名返回给手机端，用来进行极光推送
            map.put("memberId", member.getId());

            Oauth2 oauth2 = new Oauth2();
            oauth2.setClient_id(client_id);
            oauth2.setUser_id(member.getMobile());
            oauth2.setMemberId(member.getId());

            redisService.set(RedisKeyPre.OAUTH2_TOKEN + token, oauth2, expiresIn);
            return success(map);
        } else {
            //登录失败
          return   fail(MyHttpStatus._602);
        }
    }



    /*@RequestMapping(value = "/test",method = RequestMethod.POST)
    public MyResponseBody test(@RequestParam(value = "client_id") String client_id,
                               @RequestParam(value = "client_secret") String client_secret,
                               @RequestParam(value = "grant_type") String grant_type)
    {
        OAuth2AccessToken oAuth2AccessToken = geAuth2AccessToken(client_id, client_secret, grant_type, "15019271280", "e10adc3949ba59abbe56e057f20f883e");
        return success(oAuth2AccessToken);
    }*/

    /**
     * type： 指第三方应用类别：微信、qq、微博
     * 第三方登录认证
     * @return
     */
    private ThirdPartyAccount getThirdPartyAccount(String client_id, int type, String third_access_token, String third_openid, Long third_expires_in) {
        ThirdPartyAccount thirdPartyAccount = thirdPartyAccountRepository.findFirstByOpenIdAndType(third_openid, type);
        if (thirdPartyAccount == null)//(首次登录）
        {
            Member member = new Member();
            member.setClientId(client_id);
            String prefix = "";
            if (type==0)
                prefix = "weixin_";
            else if (type==1)
                prefix = "qq_";
            else
                prefix = "weibo_";
//            String loginName = prefix  + RandomUtils.generateString(8);//随机生成登录用户名(在扩展的时候，可以使用这个作为用户名登录)
            String password = DigestUtils.md5DigestAsHex(RandomUtils.generateString(8).getBytes());
            member.setPassword(password);//产生一个密码
            memberRepository.save(member);

            member.setMobile(prefix+member.getId());//确定mobile字段唯一
            member.setNickName(member.getMobile());
//            member.setLoginName(member.getMobile());
            memberRepository.save(member);

            thirdPartyAccount = new ThirdPartyAccount();
            thirdPartyAccount.setOpenId(third_openid);
            thirdPartyAccount.setThirdToken(third_access_token);
            thirdPartyAccount.setType(type);
            thirdPartyAccount.setExpire(third_expires_in);
            thirdPartyAccount.setMember(member);
            thirdPartyAccountRepository.save(thirdPartyAccount);
            return thirdPartyAccount;
        } else {//更新失效时间
            thirdPartyAccount.setExpire(third_expires_in);
            thirdPartyAccountRepository.save(thirdPartyAccount);
            return thirdPartyAccount;
        }
    }


    /**
     * OAuth2.0 认证
     * @return
     */
    private OAuth2AccessToken geAuth2AccessToken(String client_id,String client_secret, String grant_type, String loginName,String password) {
        ResourceOwnerPasswordResourceDetails resource = Oauth2Utils.getDetails();
        resource.setClientId(client_id);
        resource.setClientSecret(client_secret);
        resource.setGrantType(grant_type);
        resource.setUsername(loginName);
        resource.setPassword(password);
        ResourceOwnerPasswordAccessTokenProvider provider = new ResourceOwnerPasswordAccessTokenProvider();
        try {
            OAuth2AccessToken accessToken = provider.obtainAccessToken(resource, new DefaultAccessTokenRequest());
            return accessToken;
        }catch (Exception e){
            log.error("OAuth2AccessToken获取失败!e = {}",e.getMessage());
            return null;
        }finally {
            resource = null;//释放资源
        }
    }





}
