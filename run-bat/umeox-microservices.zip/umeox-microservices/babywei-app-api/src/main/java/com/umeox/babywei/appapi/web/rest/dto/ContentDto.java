package com.umeox.babywei.appapi.web.rest.dto;

import java.util.List;


public class ContentDto {

	private Long id;
	
	private String title;

	private String img;
	
	private String des;
	
	private Long pTimestamp;
	
	private Integer type;
	
	private String url;
	
	private List<ContentDto> sub;
	
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getDes() {
		return des;
	}

	public void setDes(String des) {
		this.des = des;
	}

	public Long getpTimestamp() {
		return pTimestamp;
	}

	public void setpTimestamp(Long pTimestamp) {
		this.pTimestamp = pTimestamp;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public List<ContentDto> getSub() {
		return sub;
	}

	public void setSub(List<ContentDto> sub) {
		this.sub = sub;
	}
	
}
