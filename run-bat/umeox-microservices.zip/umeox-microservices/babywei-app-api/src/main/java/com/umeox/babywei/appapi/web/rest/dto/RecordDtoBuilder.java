package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Record;
import com.umeox.babywei.util.DateTimeUtils;



public class RecordDtoBuilder {

	public RecordDto build(Record record) {
		SettingProperties setting = (SettingProperties)ApplicationSupport.getBean("settingProperties");
		RecordDto dto = new RecordDto();
		dto.setAddress(record.getAddress());
		dto.setRecordId(record.getId());
		dto.setLatitude(record.getLatitude());
		dto.setLongitude(record.getLongitude());
		dto.setLength(record.getLength());
		dto.setPath(setting.getSiteUrl() + record.getPath());
		dto.setDate(DateTimeUtils.getFormatDate(record.getCreateDate(), DateTimeUtils.FULL_DATE_FORMAT));
		return dto;
	}

	public List<RecordDto> build(List<Record> records) {
		List<RecordDto> dtos = new ArrayList<RecordDto>();
		for (Record record : records) {
				dtos.add(build(record));
		}
		return dtos;
	}

}
