package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.ChatDto;
import com.umeox.babywei.appapi.web.rest.dto.ChatDtoBuilder;
import com.umeox.babywei.appapi.web.rest.dto.ChatFriendDto;
import com.umeox.babywei.appapi.web.rest.dto.ChatFriendDtoBuilder;
import com.umeox.babywei.appapi.web.rest.dto.ImSendLogDto;
import com.umeox.babywei.appapi.web.rest.dto.ImSendLogDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.bean.Notice;
import com.umeox.babywei.bean.RedisWetalkCommand;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.conf.RedisKey;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Device.ActivityStatus;
import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.ImGroup;
import com.umeox.babywei.domain.ImGroupMember;
import com.umeox.babywei.domain.ImRelation;
import com.umeox.babywei.domain.ImSendLog;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.repository.DeviceRepository;
import com.umeox.babywei.repository.FamilyNumberRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.ImGroupMemberRepository;
import com.umeox.babywei.repository.ImGroupRepository;
import com.umeox.babywei.repository.ImRelationRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.MonitorRepository;
import com.umeox.babywei.service.AsyncRequestService;
import com.umeox.babywei.service.ChatService;
import com.umeox.babywei.service.CommonService;
import com.umeox.babywei.service.ImGroupService;
import com.umeox.babywei.service.ImRelationService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;

/**
 * 微话饼
 */
@RestController
@RequestMapping("/api/chat")
public class ChatController {
	
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private ImGroupRepository imGroupRepository;
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private ChatService chatService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ImRelationService ImRelationService;
	@Autowired
	private ImGroupMemberRepository imGroupMemberRepository;
	@Autowired
	private DeviceRepository deviceRepository;
	@Autowired
	private ImRelationRepository imRelationRepository;
	@Autowired
	private ImRelationService imRelationService;
	@Autowired
	private ImGroupService imGroupService;
	@Autowired
	private RedisQueueService redisQueueService;
	@Autowired
	private RedisService redisService;
	@Autowired
	private AsyncRequestService asyncRequestService;
	@Autowired
	private FamilyNumberRepository familyNumberRepository;
	
	/**
	 * 聊天列表-仅微话饼
	 */
	@DataPermission
	@RequestMapping(value = "/list", method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody list(@RequestParam(value = "memberId") Long memberId){
		//1.获取监护列表
		List<Monitor> monitorList = monitorRepository.findByMemberIdAndDeviceType(memberId, AppDetails.WE_TALK_DEVICE_TYPE);
		Collection<String> holderIdList = new ArrayList<String>();
		for (Monitor monitor : monitorList) {
			holderIdList.add(AppDetails.GROUP_PRE + monitor.getHolder().getId());
		}
		//2.获取家庭群组
		List<ImGroup> imGroupList = imGroupRepository.findByGroupIdIn(holderIdList);
		List<ChatDto> respList = ChatDtoBuilder.builder(monitorList, imGroupList);
		return success(respList);
	}
	
	/**
	 * 发送聊天消息
	 */
	@DataPermission(value = DataPermissionType.CHAT_FOLLOWER)
	@RequestMapping(value = "/sendInfo", method = {RequestMethod.POST})
	public MyResponseBody sendInfo(@RequestParam(value = "memberId") Long memberId,
									@RequestParam(value = "friendId") String friendId,
									@RequestParam(value = "type") Integer type,
									@RequestParam(value = "msg") String msg,
									@RequestParam(value = "msgTime") Long msgTime,
									@RequestParam(value = "msgType",required = false,defaultValue = "1") Integer msgType){
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404);
		}
		ImSendLog imSendLog = new ImSendLog();
		imSendLog.setImType(type);
		imSendLog.setUserId(member.getMobile());
		imSendLog.setMsg(msg);
		imSendLog.setMsgTime(msgTime);
		//imSendLog.setMsgType(ImSendLog.MSG_TYPE_FILE);
		imSendLog.setMsgType(msgType);
		
		if (type.equals(AppDetails.FRIEND_TYPE)) {//a.私聊
			Holder holder = holderRepository.findOne(Long.parseLong(friendId));
			if (holder == null) {
				return fail(MyHttpStatus._404);
			}
			imSendLog.setFriendId(holder.getImei());
			chatService.friendChat(imSendLog);
			if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
				Map<String,String> ext = new HashMap<String,String>();
				ext.put("syncFlag", Push.K3_DEVICE_CHAT  + "");
				ext.put("from", member.getMobile());
				String key = RedisKeyPre.FRIEND_CHAT+RedisKeyPre.HOLDER_CHAT+holder.getId()+":"+RedisKeyPre.MEMBER_CHAT+member.getId();
				redisService.rightPush(key, imSendLog);
				ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(),ext));
			}else {
				this.sendChatInfo(imSendLog);
			}
		}else {//b.群聊

			ImGroup imGroup = imGroupRepository.findOneByGroupId(friendId);
			if (imGroup == null) {
				return fail(MyHttpStatus._404);
			}
			imSendLog.setFriendId(friendId);
			FamilyNumber familyNumber = null;
			if (ApplicationSupport.isChinaEnv()) {
				familyNumber = familyNumberRepository.findOneByMobileAndHolderId(member.getMobile(), Long.parseLong(friendId.substring(2)));
			}else {
				familyNumber = familyNumberRepository.findOneByEmailAndHolderId(member.getMobile(), Long.parseLong(friendId.substring(2)));
			}
			//imSendLog.setUserName(member.getNickName());
			imSendLog.setUserName(familyNumber.getName());
			if (!StringUtils.isEmpty(member.getAvatar())) {
				imSendLog.setUserAvatar(member.getAvatar());
			}
			//1.数据库保存群聊消息
			chatService.groupChat(imSendLog);
			//2.下发命令给设备
			this.sendChatInfo(imSendLog);
			//3.群聊消息放入队列中，供关注者读取
			//redisService.rightPush(RedisKeyPre.GROUP_CHAT+imSendLog.getId(), imSendLog);
			redisQueueService.trimList(RedisKeyPre.GROUP_CHAT+friendId, imSendLog);
			//4.推送
			Map<String, String> extras = new HashMap<String, String>();
			extras.put("cmd", Push.IM_GROUP_CHAT + "");
			extras.put("from", member.getMobile());
			extras.put("to", friendId);

			String deviceType = "5";// AppDetails.WETALK_CLIENT_ID || AppDetails.WHERECOM_WETALK_CLIENT_ID
			String saleChannel = null;
			asyncRequestService.pushTagMessge(imGroup.getGroupName(),friendId, ApplicationSupport.getMessageByEnv("sys.famliy.group.message"), extras ,
					deviceType,saleChannel);
		}
		Map<String,Long> map = new HashMap<String, Long>();
		//map.put("messageId", imSendLog.getId());
		map.put("messageId", imSendLog.getCreateDate().getTime());
		return success(map);
	}
	
	
	private void sendChatInfo(ImSendLog imSendLog){//设备消息队列
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("cmd", RedisWetalkCommand.CMD_CHAT);
		map.put("userId", imSendLog.getUserId());
		map.put("friendId", imSendLog.getFriendId());
		map.put("type", imSendLog.getImType());
		map.put("msgType", imSendLog.getMsgType());
		map.put("msg", imSendLog.getMsg());
		map.put("msgTime", imSendLog.getMsgTime());
		redisService.rightPush(RedisKey.QUE_WETALK_SOCKET_IM, map);
	}
	/**
	 * 获取聊天消息
	 */
	@DataPermission(value = DataPermissionType.CHAT_FOLLOWER)
	@RequestMapping(value = "/getInfo", method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody getInfo(@RequestParam(value = "memberId") Long memberId,
									@RequestParam(value = "friendId") String friendId,
									@RequestParam(value = "type") Integer type,
									@RequestParam(value = "messageId") Long messageId){
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404);
		}
		List<ImSendLog> list = new ArrayList<ImSendLog>();
		if (type.equals(AppDetails.FRIEND_TYPE)) {//获取私聊消息
			Holder holder = holderRepository.findOne(Long.parseLong(friendId));
			if (holder == null) {
				return fail(MyHttpStatus._404);
			}
			String key = null;
			if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
				key = RedisKeyPre.FRIEND_CHAT+RedisKeyPre.MEMBER_CHAT+member.getId()+":"+RedisKeyPre.HOLDER_CHAT+holder.getId();
			}else {
				key = RedisKeyPre.FRIEND_CHAT + member.getId() + ":" + holder.getId();
			}
			
			list = commonService.findByMessageIdFlag2(key, messageId);
		} else {//获取群聊消息
			//1.如果messageId为空，判断此用户入群的时间来获取聊天消息，消息时间 > 入群时间
			String key = RedisKeyPre.GROUP_CHAT + friendId;
			if (StringUtils.isEmpty(messageId) || messageId < 1) {//判断入群时间
				Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, Long.parseLong(friendId.substring(2)));
				if (monitor != null) {
					Long createDate = monitor.getCreateDate().getTime();
					list = commonService.findGroupMessageByCreateDate2(key, createDate);
				}
			} else {
				list = commonService.findGroupMessageById2(key, messageId);
			}
		}
		
		List<ImSendLogDto> respList = ImSendLogDtoBuilder.build(list,false,false);
		return success(respList);
	}
	
	
	/**
	 * 获取通知消息列表
	 */
	@DataPermission
	@RequestMapping(value = "/getNotice", method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody getNotice(@RequestParam(value = "memberId") Long memberId,
									@RequestParam(value = "messageId") Long messageId){
		/*Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404);
		}*/
		String key = RedisKeyPre.NOTICE + memberId;
		List<Notice> respList = commonService.findNoticeByMessageIdFlag(key, messageId);
		return success(respList);
	}
	
	/**
	 * 获取设备好友及群组列表-仅微话饼
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/friend/list", method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody friendList(@RequestParam(value = "holderId") Long holderId){
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		List<ImRelation> imRelationList = ImRelationService.findDeviceFriendByUserId(holder.getImei());
		List<ImGroupMember> groupMemberList = imGroupMemberRepository.findByUserId(holder.getId());
		List<ChatFriendDto> respList = ChatFriendDtoBuilder.builder(imRelationList, groupMemberList);
		
		return success(respList);
	}
	
	/**
	 * 退出群组/删除好友-仅微话饼
	 * @friendId relation.id or uuid
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/friend/quit", method = {RequestMethod.POST})
	public MyResponseBody friendQuit(@RequestParam(value = "holderId") Long holderId,
										@RequestParam(value = "type") Integer type,
										@RequestParam(value = "friendId") String friendId){
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		if (type.equals(AppDetails.FRIEND_TYPE)) {//删除好友
			ImRelation imRelation = imRelationRepository.findOne(Long.parseLong(friendId));
			if (imRelation == null) {
				return fail(MyHttpStatus._404);
			}
			if (!holder.getImei().equals(imRelation.getUserId())) {//判断是否为好友
				return fail(MyHttpStatus._404);
			}
			//1.删除操作
			imRelationService.delete(imRelation);
			
			//2.下发命令
			Holder friendHolder = holderRepository.findFirstByImei(imRelation.getFriendId());
			List<Mark> markList = new ArrayList<Mark>();
			markList.add(new Mark(friendHolder.getId(), RedisWetalkCommand.CMD_FRIEND));
			markList.add(new Mark(holder.getId(), RedisWetalkCommand.CMD_FRIEND));
			redisQueueService.wetalkHandleMarkList(markList);
			
			Monitor friendMonitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(imRelation.getFriendId());
			Member friendMember = friendMonitor.getMember();
			String title = null;
			if (ApplicationSupport.isChinaEnv()) {
				title = holder.getName()+"已取消"+friendHolder.getName()+"的好友关系";
			}else {
				title = holder.getName()+" canceled relationship with "+friendHolder.getName();
			}
			
			//3.添加通知
			/*String key = RedisKeyPre.NOTICE + friendMember.getId();
			Notice notice = new Notice();
			Long time = System.currentTimeMillis();
			notice.setMessageId(time);
			notice.setNoticeTime(time);
			notice.setNoticeContent(title);
			redisService.rightPush(key, notice);*/
			
			//4.推送
			Map<String, String> extras = new HashMap<String, String>();
			extras.put("cmd", Push.NOTIFICATION + "");
			if (!StringUtils.isEmpty(friendMember.getToken())) {
				asyncRequestService.pushIosMessge(friendMember.getMobile(), title, extras, holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
			}else {
				asyncRequestService.pushAndroidMessge(friendMember.getMobile(), title, extras, holder.getDevice().getDeviceType(), holder.getDevice().getSaleChannel());
			}
		}else {//退出群组
			//群员个数少于3个群组解散
			ImGroupMember imGroupMember = imGroupMemberRepository.findOneByImGroupGroupIdAndUserId(friendId, holder.getId());
			if (imGroupMember == null) {
				return fail(MyHttpStatus._404);
			}
			List<Long> holderIdList = imGroupService.quit(imGroupMember);
			ImGroup imGroup= imGroupMember.getImGroup();
			List<Monitor> monitorList = monitorRepository.findByIsAdminTrueAndHolderIdIn(holderIdList);
			holderIdList.add(holder.getId());
			redisQueueService.redisQuitGroup(holderIdList);
			String title = null;
			if (ApplicationSupport.isChinaEnv()) {
				title = imGroup.getGroupName()+"好友群组已解散";
			}else {
				title = imGroup.getGroupName()+" friend group has been dismissed";
			}
			
			for (Monitor monitor : monitorList) {
				//添加通知消息
			/*	String key = RedisKeyPre.NOTICE + monitor.getMember().getId();
				Notice notice = new Notice();
				Long time = System.currentTimeMillis();
				notice.setMessageId(time);
				notice.setNoticeTime(time);
				notice.setNoticeContent(title);
				redisService.rightPush(key, notice);*/
				
				//添加推送
				Map<String, String> extras = new HashMap<String, String>();
				extras.put("cmd", Push.NOTIFICATION +"");
				if (!StringUtils.isEmpty(monitor.getMember().getToken())) {
					asyncRequestService.pushIosMessge(monitor.getMember().getMobile(), title, extras, holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
				} else{
					asyncRequestService.pushAndroidMessge(monitor.getMember().getMobile(), title, extras,holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
				}
			}
		}
		return success();
	}
	
	/**
	 * 为设备添加好友-仅微话饼
	 * **设备还没设置名称--好友名称为空
	 */
	@DataPermission(value = DataPermissionType.HOLDER_ADMIN)
	@RequestMapping(value = "/friend/add", method = {RequestMethod.POST})
	public MyResponseBody friendAdd(@RequestParam(value = "holderId") Long holderId,
									@RequestParam(value = "bindCode") String bindCode){
		Holder holder = holderRepository.findOne(holderId);
		Device device = deviceRepository.findOneByBindCode(bindCode);
		//1.传入的参数有误
		if (holder == null || device == null) {
			return fail(MyHttpStatus._404);
		}
		//2.设备类型不符
		if (!device.getDeviceType().equals(AppDetails.WE_TALK_DEVICE_TYPE)) {
			return fail(MyHttpStatus._404_DEVICE_TYPE_UNMATCH);
		}
		//3.该设备没有激活
		if (!device.getActivityStatus().equals(ActivityStatus.ACTIVITY)) {
			return fail(MyHttpStatus._404_DEVICE_INACTIVE);
		}
		//4.好友已添加
		ImRelation imRelation = imRelationRepository.findOneByUserIdAndFriendId(holder.getImei(), device.getHolder().getImei());
		if (imRelation != null) {
			return fail(MyHttpStatus._300_FRIEND);
		}
		//5.不能添加自己为好友
		if (holder.getDevice().getBindCode().equals(bindCode)) {
			return fail(MyHttpStatus._404);
		}
		List<Mark> markList = ImRelationService.add(holder, device.getHolder());
		redisQueueService.wetalkHandleMarkList(markList);
		
		Monitor friendMonitor = monitorRepository.findFirstByIsAdminTrueAndHolderImei(device.getImei());
		Member friendMember = friendMonitor.getMember();
		
		String msgContent = null;
		if (ApplicationSupport.isChinaEnv()) {
			msgContent = holder.getName()+"和"+device.getHolder().getName()+"成为好友";
		}else {
			msgContent = holder.getName()+" and "+device.getHolder().getName()+" now become friends";
		}
		//添加通知消息
		/*String key = RedisKeyPre.NOTICE + friendMember.getId();
		Notice notice = new Notice();
		Long time = System.currentTimeMillis();
		notice.setMessageId(time);
		notice.setNoticeTime(time);
		notice.setNoticeContent(msgContent);
		redisService.rightPush(key, notice);*/
		
		redisQueueService.insertPrivateChatListForNotify(device.getHolder().getId(),friendMember.getId(),"Admin",msgContent,System.currentTimeMillis());
		
		//推送
		Map<String, String> extras = new HashMap<String, String>();
		extras.put("cmd", Push.FRIEND + "");
		extras.put("holderId",holderId + "");
		if (StringUtils.isEmpty(friendMember.getToken())) {
			asyncRequestService.pushAndroidMessge(friendMember.getMobile(), msgContent, extras, holder.getDevice().getDeviceType(), holder.getDevice().getSaleChannel());
		} else {
			asyncRequestService.pushIosMessge(friendMember.getMobile(), msgContent, extras, holder.getDevice().getDeviceType(),holder.getDevice().getSaleChannel());
		}
		return success();
	}
}
