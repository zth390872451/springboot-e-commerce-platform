package com.umeox.babywei.appapi.web.rest;


import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.web.rest.dto.ImSendLogDto;
import com.umeox.babywei.appapi.web.rest.dto.ImSendLogDtoBuilder;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.RedisKey;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.domain.ImSendLog;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.repository.MonitorRepository;
import com.umeox.babywei.service.CommonService;
import com.umeox.babywei.service.ImService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


/**
 * @Desc 语聊
 * @author umeox
 * @version II
 */
@RestController
@RequestMapping("/api/im")
public class ImController {
	
	@Autowired
	private ImService imService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private RedisService redisService;
	
	/**
	 * 列表
	 */
	@DataPermission
	@RequestMapping(value = "/message/list",method = RequestMethod.GET)
	public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
								@RequestParam(value = "holderId") Long holderId,
								@RequestParam(value = "messageId",required = false) Long messageId){
		
		Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, holderId);
		if (monitor == null) {
			return fail(MyHttpStatus._404);
		}
		String key = RedisKeyPre.IM_USERNAME + monitor.getMember().getMobile() + ":" + monitor.getHolder().getImei();
		List<ImSendLog> list = commonService.findByMessageIdFlag(key, messageId);
		boolean isOss = false;
		if (AppDetails.DEVICE_K7_SERIES.contains(monitor.getDeviceType())){//k7系列设备
			isOss = true;
		}
		List<ImSendLogDto> respList = ImSendLogDtoBuilder.build(list,false,isOss);
		
		return success(respList);
	}
	
	
	/**
	 * 发送
	 */
	@DataPermission
	@RequestMapping(value = "/message/send",method = {RequestMethod.POST,RequestMethod.GET})
	public MyResponseBody send(@RequestParam(value = "memberId") Long memberId,
							   @RequestParam(value = "holderId") Long holderId,
							   @RequestParam(value = "msgType") Integer msgType,
							   @RequestParam(value = "msg") String msg,
							   @RequestParam(value = "msgTime") Long msgTime){

		//代表用户、设备都存在并设备已激活并用户为设备的关注者
		Monitor monitor = monitorRepository.findFirstByMemberIdAndHolderId(memberId, holderId);
		if (monitor == null) {
			return fail(MyHttpStatus._404);
		}
		
		ImSendLog sendLog = new ImSendLog();
		sendLog.setUserId(monitor.getMember().getMobile());
		sendLog.setFriendId(monitor.getHolder().getImei());
		sendLog.setMsgType(msgType);
		sendLog.setMsg(msg);
		sendLog.setMsgTime(msgTime);
		Map<String, Object> object = imService.save(sendLog,monitor.getHolder());
		redisService.rightPush(RedisKey.QUE_API2_SOCKET_IM, object);
		
		Map<String,Long> map = new HashMap<String, Long>();
		map.put("messageId", sendLog.getId());
		return success(map);
	}
}