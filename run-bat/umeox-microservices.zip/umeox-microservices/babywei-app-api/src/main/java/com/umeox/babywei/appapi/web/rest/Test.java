package com.umeox.babywei.appapi.web.rest;


import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.service.HolderScheduleService;
import com.umeox.babywei.service.PositionService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.service.RemoteService;
import com.umeox.babywei.support.MyResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;

import static com.umeox.babywei.support.MyResponseBuilder.success;

@RestController
@RequestMapping( { "/api" })
public class Test {
	
	@Autowired
	private RedisService redisService;
	
	@Autowired
	private PositionService positionService;
	
	@Autowired
	private HolderScheduleService holderScheduleService;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired private RemoteService remoteService;



	private static Long lastCreateInstanceTime = 0l;




	/**
	 * 需求：一个APP应用A的用户a_aa关注了 设备类型为1 的手表watch_01,设备类型为2 的手表 watch_02和设备类型为3的手表watch_03等等。
	 *  需要在关注的设备列表中显示手表 watch_01、watch_02、watch_03(其他的则不显示)
	 *
	 *  以app的包名为键，需要现实的设备类型列表为值
	 * function：
	 * @return
     *//*
	public List<String> showDeviceList(String appId){

		//更新instance策略，每间隔一个小时更新一次
		if(System.currentTimeMillis() > (lastCreateInstanceTime + 3600*1000)){
			createInstanceMap();
		}

		Map<String,Object> map = new HashMap<>();

		return null;
	}



	public static void main(String[] args) {
		String json = "[\n" +
				"  \"语文\",\n" +
				"  \"音乐\",\n" +
				"  \"英语\",\n" +
				"  \"音乐\",\n" +
				"  \"\",\n" +
				"  \"\",\n" +
				"  \"\",\n" +
				"  \"\"\n" +
				"]4";
		List<String> strings = JsonUtils.toObject(json, List.class);
		System.out.println("strings = " + strings.get(0));
	}*/
	//此接口做为阿里云SLB健康检查接口，请勿修改
	@RequestMapping(value = "/test")
	public MyResponseBody test() throws ParseException{
		//此接口做为阿里云SLB健康检查接口，请勿修改
		Long current = System.currentTimeMillis();
		String imei = "868281020000060";
		// 缓存imei读取设备
		String key = RedisKeyPre.HOLDER_IMEI_KEY + String.valueOf(imei);
		Object ob= redisService.get("jpushAccount");

		return success(ob);
	}
	//此接口做为阿里云SLB健康检查接口，请勿修改

	/*@RequestMapping(value = "/redis")
	public MyResponseBody redis(){
		redisService.set("xx", "val");
		String string = (String)redisService.get("xx");
		Integer mapValue = (Integer) redisService.hget(RedisKeyPre.USER_HOLDER+"user:holder:102679", RedisKey.SYNC_DATA_FLAG_KEY);
		return success(mapValue);
	}
	
	@RequestMapping(value = "/demo")
	public MyResponseBody demo() throws ParseException{
		//remoteService.getSim("777777777777771", "777777777777771");
		BaseSim sim = remoteService.getSim("777777777777771");
		return success(sim.getSim());
	}
	
	private final Map<String, DeferredResult<String>> userRequests = new ConcurrentHashMap<String, DeferredResult<String>>();
	
	@RequestMapping("/github")
    public DeferredResult<String> github(@RequestParam(value = "imei") String imei) throws ExecutionException, InterruptedException {
        final DeferredResult<String> deferredResult = new DeferredResult<String>(2000 * 10L ,"ok1");
        //deferredResult.setResult("ok");
        userRequests.put(imei, deferredResult);
        System.out.println("2222222222");
        return deferredResult;
    }
	
	@RequestMapping("/ct")
	public String ct(){
		Holder holder = holderRepository.findOne(27967L);
		boolean flag = holderScheduleService.isDuringClass(holder);
		System.out.println(flag);
		return "ok";
	}
	
	@RequestMapping("/github2")
    public String github2(@RequestParam(value = "imei") String imei) throws ExecutionException, InterruptedException {
        //deferredResult.setResult("ok");
		DeferredResult<String> deferredResult = this.userRequests.get(imei);
		deferredResult.setResult("haha");
		System.out.println("11111");
        return "ok";
    }
	 
	@RequestMapping(value = "/jpush")
	public MyResponseBody jpush(@RequestParam(value = "mobile") String mobile){
		Map<String, String> extras = new HashMap<String, String>();
		extras.put("cmd", "1");
		PushClient.sendPushAndroidNotification(mobile, "api测试--clientId", extras, "umeox_babywei_app_api");
		return success("ok");
	}
	

	@RequestMapping(value = "/ios")
	public MyResponseBody iso(String token,String cmd,String messageId,String holderId,String mobile){
		System.out.println("cmd:"+cmd+";token:"+token+";messageId:"+messageId+";holderId:"+holderId+";mobile:"+mobile);
		//消息推送
		Map<String, String> tmpParam = new HashMap<String, String>();
		tmpParam.put("cmd", cmd);
		tmpParam.put("messageId",messageId);
		tmpParam.put("holdId", holderId);

		ApnsSend.sendMsg(token, tmpParam,"testxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",mobile);
		return success("ok");
	}

	@RequestMapping(value = "/stepInfo")
	public MyResponseBody step(int step, double height,double weight){
		Map<String, String> tmpParam = new HashMap<String, String>();
		tmpParam.put("步数：",""+step+"(步)");
		tmpParam.put("身高：",""+height+"(厘米)");
		tmpParam.put("体重：",""+weight+"(千克)");
		if (!StringUtils.isEmpty(step) && !StringUtils.isEmpty(height)) {
			double distance = StepUtils.getDistance(height);//单位：米
			double m = distance * step / 100.0;
			tmpParam.put("距离：", "" + (int)m + "(米)");
			double km = m / 1000.0;
			if (!StringUtils.isEmpty(height)) {
				tmpParam.put("卡路里：",""+StepUtils.getKcal(weight, km)+"(千卡)");
			}
		}
		return success(tmpParam);
	}*/
	/*public static void main(String[] args) throws IOException {
		String endpoint = "oss-cn-hangzhou.aliyuncs.com";
	    String accessKeyId = "Wc8lFcAf3WuGtPSE";
	    String accessKeySecret = "mDBzhccybrvpkMFFnNFShRPxRe7gJm";

	    String bucketName = "babywei-wetalk";
	    String key = "123456.txt";
		OSSClient client = new OSSClient(endpoint, accessKeyId, accessKeySecret);

        try {

            File file = new File("G://test.txt");
            client.putObject(bucketName, key, file);
            System.out.println("end..........");
            System.out.println("Uploading a new object to OSS from a file\n");
            client.putObject(new PutObjectRequest(bucketName, key, createSampleFile()));

            System.out.println("Downloading an object");
            OSSObject object = client.getObject(new GetObjectRequest(bucketName, key));
            System.out.println("Content-Type: "  + object.getObjectMetadata().getContentType());
            displayTextInputStream(object.getObjectContent());

        } catch (OSSException oe) {
            System.out.println("Caught an OSSException, which means your request made it to OSS, "
                    + "but was rejected with an error response for some reason.");
            System.out.println("Error Message: " + oe.getErrorCode());
            System.out.println("Error Code:       " + oe.getErrorCode());
            System.out.println("Request ID:      " + oe.getRequestId());
            System.out.println("Host ID:           " + oe.getHostId());
        } catch (ClientException ce) {
            System.out.println("Caught an ClientException, which means the client encountered "
                    + "a serious internal problem while trying to communicate with OSS, "
                    + "such as not being able to access the network.");
            System.out.println("Error Message: " + ce.getMessage());
        } finally {

            client.shutdown();
        }
	}
	 private static File createSampleFile() throws IOException {
	        File file = File.createTempFile("oss-java-sdk-", ".txt");
	        file.deleteOnExit();

	        Writer writer = new OutputStreamWriter(new FileOutputStream(file));
	        writer.write("abcdefghijklmnopqrstuvwxyz\n");
	        writer.write("0123456789011234567890\n");
	        writer.close();

	        return file;
	    }*/
	/*@RequestMapping(value = "/iosPush")
	public MyResponseBody iosPush(String token,String cmd,String messageId,String holderId,String mobile){
		Map<String, String> extras = new HashMap<String, String>();
		extras.put("cmd", Push.IM_GROUP_CHAT + "");
		//extras.put("holderId", "27971");
		extras.put("from", "13692105428");
		extras.put("to", "gf27984");
		//extras.put("groupId", "5");
		//aliases.add("13760280656");
		PushClient.sendTagPushMessage("自定义和通知消息测试","gf107677", "自定义和通知消息测试", extras,"mykidfit_wetalk_app_api");
		//PushClient.sendTitlePushMessage("ios自定义和通知消息测试1","13760280656", "ios自定义和通知消息测试3", extras,"mykidfit_wetalk_app_api");
		return success("ok");
	}*/

	//根据定位凭证重新定位
	/*@RequestMapping(value = "/test/wifiLocation")
	public MyResponseBody wifiLocation(Long positionId, String strDate) {

		Position p = positionService.findOnePosition(positionId, DateTimeUtils.parseString2Date(strDate, null));
		Map res = new HashMap();

		if (p != null) {
			//LBS定位
			Position lbsPostion = new Position();
			lbsPostion.setLocationMode("1");
			lbsPostion.setMcc(p.getMcc());
			lbsPostion.setMnc(p.getMnc());
			lbsPostion.setLac(p.getLac());
			lbsPostion.setCi(p.getCi());
			lbsPostion.setSignalStrength(p.getSignalStrength());
			lbsPostion.setStationMsg(p.getStationMsg());
			lbsPostion.setWifiMac(p.getWifiMac());
			//position.setWifiSignal("-63#-59#-63#-61#-84#-59");
			Position lbsp = AmapLocateUtil.amapLocate(lbsPostion);
			res.put("lbs", lbsp);
			//WIFI定位
			Position wifip = new Position();
			if (!StringUtils.isEmpty(p.getWifiMac())) {
				Position wifiPostion = new Position();
				wifiPostion.setLocationMode("2");
				wifiPostion.setMcc(p.getMcc());
				wifiPostion.setMnc(p.getMnc());
				wifiPostion.setLac(p.getLac());
				wifiPostion.setCi(p.getCi());
				wifiPostion.setSignalStrength(p.getSignalStrength());
				wifiPostion.setStationMsg(p.getStationMsg());
				wifiPostion.setWifiMac(p.getWifiMac());
				//position.setWifiSignal("-63#-59#-63#-61#-84#-59");
				wifip = AmapLocateUtil.amapLocate(wifiPostion);
				res.put("wifi", wifip);
			}
			if (wifip.getLatitude() != null && wifip.getLongitude() != null && lbsp.getLatitude() != null && lbsp.getLongitude() != null) {
				Double distance = DistCnvter.cal2PDis(wifip.getLatitude(), wifip.getLongitude(), lbsp.getLatitude(),
						lbsp.getLongitude());
				res.put("distance", distance);
			}else{
				res.put("distance", "无法计算，Wifi或LBS定位为空");
			}

		}

		return success(res);
	}
	*/
	
	/*public static void main(String[] args) {
		String accessKey = "84K8sL8DAH0Ywv1xpvZtYYfD5Yxn7JQ8xgOKFsIb";
		String secretKey = "Zxgvc5g2X2NFwPjt3YzEFM38liM8dohp0v6Wz5ZG";
		String bucket = "babywei";
		Auth auth = Auth.create(accessKey, secretKey);
		String token = auth.uploadToken(bucket);
		System.out.println(token);
	}*/
	
	
	/*public static void main(String[] args) {
			 try
		        {
		            PushNotificationPayload payLoad = new PushNotificationPayload();
		            payLoad.addCustomAlertBody("测试1111111"); // 消息内容
		            //payLoad.addAlert(body); // 消息内容
		            Map<String, String> param = new HashMap<String, String>();
		            param.put("cmd", "1");
		            payLoad.addCustomAlertActionLocKey(JsonUtils.toJson(param));
		            //指令json参数
		            //payLoad.addCustomDictionary("apns", JsonUtils.toJson(param));
		            payLoad.addBadge(1); // iphone应用图标上小红圈上的数值
		            payLoad.addSound("default");//铃音
					
		            //payLoad.addCustomAlertLocArgs(parameters);  
		            PushNotificationManager pushManager = new PushNotificationManager();
		            //true：表示的是产品发布推送服务 false：表示的是产品测试推送服务
		            pushManager.initializeConnection(new AppleNotificationServerBasicImpl("D:/umeox/push.p12", "123456", false));
		            List<PushedNotification> notifications = new ArrayList<PushedNotification>();
		            // 发送push消息

	               Device device = new BasicDevice();
	               device.setToken("e21d58b186e7cedc59a58ad3d52a5d906e45c87034373e2f290bdf22508e25f2");
	               PushedNotification notification = pushManager.sendNotification(device, payLoad, true);
	               notifications.add(notification);
	               
	               List<PushedNotification> failedNotifications = PushedNotification.findFailedNotifications(notifications);
		           List<PushedNotification> successfulNotifications = PushedNotification.findSuccessfulNotifications(notifications);
		           System.out.println(failedNotifications);
		           int failed = failedNotifications.size();
		           int successful = successfulNotifications.size();
	               System.out.println(failed);
	               System.out.println(successful);
	               
		           pushManager.stopConnection();
		           System.out.println("xxxxxxxxxxxxxxxxx");
		        }
		        catch (Exception e)
		        {
		            e.printStackTrace();
		        }
	}*/

}
