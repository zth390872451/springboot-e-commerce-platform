package com.umeox.babywei.appapi.annotation;

import java.lang.annotation.*;

/**
 * 访问限制注解:
 *
 * 比如：times_max =10，timeToLive=1000，表示 在1000ms中之内最多访问10次
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface ApiLimit {
    /**
     * 在 timeToLive 内最多访问次数,默认10，
     *
     * @return
     */
    int times_max() default 10;

    /**
     * 存活时间(多长时间后失效),默认 1s
     * @return
     */
    long timeToLive() default 1;
    /**
     * 限制级别:
     * 0：用户级别
     * 1：方法级别
     * 根据限制级别，来决定当前接口限流拦截逻辑：
     *  key的来源：
     *      如果 limitLevel=0：用户级别，那么key = 用户标识或者 access_token
     *      如果 limitLevel=1：方法级别，那么key = 类名+方法名
     *
     *      默认接口级别
     */
    LimitLevel limitLevel() default LimitLevel.API_LEVEL;

    public enum  LimitLevel {
        API_LEVEL, //方法级别
        USER_LEVEL //用户级别

    }

    /**
     * key的组成 = prefixKey + suffixKey
     * 指定 后缀key的来源参数名字
     * mobile || access_token
     * @return
     */
    String suffixKeyFrom() default "";

}
