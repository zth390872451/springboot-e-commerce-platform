package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.util.StringUtils;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.bean.BaseSim;
import com.umeox.babywei.bean.HomeDto;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.HomeService;
import com.umeox.babywei.service.RemoteService;
import com.umeox.babywei.util.CommonUtils;
import com.umeox.babywei.util.DateTimeUtils;


public class MemberHoldersDtoBuilder {
	private static HomeService homeService;
	private static SettingProperties setting;
	private static MemberRepository memberRepository;
	private static RemoteService remoteService;
	static{
		homeService = (HomeService) ApplicationSupport.getBean("homeService");
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
		memberRepository = (MemberRepository) ApplicationSupport.getBean("memberRepository");
		remoteService = (RemoteService) ApplicationSupport.getBean("remoteService");
	}

	public MemberHoldersDto build(Monitor monitor) {
		MemberHoldersDto dto = new MemberHoldersDto(monitor.getHolder().getId(), 
				monitor.getId(), 
				monitor.getHolder().getName(), 
				monitor.getHolder().getFamilyName(),
				monitor.getHolder().getAvatar(),
				monitor.getHolder().getSim(),
				monitor.getIsAdmin(),
				monitor.getHolder().getFrequency().ordinal(),
				monitor.getHolder().getImei(),
				monitor.getDeviceType(),
				monitor.getHolder().getGender());
		dto.setBirthday(DateTimeUtils.getFormatDate(monitor.getHolder().getBirthday(), DateTimeUtils.PART_DATE_FORMAT));
		dto.setHeight(monitor.getHolder().getHeight());
		dto.setWeight(monitor.getHolder().getWeight());
		dto.setGrade(monitor.getHolder().getGrade());
		dto.setIsMoveRemind(monitor.getHolder().getIsMoveRemind());
		dto.setRelation(monitor.getRelation());
		dto.setStaticOpen(monitor.getHolder().getStaticOpen());
		dto.setStartHours(monitor.getHolder().getStartHours());
		dto.setEndHours(monitor.getHolder().getEndHours());
		dto.setAudioTypes(monitor.getHolder().getAudioTypes());
		dto.setTimeZone(monitor.getHolder().getTimeZone());
		dto.setAnswer(monitor.getHolder().getAnswer() == null?0:monitor.getHolder().getAnswer());
		return dto;
	}

	public List<MemberHoldersDto> build(List<Monitor> monitors) {
		List<MemberHoldersDto> dtos = new ArrayList<MemberHoldersDto>();
		for (Monitor monitor : monitors) {
			if(monitor.getStatus())
				dtos.add(build(monitor));
		}
		return dtos;
	}
	//channelSms==1的含义在短信前后加上“:”  :406063,u_sms_ip,352158042662973,223.6.255.81,888,10086,apn,2:【验证码】
	public MemberHoldersDto build(Monitor monitor, List<String> flagList ) {
		MemberHoldersDto dto = new MemberHoldersDto(monitor.getHolder().getId(), 
				monitor.getId(), 
				monitor.getHolder().getName(), 
				monitor.getHolder().getFamilyName(),
				monitor.getHolder().getAvatar(),
				monitor.getHolder().getSim(),
				monitor.getIsAdmin(),
				monitor.getHolder().getFrequency().ordinal(),
				monitor.getHolder().getImei(),
				monitor.getDeviceType(),
				monitor.getHolder().getGender());
		if (!StringUtils.isEmpty(monitor.getHolder().getAvatar())) {
			dto.setFullAvatar(setting.getSiteUrl()+monitor.getHolder().getAvatar());
		}
		dto.setBirthday(DateTimeUtils.getFormatDate(monitor.getHolder().getBirthday(), DateTimeUtils.PART_DATE_FORMAT));
		dto.setHeight(monitor.getHolder().getHeight());
		dto.setWeight(monitor.getHolder().getWeight());
		dto.setGrade(monitor.getHolder().getGrade());
		dto.setIsMoveRemind(monitor.getHolder().getIsMoveRemind());
		dto.setRelation(monitor.getRelation());
		dto.setStaticOpen(monitor.getHolder().getStaticOpen());
		dto.setStartHours(monitor.getHolder().getStartHours());
		dto.setEndHours(monitor.getHolder().getEndHours());
		dto.setAudioTypes(monitor.getHolder().getAudioTypes());
		dto.setTimeZone(monitor.getHolder().getTimeZone());
		dto.setAnswer(monitor.getHolder().getAnswer() == null?0:monitor.getHolder().getAnswer());
		//k2 根据销售渠道显示语聊表情
		if(monitor.getHolder() != null && monitor.getHolder().getDevice() != null){
			dto.setSaleChannel(monitor.getHolder().getDevice().getSaleChannel());
		}
		/*设置setChannelSms 可否采用这种形式
		根据传入的memberId查找Monitor列表，
		然后根据Monitor的id去查询对应的持有者及其对应的设备（saleChannel），
		简化下面的懒查询机制和略微有些繁琐的逻辑
		SELECT *FROM	ux_device t1
		LEFT JOIN ux_holder t2 ON t1.holder_id = t2.id
		LEFT JOIN ux_monitor t3 ON t2.id = t3.holder_id
		WHERE	t3.id = 3;
		*/
		if(flagList != null && !flagList.isEmpty()){
			if(monitor.getHolder() != null && monitor.getHolder().getDevice() != null && monitor.getHolder().getDevice().getSaleChannel() != null){
				dto.setChannelSms(flagList.contains(monitor.getHolder().getDevice().getSaleChannel()) == true ? "1" : "0");
			}else{
				dto.setChannelSms("0");
			}
		}
		return dto;
	}
	
	public List<MemberHoldersDto> build(List<Monitor> monitors, List<String> flagList,List<String> deviceTypeList) {
		List<MemberHoldersDto> dtos = new ArrayList<MemberHoldersDto>();
		
		for (Monitor monitor : monitors) {
			if(monitor.getStatus() && deviceTypeList.contains(monitor.getDeviceType())){
				dtos.add(build(monitor,flagList));
			}
		}
		return dtos;
	}
	
	public List<MemberHoldersV3Dto> buildv3(List<Monitor> monitors,Date currentDate,List<String> deviceTypeList) {
		List<MemberHoldersV3Dto> dtos = new ArrayList<MemberHoldersV3Dto>();
		String locationCode = CommonUtils.getRandomNumber();
		//Modified By JT on 2016-08-22,注释以下代码
		/*if (monitors.size() > 0) {
			Member member = monitors.get(0).getMember();
			member.setLocationCode(locationCode);
			memberRepository.save(member);
		}*/
		for (Monitor monitor : monitors) {
			if(monitor.getStatus() && isContainsDeviceType(deviceTypeList, monitor.getDeviceType())){
				monitor.getMember().setLocationCode(locationCode);
				dtos.add(buildv3(monitor,currentDate));
			}
		}
		return dtos;
	}
	private boolean isContainsDeviceType(List<String> deviceTypeList,String deviceType){
		boolean isContains = false;
		for (String str : deviceTypeList) {
			if (str.equals(deviceType)) {
				isContains = true;
				break;
			}
		}
		return isContains;
	}
	
	public MemberHoldersV3Dto buildv3(Monitor monitor,Date currentDate) {
		MemberHoldersV3Dto dto = new MemberHoldersV3Dto();
		Holder holder = monitor.getHolder();
		dto.setHolderId(holder.getId());
		dto.setMonitorId(monitor.getId());
		dto.setName(holder.getName());
		if (!StringUtils.isEmpty(holder.getAvatar())) {
			dto.setAvatar(setting.getSiteUrl() + holder.getAvatar());
		}
		dto.setGender(holder.getGender());
		dto.setImei(holder.getImei());
		Device device = holder.getDevice();
		dto.setBindCode(device.getBindCode());
		dto.setSim(holder.getSim());
		//monitor.getMember().setLocationCode(locationCode);
		//Modified By JT on 2016-08-22,传入定位码，因多个设备定位码一样
		HomeDto homeDto = homeService.getBaseData(monitor.getMember(), holder, currentDate,monitor.getMember().getLocationCode());
		if (homeDto != null) {
			dto.setLocationMode(homeDto.getLocationMode());
			dto.setLatitude(homeDto.getLatitude());
			dto.setLongitude(homeDto.getLongitude());
			dto.setRadius(homeDto.getRadius());
			dto.setAddress(homeDto.getAddress());
			dto.setReportTime(homeDto.getLocationTimeStamp());
			dto.setElectricity(homeDto.getElectric());
		}
		int flag = 0;
		if (!StringUtils.isEmpty(device.getFlag()) && device.getFlag() == 1) {
			BaseSim sim = remoteService.getSim(holder.getImei());
			dto.setRealnameStatus(sim.getRealnameStatus());//实名认证状态
			flag = 1;
		}
		dto.setFlag(flag);
		dto.setIsAdmin(monitor.getIsAdmin());
		dto.setLastActivityDate(device.getLastActivityDate().getTime());
		return dto;
	}
	
	
}
