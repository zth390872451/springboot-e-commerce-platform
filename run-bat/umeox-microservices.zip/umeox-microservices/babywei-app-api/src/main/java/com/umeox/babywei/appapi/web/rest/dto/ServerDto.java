package com.umeox.babywei.appapi.web.rest.dto;

public class ServerDto {
	
	/**
	 * 设备类型：
	 * 001 candy
	 * 002 手表
	 */
	private String deviceType;
	
	private String ip;

	private String port;

	private String code;

	private String country;

	private String channel;
	
	private String channelSms;

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getChannelSms() {
		return channelSms;
	}

	public void setChannelSms(String channel) {
		this.channelSms = channel;
	}
	
}
