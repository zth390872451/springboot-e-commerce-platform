package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.appapi.web.rest.dto.ContentDto;
import com.umeox.babywei.appapi.web.rest.dto.ContentDtoBuilder;
import com.umeox.babywei.domain.ChannelCustomer;
import com.umeox.babywei.domain.Content;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.repository.ChannelCustomerRepository;
import com.umeox.babywei.repository.ContentRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.support.MyResponseBody;


/**
 * 发现
 * @author umeox
 */
@RestController
@RequestMapping({"/api/content"})
public class ContentController {

	@Autowired
	private ContentRepository contentRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private ChannelCustomerRepository channelCustomerRepository;
	
	
	@RequestMapping(value = {"/list"} ,method = RequestMethod.GET)
	public MyResponseBody list(@RequestParam(value = "holderId",required = false) Long holderId,
							   @RequestParam(value = "memberId",required = false) Long memberId,
							   HttpServletRequest request){
		
		List<Content> parentList = new ArrayList<Content>();
		if (!StringUtils.isEmpty(holderId)) {
			Holder holder = holderRepository.getOne(holderId);
			String saleChannel = holder.getDevice().getSaleChannel();
			if (!StringUtils.isEmpty(saleChannel)) {
				ChannelCustomer channelCustomer = channelCustomerRepository.findOneBySaleChannel(saleChannel);
				parentList = contentRepository.findAllParent(channelCustomer.getSaleChannel());
			}
		}
		if (parentList == null || parentList.size() < 1) {
			parentList = contentRepository.findAllParent();
		}
		
		ContentDtoBuilder builder = new ContentDtoBuilder();
		List<ContentDto> list = builder.builder(parentList);

		return success(list);
	}

}
