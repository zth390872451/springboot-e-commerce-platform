package com.umeox.babywei.appapi.conf;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.boot.context.embedded.ServletContextInitializer;
import org.springframework.context.annotation.Configuration;

import com.alibaba.druid.support.http.StatViewServlet;

@Configuration
public class WebInitializer implements ServletContextInitializer {

  @Override
  public void onStartup(ServletContext servletContext) throws ServletException {
	//Druid Monitor
    ServletRegistration servlet = servletContext.addServlet("DruidStatView", StatViewServlet.class);
    servlet.addMapping("/druid/*");

  }
}
