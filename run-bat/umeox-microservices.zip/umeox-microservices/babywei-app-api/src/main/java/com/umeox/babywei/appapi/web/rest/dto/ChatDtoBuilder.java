package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.ImGroup;
import com.umeox.babywei.domain.Monitor;

public class ChatDtoBuilder {
	
	private final static SettingProperties setting;
	
	static{
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}
	
	public static List<ChatDto> builder(List<Monitor> monitorList,List<ImGroup> imGroupList){
		List<ChatDto> respList = new ArrayList<ChatDto>();
		List<ChatDto> groupChatList = new ArrayList<ChatDto>();
		for (Monitor monitor : monitorList) {
			Holder holder = monitor.getHolder();
			Long holderId = holder.getId();
			for (ImGroup imGroup : imGroupList) {
				if ((AppDetails.GROUP_PRE + holderId).equals(imGroup.getGroupId())) {
					ChatDto groupChat = new ChatDto();
					groupChat.setFriendId(imGroup.getGroupId());
					groupChat.setMonitorId(monitor.getId());
					groupChat.setIsAdmin(monitor.getIsAdmin());
					groupChat.setType(AppDetails.GROUP_TYPE);
					groupChat.setName(imGroup.getGroupName());
					groupChatList.add(groupChat);
					break;
				}
			}
			ChatDto monitorChat = new ChatDto();
			monitorChat.setFriendId(holderId.toString());
			monitorChat.setImei(holder.getImei());
			monitorChat.setMonitorId(monitor.getId());
			monitorChat.setIsAdmin(monitor.getIsAdmin());
			monitorChat.setType(AppDetails.FRIEND_TYPE);
			monitorChat.setName(holder.getName());
			if (!StringUtils.isEmpty(holder.getAvatar())) {
				monitorChat.setPhoto(setting.getSiteUrl() + holder.getAvatar());
			}
			respList.add(monitorChat);
		}
		respList.addAll(groupChatList);
		return respList;
	}
}
