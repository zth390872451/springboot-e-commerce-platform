package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.HttpUtil;
import com.umeox.babywei.util.JsonUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 *  Funpark对接业务
 */
public class FunparkService {
    protected static Logger logger = LoggerFactory.getLogger(FunparkService.class);
                                                /* API地址*/
    public static final String FUNPARK_API = "https://api.funpark.com.tw/funpark-watch-ws/";
    //2.1	获取邮箱验证码
    public static final String FUNPARK_API_EMAIL = "https://api.funpark.com.tw/funpark-watch-ws/api/common/email";
    //2.2	用户注册
    public static final String FUNPARK_API_REGIST = "https://api.funpark.com.tw/funpark-watch-ws/api/member/regist";
    //2.3	用户登录-第一种方式
    public static final String FUNPARK_API_LOGIN = "https://api.funpark.com.tw/funpark-watch-ws/api/member/login";
    //2.4	找回密码
    public static final String FUNPARK_API_FIND_PWD = "https://api.funpark.com.tw/funpark-watch-ws/api/member/upass";
    //2.5	修改用户资料
    public static final String FUNPARK_API_UPDATE_INFO = "https://api.funpark.com.tw/funpark-watch-ws/api/member/update";
    //2.6	用户反馈:同步反馈信息
    public static final String FUNPARK_API_SUGGEST_INFO = "https://api.funpark.com.tw/funpark-watch-ws/api/member/suggest";

    /*对接方的接口返回的状态码*/

    /**
     * 调用FunparkAPI 发送邮件
     */
    public static MyResponseBody sendEmail(String email, Integer type){
        try {
            Map<String,String> params = new HashMap<String, String>();
            email = email.replace("$", "@");
            params.put("email",email);
            params.put("type",type+"");
            String value = email + type;
            String encrypt = AESTool.getencrypt(value);
            params.put("sign",encrypt);

            String json =  HttpUtil.httpGet(params,FUNPARK_API_EMAIL);
            Map<String,Object> result = JsonUtils.toObject(json,Map.class);
            logger.info("http request params:{},result:{}",params,result);
            Integer status = (Integer) result.get("status");
            MyResponseBody myResponseBody = getMyResponseBody(status);
            return myResponseBody;
        } catch (Exception e) {
            logger.error("http request: catch exception e:",e);
            return fail();
        }
    }

    /**
     * 调用FunparkAPI 注册账号信息
     */
    public static MyResponseBody register(Map<String,String> params){
        try {
            params.put("username",params.get("username").replace("$","@"));
            StringBuffer plain = new StringBuffer(params.get("username")).append(params.get("password")).
                    append(params.get("code")).append(params.get("tel")).append(params.get("nickName")) ;
            String encrypt = AESTool.getencrypt(plain.toString());
            params.put("sign",encrypt);
            String url = HttpUtil.getUrl(params, FUNPARK_API_REGIST);
            String json =  HttpUtil.get(url);
            Map<String,Object> result = JsonUtils.toObject(json,Map.class);
            logger.info("http request params:{},result:{}",params,result);
            Integer status = (Integer) result.get("status");
            MyResponseBody myResponseBody = getMyResponseBody(status);
            return myResponseBody;
        } catch (Exception e) {
            logger.error("http request: catch exception e:",e);
            return fail();
        }
    }

    /**
     * 接入 FunPark(台湾定制K3)公司的登录校验
     * @return
     */
    public static boolean funParkLoginService(String username, String password, String newClinetId) {
        try {
            if (AppDetails.FUNPARK_APP.contains(newClinetId)){//FUNPARK 对接之登录
                Map<String,String> params = new HashMap<>();
                params.put("username",username);
                params.put("password", AESTool.getencrypt(password));//台湾的加密工具 进行加密
                MyResponseBody body = FunparkService.login(params);
                if (!body.getCode().equals("1")){//登录不成功
                    logger.error("funpark login failed ,code:{},msg:{}",body.getCode(),body.getMessage());
                    return false;
                }
            }
        }catch (Exception e){
            logger.error("funpark APP用户 login failed,e={}",e.getMessage());
            return false;
        }
        return true;
    }
    /**
     * 调用FunparkAPI 登录账号
     */
    public static MyResponseBody login(Map<String,String> params){
        long startTime = System.currentTimeMillis();
        try {
            params.put("username",params.get("username").replace("$","@"));
            StringBuffer plain = new StringBuffer(params.get("username")).append(params.get("password"));
            String encrypt =  AESTool.getencrypt(plain.toString());
            params.put("sign",encrypt);
            String url = HttpUtil.getUrl(params, FUNPARK_API_LOGIN);
            String json =  HttpUtil.httpPost(new HashMap<String, Object>(),url);
            Map<String,Object> result = JsonUtils.toObject(json,Map.class);
            logger.info("http request params:{},result:{},login请求消耗时间:{}",params,result,System.currentTimeMillis()-startTime);
            Integer status = (Integer) result.get("status");
            return getMyResponseBody(status);
        } catch (Exception e) {
            logger.error("http request: catch exception e:",e);
            return fail();
        }
    }

    /**
     * 接入 FunPark(台湾定制K3)公司的修改密码
     * newpass 传入的是明文
     * @return
     */
    public static boolean funParkServiceFindPwd(String username, String newpass, String code) {
        try {
            long startTime = System.currentTimeMillis();
            Map<String,String> params = new HashMap<>();
            params.put("username",username);
            params.put("password",  AESTool.getencrypt(newpass));
            params.put("code",code);
            MyResponseBody body = FunparkService.findPwd(params);
            logger.info("http request params:{},result:{},login请求消耗时间:{}",params,body,System.currentTimeMillis()-startTime);
            if (!body.getCode().equals("1")){//修改不成功
                logger.info("http request params:{},body:{}",params,body);
                logger.error("funpark  failed,code:{},msg:{}",body.getCode(),body.getMessage());
                return false;
            }
        }catch (Exception e){
            logger.error("http request: catch exception e:",e);
            return false;
        }

        return true;
    }
    /**
     * 调用FunparkAPI 找回密码
     */
    public static MyResponseBody findPwd(Map<String,String> params){
        try {
            long startTime = System.currentTimeMillis();
            params.put("username",params.get("username").replace("$","@"));
            StringBuffer plain = new StringBuffer(params.get("username"));
            if (!StringUtils.isEmpty(params.get("password"))){
                plain = plain.append(params.get("password"));
            }
            plain = plain.append(params.get("code"));
            String encrypt =  AESTool.getencrypt(plain.toString());
            params.put("sign",encrypt);

            String url = HttpUtil.getUrl(params, FUNPARK_API_FIND_PWD);
            String json =  HttpUtil.get(url);
            Map<String,Object> result = JsonUtils.toObject(json,Map.class);
            logger.info("http request result:{}",result);
            logger.info("http request params:{},result:{},login请求消耗时间:{}",params,result,System.currentTimeMillis()-startTime);
            Integer status = (Integer) result.get("status");
            return getMyResponseBody(status);
        } catch (Exception e) {
            logger.error("http request: catch exception e:",e);
            return fail();
        }
    }

    /**
     * 接入 FunPark(台湾定制K3)公司的修改资料
     */
    public static boolean funParkServiceUpdateInfo(String nickName, Integer gender, String tel,String username) {
        long startTime = System.currentTimeMillis();
        Map<String,String> params = new HashMap<>();
        params.put("username",username);
        params.put("nickName",nickName);
        params.put("gender",gender+"");
        params.put("tel",tel);
        MyResponseBody body = FunparkService.updateInfo(params);
        logger.info("http request params:{},login请求消耗时间:{}",params,System.currentTimeMillis()-startTime);
        if (!body.getCode().equals("1")){//修改不成功
            logger.info("http request params:{},body:{}",params);
            logger.error("funpark  failed,code:{},msg:{}",body.getCode(),body.getMessage());
            return false;
        }
        return true;
    }
    /**
     * 调用FunparkAPI 修改资料
     */
    public static MyResponseBody updateInfo(Map<String,String> params){
        try {
            params.put("username",params.get("username").replace("$","@"));
            StringBuffer plain = new StringBuffer(params.get("username")).append(params.get("nickName")).append(params.get("gender"));
            if (!StringUtils.isEmpty(params.get("tel"))){
                plain = plain.append(params.get("tel"));
            }
            String encrypt =  AESTool.getencrypt(plain.toString());
            params.put("sign",encrypt);
            String url = HttpUtil.getUrl(params, FUNPARK_API_UPDATE_INFO);
            String json =  HttpUtil.httpPost(new HashMap<String, Object>(),url);
            Map<String,Object> result = JsonUtils.toObject(json,Map.class);
            logger.info("http request params:{},result:{}",params,result);
            Integer status = (Integer) result.get("status");
            return getMyResponseBody(status);
        } catch (Exception e) {
            logger.error("http request: catch exception e:",e);
            return fail();
        }
    }

    /**
     * 调用FunparkAPI 提交反馈
     */
    public static void suggest(Map<String,String> params){
        try {
            StringBuffer plain = new StringBuffer(params.get("account"));
            if (params.get("imei")!=null){
                plain = plain.append(params.get("imei"));
            }
            if (params.get("device_type")!=null){
                plain = plain.append(params.get("device_type"));
            }
            plain = plain.append(params.get("suggest_type")).append(params.get("suggest_content")).append(params.get("app_version"))
                    .append(params.get("phone_system_system_version")).append(params.get("phone_type")).append(params.get("submit_date"));

            String encrypt =  AESTool.getencrypt(plain.toString());
            params.put("sign",encrypt);
            String url = HttpUtil.getUrl(params, FUNPARK_API_SUGGEST_INFO);
            String json =  HttpUtil.httpPost(new HashMap<String, Object>(),url);
            logger.info("http request json",json);
            Map<String,Object> result = JsonUtils.toObject(json,Map.class);
            logger.info("http request result:{}",result);
            Integer status = (Integer) result.get("status");
        } catch (Exception e) {
            logger.error("http request: catch exception e:",e);
        }
    }

    /**
     * 转换 台湾FunPark 公司给予的接口返回状态码
     * @param status
     * @return
     */
    private static MyResponseBody getMyResponseBody(Integer status) {
        logger.info("http request return status:{}",status);
//        return success();
        if (StringUtils.isEmpty(status))
            return fail();
        if (status==0){//成功
            return success();
        }else if (status==-1){//參數不足或格式錯誤
            return fail();
        }else if (status==-2 || status==-4){//-2:資料庫錯誤 -4:密码解密错误
            return fail();
        }else if (status==-5){//請求簽名錯誤
            return fail();
        }else if (status==20001){//帳號已被註冊
            return fail(MyHttpStatus._20001);
        }else if (status==20002){// code不正確
            return fail(MyHttpStatus._401_CODE_ERROR);
        }else if (status==20003){//email已經被使用
            return fail(MyHttpStatus._20001);
        }else if (status==20004){//帳號不存在，無法使用忘記密碼
            return fail(MyHttpStatus._20002);
        }else if (status==20009){//用戶名或密碼不正確無法使用忘記密碼
            return fail(MyHttpStatus._201);
        }else {
            logger.error("http request failed: return result:{}");
            return fail();
        }
    }

    /*public static void main(String[] args) {
        *//*Map<String,String> params = new HashMap<String, String>();
        params.put("account","sallie.yue$wherecom.com");
        params.put("imei","1111111111111111111111");
        params.put("device_type","7");
        params.put("suggest_type","1");
        params.put("suggest_content","test01");
        params.put("app_version","app01");
        params.put("phone_system_system_version","phoneSystem");
        params.put("phone_type","phoneType");
        params.put("submit_date", DateTimeUtils.getFormatDate(new Date(),DateTimeUtils.PART_DATE_FORMAT));*//*
        funParkServiceUpdateInfo("name",1,"15019271280","sallie.yue$wherecom.com");
//        FunparkService.suggest(params);
    }*/
}
