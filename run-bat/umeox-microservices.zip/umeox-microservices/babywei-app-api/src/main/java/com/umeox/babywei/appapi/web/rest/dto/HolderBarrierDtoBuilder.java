package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.umeox.babywei.domain.Barrier;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.util.CommonUtils;

public class HolderBarrierDtoBuilder {
	public HolderBarrierDto build(Barrier barrier,Monitor monitor,String clientId) {
		HolderBarrierDto dto = new HolderBarrierDto();
		dto.setAddress(barrier.getAddress());
		dto.setBarrierId(barrier.getId());
		dto.setLatitude(barrier.getLatitude());
		dto.setLongitude(barrier.getLongitude());
		dto.setRadius(barrier.getRadius());
		dto.setRelation(StringUtils.isNotEmpty(monitor.getRelation())?monitor.getRelation():monitor.getMember().getNickName());
		dto.setOpen(barrier.isOpen());
		dto.setStartHours(barrier.getStartHours());
		dto.setEndHours(barrier.getEndHours());
		dto.setRailName(barrier.getRailName());
		//历史数据有未选
		//String weekTime = !StringUtils.isEmpty(barrier.getWeekTime()) ? barrier.getWeekTime() : "1111111";
		dto.setWeekTime(CommonUtils.getRevertWeek(clientId, barrier.getWeekTime()));
		return dto;
	}
	
	
	public List<HolderBarrierDto> build(List<Barrier> barriers,Monitor monitor,String clientId) {
		List<HolderBarrierDto> dtos = new ArrayList<HolderBarrierDto>();
		for (Barrier barrier : barriers) {
			dtos.add(build(barrier,monitor,clientId));
		}
		return dtos;
	}
	
}
