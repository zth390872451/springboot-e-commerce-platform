package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.conf.RedisKey;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Albums;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.repository.AlbumsRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.AlbumsUtils;
import com.umeox.babywei.util.JsonUtils;

@Controller
@RequestMapping({"/api/albums"})
public class AlbumsController {
	
	@Autowired
	private AlbumsRepository albumsRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private SettingProperties setting;
	@Autowired
	private RedisService redisService;
	
	@RequestMapping(value = { "list" }, method = { RequestMethod.POST ,RequestMethod.GET })
	@ResponseBody
	public MyResponseBody list(@PageableDefault(size=10)Pageable pageable,String tagId,HttpServletResponse response,Long holderId) throws IOException{
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		
		if(StringUtils.isEmpty(tagId)){
			return fail(MyHttpStatus._400);
		}
		
		Page<Albums> page = albumsRepository.findAll(this.getSpecification(tagId), pageable);
		
		List<Object> data = new ArrayList<Object>();
		Map<String,Object> pageMap = new HashMap<String,Object>(); 
		for(Albums albums:page.getContent()){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("albumId", albums.getAlbumId());
			map.put("ablumTitle", albums.getAlbumTitle());
			map.put("albumIntro", albums.getAlbumIntro());
			map.put("coverSmal", albums.getCoverSmall());
			map.put("coverMiddle", albums.getCoverMiddle());
			map.put("coverLarge", albums.getCoverLarge());
			data.add(map);
		}
		pageMap.put("size", page.getSize());
		pageMap.put("number", page.getNumber());
		pageMap.put("totalPages", page.getTotalPages());
		
		Map<String,Object> json = new HashMap<String,Object>();
		try {
			if(!StringUtils.isEmpty(holderId)){
				Holder holder = holderRepository.findOne(holderId);
				json.put("deviceType", holder.getDevice().getDeviceType());
			}
			
			json.put("page", pageMap);
			json.put("list", data);
		} catch (Exception e) {
			e.printStackTrace();
			return fail();
		}
		return success(json);
	}
	
	@RequestMapping(value = { "browse" }, method = { RequestMethod.POST ,RequestMethod.GET })
	@ResponseBody
	public MyResponseBody browse(@PageableDefault(size=10,page=1)Pageable pageable,@RequestParam(value = "albumId")String albumId,HttpServletResponse response) throws IOException{
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		
		Map<String,String> param = new HashMap<String,String>();
		param.put("album_id", albumId);
		param.put("page", (pageable.getPageNumber())+"");
		param.put("sort", "asc");
		param.put("count", pageable.getPageSize()+"");
		try {
			String result = AlbumsUtils.getStoryStringVal(param, "albums/browse");
			return success(JsonUtils.toObject(result,  Object.class));
		} catch (Exception e) {
			e.printStackTrace();
			return fail();
		}
	}	
	
	@RequestMapping(value = { "listHolder" }, method = { RequestMethod.POST ,RequestMethod.GET })
	@ResponseBody
	public MyResponseBody listHolder(@RequestParam(value = "memberId")Long memberId,HttpServletResponse response) throws IOException{
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		
		List<Holder> list = holderRepository.queryByMemberIdAndDeviceType(memberId, "5");
		List<Object> data = new ArrayList<Object>();
		Map<String,Object> map = null;
		for(Holder holder : list){
			map = new HashMap<String, Object>();
			map.put("name", holder.getName());
			map.put("holderId", holder.getId());
			if(StringUtils.isEmpty(holder.getAvatar())){
				map.put("avatar", "http://leyuan.babywei.cn/res/img/default_avatar.png");
			}else{
				map.put("avatar", setting.getSiteUrl()+holder.getAvatar());
			}
			data.add(map);
		}
		return success(data);
	}
	
	@RequestMapping(value = { "send" }, method = { RequestMethod.POST ,RequestMethod.GET })
	@ResponseBody
	public MyResponseBody send(@RequestParam(value = "holderId")String holderId,@RequestParam(value = "title")String title,
														@RequestParam(value = "url")String url,HttpServletResponse response) throws IOException{
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		
		String holder[] = holderId.split(",");
		if(holder.length>0){
			for(String str : holder){
				try{
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("cmd", RedisCommand.CMD_STORY);
					map.put("holderId", str);
					map.put("title", title);
					map.put("url", url);
					redisService.rightPush(RedisKey.QUE_WETALK_SOCKET_IM, map);
				}catch(Exception e){
					e.printStackTrace();
				}
			}
		}
		return success();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@RequestMapping(value={"/downTag"}, method={RequestMethod.GET})
	@ResponseBody
	private void downTag(int page,String tagName,HttpServletResponse response){
		Map<String, String> paramsMap = new HashMap<String, String> ();
		if(page>0){
			paramsMap.put("page", page+"");
		}
		paramsMap.put("count", "200");
		paramsMap.put("category_id", "6");
		if(!StringUtils.isEmpty(tagName)){
			paramsMap.put("tag_name", tagName);
		}
		StringBuffer buffer = new StringBuffer();
		try {
			String result = AlbumsUtils.getStoryStringVal(paramsMap,"albums/get_all");
			Map<String,Object> map = JsonUtils.toObject(result, Map.class);
			int curPage = (int)map.get("current_page");
			int totalPage = (int)map.get("total_page");
			List list =  (List) map.get("albums");
			buffer.append(curPage+"-"+totalPage+"-"+tagName+"<br>");
			for(Object obj : list){
				Map<String,Object> m = (Map)obj;
				String title = (String)m.get("album_title");
				buffer.append(title+","+((Map)m.get("announcer")).get("nickname").toString()+"<br>");
			}
		} catch (java.lang.Exception e) {
			e.printStackTrace();
		}
		try {
			String str = new String(buffer.toString().getBytes("UTF-8"));
			response.setContentType("text/html;charset=UTF-8");
			response.getWriter().write(str);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private Specification<Albums> getSpecification(final String categoryId){
		return new Specification<Albums>(){

			@Override
			public Predicate toPredicate(Root<Albums> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predicate = new ArrayList<>();
				if(!StringUtils.isEmpty(categoryId)){
					predicate.add(cb.equal(root.get("tagId").as(String.class),categoryId));
				}
				predicate.add(cb.equal(root.get("enabled").as(boolean.class),true));
				predicate.add(cb.equal(root.get("displayed").as(boolean.class),true));
				Predicate[] pre = new Predicate[predicate.size()];
				query.where(predicate.toArray(pre));
				 List<Order> orders = new ArrayList<Order>();
				 orders.add(cb.desc(root.get("seq").as(Integer.class)));
				 orders.add(cb.desc(root.get("createDate").as(Date.class)));
				query.orderBy(orders);
                return query.getRestriction();
			}
			
		};
	}
}
