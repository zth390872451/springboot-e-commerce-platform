package com.umeox.babywei.appapi.web.rest.dto;

import org.springframework.util.StringUtils;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderStep;
import com.umeox.babywei.util.StepUtils;

public class SportDtoBuilder {
	
	public static SportDto build(Holder holder,HolderStep holderStep) {
		SportDto sportDto = new SportDto();
		if (!StringUtils.isEmpty(holder.getHeight()) && holderStep != null) {

			if (holder.getHeight()!=null&&holder.getHeight().contains("cm")){//清除以cm或者空格+cm 结尾的字符
				String height = holder.getHeight();
				height = height.replace("cm","").replace(" ","");
				holder.setHeight(height);
			}
			double distance = StepUtils.getDistance(Double.parseDouble(holder.getHeight()));//单位：厘米
			double m = distance * holderStep.getStepValue() / 100.0;//单位：米
			sportDto.setDistance((int)m);
			double km = m / 1000.0;
			if (!StringUtils.isEmpty(holder.getWeight())) {
				if (holder.getWeight()!=null&&holder.getWeight().contains("kg")){//清除以kg或者空格+kg 结尾的字符
					String weight = holder.getWeight();
					weight = weight.replace("kg","").replace(" ","");
					holder.setWeight(weight);
				}
				sportDto.setCalory((int)StepUtils.getKcal(Double.parseDouble(holder.getWeight()), km));
			}
			sportDto.setStepValue(holderStep.getStepValue());
		}
		
		return sportDto;
	}
}
