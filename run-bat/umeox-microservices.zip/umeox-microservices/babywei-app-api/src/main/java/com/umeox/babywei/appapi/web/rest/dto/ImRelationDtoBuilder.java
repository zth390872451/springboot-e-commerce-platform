package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.ImRelation;
import com.umeox.babywei.repository.HolderRepository;

public class ImRelationDtoBuilder {
	
	private static HolderRepository holderRepository;
	private static SettingProperties setting;
	static{
		holderRepository = (HolderRepository) ApplicationSupport.getBean("holderRepository");
		setting = (SettingProperties)ApplicationSupport.getBean("settingProperties");
	}
	
	public static ImRelationDto build(ImRelation imRelation) {
		ImRelationDto respBean = new ImRelationDto();
		respBean.setImUserID(imRelation.getUserId());
		respBean.setImFriendID(imRelation.getFriendId());
		Holder friendHolder = holderRepository.findFirstByImei(imRelation.getFriendId());
		respBean.setMobile(friendHolder.getSim());
		respBean.setNick(imRelation.getNick());
		respBean.setPhotoFlag(Integer.parseInt(imRelation.getPhotoFlag()));
		respBean.setPhotoUrl(setting.getSiteUrl() + friendHolder.getAvatar());
		respBean.setGender(friendHolder.getGender());
		
		return respBean;
	}

	public static List<ImRelationDto> build(List<ImRelation> imRelationList) {
		List<ImRelationDto> respList = new ArrayList<ImRelationDto>();
		for (ImRelation imRelation : imRelationList) {
			respList.add(build(imRelation));
		}
		return respList;
	}

}
