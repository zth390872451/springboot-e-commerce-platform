package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.*;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderSchedule;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.HolderScheduleRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.HolderScheduleService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.DateTimeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Iterator;
import java.util.List;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * @author umeox
 * @version II
 * @Desc 时间表设置
 */
@RestController
@RequestMapping("/api/holderSchedule")
public class HolderScheduleController {

    private static final int secLength = 11;
    private static final String falseRepeatExpression = "0000000";

    @Autowired
    private HolderScheduleRepository holderScheduleRepository;
    @Autowired
    private HolderRepository holderRepository;
    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private HolderScheduleService holderScheduleService;
    @Autowired
    private RedisQueueService redisQueueService;

    /**
     * @Desc 设置上课禁用时段
     */
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    @RequestMapping(value = "/setClassTime", method = RequestMethod.POST)
    public MyResponseBody setClassTime(@RequestParam(value = "memberId") Long memberId,
                                       @RequestParam(value = "holderId") Long holderId,
                                       @RequestParam(value = "amSec") String amSec,
                                       @RequestParam(value = "pmSec") String pmSec,
                                       @RequestParam(value = "nightSec", required = false) String nightSec,
                                       @RequestParam(value = "repeatExpression") String repeatExpression,
                                       @RequestParam(value = "status") Boolean status) {
        if (amSec.length() != secLength || pmSec.length() != secLength) {
            return fail(MyHttpStatus._400);
        }
        HolderSchedule holderSchedule =
                holderScheduleRepository.findFirstByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_CLASS);
        if (holderSchedule == null) {//添加
            Holder holder = holderRepository.findOne(holderId);
            if (holder == null) {
                return fail(MyHttpStatus._404);
            }
            holderSchedule = new HolderSchedule();
            holderSchedule.setHolder(holder);
            holderSchedule.setScheduleType(HolderSchedule.SCHEDULE_TYPE_CLASS);
        }
        holderSchedule.setAmSec(amSec);
        holderSchedule.setPmSec(pmSec);
        holderSchedule.setNightSec(nightSec);
        holderSchedule.setRepeatExpression(repeatExpression);
        holderSchedule.setStatus(status);
        holderScheduleService.setClassTime(holderSchedule);
        Holder holder = holderSchedule.getHolder();
        if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
            ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_CLASS_TIME + ""));
        } else {
            redisQueueService.k2HandleMark(new Mark(holderSchedule.getHolder().getId(), RedisCommand.CMD_CLASS_TIME));
        }
        return success();
    }

    /**
     * @Desc 获取上课禁用时段
     */
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    @RequestMapping(value = "/getClassTime", method = RequestMethod.GET)
    public MyResponseBody getClassTime(@RequestParam(value = "memberId") Long memberId,
                                       @RequestParam(value = "holderId") Long holderId) {
        HolderSchedule holderSchedule =
                holderScheduleRepository.findFirstByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_CLASS);
        if (holderSchedule == null) {
            return success();
        }
        HolderScheduleDto respBean = HolderScheduleDtoBuilder.build(holderSchedule, memberId, holderId);
        return success(respBean);
    }

    /**
     * @Desc 设置特别关心时段
     */
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    @RequestMapping(value = "/setConcernTime", method = RequestMethod.POST)
    public MyResponseBody setConcernTime(@RequestParam(value = "memberId") Long memberId,
                                         @RequestParam(value = "holderId") Long holderId,
                                         @RequestParam(value = "amSec") String amSec,
                                         @RequestParam(value = "pmSec") String pmSec,
                                         @RequestParam(value = "repeatExpression") String repeatExpression,
                                         @RequestParam(value = "frequency") Integer frequency,
                                         @RequestParam(value = "status") Boolean status) {
        if (amSec.length() != secLength || pmSec.length() != secLength) {
            return fail(MyHttpStatus._400);
        }
        HolderSchedule holderSchedule =
                holderScheduleRepository.findFirstByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_CONCERN);
        if (frequency < 0 || frequency > 4) {
            return fail(MyHttpStatus._400);
        }
        if (holderSchedule == null) {//添加
            Holder holder = holderRepository.findOne(holderId);
            if (holder == null) {
                return fail(MyHttpStatus._404);
            }
            holderSchedule = new HolderSchedule();
            holderSchedule.setHolder(holder);
            holderSchedule.setScheduleType(HolderSchedule.SCHEDULE_TYPE_CONCERN);
        }
        holderSchedule.setAmSec(amSec);
        holderSchedule.setPmSec(pmSec);
        holderSchedule.setRepeatExpression(repeatExpression);
        holderSchedule.setFrequency(frequency);
        holderSchedule.setStatus(status);
        holderScheduleService.setConcernTime(holderSchedule);
        //messageQueueService.addSyncDataAndUpdateFlag(holderSchedule.getHolder().getId(), RedisCommand.CMD_CONCERN_TIME);
        Holder holder = holderSchedule.getHolder();
        if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(holder.getDevice().getDeviceType())) {
            ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), Push.K3_DEVICE_CONCERN_TIME + ""));
        } else {
            redisQueueService.k2HandleMark(new Mark(holderSchedule.getHolder().getId(), RedisCommand.CMD_CONCERN_TIME));
        }
        return success();
    }

    /**
     * @Desc 获取特别关心时段
     */
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    @RequestMapping(value = "/getConcernTime", method = RequestMethod.GET)
    public MyResponseBody getConcernTime(@RequestParam(value = "memberId") Long memberId,
                                         @RequestParam(value = "holderId") Long holderId) {
        HolderSchedule holderSchedule =
                holderScheduleRepository.findFirstByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_CONCERN);
        if (holderSchedule == null) {
            return success();
        }
        HolderScheduleConcernTimeDto respBean = HolderScheduleConcernTimeDtoBuilder.build(holderSchedule, memberId, holderId);
        return success(respBean);
    }

    /**
     * @Desc 设置久座提醒时段
     */
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    @RequestMapping(value = "/setSedentaryTime", method = RequestMethod.POST)
    public MyResponseBody setSedentaryTime(@RequestParam(value = "memberId") Long memberId,
                                           @RequestParam(value = "holderId") Long holderId,
                                           @RequestParam(value = "amSec", required = false, defaultValue = "08:00-20:00") String sec,
                                           @RequestParam(value = "repeatExpression", required = false, defaultValue = "1111111") String repeatExpression,
                                           @RequestParam(value = "frequency", required = false, defaultValue = "120") Integer frequency,
                                           @RequestParam(value = "status") Boolean status) {
        if (status == true && sec.length() != secLength) {
            return fail(MyHttpStatus._400);
        }

        if (status == true && frequency < 1) {
            return fail(MyHttpStatus._400, "久座提醒时长不能小于1分钟");
        }

        HolderSchedule holderSchedule =
                holderScheduleRepository.findFirstByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_SEDENTARY);

        if (holderSchedule == null) {//添加
            Holder holder = holderRepository.findOne(holderId);
            if (holder == null) {
                return fail(MyHttpStatus._404);
            }
            holderSchedule = new HolderSchedule();
            holderSchedule.setHolder(holder);
            holderSchedule.setScheduleType(HolderSchedule.SCHEDULE_TYPE_SEDENTARY);
            holderSchedule.setAmSec(sec);//只需要一个时段
            holderSchedule.setPmSec(sec); //此字段无效
            holderSchedule.setRepeatExpression(repeatExpression);
            holderSchedule.setFrequency(frequency);
        }

        //打开需要更新其它字段
        if (status == true) {
            holderSchedule.setAmSec(sec);//只需要一个时段
            holderSchedule.setPmSec(sec); //此字段无效
            holderSchedule.setRepeatExpression(repeatExpression);
            holderSchedule.setFrequency(frequency);
        }

        holderSchedule.setStatus(status);
        holderScheduleService.setConcernTime(holderSchedule);
        //同步到设备
        redisQueueService.k2HandleMark(new Mark(holderSchedule.getHolder().getId(), RedisCommand.CMD_SEDENTARY_TIME));
        return success();
    }

    /**
     * @Desc 获取久座提醒时段
     */
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    @RequestMapping(value = "/getSedentaryTime", method = RequestMethod.GET)
    public MyResponseBody getSedentaryTime(@RequestParam(value = "memberId") Long memberId,
                                           @RequestParam(value = "holderId") Long holderId) {
        HolderSchedule holderSchedule =
                holderScheduleRepository.findFirstByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_SEDENTARY);
        if (holderSchedule == null) {
            return success();
        }
        HolderScheduleConcernTimeDto respBean = HolderScheduleConcernTimeDtoBuilder.build(holderSchedule, memberId, holderId);
        return success(respBean);
    }

    /**
     * @Desc 新增来电铃声音量设置
     */
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    @RequestMapping(value = "/volume/add", method = RequestMethod.POST)
    public MyResponseBody setVolumeTime(
            @RequestParam(value = "holderId") Long holderId,
            @RequestParam(value = "volumeNum") Integer volumeNum,
            @RequestParam(value = "startTime") String startTime,
            @RequestParam(value = "endTime") String endTime,
            @RequestParam(value = "repeatExpression") String repeatExpression,
            @RequestParam(value = "status") Boolean status) {
        if (startTime.length() != 5 || endTime.length() != 5) {
            return fail(MyHttpStatus._400, "时间格式错误");
        }
        String amSec = startTime + "-" + endTime;
        List<HolderSchedule> holderScheduleList = holderScheduleRepository.findByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_VOLUME);
        if (holderScheduleList.size() > 20) {
            return fail(MyHttpStatus._406_MAX_LIMIT);
        }
        MyResponseBody result = holderScheduleValidate(holderScheduleList, startTime, endTime, repeatExpression);
        if (result != null) {
            return result;
        }
        HolderSchedule holderSchedule = new HolderSchedule();
        Holder holder = holderRepository.findOne(holderId);
        if (holder == null) {
            return fail(MyHttpStatus._400);
        }
        holderSchedule.setHolder(holder);
        holderSchedule.setScheduleType(HolderSchedule.SCHEDULE_TYPE_VOLUME);

        if (repeatExpression.equals(falseRepeatExpression)) {
            return fail(MyHttpStatus._401_ILLEGALITY);
        }
        holderSchedule.setRepeatExpression(repeatExpression);
        holderSchedule.setVolumeNum(volumeNum);
        holderSchedule.setAmSec(amSec);
        holderSchedule.setPmSec(amSec);
        holderSchedule.setStatus(status);
        holderScheduleRepository.save(holderSchedule);
       //仅功能机
        redisQueueService.k2HandleMark(new Mark(holderId, RedisCommand.CMD_VOLUME_TIME));
        return success();
    }

    /**
     * @Desc 修改来电铃声音量设置
     */
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    @RequestMapping(value = "/volume/update", method = RequestMethod.POST)
    public MyResponseBody updateVolumeTime(@RequestParam(value = "memberId") Long memberId,
                                           @RequestParam(value = "id") Long id,
                                           @RequestParam(value = "holderId") Long holderId,
                                           @RequestParam(value = "volumeNum") Integer volumeNum,
                                           @RequestParam(value = "startTime") String startTime,
                                           @RequestParam(value = "endTime") String endTime,
                                           @RequestParam(value = "repeatExpression") String repeatExpression
    ) {
        HolderSchedule holderSchedule = holderScheduleRepository.findOne(id);
        Holder holder = holderRepository.findOne(holderId);
        if (holderSchedule == null || holder == null || holderSchedule.getHolder() == null || !holderId.equals(holderSchedule.getHolder().getId())) {
            return fail(MyHttpStatus._400);
        }
        if (startTime.length() != 5 || endTime.length() != 5) {
            return fail(MyHttpStatus._400);
        }
        String amSec = startTime + "-" + endTime;
        if (repeatExpression.equals(falseRepeatExpression)) {
            return fail(MyHttpStatus._401_ILLEGALITY);
        }
        List<HolderSchedule> holderScheduleList = holderScheduleRepository.findByHolderIdAndScheduleType(holderId, HolderSchedule.SCHEDULE_TYPE_VOLUME);
        Iterator<HolderSchedule> it = holderScheduleList.iterator();
        while(it.hasNext())
        {
            if(it.next().getId() == id)
            {
                it.remove();
            }
        }
        MyResponseBody result = holderScheduleValidate(holderScheduleList, startTime, endTime, repeatExpression);
        if (result != null) {
            return result;
        }
        if (repeatExpression.equals(falseRepeatExpression)) {
            return fail(MyHttpStatus._401_ILLEGALITY);
        }
        holderSchedule.setRepeatExpression(repeatExpression);
        holderSchedule.setVolumeNum(volumeNum);
        holderSchedule.setAmSec(amSec);
        holderSchedule.setPmSec(amSec);
        holderScheduleRepository.save(holderSchedule);//修改
        //仅功能机
        redisQueueService.k2HandleMark(new Mark(holderId, RedisCommand.CMD_VOLUME_TIME));
        return success();
    }

    public MyResponseBody holderScheduleValidate(List<HolderSchedule> holderScheduleList, String startTime, String endTime, String repeatExpression) {
        if (holderScheduleList.size() > 0) {

            for (HolderSchedule holderSchedule : holderScheduleList) {
                int i1 = Integer.parseInt(holderSchedule.getRepeatExpression(), 2);
                int i2 = Integer.parseInt(repeatExpression, 2);
                int i3 = i1 & i2;
                if (i3 > 0) {
                    String startTime2 = holderSchedule.getAmSec().substring(0, 5);
                    String endTime2 = holderSchedule.getAmSec().substring(6, 11);
                    if (startTime2.isEmpty() || endTime2.isEmpty()) {
                        return fail(MyHttpStatus._400);
                    }
                    if (DateTimeUtils.parseString2Date2(startTime, "HH:mm").getTime() < DateTimeUtils.parseString2Date2(endTime2, "HH:mm").getTime()
                            && DateTimeUtils.parseString2Date2(endTime, "HH:mm").getTime() > DateTimeUtils.parseString2Date2(startTime2, "HH:mm").getTime()) {
                        return fail(MyHttpStatus._40007);
                    }
                }

            }
        }
        return null;
    }

    /**
     * @Desc 获取手表的来电铃声音量设置
     */
    @RequestMapping(value = "/volume/list", method = RequestMethod.GET)
    public MyResponseBody getVolumeTime(
            @RequestParam(value = "holderId") Long holderId) {
        List<HolderSchedule> holderScheduleList =
                holderScheduleRepository.findVolumeTimeList(holderId, HolderSchedule.SCHEDULE_TYPE_VOLUME);
        if (holderScheduleList == null) {
            return success();
        }
        List<HolderScheduleVolumeTimeDto> respBean = HolderScheduleVolumeTimeDtoBuilder.build(holderScheduleList, holderId);
        return success(respBean);
    }

    /**
     * @Desc 来电铃声的设置记录删除
     */
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    @RequestMapping(value = "/volume/delete", method = RequestMethod.POST)
    public MyResponseBody deleteVolumeTime(@RequestParam(value = "holderId") Long holderId,
                                           @RequestParam(value = "id") Long id,
                                           @RequestParam(value = "memberId") Long memberId) {
        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        if (member == null || holder == null) {
            return fail(MyHttpStatus._400);
        }
        HolderSchedule holderSchedule =
                holderScheduleRepository.findOne(id);
        if (holderSchedule == null) {
            return fail(MyHttpStatus._400);
        }
        if (holderId.equals(holderSchedule.getHolder().getId())) {
            holderScheduleRepository.delete(id);
        }
        //仅功能机
        redisQueueService.k2HandleMark(new Mark(holderId, RedisCommand.CMD_VOLUME_TIME));
        return success();
    }

    /**
     * @Desc 来电铃声开关
     */
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    @RequestMapping(value = "/volume/status", method = RequestMethod.POST)
    public MyResponseBody setVolumeStatus(@RequestParam(value = "holderId") Long holderId,
                                          @RequestParam(value = "id") Long id,
                                          @RequestParam(value = "memberId") Long memberId,
                                          @RequestParam(value = "status") Boolean status) {

        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        if (member == null || holder == null) {
            return fail(MyHttpStatus._400);
        }
        HolderSchedule holderSchedule = holderScheduleRepository.findOne(id);
        if (holderSchedule == null || holder == null || holderSchedule.getHolder() == null || !holderId.equals(holderSchedule.getHolder().getId())) {
            return fail(MyHttpStatus._400);
        }
        holderSchedule.setStatus(status);
        holderScheduleRepository.save(holderSchedule);
        //仅功能机
        redisQueueService.k2HandleMark(new Mark(holderId, RedisCommand.CMD_VOLUME_TIME));
        return success();
    }


}
