package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.HolderSchedule;

public class HolderScheduleConcernTimeDtoBuilder {

	public static HolderScheduleConcernTimeDto build(HolderSchedule holderSchedule,Long memberId,Long holderId) {
		HolderScheduleConcernTimeDto dto = new HolderScheduleConcernTimeDto();
		dto.setMemberId(memberId);
		dto.setHolderId(holderId);
		dto.setAmSec(holderSchedule.getAmSec());
		dto.setPmSec(holderSchedule.getPmSec());
		dto.setRepeatExpression(holderSchedule.getRepeatExpression());
		dto.setStatus(holderSchedule.getStatus());
		dto.setFrequency(holderSchedule.getFrequency());
		return dto;
	}
}
