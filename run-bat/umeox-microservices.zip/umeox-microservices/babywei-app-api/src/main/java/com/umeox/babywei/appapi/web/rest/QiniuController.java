package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.success;
import static com.umeox.babywei.support.MyResponseBuilder.fail;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.plugin.QiniuClient;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;


@RestController
@RequestMapping("/api/qiniu")
public class QiniuController {
	
	/**
	 * 获取上传凭证（未使用）
	 */
	@RequestMapping(value = "/getUpToken",method = RequestMethod.GET)
	public MyResponseBody getUpToken(HttpServletRequest request){
		String client_id = request.getHeader("client_id");
		if (StringUtils.isEmpty(client_id)) {
			return fail(MyHttpStatus._400);
		}
		
		String upToken = QiniuClient.getImUpToken();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("upToken", upToken);
		
		return success(map);
	}
	
	
	
}
