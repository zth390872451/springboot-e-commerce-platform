package com.umeox.babywei.appapi.annotation;

public enum DataPermissionType {
	MEMBER_CHECK("memberCheck"),//检查App传入的memberId与认证(Oauth2)关联的memberId是否相等，不相等认为非法操作；以下如果有传入memberId默认检查
	HOLDER_FOLLOWER("holderFollower"),         //关注者
	HOLDER_ADMIN("holderAdmin"),//管理员
	BARRIER_ADMIN("barrierAdmin"),             //安全区域
	CHAT_FOLLOWER("chatFollower"),             //聊天
	FAMILYNUMBER_ADMIN("familyNumberAdmin"),   //联系人
	LOG_MESSAGE_FOLLOWER("logMessageFollower"),//消息记录
	IMEI_ADMIN("imeiAdmin");                   ////管理员
	
	private final String value;
	
	private DataPermissionType(String value){
		this.value = value;
	}

	public String getValue() {
		return value;
	}
	
}
