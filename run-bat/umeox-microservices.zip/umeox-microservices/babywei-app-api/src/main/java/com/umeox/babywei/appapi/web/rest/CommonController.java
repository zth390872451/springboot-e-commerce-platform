package com.umeox.babywei.appapi.web.rest;

import com.alibaba.druid.pool.DruidDataSource;
import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.ApiLimit;
import com.umeox.babywei.bean.SmsType;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Constants;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.domain.enums.AppType;
import com.umeox.babywei.repository.AppVersionRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.I18nService;
import com.umeox.babywei.service.MailServerService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.IhuyiSms;
import com.umeox.babywei.support.KinglangSms;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.CommonUtils;
import com.umeox.babywei.util.RuleSupport;
import com.umeox.babywei.util.UploadUtil;
import com.umeox.babywei.util.mail.MailUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.store.JdbcTokenStore;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


/**
 * @author umeox
 *
 */
@RestController
@RequestMapping( { "/api/common" })
public class CommonController{
	private static final Logger log = LoggerFactory.getLogger(CommonController.class);
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private RedisService redisService;
	@Autowired
	private AppVersionRepository appVersionRepository;
	@Autowired
	private I18nService i18nService;
	@Autowired
	private MailServerService mailServerService;

	@RequestMapping(value = "getRedis", method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody getRedisValBykey(@RequestParam(value = "key") String key){
		Object object = (Object)redisService.get(key);
		if(object instanceof Device){
			Device device = (Device) object;
			device.setHolder(null);
			device.setServer(null);
			return success(device);
		}else if (object instanceof Holder) {
			Holder holder = (Holder) object;
			holder.setDevice(null);
			holder.setSos(null);
			return success(holder);
		}else {
			return success(object);
		}
	}

	@RequestMapping(value = "isExistAccessToken", method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody isExistAccessToken(@RequestParam(value = "accessToken") String accessToken){
		DruidDataSource dataSource = (DruidDataSource) ApplicationSupport.getBean("druidDataSource");
		JdbcTokenStore store = new JdbcTokenStore(dataSource);
		OAuth2AccessToken oAuth2AccessToken = store.readAccessToken(accessToken);

		boolean isExistAccessToken = true;
		if (oAuth2AccessToken == null || oAuth2AccessToken.isExpired()) {//Token过期
			isExistAccessToken = false;
		}
		Map<String, Boolean> map = new HashMap<String,Boolean>();
		map.put("isExistAccessToken", isExistAccessToken);
		return success(map);
	}

	@RequestMapping(value = "delRedis", method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody delRedisValBykey(@RequestParam(value = "key") String key){
		redisService.del(key);
		return success();
	}

	@RequestMapping(value = "setRedis", method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody delRedisValBykey(@RequestParam(value = "key") String key,
										   @RequestParam(value = "val") String val){
		redisService.set(key,val);
		return success();
	}

	/**
	 * 版本检测 for android
	 */
	@Deprecated
	@RequestMapping(value = { "/check_update" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody check(@RequestParam(value = "version") String version,
								HttpServletRequest request) {
		SettingProperties setting = (SettingProperties)ApplicationSupport.getBean("settingProperties");
		int currentVersion = Integer.parseInt(version);
		String appId = request.getHeader(AppDetails.APP_ID);
		if (StringUtils.isEmpty(appId) || appId.equals(AppDetails.ANDROID_PACKAGE_BABYWEI)) {//默认 babywei
			if (Integer.parseInt(setting.getBabyweiVersion()) <= currentVersion) {
				return success("sys.no.update");
			}
			return success(setting.getBabyweiVersion().trim(),setting.getBabyweiAppMessage(),setting.getBabyweiAppDownloadPath());
		} else { // wherecom
			if (Integer.parseInt(setting.getWherecomVersion()) <= currentVersion) {
				return success("sys.no.update");
			}
			return success(setting.getWherecomVersion().trim(),setting.getWherecomAppMessage(),setting.getWherecomAppDownloadPath());
		}

	}

	/**
	 * 版本检测更新
	 */
	@RequestMapping(value = { "/checkUpdate" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody checkUpdate(@RequestParam(value = "client_id") String client_id,
										@RequestParam(value = "type") Integer type,
										@RequestParam(value = "currentVersion") Double currentVersion,
										@RequestParam(value = "storeVersion", required = false) Double storeVersion) {
		int status = 0;// 0:无更新；1:有更新；2:强制更新
		String download = null;
		String content = null;
		List<AppVersion> appVersionList = new ArrayList<AppVersion>();
		if (AppType.ISO.ordinal() == type) {
			if (StringUtils.isEmpty(storeVersion)) {
				return fail(MyHttpStatus._404);
			}
			if (currentVersion < storeVersion) {
				 appVersionList = appVersionRepository.findByIosParam(client_id, currentVersion, storeVersion);
				 if (appVersionList.size() > 0) {
					status = 1;
					content  = appVersionList.get(appVersionList.size()-1).getContent();
				}
				for (AppVersion appVersion : appVersionList) {
					if (appVersion.getForcedUpdate()) {
						status = 2;
						break;
					}
				}
			}
		} else {
			appVersionList = appVersionRepository.findByAndroidParam(client_id, currentVersion);
			if (appVersionList.size() > 0) {
				status = 1;
				download = appVersionList.get(appVersionList.size()-1).getDownload();
				content  = appVersionList.get(appVersionList.size()-1).getContent();
			}
			for (AppVersion appVersion : appVersionList) {
				if (appVersion.getForcedUpdate()) {
					status = 2;
					break;
				}
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("status", status);
		map.put("download", download);
		map.put("content", content);
		return success(map);
	}

	@Deprecated
	@RequestMapping(value = { "/google_check_update" }, method = {RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody google_check(@RequestParam(value = "version") String version) {

		return success("sys.no.update");
	}

	@Deprecated
	@RequestMapping(value = { "/ios_check_update" }, method = {RequestMethod.GET,RequestMethod.POST})
	public String ios_check_update(@RequestParam(value = "version") String version) {

		//return success("https://itunes.apple.com/us/app/qun-xiang-dao/id907821429?ls=1&mt=8");
		return "https://itunes.apple.com/us/app/qun-xiang-dao/id907821429?ls=1&mt=8";
	}

	/**
	 * 上传
	 */
	@Deprecated
	@RequestMapping(value = { "/upload" }, method = { RequestMethod.POST })
	public MyResponseBody upload(HttpServletRequest request, MultipartFile file) {
		SettingProperties setting = (SettingProperties)ApplicationSupport.getBean("settingProperties");
		if (file == null || file.getSize() < 1) {
			fail("sys.choose.file");
		}
		String path = setting.getSiteUrl()+UploadUtil.saveMartipartFile(request, file);

		return success(path);
	}

	/**
	 * 短信：
	 * type:0-注册 1-找回密码
	 * 此接口单个用户 10分钟内只能使用该接口 5次，金伦短信1分钟只能调用一次
	 */
	@RequestMapping(value = { "/msg" }, method = { RequestMethod.GET })
	@ApiLimit(times_max = 3,suffixKeyFrom="mobile",timeToLive = 3600,limitLevel= ApiLimit.LimitLevel.USER_LEVEL)
	public MyResponseBody msg(@RequestParam(value = "mobile") String mobile,
							  @RequestParam(value = "type") int type,
							  HttpServletRequest request) {
		log.info("调用发送短信,mobile:{},type:{}", mobile,type);

		if(request.getHeader("client_id") == null || request.getHeader("app_id") ==null){
			log.info("非法请求");
			return fail(MyHttpStatus._400);
		}

		Member member = memberRepository.findOneByMobile(mobile);
		if(type == 0 && member != null) {
			return fail(MyHttpStatus._20001);
		}

		String key = mobile+"-"+SmsType.values()[type].name();
		String code = redisService.getCode(key);

		String content = "";

		if(ApplicationSupport.isEnv(Constants.SPRING_PROFILE_PRODUCTION_CHINA_LONLIV)){
			//使用互忆的短信接口
			if(type == 0) {
				content = String.format(ApplicationSupport.getParamVal("thirdparty.ihuyisms.regMsg"),code);
			} else if(type == 1){
				content = String.format(ApplicationSupport.getParamVal("thirdparty.ihuyisms.findPasswordMsg"),code);
			}
			IhuyiSms.SendAndLog(mobile, content, type);
		}else{
			//使用金伦短信接口
			if(type == 0) {
				content = String.format(ApplicationSupport.getParamVal("thirdparty.kinglandsms.regMsg"),code);
			} else if(type == 1){
				content = String.format(ApplicationSupport.getParamVal("thirdparty.kinglandsms.findPasswordMsg"),code);
			}
			String sendStatus = KinglangSms.sendSmsHttpAndSave(mobile, content, type);//调用短信接口
			if (sendStatus.equals("0")){//发送成功
				return success();
			}else if(sendStatus.equals("1")){//被叫连续下单限制(短信平台限制)
				return fail(MyHttpStatus._600);
			}else{
				return fail(sendStatus);
			}
		}
		return success();
	}

	/**
	 */
	/*@Deprecated
	@RequestMapping(value = { "/sendMsg" }, method = {RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody sendMsg(@RequestParam(value = "mobile") String mobile,
		  			  			  @RequestParam(value = "content") String content) {

		KinglangSms.sendSmsHttp(mobile, content);
		return success();
	}*/

	/**
	 * 邮件
	 * param - type  0：注册	 1：忘记密码
	 */
	@RequestMapping(value = { "/email" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody email(@RequestParam(value = "email") String email,
								@RequestParam(value = "type") int type,
								HttpServletRequest request) {
		String clientId = request.getHeader("client_id");
		String lang = request.getHeader("lang");

		if (AppDetails.FUNPARK_APP.contains(clientId)){//FUNPARK 对接之发邮件
			return FunparkService.sendEmail(email, type);
		}

		if(type == 0) {
			Member member = memberRepository.findOneByMobile(email);
			if(member != null) {
				return fail(MyHttpStatus._20001);
			}
		}
		String key = email + "-"+SmsType.values()[type].name();
		String code = redisService.getCode(key); 
		
		String content = "";
		String subject = "";
		if(type == 0) {		
			if (AppDetails.WHERECOM_K2_POMO_CLIENT_IDS.contains(clientId)) {
				content = String.format("<p>Thanks for activating your device. Your verification code is %s,please use it within 30 minutes.</p>" +
						"<p>ขอขอบคุณสำหรับการเปิดใช้งานนาฬิกา Pomo Kids Moji รหัสยืนยันของคุณคือ %s กรุณากรอกรหัสภายใน 30 นาที .</p>" ,code,code);
				subject = "Register Verification code - ลงทะเบียนรับรหัสยืนยัน";
			}else if(AppDetails.WHERECOM_K2_IRIST_CLIENT_IDS.contains(clientId)){
				content = String.format("<p>Thanks for activating your device. Your verification code is %s,please use it within 30 minutes.</p>",code);
				subject = "Register Verification code";
			} else {
				if (StringUtils.isEmpty(lang)) {
					content = String.format("<p>Thanks for activating your device. Your verification code is %s,please use it within 30 minutes.</p>" +
							"<p>Grazie per aver attivato il tuo dispositivo. Il tuo codice di verifica è %s. Utilizzalo entro 30 minuti.</p>" +
							"<p>Merci pour l'activation de votre dispositif. Votre code de vérification %s doit être utilisé dans les 30 minutes.</p>" +
							"<p>Добро пожаловать в Wherecom! Для завершения регистрации введите код подтверждения %s в приложении Wherecom на Вашем смартфоне. Данный код действителен в течение 30 минут.</p>"+
							"<p>Ďakujeme za aktiváciu Vášho zariadenia. Váš verifikačný kód je %s, prosím použite ho počas nasledujúcich 30 minút.</p>" +
							"<p>Hartelijk dank voor het activeren van het horloge. Uw verificatiecode is %s, gebruik deze code binnen 30 minuten.</p>",code,code,code,code,code,code);
					subject = "Register Verification code - Codice di Verifica - Code de vérification";
				}else {
					//发送邮件注册消息，从数据库改为本地资源文件获取
					/*String contentPattern =  i18nService.findByLocaleAndKey(lang, I18NField.email_regist_content);
					content = MessageFormat.format(contentPattern, code);
					subject = i18nService.findByLocaleAndKey(lang, I18NField.email_regist_subject);*/
					
					subject = RuleSupport.getMsgByLocale(lang,"user.reg.title");
					content = RuleSupport.getMsgByLocale(lang,"user.reg.body",new String[]{code});
					if (AppDetails.WXB_DOKI_CLIENT_IDS.contains(clientId) && content.contains("Wherecom")){
						content = content.replace("Wherecom","Doki");
					}
				}
			}
		} else if(type == 1){
			if (AppDetails.WHERECOM_K2_POMO_CLIENT_IDS.contains(clientId)) {
				content = String.format("<p>Your new verification code is %s.</p>"+
						"<p>รหัสยืนยันใหม่ของคุณคือ %s.</p>",code,code);
				subject = "Verification code - รหัสยืนยัน";
			} else if(AppDetails.WHERECOM_K2_IRIST_CLIENT_IDS.contains(clientId)){
				content = String.format("<p>Your new verification code is %s.</p>",code);
				subject = "Verification code";
			} else {
				if (StringUtils.isEmpty(lang)) {
					content = String.format("<p>Your new verification code is %s.</p>" +
							"<p>Il nuovo codice di verifica è %s.</p>" +
							"<p>Le nouveau code de vérification est %s.</p>" +
							"<p>Ваш код подтверждения:%s.</p>" +
							"<p>Uw nieuwe verificatiecode is %s.</p>",code,code,code,code,code);
					subject = "Verification code";
				}else {
					//找回密码消息，从数据库改为本地资源文件获取
					/*String contentPattern =  i18nService.findByLocaleAndKey(lang, I18NField.email_forget_content);
					content = MessageFormat.format(contentPattern, code);
					subject = i18nService.findByLocaleAndKey(lang, I18NField.email_forget_subject);*/

					subject = RuleSupport.getMsgByLocale(lang,"user.findpwd.title");
					content = RuleSupport.getMsgByLocale(lang,"user.findpwd.body",new String[]{code});
				}
			}
		}
		if(!StringUtils.isEmpty(content)) {
			if(email != null && email.contains("$")){
				email = email.replace("$", "@");
			}
			if (AppDetails.WXB_DOKI_CLIENT_IDS.contains(clientId)){//如果是Doki的邮件，则添加无需回复的提示信息
				content = content +"<p>Do not reply to this email. If you have any questions, please email us at support@doki.com.</p>";
			}
			//查找应使用的邮箱服务器
			MailServer mailServer = mailServerService.findMailServerByClientId(clientId);
			//邮件发送改成HTML格式
			MailUtil.sendToSingle(email, subject, content, true ,mailServer);
		}
		
		return success();
	}

	@RequestMapping(value = { "/emailForOpen" }, method = {RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody emailForOpen(@RequestParam(value = "email") String email,
							   @RequestParam(value = "subject") String subject,
							   @RequestParam(value = "content") String content
							   ){
		if(!StringUtils.isEmpty(content)) {
			if(email != null && email.contains("$")){
				email = email.replace("$", "@");
			}
			//查找应使用的邮箱服务器
			MailServer mailServer = mailServerService.getDefaultMailServer();
//			MailServer mailServer = mailServerService.findMailServerByClientId("wherecom_nomi_api_ios");
			// 国内可以使用这个测试能否发送邮件 Nomi、TinyTrack的邮件服务器发送，在本地测试时，会受到代理的影响，导致超时错误,原因不明。
			//邮件发送改成HTML格式
			try {
				MailUtil.sendToSingle(email, subject, content, true ,mailServer);
			}catch (Exception e){
				return fail();
			}
		}
		return success();
	}

	@RequestMapping(value = { "/isMember" }, method = { RequestMethod.POST, RequestMethod.GET })
	public MyResponseBody isMember(@RequestParam(value = "mobile") String mobile) {
		log.info("isMember mobile:{}",mobile);
		mobile = CommonUtils.aliasHandle(mobile);
		Member member = memberRepository.findOneByMobile(mobile);
		if (member == null ) {
			return success(false);
		}
		return success(true);

	}
}
