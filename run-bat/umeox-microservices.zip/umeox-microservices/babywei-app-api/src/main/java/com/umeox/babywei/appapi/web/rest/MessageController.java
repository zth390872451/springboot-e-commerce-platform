package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.MessageDto;
import com.umeox.babywei.appapi.web.rest.dto.MessageDtoBuilder;
import com.umeox.babywei.bean.Notice;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.Message;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.MessageRepository;
import com.umeox.babywei.repository.MonitorRepository;
import com.umeox.babywei.service.CommonService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;



/**
 * 消息接口
 * @author umeox
 */
@RestController
@RequestMapping( { "/api/message" })
public class MessageController {
	
	private static final Logger log = LoggerFactory.getLogger(MessageController.class);
	
	@Autowired
	private MessageRepository messageRepository;
	@Autowired
	private CommonService commonService;
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private MemberRepository memberRepository;
	
	
	/**
	 * 消息记录查询
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
							   @RequestParam(value = "holderId") Long holderId) {

		//---------------版本升级控制
		if (ApplicationSupport.isChinaEnv()) {
			Member member = memberRepository.findOne(memberId);
			if (member == null) {
				return fail(MyHttpStatus._404);
			}
			if (member.getPushType() != Member.PUSH_TYPE_JPUSH && StringUtils.isEmpty(member.getToken())) {
				log.error("获取消息记录查询失败，因Android APP版本过旧,MemberId:{}",member.getId());
				return fail(MyHttpStatus._401_APP_NEEDS_UPDATED);
			}
		}
		//---------------版本升级控制

		List<Message> messageList = messageRepository.findByHolderIdAndAdminIdOrMemberId(holderId, memberId, memberId);
		
		MessageDtoBuilder builder = new MessageDtoBuilder();
		List<MessageDto> dtoList = builder.build(messageList);
		
		return success(dtoList);
	}
	
	/**
	 * 删除消息记录
	 */
	//TODO 待处理，不确定所属逻辑
	@RequestMapping(value = { "/delete" }, method = { RequestMethod.POST })
	public MyResponseBody delete(@RequestParam(value = "messageId") Long messageId) {
		try {
			messageRepository.delete(messageId);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return success();
	}
	
	
	/**
	 * 获取通知消息列表(K3)
	 */
	@DataPermission
	@RequestMapping(value = "/list2", method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody getNotice(@RequestParam(value = "memberId") Long memberId,
									@RequestParam(value = "holderId",required = false) Long holderId,
									@RequestParam(value = "messageId") Long messageId){
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404);
		}
		String key = "";
		if(holderId != null){
			key = RedisKeyPre.NOTICE + memberId + ":" + holderId;
		}else{
			key = RedisKeyPre.NOTICE + memberId;			
		}
		List<Notice> respList = commonService.findNoticeByMessageIdFlag(key, messageId);
		return success(respList);
	}

}
