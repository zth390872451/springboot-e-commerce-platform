package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.domain.ImGroupMember;
import com.umeox.babywei.domain.ImRelation;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.MemberRepository;

import java.util.ArrayList;
import java.util.List;

public class ChatFriendDtoBuilder {
	
	public static List<ChatFriendDto> builder(List<ImRelation> imRelationList,List<ImGroupMember> groupMemberList){
		List<ChatFriendDto> respList = new ArrayList<ChatFriendDto>();
		MemberRepository memberRepository = (MemberRepository) ApplicationSupport.getBean("memberRepository");
		for (ImRelation imRelation : imRelationList) {
			ChatFriendDto friend = new ChatFriendDto();
			friend.setType(AppDetails.FRIEND_TYPE);
			friend.setName(imRelation.getNick());
			Member member = memberRepository.findOneByMobile(friend.getFriendId());
			if (member!=null){
				String nickName = member.getNickName();//关注者或者管理员一律使用 账号的名字
				friend.setName(nickName);
			}
			friend.setFriendId(imRelation.getId().toString());
			respList.add(friend);
		}
		for (ImGroupMember imGroupMember : groupMemberList) {
			ChatFriendDto group = new ChatFriendDto();
			group.setType(AppDetails.GROUP_TYPE);
			group.setName(imGroupMember.getImGroup().getGroupName());
			group.setFriendId(imGroupMember.getImGroup().getGroupId());
			respList.add(group);
		}
		return respList;
	}
}
