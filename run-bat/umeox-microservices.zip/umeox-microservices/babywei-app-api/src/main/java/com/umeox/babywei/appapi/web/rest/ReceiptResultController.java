package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.repository.SmsResultRepository;
import com.umeox.babywei.service.SmsResultService;
import com.umeox.babywei.support.MyResponseBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.io.StringReader;
import java.text.ParseException;

import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * 短信平台
 */
@RestController
@RequestMapping("/api/receipt")
public class ReceiptResultController {

    private static final Logger log = LoggerFactory.getLogger(ReceiptResultController.class);

    @Autowired
    private SmsResultRepository smsResultRepository;
    @Autowired
    private SmsResultService smsResultService;
   /*
     * 接收短信平台的状态回执（发送是否成功）
     * 回执的参数参考：短信接口说明HTTP.doc文档
     * 因为接收的参数，并非 标准的xml格式(指定header和<?xml>。。。)，所以只能自己定义解析方法
     * @param response
     * @return
     * @throws ParseException
    */
    @RequestMapping(value = "/receiptResult")
    public MyResponseBody receiptResult(HttpServletRequest httpServletRequest)  throws ParseException, IOException {
        String xml = httpServletRequest.getParameter("xml");
        log.info("收到短信回执  xml = {}",xml);
        String msgId = getNodeValueFromXmlStr(xml,"msgId");
        String statusInt = getNodeValueFromXmlStr(xml,"statusInt");
        if (!StringUtils.isEmpty(msgId))
                smsResultService.updateSmsResult(msgId,statusInt);
        else {
            log.info("收到短信回执  msgId =空");
        }
        return success();
    }
    /**
     * 从xml字符串中获取指定的节点值
     */
    public static String getNodeValueFromXmlStr(String xmlStr,String nodeName) {
        String startStr = "<"+nodeName+">";
        int start = xmlStr.indexOf(startStr)+startStr.length();
        int end = xmlStr.indexOf("</"+nodeName+">");
        CharSequence charSequence = xmlStr.subSequence(start, end);
        return charSequence.toString();
    }
}
