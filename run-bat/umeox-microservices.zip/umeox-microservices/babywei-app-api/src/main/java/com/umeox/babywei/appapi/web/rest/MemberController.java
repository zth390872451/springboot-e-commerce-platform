package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.web.rest.dto.MemberDto;
import com.umeox.babywei.appapi.web.rest.dto.MemberDtoBuilder;
import com.umeox.babywei.bean.MultiFile;
import com.umeox.babywei.bean.SmsType;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.Monitor;
import com.umeox.babywei.domain.enums.GenderType;
import com.umeox.babywei.repository.FamilyNumberRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.MonitorRepository;
import com.umeox.babywei.service.MemberService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.service.SmsResultService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.util.UploadUtil;
import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * 会员
 *
 * @author umeox
 */
@RestController
@RequestMapping({"/api/member"})
public class MemberController {
	private static final Logger log = LoggerFactory.getLogger(MemberController.class);

	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private RedisService redisService;
	@Autowired
	private MemberService memberService;
	@Autowired
	private SettingProperties setting;
	@Autowired
	private MonitorRepository monitorRepository;
	@Autowired
	private FamilyNumberRepository familyNumberRepository;
	@Autowired
	private SmsResultService smsResultService;

	/**
	 * 会员登录 新的app不用该接口
	 */
	@RequestMapping(value = {"/login"}, method = {RequestMethod.POST})
	public MyResponseBody login(@RequestParam(value = "mobile") String mobile,
								@RequestParam(value = "password") String password) {

		Member member = memberRepository.findOneByMobile(mobile);
		if (member == null || !member.getPassword().equals(DigestUtils.md5DigestAsHex(password.getBytes()))) {
			return fail("sys.accountOrPassword.error");
		}
		;
		//TODO: token可删除？
		String token = RandomStringUtils.randomAlphanumeric(10);
		member.setPushType(Member.PUSH_TYPE_DEFAULT);
		member.setClientId("");
		if (member.getMemberExt() != null) {
			member.getMemberExt().setLocale("");
		}
		memberRepository.save(member);
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("id", member.getId());
		map.put("nickName", member.getNickName());
		map.put("mobile", member.getMobile());
		map.put("token", token);
		map.put("pushServerAddress", setting.getPushServerAddress());
		return success(map);
	}

	/**
	 * 会员注册
	 */
	@RequestMapping(value = {"/regist"}, method = {RequestMethod.POST})
	public MyResponseBody regist(@RequestParam(value = "mobile") String mobile,
								 @RequestParam(value = "password") String password,
								 @RequestParam(value = "code", required = false) String code,
								 @RequestParam(value = "nickName", required = false) String nickName,
								 @RequestParam(value = "tel", required = false) String tel,
								 @RequestHeader(value = "client_id", required = false) String client_id) throws Exception {

		//POMO定制版不需要注册验证码，通过client_id标识POMO定制版
		//funpark 公司用户注册 无需我司code
		if (!AppDetails.WHERECOM_K2_POMO_CLIENT_IDS.contains(client_id) && !AppDetails.FUNPARK_APP.contains(client_id)) {
			String mobileCode = (String) redisService.get(mobile + "-" + SmsType.REGIST.name());
			if (mobileCode == null) {
				return fail("sys.code.invalid");
			}
			if (!mobileCode.equals(code)) {
				return fail("sys.code.error");
			}
			//标记该验证码已经被使用了
			smsResultService.updateSmsResultStatus(mobile, code);
		}

		//1、台湾远程库存在账号，本地库不存在，本地库更新，并提示注册成功
		//2、台湾远程库不存在账号，本地库存在，台湾库注册账号，本地库不做操作
		if (AppDetails.FUNPARK_APP.contains(client_id)) {//FUNPARK 对接之注册
			Map<String, String> params = new HashMap<String, String>();
			params.put("username", mobile);
			params.put("password", AESTool.getencrypt(password));
			params.put("code", code);
			params.put("tel", tel);
			params.put("nickName", nickName);
			MyResponseBody body = FunparkService.register(params);
			if (body.getCode().equals("1") || body.getCode().equals("20001")) {//该账号已注册(远程库已存在)
				Member localMember = memberRepository.findOneByMobile(mobile);
				if (StringUtils.isEmpty(localMember)) {//本地库不存在,本地库添加数据
					localMember = new Member();
				} else {//本地库已存在,本地库更新数据

				}
				//更新(添加)数据
				localMember.setMobile(mobile);
				localMember.setNickName(nickName);
//				localMember.setPassword(password);
				localMember.setTel(tel);
				localMember.setPassword(DigestUtils.md5DigestAsHex(password.getBytes()));
				if (StringUtils.isEmpty(nickName)) {
					localMember.setNickName("ux" + RandomStringUtils.random(6, "0123456789"));
				} else {
					localMember.setNickName(nickName);
				}
				memberRepository.save(localMember);


				Map<String, Object> map = new HashMap<String, Object>();
				map.put("id", localMember.getId());
				map.put("nickName", localMember.getNickName());
				map.put("mobile", localMember.getMobile());
				return success(map);
			} else {//注册失败
				return fail();
			}

		} else {
			Member president = memberRepository.findOneByMobile(mobile);
			if (president != null) {
				return fail(MyHttpStatus._20001);
			}

			if (!StringUtils.isEmpty(tel)) {
				Member m = memberRepository.findOneByTel(tel);
				if (m != null) {
					return fail(MyHttpStatus._20003);
				}
			}
			Member member = memberService.regist(mobile, password, nickName, tel);
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("id", member.getId());
			map.put("nickName", member.getNickName());
			map.put("mobile", member.getMobile());
			return success(map);
		}

	}

	/**
	 * 会员注册(K3)（未使用）
	 */
	@RequestMapping(value = {"/create"}, method = {RequestMethod.POST})
	public MyResponseBody create(MultiFile multiFile,
								 @RequestParam(value = "name") String name,
								 @RequestParam(value = "familyName") String familyName,
								 @RequestParam(value = "mobile") String mobile,
								 @RequestParam(value = "code") String code,
								 @RequestParam(value = "password") String password) {
		String mobileCode = (String) redisService.get(mobile + "-" + SmsType.REGIST.name());
		if (mobileCode == null) {
			return fail("sys.code.invalid");
		}
		if (!mobileCode.equals(code)) {
			return fail("sys.code.error");
		}
		//标记该验证码已经被使用了
		smsResultService.updateSmsResultStatus(mobile, code);

		Member president = memberRepository.findOneByMobile(mobile);
		if (president != null) {
			return fail(MyHttpStatus._20001);
		}

		Member member = new Member();
		if (multiFile.getFile() != null && multiFile.getFile().getSize() > 0) {
			String filePath = UploadUtil.saveMartipartFile(null, multiFile.getFile());
			if (!StringUtils.isEmpty(filePath)) {
				member.setAvatar(filePath);
			}
		}
		member.setName(name);
		member.setFamilyName(familyName);
		member.setMobile(mobile);
		member.setPassword(password);
		member.setNickName("ux" + RandomStringUtils.random(6, "0123456789"));
		memberRepository.save(member);

		return success();
	}

	/**
	 * 获取会员资料
	 * 场景：微话饼、K3
	 */
	@DataPermission
	@RequestMapping(value = {"/get"}, method = {RequestMethod.GET, RequestMethod.POST})
	public MyResponseBody get(@RequestParam(value = "memberId") Long memberId) {
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404);
		}
		MemberDto resp = MemberDtoBuilder.build(member);
		return success(resp);
	}

	/**
	 * 修改信息
	 */
	@DataPermission
	@RequestMapping(value = {"/update"}, method = {RequestMethod.POST})
	public MyResponseBody update(@RequestParam(value = "memberId") Long memberId,
								 MultiFile multiFile,
								 @RequestParam(value = "nickName") String nickName,
								 @RequestParam(value = "gender") Integer gender,
								 @RequestParam(value = "tel", required = false) String tel) {
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404);
		}

		String oldTel = member.getTel();
		boolean isUploadFile = false;
		String filePath = null;
		if (multiFile.getFile() != null && multiFile.getFile().getSize() > 0) {
			filePath = UploadUtil.saveMartipartFile(null, multiFile.getFile());
			if (!StringUtils.isEmpty(filePath)) {
				isUploadFile = true;
				member.setAvatar(filePath);
			}
		}

		member.setNickName(nickName);
		member.setGender(GenderType.values()[gender]);
		Boolean isUpdate = memberService.update(member, tel);
		if (!isUpdate) {
			return fail(MyHttpStatus._300_FM_ADDED);
		}

		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		String client_id = request.getHeader("client_id");
		if (AppDetails.FUNPARK_APP.contains(client_id)) {//FUNPARK 对接之修改资料
			if (StringUtils.isEmpty(tel) && StringUtils.isEmpty(member.getTel())) {
				return fail(MyHttpStatus._400);
			}
			if (!FunparkService.funParkServiceUpdateInfo(nickName, gender, member.getTel(), member.getMobile()))
				return fail();
		}

		//海外环境 电话号码或头像修改k3系列设备收到推送
		//国内环境 头像修改k3系列设备收到推送
		if ((ApplicationSupport.isAmazonEnv() && (!StringUtils.isEmpty(tel) && !tel.equals(oldTel))) || isUploadFile) {
			List<Monitor> monitorList = monitorRepository.findByMemberId(member.getId());
			for (Monitor monitor : monitorList) {
				if (AppDetails.K3_SERIES_DEVICE_TYPE.contains(monitor.getDeviceType())) {
					ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(monitor.getHolder().getImei(), (Push.K3_DEVICE_UPDATE_FRIEND | Push.K3_DEVICE_UPDATE_CONTACT) + ""));
				}
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (isUploadFile) {
			filePath = setting.getSiteUrl() + filePath;
			map.put("isUploadFile", 1);
		} else {
			map.put("isUploadFile", 0);
		}
		map.put("fileUrl", filePath);
		return success(map);
	}


	/**
	 * 找回密码
	 */
	@RequestMapping(value = {"/upass"}, method = {RequestMethod.POST})
	public MyResponseBody upass(@RequestParam(value = "mobile") String mobile,
								@RequestParam(value = "password", required = false) String password,
								@RequestParam(value = "newpass") String newpass,
								@RequestParam(value = "code") String code) {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		String client_id = request.getHeader("client_id");
		if (AppDetails.FUNPARK_APP.contains(client_id)) {//FUNPARK 对接之找回密码
			if (FunparkService.funParkServiceFindPwd(mobile, newpass, code))//修改成功
			{
				Member member = memberRepository.findOneByMobile(mobile);
				if (member != null) {
					member.setPassword(DigestUtils.md5DigestAsHex(newpass.getBytes()));
				} else {
					member = new Member();
					member.setMobile(mobile);
					member.setPassword(DigestUtils.md5DigestAsHex(newpass.getBytes()));
					member.setNickName("ux" + RandomStringUtils.random(6, "0123456789"));
				}
				memberRepository.save(member);
				return success();
			} else {
				return fail();
			}

		} else {
			String mobileCode = (String) redisService.get(mobile + "-" + SmsType.FORGET.name());
			if (mobileCode == null) {
				return fail("sys.code.invalid");
			}
			if (!mobileCode.toString().equals(code)) {
				return fail("sys.code.error");
			}
			//标记该验证码已经被使用了
			smsResultService.updateSmsResultStatus(mobile, code);

			Member member = memberRepository.findOneByMobile(mobile);
			if (member != null) {
				member.setPassword(DigestUtils.md5DigestAsHex(newpass.getBytes()));
			} else {
				member = new Member();
				member.setMobile(mobile);
				member.setPassword(DigestUtils.md5DigestAsHex(newpass.getBytes()));
				member.setNickName("ux" + RandomStringUtils.random(6, "0123456789"));
			}
			memberRepository.save(member);
			return success();
		}


	}

	/**
	 * 生成定位/录音随机码
	 */
	@DataPermission
	@RequestMapping(value = {"/genLocationCode"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody genLocationCode(@RequestParam(value = "memberId") Long memberId) {

		Member member = memberRepository.findOne(memberId);
		member.setLocationCode(RandomStringUtils.random(6, "0123456789"));
		memberRepository.save(member);
		return success(member.getLocationCode());
	}

	/**
	 * ios初始化接口 更新appId和token
	 * android传空把appId和token清空
	 */
	@DataPermission
	@RequestMapping(value = {"/iosInit"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody iosInit(@RequestParam(value = "memberId") Long memberId,
								  @RequestParam(value = "appId") String appId,
								  @RequestParam(value = "token") String token) {

		log.info("iosInit,memberId:{},appId:{},token:{}", memberId, appId, token);

		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404_USER_NO_EXISTS);
		}
		member.setAppId(appId);
		member.setToken(token);
		memberRepository.save(member);
		return success();
	}

	/**
	 * APP登录后的初始化接口(替换上面的iosInit接口)
	 * @param memberId
	 * @param token
	 * @param packageName
	 * @param pushMode
	 * @return
	 */
	@DataPermission
	@RequestMapping(value = {"/init"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody init(@RequestParam(value = "memberId") Long memberId,
							   @RequestParam(value = "token") String token,
							   @RequestParam(value = "packageName") String packageName,
							   @RequestParam(value = "pushMode") Integer pushMode) {
		log.info("app init,memberId:{},token:{},packageName:{},pushMode:{}", memberId,token,packageName,pushMode);
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404_USER_NO_EXISTS);
		}
		member.setToken(token);
		member.setPackageName(packageName);
		member.setPushMode(pushMode);
		memberRepository.save(member);
		return success();
	}

	/**
	 * 华为 手机登录账号初始化接口 更新 loginInfo
	 */
	@DataPermission
	@RequestMapping(value = {"/androidInit"}, method = {RequestMethod.POST, RequestMethod.GET})
	public MyResponseBody iosInit(@RequestParam(value = "memberId") Long memberId,
								  @RequestParam(value = "loginInfo", required = false) String loginInfo) {

		log.info("androidInit,memberId:{},appId:{},token:{}", memberId, loginInfo);
		Member member = memberRepository.findOne(memberId);
		if (member == null) {
			return fail(MyHttpStatus._404_USER_NO_EXISTS);
		}
		if (!StringUtils.isEmpty(member.getLoginInfo()) && member.getLoginInfo().contains("huawei:")) {
			if (StringUtils.isEmpty(loginInfo)) {
				loginInfo = null;
				log.info("用户memberId:{}登出APP,loginInfo:{}", memberId, member.getLoginInfo());
			}
			member.setLoginInfo(loginInfo);
		}
		memberRepository.save(member);
		return success();

	}


}
