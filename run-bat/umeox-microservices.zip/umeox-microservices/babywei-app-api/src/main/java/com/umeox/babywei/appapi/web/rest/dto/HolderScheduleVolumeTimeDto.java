package com.umeox.babywei.appapi.web.rest.dto;

/**
 * Created by Administrator on 2017-10-13.
 */
public class HolderScheduleVolumeTimeDto {

    private Long id;

    private Long holderId;

    private String startTime;

    private String endTime;

    private Integer volumeNum;

    private String repeatExpression;

    private Boolean status;




    public Long getHolderId() {
        return holderId;
    }

    public void setHolderId(Long holderId) {
        this.holderId = holderId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getVolumeNum() {
        return volumeNum;
    }

    public void setVolumeNum(Integer volumeNum) {
        this.volumeNum = volumeNum;
    }

    public String getRepeatExpression() {
        return repeatExpression;
    }

    public void setRepeatExpression(String repeatExpression) {
        this.repeatExpression = repeatExpression;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }


}
