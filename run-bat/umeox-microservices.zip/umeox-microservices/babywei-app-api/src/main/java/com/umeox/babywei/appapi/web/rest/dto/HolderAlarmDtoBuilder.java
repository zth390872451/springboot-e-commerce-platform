package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.HolderAlarm;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class HolderAlarmDtoBuilder {
	
	public static HolderAlarmDto build(HolderAlarm holderAlarm) {
		HolderAlarmDto dto = new HolderAlarmDto();
		dto.setAlarmId(holderAlarm.getId());
		dto.setAlarmName(holderAlarm.getAlarmName());
		dto.setAlarmTime(holderAlarm.getAlarmTime());
		dto.setIcon(holderAlarm.getIcon());
		if (StringUtils.isEmpty(holderAlarm.getAlarmTimeStr()) && !StringUtils.isEmpty(holderAlarm.getAlarmTime())) {
			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
			dto.setAlarmTimeStr(sdf.format(holderAlarm.getAlarmTime()));
		}else {
			dto.setAlarmTimeStr(holderAlarm.getAlarmTimeStr());
		}
		
		dto.setRepeatFlag(holderAlarm.getRepeatFlag());
		dto.setRepeatExpression(holderAlarm.getRepeatExpression());
		dto.setStatus(holderAlarm.getStatus());
		dto.setRingType(holderAlarm.getRingType());
		return dto;
	}

	public static List<HolderAlarmDto> build(List<HolderAlarm> list) {
		List<HolderAlarmDto> dtoList = new ArrayList<HolderAlarmDto>();
		for (HolderAlarm holderAlarm : list) {
			dtoList.add(build(holderAlarm));
		}
		return dtoList;
	}


}
