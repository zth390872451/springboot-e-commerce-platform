package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.LogMessageDto;
import com.umeox.babywei.appapi.web.rest.dto.LogMessageDtoBuilder;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.LogMessage;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.LogMessageRepository;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.web.rest.BaseController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


/**
 * 监护日志/通知消息
 * umeox
 *
 */
@RestController
@RequestMapping( { "/api/log_message" })
public class LogMessageController extends BaseController{
	
	private static final Logger log = LoggerFactory.getLogger(LogMessageController.class);
	
	 @Autowired
	 private LogMessageRepository logMessageRepository;
	@Autowired
	private HolderRepository holderRepository;

	/**
	 * 删除消息记录
	 */
	@DataPermission(value = DataPermissionType.LOG_MESSAGE_FOLLOWER)
	@RequestMapping(value = { "/delete" }, method = { RequestMethod.POST })
	public MyResponseBody delete(@RequestParam(value = "messageId") Long messageId) {
		try {
			logMessageRepository.delete(messageId);
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		return success();
	}
	
	/**
	 * 2. 监护日志/通知消息的信息
	 */
	@DataPermission(value = DataPermissionType.LOG_MESSAGE_FOLLOWER)
	@RequestMapping(value = { "/detail" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody detail(@RequestParam(value = "logMessageId") Long logMessageId) {

		LogMessage logMessage = logMessageRepository.findOne(logMessageId);
		if (logMessage == null) {
			return fail(MyHttpStatus._404);
		}
		boolean isOss = false;
		Holder holder = logMessage.getHolder();
		Device device = holder.getDevice();
		if (AppDetails.DEVICE_K7_SERIES.contains(device.getDeviceType())){
			isOss = true;
		}
		LogMessageDtoBuilder builder = new LogMessageDtoBuilder();
		LogMessageDto dto = builder.build(logMessage,isOss);

		return success(dto);
	}
	/**
	 * 3 监护日志/通知消息的信息列表 旧接口,保留
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody list(@RequestParam(value = "holderId") Long holderId,
							   @RequestParam(value = "mobile", required = false) String mobile,
							   @RequestParam(value = "dept", required = false) Date dept,
							   @RequestParam(value = "dest", required = false) Date dest,
							   @RequestParam(value = "first", required = false) Integer first,
							   @RequestParam(value = "count", required = false,defaultValue = "10") Integer count ) {

		if(first == null || first == 1){
			first = 0;//兼容ios
		}
		List<LogMessage> logMessageList = logMessageRepository.queryByHolderIdAndMobileAsPage(holderId, "%"+mobile+"%", dept, dest, first, count);
		LogMessageDtoBuilder builder = new LogMessageDtoBuilder();
		boolean isOss = false;
		Holder holder = holderRepository.findOne(holderId);
		Device device = holder.getDevice();
		if (AppDetails.DEVICE_K7_SERIES.contains(device.getDeviceType())){
			isOss = true;
		}
		List<LogMessageDto> dtoList = builder.build(logMessageList,isOss);
	
		return success(dtoList);
	}

	/**
	 * 新接口 查看监护日志/通知消息的信息列表 对于上面的 /list 接口的修改(后续APP均采用这个接口，旧接口保留)
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/get" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody get(@RequestParam(value = "holderId") Long holderId,
							   @RequestParam(value = "mobile") String mobile,
							   @RequestParam(value = "messageId", required = false,defaultValue = "0") Long messageId,
							  @RequestParam(value = "direction", required = false,defaultValue = "false") Boolean  direction,
							   @RequestParam(value = "size", required = false,defaultValue = "10") Integer size ) {

		List<LogMessage> logMessageList = new ArrayList<>();
		if (messageId==0){//获取最近的size条数据
			logMessageList = logMessageRepository.findAllByHolderIdAndMobileAndOrderByIdDesc(holderId,"%"+mobile+"%",size);
		}else {
			if (direction){//查看方向：新数据
				logMessageList = logMessageRepository.findAllByMessageIdGrater(holderId,"%"+mobile+"%",messageId,size);
			}else {//查看方向：旧数据
				logMessageList = logMessageRepository.findAllByMessageIdLess(holderId,"%"+mobile+"%",messageId,size);
			}
		}

		LogMessageDtoBuilder builder = new LogMessageDtoBuilder();
		boolean isOss = false;
		Holder holder = holderRepository.findOne(holderId);
		if (holder==null){
			return fail(MyHttpStatus._404);
		}
		Device device = holder.getDevice();
		if (AppDetails.DEVICE_K7_SERIES.contains(device.getDeviceType())){
			isOss = true;
		}
		List<LogMessageDto> dtoList = builder.build(logMessageList,isOss);
		return success(dtoList);
	}
}
