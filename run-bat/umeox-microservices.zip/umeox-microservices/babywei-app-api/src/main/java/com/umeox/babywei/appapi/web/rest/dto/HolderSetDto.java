package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.HolderSet;

public class HolderSetDto {

    private Long holderId;

    private Boolean answer = HolderSet.ON_TYPE;

    private Boolean callLocation = HolderSet.OFF_DEFAULT_TYPE;

    private Boolean electricProtect = HolderSet.OFF_DEFAULT_TYPE;

    private Boolean powerOffLocation = HolderSet.OFF_DEFAULT_TYPE;

    private Boolean refusePhone = HolderSet.OFF_DEFAULT_TYPE;

    private Boolean classTimeProtect = HolderSet.OFF_DEFAULT_TYPE;

    private Boolean concernTimeProtect = HolderSet.OFF_DEFAULT_TYPE;

    private Boolean deviceOffAlarm = HolderSet.OFF_DEFAULT_TYPE;

    private String timeZoneId;

    private String timeZone;

    private Integer frequency;

    private Boolean isMoveRemind;

    private Boolean staticOpen;

    private String startHours;

    private String endHours;

    private String amSec;

    private Boolean bluetoothAccompanyState = HolderSet.OFF_DEFAULT_TYPE;

    private Integer deviceWorkModel = 0;


    public String getAmSec() {
        return amSec;
    }

    public void setAmSec(String amSec) {
        this.amSec = amSec;
    }

    public Long getHolderId() {
        return holderId;
    }

    public void setHolderId(Long holderId) {
        this.holderId = holderId;
    }

    public Boolean getAnswer() {
        return answer;
    }

    public void setAnswer(Boolean answer) {
        this.answer = answer;
    }

    public Boolean getCallLocation() {
        return callLocation;
    }

    public void setCallLocation(Boolean callLocation) {
        this.callLocation = callLocation;
    }

    public Boolean getElectricProtect() {
        return electricProtect;
    }

    public void setElectricProtect(Boolean electricProtect) {
        this.electricProtect = electricProtect;
    }

    public Boolean getPowerOffLocation() {
        return powerOffLocation;
    }

    public void setPowerOffLocation(Boolean powerOffLocation) {
        this.powerOffLocation = powerOffLocation;
    }

    public Boolean getRefusePhone() {
        return refusePhone;
    }

    public void setRefusePhone(Boolean refusePhone) {
        this.refusePhone = refusePhone;
    }

    public Boolean getClassTimeProtect() {
        return classTimeProtect;
    }

    public void setClassTimeProtect(Boolean classTimeProtect) {
        this.classTimeProtect = classTimeProtect;
    }

    public Boolean getConcernTimeProtect() {
        return concernTimeProtect;
    }

    public void setConcernTimeProtect(Boolean concernTimeProtect) {
        this.concernTimeProtect = concernTimeProtect;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public Integer getFrequency() {
        return frequency;
    }

    public void setFrequency(Integer frequency) {
        this.frequency = frequency;
    }

    public Boolean getIsMoveRemind() {
        return isMoveRemind;
    }

    public void setIsMoveRemind(Boolean isMoveRemind) {
        this.isMoveRemind = isMoveRemind;
    }

    public Boolean getStaticOpen() {
        return staticOpen;
    }

    public void setStaticOpen(Boolean staticOpen) {
        this.staticOpen = staticOpen;
    }

    public String getStartHours() {
        return startHours;
    }

    public void setStartHours(String startHours) {
        this.startHours = startHours;
    }

    public String getEndHours() {
        return endHours;
    }

    public void setEndHours(String endHours) {
        this.endHours = endHours;
    }


    public String getTimeZoneId() {
        return timeZoneId;
    }

    public void setTimeZoneId(String timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public Boolean getDeviceOffAlarm() {
        return deviceOffAlarm;
    }

    public void setDeviceOffAlarm(Boolean deviceOffAlarm) {
        this.deviceOffAlarm = deviceOffAlarm;
    }

    public Boolean getBluetoothAccompanyState() {
        return bluetoothAccompanyState;
    }

    public void setBluetoothAccompanyState(Boolean bluetoothAccompanyState) {
        this.bluetoothAccompanyState = bluetoothAccompanyState;
    }

    public Integer getDeviceWorkModel() {
        return deviceWorkModel;
    }

    public void setDeviceWorkModel(Integer deviceWorkModel) {
        this.deviceWorkModel = deviceWorkModel;
    }

}
