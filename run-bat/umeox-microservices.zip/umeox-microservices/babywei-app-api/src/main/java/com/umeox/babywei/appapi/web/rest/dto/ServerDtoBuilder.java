package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.Server;


public class ServerDtoBuilder {

	public ServerDto build(Server server,String type, String channelSms) {
		ServerDto dto = new ServerDto();
		dto.setDeviceType(type);
		dto.setChannel(server.getChannel());
		dto.setCode(server.getCode());
		dto.setCountry(server.getCountry());
		dto.setIp(server.getIp());
		dto.setPort(server.getPort());
		dto.setChannelSms(channelSms);//添加短信修改的渠道 0不变1修改
		return dto;
	}



}
