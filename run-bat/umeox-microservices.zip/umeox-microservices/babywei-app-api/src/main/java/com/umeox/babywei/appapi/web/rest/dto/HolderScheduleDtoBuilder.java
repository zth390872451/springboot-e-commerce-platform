package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.HolderSchedule;

public class HolderScheduleDtoBuilder {

	public static HolderScheduleDto build(HolderSchedule holderSchedule,Long memberId,Long holderId) {
		HolderScheduleDto dto = new HolderScheduleDto();
		dto.setMemberId(memberId);
		dto.setHolderId(holderId);
		dto.setAmSec(holderSchedule.getAmSec());
		dto.setPmSec(holderSchedule.getPmSec());
		dto.setNightSec(holderSchedule.getNightSec());
		dto.setRepeatExpression(holderSchedule.getRepeatExpression());
		dto.setStatus(holderSchedule.getStatus());
		return dto;
	}
}
