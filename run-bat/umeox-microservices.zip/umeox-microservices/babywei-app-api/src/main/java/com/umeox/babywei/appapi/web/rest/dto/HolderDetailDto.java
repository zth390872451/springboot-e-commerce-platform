package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;


/**
 * 持有者详细信息DTO
 * @author Yan
 *
 */
public class HolderDetailDto {
	
	/**
	 * 设备编号
	 */
	private Long deviceId;
	
	/**
	 * 监护编号
	 */
	private Long monitorId;
	
	/**
	 * 持有者编号
	 */
	private Long holderId;
	
	/**
	 * 持有者名字
	 */
	private String name;
	
	/**
	 * 头像
	 */
	private String avatar;

	/**
	 * 头像(URL)
	 */
	private String fullAvatar;

	/**
	 * SIM
	 */
	private String sim;
	
	/**
	 * 生日
	 */
	private String birthday;
	
	/**
	 * 年级
	 */
	private String grade;
	
	/**
	 * 性别 男male 女 woman
	 */
	private String gender;
	
	/**
	 * 是否为监护人
	 */
	private Boolean isAdmin;
	
	/**
	 * 设备IMEI
	 */
	private String imei;
	
	/**
	 * 设备二维码
	 */
	private String qrcode;
	
	/**
	 * 定位频率
	 */
	private int frequency;
	
	/**
	 * SOS设定
	 */
	private List<String> sos = new ArrayList<String>();
	
	/**
	 * 身高
	 */
	private String height;
	
	/**
	 * 体重
	 */
	private String weight;
	/**
	 * 运动提醒
	 * 是否接收运动静止状态改变的推送，叫做运动提醒；
	       如果APP打开了开关，服务器需要记录状态，以备推送状态信息判断
	 */
	private Boolean isMoveRemind;
	
	private String relation;

	private String audioTypes;
	
	/**
	 * 渠道短信标志位
	 */
	private String channelSms;
	
	private Integer answer;
	private String timeZone;
	
	/**
	 * 是否是合约机
	 * 1：是（不能修改号码）
	 * 0：不是
	 */
	private Integer flag = 0;
	
	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getSim() {
		return sim;
	}

	public void setSim(String sim) {
		this.sim = sim;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}

	public Long getMonitorId() {
		return monitorId;
	}

	public void setMonitorId(Long monitorId) {
		this.monitorId = monitorId;
	}

	public Long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(Long deviceId) {
		this.deviceId = deviceId;
	}

	public String getQrcode() {
		return qrcode;
	}

	public void setQrcode(String qrcode) {
		this.qrcode = qrcode;
	}

	public List<String> getSos() {
		return sos;
	}

	public void setSos(List<String> sos) {
		this.sos = sos;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public Boolean getIsMoveRemind() {
		return isMoveRemind;
	}

	public void setIsMoveRemind(Boolean isMoveRemind) {
		this.isMoveRemind = isMoveRemind;
	}

	public String getAudioTypes() {
		return audioTypes;
	}

	public void setAudioTypes(String audioTypes) {
		this.audioTypes = audioTypes;
	}
	
	public String getChannelSms() {
		return channelSms;
	}

	public void setChannelSms(String channel) {
		this.channelSms = channel;
	}

	public Integer getAnswer() {
		return answer;
	}

	public void setAnswer(Integer answer) {
		this.answer = answer;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public Integer getFlag() {
		return flag;
	}

	public void setFlag(Integer flag) {
		this.flag = flag;
	}


	public String getFullAvatar() {
		return fullAvatar;
	}

	public void setFullAvatar(String fullAvatar) {
		this.fullAvatar = fullAvatar;
	}
}
