package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.conf.Push;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.YzxClient;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.repository.YzxClientRepository;
import com.umeox.babywei.service.HolderScheduleService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.thrift.device.ThriftClient;
import com.umeox.babywei.ucpaas.UcClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.async.DeferredResult;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * 视频通话
 */
@RestController
@RequestMapping("/api/video")
public class VideoController {
	
	private static final Logger logger = LoggerFactory.getLogger(VideoController.class);
	
	private final Map<String, DeferredResult<MyResponseBody>> userRequests = new ConcurrentHashMap<String, DeferredResult<MyResponseBody>>();
	
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private YzxClientRepository yzxClientRepository;
	@Autowired
	private SettingProperties setting;
	@Autowired
	private HolderScheduleService holderScheduleService;
	private RestTemplate restTemplate = new RestTemplate();
	
	
	/**
	 * 之前使用云之讯接口做视频通话服务，现在据说已经替换为声网的视频通话，接口可能已经废弃
	 * 获取云之讯Client信息
	 * 1.用户Client账号信息本地服务不存在向云之讯申请Client账号并存储数据库中
	 * 2.持有者Client账号信息获取
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/getConfig",method = RequestMethod.GET)
	public MyResponseBody config(@RequestParam(value = "memberId")Long memberId,
								@RequestParam(value = "holderId")Long holderId){
		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findOne(holderId);
		if (member == null || holder == null) {
			return fail(MyHttpStatus._404);
		}
		YzxClient memberClient = yzxClientRepository.findOneByAccountAndType(member.getMobile(), YzxClient.member_type);
		if (memberClient == null) {//申请账号
			Map<String, Object> map = UcClient.createClient();
			if (map == null) {
				return fail(MyHttpStatus._404);
			}
			memberClient = new YzxClient();
			memberClient.setClientNumber(map.get("clientNumber").toString());
			memberClient.setClientPwd(map.get("clientPwd").toString());
			memberClient.setType(YzxClient.member_type);
			memberClient.setAccount(member.getMobile());
			yzxClientRepository.save(memberClient);
		}
		YzxClient holderClient = yzxClientRepository.findOneByAccountAndType(holder.getImei(), YzxClient.device_type);
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("memberClientNumber", memberClient != null ? memberClient.getClientNumber() : null);
		map.put("memberClientPwd",    memberClient != null ? memberClient.getClientPwd()    : null);
		map.put("holderClientNumber", holderClient != null ? holderClient.getClientNumber() : null);
		return success(map);
	}
	
	
	/**
	 * 通知设备加入频道
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/notifyJoinChannel",method = RequestMethod.POST)
	public DeferredResult<MyResponseBody> notifyJoinChannel(@RequestParam(value = "memberId") Long memberId,
											@RequestParam(value = "holderId") Long holderId,
											@RequestParam(value = "version",required = false,defaultValue = "1")int version){
		long timeout = 15 * 1000L;
		if (version == 2 || version == 3) {
			timeout = 5 * 1000L;
		}
		final DeferredResult<MyResponseBody> deferredResult = new DeferredResult<MyResponseBody>(timeout, fail(MyHttpStatus._408));
		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findOne(holderId);
		if (member == null || holder == null) {
			deferredResult.setResult(fail(MyHttpStatus._404));
			return deferredResult;
		}
		boolean isDuring = holderScheduleService.isDuringClass(holder);
		if (isDuring) {
			deferredResult.setResult(fail(MyHttpStatus._404_CLASS_TIME_DURING));
			return deferredResult;
		}
		
		//待删除 临时代码，视频调用返回： Video call is temporarily unavailable due to server upgrade.  Please try again later.
		if(version != 3){
			if(ApplicationSupport.isChinaEnv()){
				//deferredResult.setResult(new MyResponseBody(40107,"很报歉！视频电话服务正在升级，暂时不能使用，请稍后再试。"));
				deferredResult.setResult(new MyResponseBody(40107,"当前版本过旧不能拨打视频电话，请将APP端升级到最新版，手表端升级到v4.6及其以上版本."));
			}else{
				//deferredResult.setResult(new MyResponseBody(40107,"Video call is temporarily unavailable due to server upgrade. Please try again later."));
				deferredResult.setResult(new MyResponseBody(40107,"The current version cannot support video calling. Please update your app for better video call experience."));
			}
			return deferredResult;
		}
		// end
		
		final String key = holder.getImei() + "-" + memberId;
		if(version == 2 || version == 3){
			@SuppressWarnings("unchecked")
			Map<String, Integer> map = restTemplate.getForObject(setting.getDeviceOnlineUrl()+holder.getImei(), Map.class);
			if (map == null || "0".equals(map.get("status"))) {
				deferredResult.setResult(fail(MyHttpStatus._404_DEVICE_NOT_ONLINE));
				logger.info("userRequests not online:{}",key);
				return deferredResult;
			}
		}
		//超时 or setResult 会执行
		if (version != 2) {
			deferredResult.onCompletion(new Runnable() {
				@Override
				public void run() {
					logger.info("userRequests completion:{}",key);
					userRequests.remove(key);
				}
			});
			deferredResult.onTimeout(new Runnable() {
				@Override
				public void run() {
					logger.info("userRequests timeout:{}",key);
				}
			});
			
			userRequests.put(key, deferredResult);
		}
		
		Map<String,String> ext = new HashMap<String,String>();
		ext.put("syncFlag", Push.K3_DEVICE_NOTIFY_JOIN_CHANNEL + "");
		ext.put("from", member.getMobile());
		ext.put("ackUrl", setting.getSelfUrl() + "/api/video/ackJoinChannel?key="+key); //频道号
		ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), ext));
		if (version == 2 || version == 3) {
			deferredResult.setResult(success());
		}
		return deferredResult;
	}
	
	/**
	 * 设备确认加入频道
	 */
	@RequestMapping(value = "/ackJoinChannel",method = RequestMethod.GET)
	public MyResponseBody ackJoinChannel(@RequestParam(value = "key") String key){
		DeferredResult<MyResponseBody> deferredResult = userRequests.get(key);
		logger.info("userRequests ack:{}",key);
		if (deferredResult != null) {
			logger.info("userRequests result:{}",key);
			deferredResult.setResult(success());
		}
		return success();
	}



	/**
	 * 通知设备加入频道
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/notifyJoinVoiceChannel", method = RequestMethod.POST)
	public DeferredResult<MyResponseBody> notifyJoinChannel(@RequestParam(value = "memberId") Long memberId,
															@RequestParam(value = "holderId") Long holderId,
															@RequestParam(value = "version") Long version) {
		long timeout = 15 * 1000L;
		final DeferredResult<MyResponseBody> deferredResult = new DeferredResult<MyResponseBody>(timeout, fail(MyHttpStatus._408));
		Member member = memberRepository.findOne(memberId);
		Holder holder = holderRepository.findOne(holderId);
		if (member == null || holder == null) {
			deferredResult.setResult(fail(MyHttpStatus._404));
			return deferredResult;
		}
		boolean isDuring = holderScheduleService.isDuringClass(holder);
		if (isDuring) {
			deferredResult.setResult(fail(MyHttpStatus._404_CLASS_TIME_DURING));
			return deferredResult;
		}

		// end
		final String key = holder.getImei() + "-" + memberId;
		System.out.println("key = " + key);
		@SuppressWarnings("unchecked")
		Map<String, Integer> map = restTemplate.getForObject(setting.getDeviceOnlineUrl() + holder.getImei(), Map.class);
		if (map == null || "0".equals(map.get("status"))) {
			deferredResult.setResult(fail(MyHttpStatus._404_DEVICE_NOT_ONLINE));
			logger.info("userRequests not online:{}", key);
			return deferredResult;
		}
		//超时 or setResult 会执行
		deferredResult.onCompletion(new Runnable() {
			@Override
			public void run() {
				logger.info("userRequests completion:{}", key);
				userRequests.remove(key);
			}
		});
		deferredResult.onTimeout(new Runnable() {
			@Override
			public void run() {
				logger.info("userRequests timeout:{}", key);
			}
		});
		userRequests.put(key, deferredResult);

		Map<String, String> ext = new HashMap<String, String>();
		//通知加入语音平道
		ext.put("syncFlag", Push.K3_DEVICE_NOTIFY_JOIN_VOICE_CHANNEL + "");
		ext.put("from", member.getMobile());
		ThriftClient.pushNotification(ThriftClient.getDefaultAppPayload(holder.getImei(), ext));
		return deferredResult;
	}

}
