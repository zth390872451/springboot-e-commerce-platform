package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import com.umeox.babywei.domain.Monitor;


public class HolderMembersDtoBuilder {
	public HolderMembersDto build(Monitor monitor) {
		HolderMembersDto dto = new HolderMembersDto();
		dto.setHolderName(monitor.getHolder().getName());
		dto.setNickName(monitor.getMember().getNickName());
		dto.setRelation(monitor.getRelation());
		dto.setMobile(monitor.getMember().getMobile());
		dto.setIsAdmin( monitor.getIsAdmin()? "1":"0" );
		return dto;
	}

	public List<HolderMembersDto> build(List<Monitor> monitors) {//use
		List<HolderMembersDto> dtos = new ArrayList<HolderMembersDto>();
		for (Monitor monitor : monitors) {
			if(monitor.getStatus())
				dtos.add(build(monitor));
		}
		return dtos;
	}
}
