package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.FileDto;
import com.umeox.babywei.conf.RedisKey;
import com.umeox.babywei.domain.*;
import com.umeox.babywei.repository.*;
import com.umeox.babywei.service.HolderAlbumFileService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.DateTimeUtils;
import com.umeox.babywei.util.JsonUtils;
import com.umeox.babywei.web.rest.BaseController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;
import static com.umeox.babywei.util.DateTimeUtils.PART_DATE_FORMAT;

/**
 * 照片
 */
@RestController
@RequestMapping("/api/holderAlbum")
public class HolderAlbumController extends BaseController {

    @Autowired
    private MemberRepository memberRepository;
    @Autowired
    private HolderRepository holderRepository;
    @Autowired
    private HolderAlbumsDayRepository holderAlbumsDayRepository;
    @Autowired
    private HolderAlbumsFileRepository holderAlbumsFileRepository;
    @Autowired
    private HolderAlbumsRepository holderAlbumsRepository;
    @Autowired
    private HolderAlbumsDayZanRepository holderAlbumsDayZanRepository;
    @Autowired
    private HolderAlbumFileService holderAlbumFileService;
    @Autowired
    private RedisService redisService;
    public static Logger logger = LoggerFactory.getLogger(HolderAlbumController.class);
    /**
     * 	8.1	获取推荐照片
     */
    @RequestMapping(value = "/recommend", method = RequestMethod.GET)
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    public MyResponseBody recommend(@RequestParam(value = "memberId") Long memberId,
                               @RequestParam(value = "holderId") Long holderId,
                                    @RequestParam(value = "lastViewTime") Long lastViewTime){
        Map<String,Object> result = new HashMap<String, Object>();
        List<String> fileList = new ArrayList<String>(4);//推荐照片列表
        Long fileUpdateNum = 0L;//照片更新数量

        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        if (member==null || holder==null){
            return fail(MyHttpStatus._400);
        }
        HolderAlbums holderAlbums = holderAlbumsRepository.findOneByHolderId(holderId);

       if (holderAlbums==null)//如果自己的相册集不存在
       {
           fileList.add("http://7xnjip.dl2.z0.glb.qiniucdn.com/wxbalbum_default_1.jpg");
           fileList.add("http://7xnjip.dl2.z0.glb.qiniucdn.com/wxbalbum_default_2.jpg");
           fileList.add("http://7xnjip.dl2.z0.glb.qiniucdn.com/wxbalbum_default_3.jpg");
           fileList.add("http://7xnjip.dl2.z0.glb.qiniucdn.com/wxbalbum_default_4.jpg");
       }else {
               Long  holderAlbumsId = holderAlbums.getId();
               //查找未查看过的照片记录:时间大于 lastViewTime 且所属人 holder
               //最近上传的四张照片作为推荐照片
               List<HolderAlbumsFile> holderAlbumsFileList = holderAlbumsFileRepository.findRecommendFiles(holderAlbumsId, HolderAlbumsFile.EXIST,4);
               fileUpdateNum = holderAlbumsFileRepository.countFileUpdateNum(holderAlbumsId, HolderAlbumsFile.EXIST,lastViewTime);

               String domain = holderAlbums.getDomain();
               String bucket = holderAlbums.getBucket();
               int count = 0;
               for (HolderAlbumsFile holderAlbumsFile : holderAlbumsFileList){
                   String fileUrl = ApplicationSupport.getCloudStorageURL(domain,bucket,holderAlbumsFile.getFileName());
                   fileList.add(fileUrl);
                   count++;
                   if (count==4)
                       break;
               }
           int i =1;
           while (fileList.size()!=4){//如果推荐列表数量不足四张，则依次添加
               fileList.add("http://7xnjip.dl2.z0.glb.qiniucdn.com/wxbalbum_default_"+i+".jpg");
               i++;
           }
       }
        result.put("holderId",holderId);
        if (lastViewTime==0){//未读数量为0
            result.put("fileUpdateNum",0);
        }else {
            result.put("fileUpdateNum",fileUpdateNum);
        }
        result.put("fileList",fileList);
        return success(result);
    }

    //获取相册照片列表接口的参数 fromDate 如果传入 0,则会被格式化成日期字符 0001-01-01
    //传0代表 永远获取最新的照片
    public static final String DATE_OTHER = "0001-01-01";

    /**
     * 	8.2	获取每日照片列表
     */
    @RequestMapping(value = "/set/list", method = RequestMethod.GET)
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    public MyResponseBody list(@RequestParam(value = "memberId") Long memberId,
                                    @RequestParam(value = "holderId") Long holderId,
                                    @RequestParam(value = "fromDate") Date fromDate,
                                     @RequestParam(value = "viewFlag") Integer viewFlag,
                                    @RequestParam(value = "day",required = false,defaultValue = "7") Integer day){
        day = day>30 ? 30:day;//day最大为30
        List<Map<String,Object>> resultList= new ArrayList<>();

        Map<String,Object> result = null;

        List<FileDto> fileList = null;

        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        if (member==null || holder==null){
            return fail(MyHttpStatus._400);
        }

        String fromDateStr = DateTimeUtils.getFormatDate(fromDate, PART_DATE_FORMAT);
        HolderAlbums holderAlbums = holderAlbumsRepository.findOneByHolderId(holderId);
        if (holderAlbums==null)//相册不存在
            return  success(resultList);
        Long  holderAlbumsId = holderAlbums.getId();

        //查找 照片记录:时间大于 lastViewTime 且所属人 holder
        List<HolderAlbumsDay> holderAlbumsDayList = new ArrayList<HolderAlbumsDay>();

        if (DATE_OTHER.equals(fromDateStr)){//永远获取最近的几天的数据(默认最近七天,以当前系统时间为基准点)
            Date nowDate = new Date();
            holderAlbumsDayList = holderAlbumsDayRepository.findAllByDayLessThanAndHolderAlbumsIdOrderByDayDesc(nowDate,holderAlbumsId);
            HolderAlbumsDay currentHolderAlbumsDay = holderAlbumsDayRepository.findOneByDayAndHolderAlbumsId(nowDate, holderAlbumsId);
            if (currentHolderAlbumsDay!=null)
                holderAlbumsDayList.add(0,currentHolderAlbumsDay);
        }else {
            if (viewFlag.equals(1)){//根据上传日期，获取 历史照片  小于指定日期 = 历史照片
                holderAlbumsDayList = holderAlbumsDayRepository.findAllByDayLessThanAndHolderAlbumsIdOrderByDayDesc(fromDate,holderAlbumsId);
            }else if (viewFlag.equals(0)){//根据上传日期，获取最新照片(包含当天的)  大于指定日期 = 最新照片
                holderAlbumsDayList = holderAlbumsDayRepository.findAllByDayGreaterThanAndDayNumGreaterThanAndHolderAlbumsIdOrderByDayDesc(fromDate,0,holderAlbumsId);
                HolderAlbumsDay currentHolderAlbumsDay = holderAlbumsDayRepository.findOneByDayAndHolderAlbumsId(fromDate, holderAlbumsId);
                if (currentHolderAlbumsDay!=null)
                    holderAlbumsDayList.add(0,currentHolderAlbumsDay);
            }
        }

        Integer fileSum = 0;//照片文件总数量
        //查看最近几天(控制记录数)
        int num = day<holderAlbumsDayList.size()? day : holderAlbumsDayList.size();
        if (holderAlbumsDayList.size()==0){
            return success(resultList);
        }

        for (int i=0; i< num ; i++ ){
            HolderAlbumsDay holderAlbumsDay  =holderAlbumsDayList.get(i);
            Integer dayNum = holderAlbumsDay.getDayNum();//当天拍的照片总数
            fileSum = fileSum +dayNum;//查询的照片总数=查询的这几天总数相加

            result =  new HashMap<String, Object>();
            String shootDate = DateTimeUtils.getFormatDate(holderAlbumsDay.getDay(), PART_DATE_FORMAT);//拍摄日期
            //按日期查询上传的图片
            List<HolderAlbumsFile> holderAlbumsFileList = holderAlbumsFileRepository.findAllByDayAndHolderAlbumsId(shootDate, holderAlbumsId,HolderAlbumsFile.EXIST);
            if (holderAlbumsFileList.size()>9){//大于9返回前9张
                List<HolderAlbumsFile> subList = holderAlbumsFileList.subList(0, 9);//默认返回9张照片
                fileList = getFileDtoList(subList);
                result.put("dayMoreFlag",1);//当天文件数量大于9，则当天有更多照片为显示(一行最多显示9张)
            }else {//小于等于9返回所有的
                fileList = getFileDtoList(holderAlbumsFileList);
                result.put("dayMoreFlag",0);
            }

            HolderAlbumsDayZan dayAndIsZan = holderAlbumsDayZanRepository.findByMemberIdAndDayAndIsZan(memberId, holderAlbumsDay.getDay(), true);
            result.put("holderId",holderId);
            result.put("day",shootDate);//相片日期
            result.put("fileList",fileList);//照片列表
            result.put("dayNum",dayNum);

            result.put("isUpvote",!StringUtils.isEmpty(dayAndIsZan));//是否点赞过
            resultList.add(result);

        }
        return success(resultList);
    }


    /**
     * 	8.3	获取每日更多照片列表
     */
    @RequestMapping(value = "/day/list", method = RequestMethod.GET)
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    public MyResponseBody dayList(@RequestParam(value = "memberId") Long memberId,
                                    @RequestParam(value = "holderId") Long holderId,
                                    @RequestParam(value = "fromTime") Long fromTime,
                                  @RequestParam(value = "rows",required = false,defaultValue = "9") Integer rows){
        rows = rows>100 ? 100:rows;//day最大为100
        Map<String,Object> result = new HashMap<>();
        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        if (member==null || holder==null){
            return fail(MyHttpStatus._400);
        }

        Date today = new Date(fromTime);
        String searchDay = DateTimeUtils.getFormatDate(today, PART_DATE_FORMAT);
        Date todayStart = DateTimeUtils.parseString2Date(searchDay, PART_DATE_FORMAT);//当天的 0点0分的时间戳
        Date todayEnd = DateTimeUtils.addDays(todayStart, 1);

        HolderAlbums holderAlbums = holderAlbumsRepository.findOneByHolderId(holderId);
        Long  holderAlbumsId = holderAlbums.getId();


        List<HolderAlbumsFile> holderAlbumsFileList =  new ArrayList<>();
        holderAlbumsFileList = holderAlbumsFileRepository.findAllByUploadTimeAndHolderAlbumsIdAndStatus(todayStart.getTime(),fromTime-1, holderAlbumsId,HolderAlbumsFile.EXIST,rows);//不加限制

        List<FileDto> fileList = this.getFileDtoList(holderAlbumsFileList);

        HolderAlbumsDay holderAlbumsDay = holderAlbumsDayRepository.findOneByDayAndHolderAlbumsId(today, holderAlbumsId);
        Integer dayNum = holderAlbumsDay!=null ? holderAlbumsDay.getDayNum(): 0;//当天的总的照片数量
        //查找 fromTime-1 ~ 当天24点的记录数 (已查看的)
        //查询时间-1 是为了包含当前最后一张照片的时间戳对应的记录(APP端取得最后一张照片也是查看过了的)
        List<HolderAlbumsFile> beforeFromTime = holderAlbumsFileRepository.findAllByUploadTimeAndHolderAlbumsIdAndStatus(fromTime-1, todayEnd.getTime(), holderAlbumsId, HolderAlbumsFile.EXIST, rows);
        if(dayNum>beforeFromTime.size()+holderAlbumsFileList.size()){//当天总记录数>已查看记录数+当页显示数量，则表示下一页还有 未显示的照片
            result.put("dayMoreFlag",1);
        }else {
            result.put("dayMoreFlag",0);
        }
        result.put("holderId",holderId);
        result.put("day",searchDay);//相片日期
        result.put("fileList",fileList);//照片列表
        result.put("dayNum",dayNum);

        return success(result);
    }

    private List<FileDto> getFileDtoList(List<HolderAlbumsFile> holderAlbumsFileList) {
        List<FileDto> fileList = new ArrayList<FileDto>();
        for (HolderAlbumsFile holderAlbumsFile: holderAlbumsFileList){
            String domain = holderAlbumsFile.getHolderAlbums().getDomain();
            String bucket = holderAlbumsFile.getHolderAlbums().getBucket();
            String fileUrl = ApplicationSupport.getCloudStorageURL(domain,bucket,holderAlbumsFile.getFileName());
            String thumbnailUrl = fileUrl ;//+ "?x-oss-process=image/resize,h_432,w_576";//将图缩略成宽度为h1，高度为h2，按长边优先
            FileDto fileDto = new FileDto(holderAlbumsFile.getUploadTime(),holderAlbumsFile.getId()+"" ,fileUrl,thumbnailUrl);
            fileList.add(fileDto);
        }
        return fileList;
    }


    /**
     * 每日照片点赞
     * @return
     */
    @RequestMapping(value = "/day/upvote", method = RequestMethod.POST)
    @DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
    public MyResponseBody dayUpvote(@RequestParam(value = "memberId") Long memberId,
                                  @RequestParam(value = "holderId") Long holderId,
                                  @RequestParam(value = "day") String day){

        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        HolderAlbums holderAlbums = holderAlbumsRepository.findOneByHolderId(holderId);
        if (member==null || holder==null || holderAlbums==null){
            return fail(MyHttpStatus._400);
        }
        Date date = DateTimeUtils.parseString2Date(day, PART_DATE_FORMAT);
        HolderAlbumsDayZan isZan = holderAlbumsDayZanRepository.findByMemberIdAndDayAndIsZan(memberId, date, true);
        if (isZan!=null){
            return fail(MyHttpStatus._406_ZAN_CLICKED);//已经点赞过了
        }
        //查找当天是否有存在上传的文件
        List<HolderAlbumsFile> albumsFiles = holderAlbumsFileRepository.findAllByDayAndHolderAlbumsId(day, holderAlbums.getId(), HolderAlbumsFile.EXIST);
        if (albumsFiles.size()>0){
            HolderAlbumsDayZan holderAlbumsDayZan = new HolderAlbumsDayZan();
            holderAlbumsDayZan.setDay(date);
            holderAlbumsDayZan.setHolderAlbums(holderAlbums);
            holderAlbumsDayZan.setIsZan(true);
            holderAlbumsDayZan.setMember(member);
            holderAlbumsDayZan.setZanTime(new Date());
            holderAlbumsDayZanRepository.save(holderAlbumsDayZan);

            // 当前设备点赞总数
            Long dayZanSum = holderAlbumsDayZanRepository.countByHolderAlbumsAndDayAndIsZanAndIsZan(holderAlbums.getId(), 1);
            Map<String, Object> map = holderAlbumFileService.sendHolderAlbumsDayZan(member.getMobile(), holder.getImei(), dayZanSum);
            redisService.rightPush(RedisKey.QUE_API2_SOCKET_IM, map);
            return success();
        }else {//点赞文件不存在(或者参数错误)
            return fail(MyHttpStatus._404);
        }
    }


    /**
     *  删除相册照片
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    public MyResponseBody delete(@RequestParam(value = "memberId") Long memberId,
                                    @RequestParam(value = "holderId") Long holderId,
                                    @RequestParam(value = "fileIds") String fileIds){
        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        if (member==null || holder==null){
            return fail(MyHttpStatus._400);
        }
        List<String> idList = JsonUtils.toObject(fileIds, List.class);
        if (StringUtils.isEmpty(idList))
            return fail(MyHttpStatus._400);

        List<HolderAlbumsFile> holderAlbumsFiles = holderAlbumsFileRepository.findAllIdIn(idList,holderId,HolderAlbumsFile.EXIST);
        //将删除的照片分类：某天几张
        Map<String,Integer> dateNum = new HashMap<>();
        for (HolderAlbumsFile holderAlbumsFile : holderAlbumsFiles){
                Date date = new Date(holderAlbumsFile.getUploadTime());
                holderAlbumsFile.setStatus(HolderAlbumsFile.DELETED);
                String formatDate = DateTimeUtils.getFormatDate(date, PART_DATE_FORMAT);
                if (formatDate!=null){
                    if (dateNum.get(formatDate)!=null){
                        dateNum.put(formatDate,dateNum.get(formatDate)+1);
                    }else {
                        dateNum.put(formatDate,1);
                    }
                }
        }
        if (CollectionUtils.isEmpty(holderAlbumsFiles)){
            return success();
        }
        HolderAlbums holderAlbums = holderAlbumsFiles.get(0).getHolderAlbums();
        List<HolderAlbumsDay> holderAlbumsDays = holderAlbumsDayRepository.findAllByHolderAlbumsId(holderAlbums.getId());
        List<HolderAlbumsDay> emptyAlbumsDays = new ArrayList<>();
        List<HolderAlbumsDay> notEmptyAlbumsDays = new ArrayList<>();
        for (HolderAlbumsDay holderAlbumsDay : holderAlbumsDays){
            Date date = holderAlbumsDay.getDay();
            String formatDate = DateTimeUtils.getFormatDate(date, PART_DATE_FORMAT);
            Integer num = dateNum.get(formatDate);
            if (!StringUtils.isEmpty(num)){
                Integer residue = holderAlbumsDay.getDayNum() - num;//剩余照片
                holderAlbumsDay.setDayNum(residue);
                if (residue==0){
                    //删除 holderAlbumsDay
                    emptyAlbumsDays.add(holderAlbumsDay);
                }else {
                    //更新
                    notEmptyAlbumsDays.add(holderAlbumsDay);
                }
            }
        }
        logger.info("holderAlbumsFiles:{},emptyAlbumsDays:{},notEmptyAlbumsDays:{}",holderAlbumsFiles,emptyAlbumsDays,notEmptyAlbumsDays);
        holderAlbumFileService.updateAlbumFileAndDays(holderAlbumsFiles,emptyAlbumsDays,notEmptyAlbumsDays);

        return success();
    }


    @Autowired
    private HolderPaipaiSpaceRepository holderPaipaiSpaceRepository;

    /**
     *   管理员 分享到拍拍秀
     * @return
     */
    @RequestMapping(value = "/shareToPaipai", method = RequestMethod.POST)
    @DataPermission(value = DataPermissionType.HOLDER_ADMIN)
    public MyResponseBody shareToPaipai(@RequestParam(value = "memberId") Long memberId,
                                 @RequestParam(value = "holderId") Long holderId,
                                 @RequestParam(value = "fileIds") String fileIds,
                                        @RequestParam(value = "shareTitle",required = false) String shareTitle,
                                        @RequestParam(value = "shareDesc",required = false) String shareDesc
                                        ){
        Member member = memberRepository.findOne(memberId);
        Holder holder = holderRepository.findOne(holderId);
        HolderAlbums holderAlbums = holderAlbumsRepository.findOneByHolderId(holderId);
        if (member==null || holder==null || holderAlbums==null){
            return fail(MyHttpStatus._400);
        }
        List<Integer> idList  = JsonUtils.toObject(fileIds, List.class);
        if (StringUtils.isEmpty(idList))
            return fail(MyHttpStatus._400);
        if (idList.size()>9){//最多9张
            return fail(MyHttpStatus._400);
        }

        List<HolderAlbumsFile> holderAlbumsFiles = new ArrayList<>();
        for (int i= 0; i<idList.size(); i++){
            HolderAlbumsFile holderAlbumsFile = holderAlbumsFileRepository.findOne(new Long(idList.get(i)));
            if (holderAlbumsFile!=null && holderAlbumsFile.getStatus().equals(0)){//照片存在
                holderAlbumsFile.setAccessFlag(1);//公开
                holderAlbumsFile.setShareDesc(shareDesc);
                holderAlbumsFile.setShareTitle(shareTitle);
                holderAlbumsFile.setShareDate(new Date());//分享时间
                holderAlbumsFiles.add(holderAlbumsFile);
                holderAlbumsFile = holderAlbumsFileRepository.save(holderAlbumsFile);

                if (i==idList.size()-1){//最近一次分享时间(最后一个文件为最近分享的文件)
                    if (!holderId.equals(holderAlbumsFile.getHolderAlbums().getHolder().getId())){
                        return fail(MyHttpStatus._400);
                    }
                    HolderPaipaiSpace holderPaipaiSpace = holderPaipaiSpaceRepository.findOneByHolderId(holder.getId());
                    if (holderPaipaiSpace==null){
                        holderPaipaiSpace = new HolderPaipaiSpace();
                        holderPaipaiSpace.setHolder(holder);
                    }
                    //设置初始点赞文件和初始查看文件
                    if (holderPaipaiSpace.getMostViewFile()==null){
                        holderPaipaiSpace.setMostZanFile(holderAlbumsFile);
                        holderAlbumsFile.setZanNum(0);
                    }
                    if (holderPaipaiSpace.getMostViewFile()==null){
                        holderPaipaiSpace.setMostViewFile(holderAlbumsFile);
                        holderPaipaiSpace.setViewNum(0);
                    }
                    //最后分享文件
                    holderPaipaiSpace.setLastShareFile(holderAlbumsFile);
                    holderPaipaiSpace.setLastShareTime(holderAlbumsFile.getShareDate().getTime());
                    holderPaipaiSpaceRepository.save(holderPaipaiSpace);
                }
            }else {//被分享的图片 不存在
                return fail(MyHttpStatus._400);
            }

        }
        return success();
    }

}
