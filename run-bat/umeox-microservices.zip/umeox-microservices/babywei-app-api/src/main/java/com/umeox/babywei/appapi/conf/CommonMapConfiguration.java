package com.umeox.babywei.appapi.conf;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration("commonMap")
@ConfigurationProperties(prefix = "common")
public class CommonMapConfiguration {
	private Map<String, String> downloadUrl = new HashMap<String, String>();

	public Map<String, String> getDownloadUrl() {
		return downloadUrl;
	}
	
	
}
