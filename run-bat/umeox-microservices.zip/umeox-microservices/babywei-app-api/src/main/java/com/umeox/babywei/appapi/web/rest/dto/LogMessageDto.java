package com.umeox.babywei.appapi.web.rest.dto;

public class LogMessageDto {
	private Long messageId;
	/**
	 * 消息类型 
	 * 1：电量警告
	 * 2：充电提醒
	 * 3：超出围栏
	 * 4: 定位消息
	 * 5：录音消息
	 */
	private int type;
	
	
	/**
	 * 消息
	 */
	private String msg;
	
	
	/**
	 * 地址
	 */
	private String address;
	
	/**
	 * 经度
	 */
	private Double longitude;
	
	/**
	 * 纬度
	 */
	private Double latitude;
	
	/**
	 * 区域范围
	 */
	private Double radius;
	
	/**
	 * 编号
	 */
	private Long barrierId;
	
	private Long memberId;
	
	/**
	 * 时间
	 */
	private String date;
	/**
	 * 胶囊名称
	 */
	private String nickName;
	/**
	 * 胶囊的IMEI
	 */
	private String imei;
	
	/**
	 * 胶囊的sim
	 */
	private String sim;
	/**
	 * 录音地址
	 */
	private String tapurl;

	private String fullTapUrl;//兼容所有设备类型：全路径的url

	public String getFullTapUrl() {
		return fullTapUrl;
	}

	public void setFullTapUrl(String fullTapUrl) {
		this.fullTapUrl = fullTapUrl;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getRadius() {
		return radius;
	}

	public void setRadius(Double radius) {
		this.radius = radius;
	}

	public Long getBarrierId() {
		return barrierId;
	}

	public void setBarrierId(Long barrierId) {
		this.barrierId = barrierId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}


	public Long getMessageId() {
		return messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getSim() {
		return sim;
	}

	public void setSim(String sim) {
		this.sim = sim;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	public String getTapurl() {
		return tapurl;
	}

	public void setTapurl(String tapurl) {
		this.tapurl = tapurl;
	}
}
