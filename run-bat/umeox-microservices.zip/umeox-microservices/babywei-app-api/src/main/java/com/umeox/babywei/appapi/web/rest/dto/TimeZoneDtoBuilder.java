package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.umeox.babywei.domain.TimeZone;
import com.umeox.babywei.util.TimeZoneUtils;

public class TimeZoneDtoBuilder {
	
	public static List<TimeZoneDto> builder(List<TimeZone> timeZoneList){
		List<TimeZoneDto> respList = new ArrayList<TimeZoneDto>();
		for (TimeZone timeZone : timeZoneList) {
			TimeZoneDto timeZoneDto = new TimeZoneDto();
			String timeZodeId = timeZone.getTimeZoneId();
			timeZoneDto.setTimeZoneId(timeZodeId);
			timeZoneDto.setName(timeZodeId);
			Map<String, Object> map = TimeZoneUtils.displayTimeZoneMap(timeZodeId);
			timeZoneDto.setGmt(map.get("result").toString());
			timeZoneDto.setVal(Long.parseLong(map.get("time").toString()));
			respList.add(timeZoneDto);
		}
		return respList;
	}
	
	
	public static List<TimeZoneDto> sort(List<TimeZoneDto> list){
		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < list.size()-i-1; j++) {
				if (list.get(j).getVal() > list.get(j+1).getVal()) {
					TimeZoneDto temp = list.get(j);
					list.set(j, list.get(j+1));
					list.set(j + 1, temp);
				}
				if (list.get(j).getVal() == list.get(j+1).getVal()) {
					String str1 = list.get(j).getTimeZoneId();
					String str2 = list.get(j+1).getTimeZoneId();
					int len1 = str1.length();
					int len2 = str2.length();
					int len = 0;
					if (len1 >= len2) {
						len = len2;
					}else {
						len = len1;
					}
					//两个字符串没有包含关系，所以不考虑两个字符串长度不相等的情况
					for (int k = 0; k < len; k++) {
						if (str1.charAt(k) > str2.charAt(k)) {//ascii码比较
							TimeZoneDto temp = list.get(j);
							list.set(j, list.get(j+1));
							list.set(j + 1, temp);
							break;
						}else if(str1.charAt(k) < str2.charAt(k)){
							break;
						} else {
							;
						}
					}
				}
			}
		}
		return list;
	}
	
}
