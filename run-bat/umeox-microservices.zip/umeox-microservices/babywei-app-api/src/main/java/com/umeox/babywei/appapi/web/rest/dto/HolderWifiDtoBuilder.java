package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.HolderWifi;

import java.util.ArrayList;
import java.util.List;

public class HolderWifiDtoBuilder {
	public static List<HolderWifiDto> build(List<HolderWifi> holderWifis) {
		List<HolderWifiDto> dtos = new ArrayList<HolderWifiDto>();
		for (HolderWifi dao : holderWifis) {
				dtos.add(new HolderWifiDto(dao));
		}
		return dtos;
	}
}
