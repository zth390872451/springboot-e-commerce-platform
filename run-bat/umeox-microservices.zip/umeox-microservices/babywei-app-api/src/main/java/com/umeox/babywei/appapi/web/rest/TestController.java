package com.umeox.babywei.appapi.web.rest;


import com.umeox.babywei.conf.Push;
import com.umeox.babywei.plugin.PushClient;
import com.umeox.babywei.service.PushService;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

import static com.umeox.babywei.constant.PushConstant.DEFAULT_TIME_TO_LIVE;
import static com.umeox.babywei.support.MyResponseBuilder.success;
import static com.umeox.babywei.util.XiaoMiUtil.Notification_Type;

//import com.alibaba.fastjson.

@RestController
@RequestMapping( { "/api/push/" })
public class TestController {

	@Autowired
	private PushService pushService;


	@RequestMapping(value = "/pushAppInfo")
	public MyResponseBody test()throws Exception{
		/*Map<String,String> extras = new HashMap<>();
		extras.put("test","extra");
		boolean flag = HuaWeiUtil.sendAndroidAll(MI_PACKAGE_NAME,new ArrayList<String>(Arrays.asList(alias)),"title","description","payload", extras);
		System.out.println("flag = " + flag);*/
		/*SettingProperties settingProperties   = (SettingProperties) ApplicationSupport.getBean("settingProperties");
		File file = new File(settingProperties.getKeyStorebjPath());
		try {
			InputStream inputStream = new FileInputStream(file);
			System.out.println("inputStream = " + inputStream);
			OAuth2Client oauth2Client = new OAuth2Client();
//            File file = ResourceUtils.getFile("s/mykeystorebj.jks");
//            boolean canRead = file.canRead();
//            System.out.println("file = " + file.getName()+ canRead);
			oauth2Client.initKeyStoreStream(inputStream, "123456");
//            String packagename = "com.example.huaweipush";
			String appId = "10890291";
			String appKey = "058a4966789fa598cc495ebe67b7cac8";

			AccessToken access_token = oauth2Client.getAccessToken("client_credentials", appId, appKey);
			System.out.println("access_token = " + access_token);
			System.err.println("access token :" + access_token.getAccess_token() + ",expires time[access token 过期时间]:");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}*/
//		NSPClient nspClient = HuaWeiUtil.getNSPClient("com.example.huaweipush");
		String token  = "0864914033283265300000392900CN01";

		HashMap<String, String> extras = new HashMap<>();
		extras.put("testkey","testvalue");
		//调用push单发接口
		HuaWeiUtil.sendMessage("com.umeox.capsule",token,"华为推送测试：透传消息");

		String xiaomi_alias = "86398502560466913684915971";
		XiaoMiUtil.sendMsg("com.hemdenry.xiaomipush",new ArrayList<String>(Arrays.asList(xiaomi_alias)),"titile","描述信息","payload信息",extras, Notification_Type);
		return success();
	}



	@RequestMapping(value = "/miweiPush")
	public MyResponseBody test2(@RequestParam(value = "xiaomiAlias") String xiaomiAlias,@RequestParam(value = "packageName") String packageName
			,@RequestParam(value = "title") String title
			,@RequestParam(value = "msgContent") String msgContent
			,@RequestParam(value = "description") String description)throws Exception{
		String token  = "0864914033283265300000392900CN01";
		HashMap<String, String> extras = new HashMap<>();
		extras.put("testkey","testvalue");
		//调用push单发接口
		HuaWeiUtil.sendMessage("com.umeox.capsule",token,"华为推送测试：透传消息");
		HuaWeiUtil.notification_send("com.umeox.capsule",token,title,msgContent,extras);
		XiaoMiUtil.sendMsg(packageName,new ArrayList<String>(Arrays.asList(xiaomiAlias)),title,description,msgContent,extras,Notification_Type);
		return success();
	}


	@RequestMapping(value = "/jpush")
	public MyResponseBody push(@RequestParam(value = "alias") String alias,@RequestParam(value = "title") String title
			,@RequestParam(value = "msgContent") String msgContent
			,@RequestParam(value = "description") String description
			,@RequestParam(value = "extra") String extra
			,@RequestParam(value = "deviceType") String deviceType
			,@RequestParam(value = "saleChannel") String saleChannel)throws Exception{

		Map<String,String> extraJson = JsonUtils.toObject(extra,Map.class);
		System.out.println("extraJson = " + extraJson);

//		PushClient.sendPushAndroidNotification(alias,msgContent,extraJson,deviceType,saleChannel);
//推送
		Map<String, String> param = new HashMap<String, String>();
		param.put("cmd", Push.IM_CHAT + "");
		param.put("holderId", 1 + "");
		param.put("datatime", DateTimeUtils.getFormatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));//这个不会有问题吗？ datatime
		param.put("logMessageId", 0 + "");
		PushClient.sendTitlePushMessage(title,alias,msgContent,extraJson,deviceType,saleChannel);
//		PushClient.sendAndroidTitlePushMessage(title,alias,msgContent,extraJson,deviceType,saleChannel,5);

		return success();
	}


	@RequestMapping(value = "/fcmPush")
	public MyResponseBody push(@RequestParam(value = "packageName") String packageName,
							   @RequestParam(value = "alias") String alias,
							   @RequestParam(value = "title") String title
			,@RequestParam(value = "msgContent") String msgContent
			,@RequestParam(value = "description") String description
			,@RequestParam(value = "extra") String extra
			)throws Exception{
		Map map = JsonUtils.toObject(extra, Map.class);
		/*Map<String, String> param = new HashMap<String, String>();
		param.put("cmd", Push.IM_CHAT + "");
		param.put("from","60946" );
		PushService pushService = new PushServiceImpl();
		String packageName = "com.doki.dokiwatch";
		String title = "Receive Message";
		String alias = "FCM_71305_ANDROID";
		String msgContent = "taylor dark has sent you a new message test02 zth";*/
//		PushUtils.fcmPush(title,alias,msgContent,map,DEFAULT_TIME_TO_LIVE);
		pushService.sendMsg(packageName,alias,title,msgContent,map,DEFAULT_TIME_TO_LIVE);
		return success();
	}


}
