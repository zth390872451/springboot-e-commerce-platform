package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.util.PushUtils;
import org.springframework.util.StringUtils;

import static com.umeox.babywei.domain.Member.JPUSH_PUSH;

public class MemberDtoBuilder {

	private final static SettingProperties setting;

	static {
		setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
	}

	public static MemberDto build(Member member) {
		MemberDto resp = new MemberDto();
		resp.setMemberId(member.getId());
		if (!StringUtils.isEmpty(member.getAvatar())) {
			resp.setAvatar(setting.getSiteUrl() + member.getAvatar());
		}
		resp.setMobile(member.getMobile());
		resp.setNickName(member.getNickName());
		/*resp.setName(member.getName());
		resp.setFamilyName(member.getFamilyName());*/
		resp.setTel(member.getTel());
		if (!StringUtils.isEmpty(member.getGender())) {
			resp.setGender(member.getGender().ordinal());
		}
		if (JPUSH_PUSH.equals(member.getPushMode())) {
			resp.setAlias(member.getMobile());
		} else {
			resp.setAlias(PushUtils.PREFIX + member.getId());
		}
		return resp;
	}

}
