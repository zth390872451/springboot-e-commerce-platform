package com.umeox.babywei.appapi.web.rest.dto;

import java.util.List;


public class PageDto<T> {
	private int totalPages;//共多少页
	private int number;//页索引
	private int size;//页条数
	private List<T> content;
	
	
	public int getTotalPages() {
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public List<T> getContent() {
		return content;
	}
	public void setContent(List<T> content) {
		this.content = content;
	}
	
}
