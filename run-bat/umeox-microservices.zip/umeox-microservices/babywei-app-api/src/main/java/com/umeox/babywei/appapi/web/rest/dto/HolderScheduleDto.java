package com.umeox.babywei.appapi.web.rest.dto;


public class HolderScheduleDto {
	
	private Long memberId;
	
	private Long holderId;
	
	private String amSec;
	
	private String pmSec;
	
	private String repeatExpression;

	private Boolean status;
	/**
	 * 晚上时段
	 */
	private String nightSec;

	public String getNightSec() {
		return nightSec;
	}

	public void setNightSec(String nightSec) {
		this.nightSec = nightSec;
	}
	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}

	public String getAmSec() {
		return amSec;
	}

	public void setAmSec(String amSec) {
		this.amSec = amSec;
	}

	public String getPmSec() {
		return pmSec;
	}

	public void setPmSec(String pmSec) {
		this.pmSec = pmSec;
	}

	public String getRepeatExpression() {
		return repeatExpression;
	}

	public void setRepeatExpression(String repeatExpression) {
		this.repeatExpression = repeatExpression;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	
	
}
