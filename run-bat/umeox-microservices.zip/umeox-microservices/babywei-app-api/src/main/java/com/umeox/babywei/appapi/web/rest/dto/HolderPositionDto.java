package com.umeox.babywei.appapi.web.rest.dto;

public class HolderPositionDto {
	private Long id;
	/**
	 * 经度
	 */
	private Double longitude;
	
	/**
	 * 纬度
	 */
	private Double latitude;
	
	/**
	 * 上报时间
	 */
	private String date;
	
	/**
	 * 基站
	 */
	private String station;
	
	/**
	 * 电量
	 */
	private Integer electric;
	
	/**
	 * 是否超出范围
	 */
	private int outrange = 2;
	
	private String address;
	
	/**
	0	定位方式：
	0 开启GPS定位 1 未开启GPS定位
	*/
    private String  locationMode;
	
	private String timeQuantum;//时间段
	
	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getStation() {
		return station;
	}

	public void setStation(String station) {
		this.station = station;
	}

	public Integer getElectric() {
		return electric;
	}

	public void setElectric(Integer electric) {
		this.electric = electric;
	}

	public int getOutrange() {
		return outrange;
	}

	public void setOutrange(int outrange) {
		this.outrange = outrange;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLocationMode() {
		return locationMode;
	}

	public void setLocationMode(String locationMode) {
		this.locationMode = locationMode;
	}


	public String getTimeQuantum() {
		return timeQuantum;
	}

	public void setTimeQuantum(String timeQuantum) {
		this.timeQuantum = timeQuantum;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}


}
