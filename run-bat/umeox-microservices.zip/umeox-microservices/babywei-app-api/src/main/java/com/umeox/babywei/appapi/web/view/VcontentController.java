package com.umeox.babywei.appapi.web.view;

import static com.umeox.babywei.support.MyResponseBuilder.success;
import static com.umeox.babywei.support.MyResponseBuilder.fail;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Content;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderStep;
import com.umeox.babywei.domain.enums.ContentType;
import com.umeox.babywei.repository.ContentRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.HolderStepRepository;
import com.umeox.babywei.service.ContentService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.DateTimeUtils;


/**
 * @author umeox
 */
@Controller
@RequestMapping({"/api/content"})
public class VcontentController {

	@Autowired
	private ContentService contentService;
	@Autowired
	private ContentRepository contentRepository;
	@Autowired
	private HolderStepRepository holderStepRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private Environment env;
	@Autowired
	private SettingProperties setting;
	
	@RequestMapping(value = { "show" }, method = { RequestMethod.GET })
	public String show(Long id,ModelMap model){
		
		Content content = contentService.updateViewCnt(id);
		String serverPath = env.getProperty("server.context-path");//就一个，暂时这样处理，可以通过freemarker参数配置
		
		model.addAttribute("base",serverPath);
		model.addAttribute("content",content);
		return "/show";
	}
	@RequestMapping(value = { "load" }, method = { RequestMethod.POST ,RequestMethod.GET })
	@ResponseBody
	public MyResponseBody load(Long holderId,String date,String callback,HttpServletResponse response) throws IOException{
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		
		if(StringUtils.isEmpty(holderId)){
			 return fail(MyHttpStatus._400);
		}
		Date stepDate = null;
		if(StringUtils.isEmpty(date)){
			stepDate = new Date();
		}else{
			stepDate = DateTimeUtils.parseString2Date(date, DateTimeUtils.PART_DATE_FORMAT);
		}
		JSONObject json = new JSONObject();
		Map<String,Object> stepMap = new HashMap<String,Object>();
		HolderStep holderStep = holderStepRepository.findOneByHolderIdAndStepDate(holderId,stepDate);
		Holder holder = holderRepository.findOne(holderId);
		if(holderStep != null){
			stepMap.put("stepNum", holderStep.getStepValue());
			stepMap.put("name", holderStep.getHolder().getName());
			stepMap.put("imgUrl", setting.getSiteUrl()+holderStep.getHolder().getAvatar());
			stepMap.put("detailsUrl", env.getProperty("setting.selfUrl")+"/api/holderStep/step?holderId="+holderId+"&stepDate="+date+"&type=-1");
		}
		
		try {
			json.put("deviceType", holder.getDevice().getDeviceType());
			json.put("step", stepMap);
			json.put("ad", this.buildContent(contentRepository.findByType(ContentType.AD.getId())));
			json.put("eat", this.buildContent(contentRepository.findByTypeAndLimit(ContentType.EAT.getId(), 2)));
			json.put("health", this.buildContent(contentRepository.findByTypeAndLimit(ContentType.HEALTH.getId(), 3)));
			json.put("everyDay", this.buildContent(contentRepository.findByTypeAndLimit(ContentType.EVERYDAY.getId(), 1)));
		} catch (Exception e) {
			 e.printStackTrace();
			 return fail();
		}
		return success(json.toString());
	}
	
	@RequestMapping(value = { "listContent" }, method = { RequestMethod.POST ,RequestMethod.GET })
	@ResponseBody
	public MyResponseBody listContent(@PageableDefault(size=10)Pageable pageable,String type,HttpServletResponse response) throws IOException{
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "x-requested-with");
		
		if(StringUtils.isEmpty(type)){
			return fail(MyHttpStatus._400);
		}
		Page<Content> page = contentRepository.findAll(this.getSpecification(type), pageable);
		List<Object> data = new ArrayList<Object>();
		for(Content content: page.getContent()){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("id", content.getId());
			map.put("imgUrl", content.getImg());
			map.put("title", content.getTitle());
			map.put("publishDate", DateTimeUtils.getFormatDate(content.getPublishDate(), DateTimeUtils.FULL_DATE_FORMAT)); 
			map.put("detailsUrl", content.getContent());
			data.add(map);
		}
		Map<String,Object> pageMap = new HashMap<String,Object>(); 
		pageMap.put("size", page.getSize());
		pageMap.put("number", page.getNumber());
		pageMap.put("totalPages", page.getTotalPages());
		
		JSONObject json = new JSONObject();
		try {
			json.put("page", pageMap);
			json.put("list", data);
		} catch (Exception e) {
			e.printStackTrace();
			return fail();
		}
		return success(json.toString());
	}
	
	private Specification<Content> getSpecification(final String type){
		return new Specification<Content>(){

			@Override
			public Predicate toPredicate(Root<Content> root,
					CriteriaQuery<?> query, CriteriaBuilder cb) {
				List<Predicate> predicate = new ArrayList<>();
				if(!StringUtils.isEmpty(type)){
					predicate.add(cb.equal(root.get("type").as(Integer.class),type));
				}
				predicate.add(cb.lessThan(root.get("publishDate").as(Date.class),new Date()));
				predicate.add(cb.equal(root.get("enabled").as(boolean.class),true));
				Predicate[] pre = new Predicate[predicate.size()];
				query.where(predicate.toArray(pre));
				 List<Order> orders = new ArrayList<Order>();
				 orders.add(cb.desc(root.get("seq").as(Integer.class)));
				 orders.add(cb.desc(root.get("publishDate").as(Date.class)));
				query.orderBy(orders);
                return query.getRestriction();
			}
			
		};
	}
	
	private List<Object> buildContent(List<Content> list){
		List<Object> data = new ArrayList<Object>();
		for(Content content : list){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("type", content.getType().getId());
			if(content.getType().getId().equals(ContentType.AD.getId())){
				map.put("imgUrl", content.getImg());
			}else{
				if(StringUtils.isEmpty(content.getThumbnail())){
					map.put("imgUrl", content.getImg());
				}else{
					map.put("imgUrl", content.getThumbnail());
				}
			}
			map.put("remark", content.getTitle());
			map.put("detailsUrl", content.getContent());
			data.add(map);
		}
		return data;
	}

	
}
