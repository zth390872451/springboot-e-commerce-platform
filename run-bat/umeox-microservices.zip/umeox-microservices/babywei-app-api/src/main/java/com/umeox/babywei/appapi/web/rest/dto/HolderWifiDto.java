package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.domain.HolderWifi;

/**
 *
 */
public class HolderWifiDto {

    private String ssid;//WiFi名称

    private String password;//WiFi密码

    private Long wifiId;

    public HolderWifiDto() {
    }

    public HolderWifiDto(HolderWifi holderWifi) {
        super();
        this.setWifiId(holderWifi.getId());
        this.ssid = holderWifi.getSsid();
        this.password = holderWifi.getPassword();
    }

    public HolderWifiDto(String ssid, String password) {
        this.ssid = ssid;
        this.password = password;
    }

    public Long getWifiId() {
        return wifiId;
    }

    public void setWifiId(Long wifiId) {
        this.wifiId = wifiId;
    }

    public String getSsid() {
        return ssid;
    }

    public void setSsid(String ssid) {
        this.ssid = ssid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
