package com.umeox.babywei.appapi.web.rest.dto;

public class HolderAlarmDto {
	
	private Long alarmId;
	
	private String alarmName;
	
	private Long alarmTime;
	
	private String alarmTimeStr;
	
	private Integer repeatFlag;
	
	private String repeatExpression;
	
	private Boolean status;

	private Integer ringType;

	private String icon;

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Integer getRingType() {
		return ringType;
	}

	public void setRingType(Integer ringType) {
		this.ringType = ringType;
	}

	public Long getAlarmId() {
		return alarmId;
	}

	public void setAlarmId(Long alarmId) {
		this.alarmId = alarmId;
	}

	public String getAlarmName() {
		return alarmName;
	}

	public void setAlarmName(String alarmName) {
		this.alarmName = alarmName;
	}

	public Long getAlarmTime() {
		return alarmTime;
	}

	public void setAlarmTime(Long alarmTime) {
		this.alarmTime = alarmTime;
	}
	

	public String getAlarmTimeStr() {
		return alarmTimeStr;
	}

	public void setAlarmTimeStr(String alarmTimeStr) {
		this.alarmTimeStr = alarmTimeStr;
	}

	public Integer getRepeatFlag() {
		return repeatFlag;
	}

	public void setRepeatFlag(Integer repeatFlag) {
		this.repeatFlag = repeatFlag;
	}

	public String getRepeatExpression() {
		return repeatExpression;
	}

	public void setRepeatExpression(String repeatExpression) {
		this.repeatExpression = repeatExpression;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}
	
}
