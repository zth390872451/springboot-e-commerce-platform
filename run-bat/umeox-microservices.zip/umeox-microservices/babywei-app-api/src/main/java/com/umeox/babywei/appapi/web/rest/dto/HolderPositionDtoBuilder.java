package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import com.umeox.babywei.domain.Barrier;
import com.umeox.babywei.domain.Position;
import com.umeox.babywei.util.DateTimeUtils;
import com.umeox.babywei.util.MapUtil;


public class HolderPositionDtoBuilder {

	public HolderPositionDto build(Position position) {
		HolderPositionDto dto = new HolderPositionDto();
//		dto.setDate(DateTimeUtils.getFormatDate(position.getCreateDate(), DateTimeUtils.FULL_DATE_FORMAT));
		dto.setDate(DateTimeUtils.getFormatDate(position.getReportTime(), DateTimeUtils.FULL_DATE_FORMAT));
		dto.setLongitude(position.getLongitude());
		dto.setLatitude(position.getLatitude());
		dto.setElectric(position.getElectricity());
		dto.setStation(position.getCi());
		dto.setAddress(position.getAddress());
		dto.setLocationMode(position.getLocationMode());
//		dto.setNearbyPosition(position.getNearbyPosition());
		String timeQuantum = DateTimeUtils.getFormatDate(position.getCreateDate(), "HH:mm");
		if(position.getEarlyDate()!=null)
		timeQuantum = DateTimeUtils.getFormatDate(position.getEarlyDate(), "HH:mm")+"-"+DateTimeUtils.getFormatDate(position.getCreateDate(), "HH:mm");
		
		dto.setTimeQuantum(timeQuantum);
//		dto.setOlderId(position.getOlderId());
		/*if(position.getId()!= null){
		dto.setId(position.getId());
		}else {
			dto.setId((long)1);
		}*/
		dto.setId(1L);
		return dto;
	}

	public List<HolderPositionDto> build(List<Position> positions) {
		List<HolderPositionDto> dtos = new ArrayList<HolderPositionDto>();
		for (Position position : positions) {
			dtos.add(build(position));
		}
		return dtos;
	}
	
	

	public List<HolderPositionDto> build(List<Position> positions,List<Barrier> barriers) {
		List<HolderPositionDto> dtos = build(positions);
		if(barriers != null && barriers.size() > 0){
			for (HolderPositionDto dto : dtos) {
				//TODO 是否不需要？
				boolean flag = MapUtil.check(dto.getLatitude(),dto.getLongitude(),barriers.get(0).getLatitude(), barriers.get(0).getLongitude(), barriers.get(0).getRadius());
				dto.setOutrange(flag == true ? 0 : 1);
			}
		}
		return dtos;
	}
	
}
