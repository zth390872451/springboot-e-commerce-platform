package com.umeox.babywei.appapi.web.rest.dto;

import java.util.ArrayList;
import java.util.List;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Content;



public class ContentDtoBuilder {
	
	
	public List<ContentDto> builder(List<Content> parentList){
		List<ContentDto> list = new ArrayList<ContentDto>();
		SettingProperties setting = (SettingProperties)ApplicationSupport.getBean("settingProperties");
		String url = setting.getSelfUrl() + "/api/content/show.jhtml?id=";
		
		for (Content parent : parentList) {
			ContentDto parentDto = new ContentDto();
			parentDto.setId(parent.getId());
			parentDto.setTitle(parent.getTitle());
			parentDto.setImg(parent.getImg());
			parentDto.setDes(parent.getDescriptions());
			parentDto.setpTimestamp(parent.getPublishDate().getTime());
			parentDto.setType(parent.getType().getId());
			/*if (parent.getIsThirdContent()){
				parentDto.setUrl(parent.getContent());
			}else {
				parentDto.setUrl(url+parent.getId());
			}*/
			parentDto.setUrl(url+parent.getId());//第三方也到服务器请求
			
			List<Content> childList = parent.getChildren();
			
			List<ContentDto> childDtoList = new ArrayList<ContentDto>();
			for (Content child : childList) {
				ContentDto childDto = new ContentDto();
				childDto.setId(child.getId());
				childDto.setTitle(child.getTitle());
				childDto.setImg(child.getImg());
				childDto.setDes(child.getDescriptions());
				childDto.setpTimestamp(child.getPublishDate().getTime());
				childDto.setType(child.getType().getId());
				/*if (child.getIsThirdContent()){
					childDto.setUrl(child.getContent());
				}else {
					childDto.setUrl(url+child.getId());
				}*/
				childDto.setUrl(url+child.getId());
				childDtoList.add(childDto);
			}
			parentDto.setSub(childDtoList);
			list.add(parentDto);
		}
		
		return list;
	}
}
