package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.appapi.web.rest.dto.ServerDto;
import com.umeox.babywei.appapi.web.rest.dto.ServerDtoBuilder;
import com.umeox.babywei.domain.ChannelCustomer;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.repository.ChannelCustomerRepository;
import com.umeox.babywei.repository.DeviceRepository;
import com.umeox.babywei.support.MyResponseBody;


/**
 * 服务器配置
 */
@RestController
@RequestMapping( { "/api/server" })
public class ServerController {
	
	@Autowired
	private ChannelCustomerRepository channelCustomerRepository;
	@Autowired
	private DeviceRepository deviceRepository;
	
	/**
	 * 获取服务器配置
	 */
	@RequestMapping(value = { "/get" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody get(@RequestParam(value = "imei") String imei) {		
		Device device = deviceRepository.findOneByImei(imei);
		if(device == null || device.getServer() == null) {//如果设备为空需要进行一个提示
			return fail("sys.invalid.imei");
		}
		ChannelCustomer channelCustomer = channelCustomerRepository.findOneBySaleChannel(device.getSaleChannel());
		String channelSms = channelCustomer != null ? (channelCustomer.getSmsFlag()+"") : "0";
		
		ServerDtoBuilder builder = new ServerDtoBuilder();
		ServerDto dto = builder.build(device.getServer(), device.getDeviceType(), channelSms);

		return success(dto);
		
	} 
}
