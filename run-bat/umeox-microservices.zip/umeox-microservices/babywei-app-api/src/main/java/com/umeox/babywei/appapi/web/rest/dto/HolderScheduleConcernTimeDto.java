package com.umeox.babywei.appapi.web.rest.dto;


public class HolderScheduleConcernTimeDto {
	
	private Long memberId;
	
	private Long holderId;
	
	private String amSec;
	
	private String pmSec;
	
	private String repeatExpression;

	private Boolean status;
	
	private Integer frequency;
	
	
	
	public Integer getFrequency() {
		return frequency;
	}

	public void setFrequency(Integer frequency) {
		this.frequency = frequency;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public Long getHolderId() {
		return holderId;
	}

	public void setHolderId(Long holderId) {
		this.holderId = holderId;
	}

	public String getAmSec() {
		return amSec;
	}

	public void setAmSec(String amSec) {
		this.amSec = amSec;
	}

	public String getPmSec() {
		return pmSec;
	}

	public void setPmSec(String pmSec) {
		this.pmSec = pmSec;
	}

	public String getRepeatExpression() {
		return repeatExpression;
	}

	public void setRepeatExpression(String repeatExpression) {
		this.repeatExpression = repeatExpression;
	}

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}
	
	
	
}
