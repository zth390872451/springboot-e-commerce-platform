package com.umeox.babywei.appapi.web.view;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderStep;
import com.umeox.babywei.repository.HolderStepRepository;
import com.umeox.babywei.util.DateTimeUtils;
import com.umeox.babywei.util.StepUtils;
import com.umeox.babywei.web.rest.BaseController;

@Controller

@RequestMapping("/api/holderStep")
public class HolderStepController extends BaseController{
	
	@Autowired
	private HolderStepRepository holderStepRepository;
	@Autowired
	private Environment env;
	
	public static String[] foodText = {"颗牛奶糖","块巧克力","个橙子","根香蕉","个鸡腿","个生煎包"};
	public static  int[] foodUnit = {18,47,94,113,150,147};
	public static  String[] foodClass= {"food_sugar","food_chocolates","food_orange","food_banana","food_chicken","food_bun"};
	
	
	@RequestMapping(value = { "step" }, method = { RequestMethod.GET })
	public String getHolderStep(Long holderId,Date stepDate,Model model){
		Random random = new Random();
		String serverPath = env.getProperty("server.context-path");
		if(stepDate == null){
			stepDate = new Date();
		}
		
		model.addAttribute("base",serverPath);
		int index = random.nextInt(foodText.length);
		model.addAttribute("foodText",foodText[index]);
		model.addAttribute("foodClass",foodClass[index]);
		model.addAttribute("stepDate",DateTimeUtils.getFormatDate(stepDate, "MM月dd日"));
		
		HolderStep holderStep = holderStepRepository.findOneByHolderIdAndStepDate(holderId,stepDate);
		if(holderStep == null){
			return "/step";
		}
		Holder holder = holderStep.getHolder();
		if(holder == null){
			return "/step";
		}

		if (holder.getHeight()!=null&&holder.getHeight().contains("cm")){//清除以cm或者空格+cm 结尾的字符
			String height = holder.getHeight();
			height = height.replace("cm","").replace(" ","");
			holder.setHeight(height);
		}

		if (holder.getWeight()!=null&&holder.getWeight().contains("kg")){//清除以kg或者空格+kg 结尾的字符
			String weight = holder.getWeight();
			weight = weight.replace("kg","").replace(" ","");
			holder.setWeight(weight);
		}

		String height = holder.getHeight();
		String weight = holder.getWeight();
		String gender = holder.getGender();
		Integer step = holderStep.getStepValue();
		String sexImg = "";
		double distance = 0 ;
		double kcal = 0;
		String foodNumStr = "";
		String distanceStr = "";

		if(StringUtils.isEmpty(gender)){
			gender = "male";
		}
		if(!StringUtils.isEmpty(height)){
			distance = StepUtils.getDistance(Double.parseDouble(height))*step/100/1000;
		}
		if(!StringUtils.isEmpty(weight)){
			kcal = StepUtils.getKcal(Double.parseDouble(weight), distance);
		}
		
		if("male".equals(gender)){
			sexImg = "boy.png";
		}else{
			sexImg = "girl.png";
		}
		String gifName = this.getGifName(gender, step);
		String cssName = this.getCssClass(step);
		double foodNum =  kcal/foodUnit[index];
		DecimalFormat df  = new DecimalFormat("##0.0");
		if(foodNum <0.1){
			foodNum = 0;
		}else{
			if(!StringUtils.isEmpty(foodNum)){
				foodNumStr = df.format(foodNum);
			}
		}
		if(distance<0.1){
			distance=0;
		}else{
			if(!StringUtils.isEmpty(distance)){
				distanceStr = df.format(distance);
			}
		}
		
		model.addAttribute("cssName",cssName);
		model.addAttribute("sexImg",sexImg);
		model.addAttribute("step",step);
		model.addAttribute("foodNum",foodNumStr);
		model.addAttribute("gifName",gifName);
		model.addAttribute("distance",distanceStr);
		model.addAttribute("gender",gender);
		model.addAttribute("kcal",df.format(kcal));
		
		return "/step";
	}
	
	private String getCssClass(Integer step){
		String cssName = "";
		if(step > 9000){
			cssName = "red";
		}else if(step > 6000){
			cssName = "orange";
		}else if(step > 3000){
			cssName = "yellow";
		}else{
			cssName = "purple";
		}
		return cssName;
	}
	
	private String getGifName(String gender,Integer setp){
		if(gender.equals("male")){
			if(setp<=3000){
				return "ani_skating.gif";
			}else if(setp<6000){
				return "ani_basketball.gif";
			}else if(setp<9000){
				return "ani_football.gif";
			}else{
				return "ani_superman.gif";
			}
		}else{
			if(setp<=3000){
				return "ani_yoga.gif";
			}else if(setp<6000){
				return "ani_hoop.gif";
			}else if(setp<9000){
				return "ani_skip.gif";
			}else{
				return "ani_running.gif";
			}
		}
	}
	
}
