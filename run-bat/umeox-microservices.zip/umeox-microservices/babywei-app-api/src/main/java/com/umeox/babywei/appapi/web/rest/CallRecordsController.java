package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.CallRecordsDto;
import com.umeox.babywei.appapi.web.rest.dto.CallRecordsDtoBuilder;
import com.umeox.babywei.appapi.web.rest.dto.PageDto;
import com.umeox.babywei.domain.CallRecords;
import com.umeox.babywei.domain.FamilyNumber;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.repository.CallRecordsRepository;
import com.umeox.babywei.repository.FamilyNumberRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * 通话记录
 */
@RestController
@RequestMapping({"/api/callRecords"})
public class CallRecordsController{
	
	@Autowired
	private CallRecordsRepository callRecordsRepository;
	@Autowired
	private FamilyNumberRepository familyNumberRepository;
	@Autowired
	private MemberRepository memberRepository;
	
	/**
	 * 通话记录列表
	 */
	@DataPermission(DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/list", method = {RequestMethod.GET} )
	public MyResponseBody list(@PageableDefault(size=5)Pageable pageable,
								@RequestParam(value = "holderId") Long holderId){
		Page<CallRecords> page = callRecordsRepository.findByHolderIdOrderByStartTimeDesc(holderId, pageable);
		PageDto<CallRecordsDto> respData = CallRecordsDtoBuilder.build(page);
		return success(respData);
	}
	
	/**
	 * 添加通话记录
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/add",method = RequestMethod.POST)
	public MyResponseBody add(@RequestParam(value = "holderId") Long holderId,
									@RequestParam(value = "memberId") Long memberId,
									@RequestParam(value = "startTime") Long startTime,
									@RequestParam(value = "endTime") Long endTime,
							  	@RequestParam(value = "type",required = false,defaultValue = "2") Integer type){
		Member member = memberRepository.findOne(memberId);
		FamilyNumber familyNumber;
		if (ApplicationSupport.isChinaEnv()) {
			familyNumber = familyNumberRepository.findOneByMobileAndHolderId(member.getMobile(), holderId);
		}else {
			familyNumber = familyNumberRepository.findOneByEmailAndHolderId(member.getMobile(), holderId);
		}
		if (familyNumber == null) {
			return fail(MyHttpStatus._404);
		}
		CallRecords callRecords = new CallRecords();
		callRecords.setHolderId(holderId);
		callRecords.setFamilyNumber(familyNumber);
		callRecords.setStartTime(startTime);
		callRecords.setEndTime(endTime);
		callRecords.setCallTime((endTime-startTime)/1000);
		callRecords.setCallType(CallRecords.CALL_TYPE_IN);
		callRecords.setType(type);
		callRecordsRepository.save(callRecords);
		
		return success();
	}
}
