package com.umeox.babywei.appapi.web.rest;

import com.umeox.babywei.domain.AppVersion;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.enums.AppType;
import com.umeox.babywei.repository.AppVersionRepository;
import com.umeox.babywei.repository.DeviceRepository;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;


@RestController
@RequestMapping({"/api/device"})
public class DeviceController {
	
	@Autowired
	private DeviceRepository deviceRepository;
	@Autowired
	private AppVersionRepository appVersionRepository;
	
	@RequestMapping(value = "/getType",method = {RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody getDeviceType(@RequestParam(value = "code") String code){
		Device device = deviceRepository.findOneByBindCode(code);
		if (device == null) {
			return fail(MyHttpStatus._404);
		}
		Map<String, String> map = new HashMap<String, String>();
		map.put("imei", device.getImei());
		map.put("deviceType", device.getDeviceType());
		
		return success(map);
	}
	
	/**
	 * 电商网站接口1
	 */
	@RequestMapping(value = "/getActivityTime",method = {RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody getDeviceActivityTime(@RequestParam(value = "imei") String imei){
		Device device = deviceRepository.findOneByImei(imei);
		if (device == null) {
			return fail(MyHttpStatus._404);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		if (Device.ActivityStatus.ACTIVITY==device.getActivityStatus()) {
			long activityTime = 0L;
			if (!StringUtils.isEmpty(device.getActivityDate())) {
				activityTime = device.getActivityDate().getTime();
			}else if(!StringUtils.isEmpty(device.getExFactoryDate())){
				activityTime = device.getExFactoryDate().getTime();
			}else {
				activityTime = device.getCreateDate().getTime();
			}
			map.put("activityTime",  activityTime);
		}else {
			map.put("activityTime",  null);
		}
		map.put("deviceType", device.getDeviceType());
		map.put("saleChannel", device.getSaleChannel());
		map.put("saleCountry", device.getSaleCountry());
		return success(map);
	}
	/**
	 * 电商网站接口2
	 */
	@RequestMapping(value = "/getSimpleActivityTime",method = {RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody getDeviceSimpleActivityTime(@RequestParam(value = "imei") String imei){
		Device device = deviceRepository.findOneByImei(imei);
		if (device == null) {
			return fail(MyHttpStatus._404);
		}
		/*if (device.getActivityStatus() == ActivityStatus.UN_ACTIVITY) {
			return fail(MyHttpStatus._404_DEVICE_INACTIVE);
		}*/
		Map<String, Object> map = new HashMap<String, Object>();
		long activityTime = 0L;
		if (!StringUtils.isEmpty(device.getActivityDate())) {
			activityTime = device.getActivityDate().getTime();
		}/*else if(!StringUtils.isEmpty(device.getExFactoryDate())){
			activityTime = device.getExFactoryDate().getTime();
		}else {
			activityTime = device.getCreateDate().getTime();
		}*/
		map.put("activityTime",  activityTime);
		map.put("deviceType", device.getDeviceType());
		map.put("saleChannel", device.getSaleChannel());
		map.put("saleCountry", device.getSaleCountry());
		return success(map);
	}


	@RequestMapping(value = "/checkUpdate",method = {RequestMethod.GET,RequestMethod.POST})
	public MyResponseBody checkUpdate(@RequestParam(value = "imei") String imei){
		Device device = deviceRepository.findOneByImei(imei);
		if (device == null) {
			return fail(MyHttpStatus._404);
		}
		
		String version = device.getVersion();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("status",0);
		map.put("currentVersion",device.getVersion());
		map.put("newVersion",null);
		map.put("content",null);
		map.put("size",0d);
		
		//根据version，算出client_id 和 version,例 ELARI_SP1_EN_V2.35，client_id: ELARI_SP1_EN_{V}, version: 2.35
		if(!StringUtils.isEmpty(version)){
			String regex = "V[0-9]{1,}\\.[0-9]{1,}\\.{0,1}[0-9]{0,}";
			Pattern p = Pattern.compile(regex);
			java.util.regex.Matcher m = p.matcher(version);
			String clientVersion=null;
			if (m.find()) {
				clientVersion = m.group();
			}			
			if(clientVersion!=null){
				String client_id = version.replace(clientVersion,"{V}");
				AppVersion appVersion = appVersionRepository.findMaxByClientIdAndType(client_id, AppType.DEVICE.ordinal());
				if(appVersion != null){
					Double versionNum = Double.parseDouble(clientVersion.substring(1));
					if(appVersion.getAppVersion() > versionNum){
						if (appVersion.getForcedUpdate()){//强制
							map.put("status", 2);
						}else {
							map.put("status", 1);
						}
						map.put("currentVersion",device.getVersion());
						map.put("newVersion",appVersion.getVersionName());
						map.put("content",appVersion.getContent());
						map.put("size",Double.parseDouble(appVersion.getSize()));
					}
				}	
			}
		}
		
		return success(map);
	}



}
