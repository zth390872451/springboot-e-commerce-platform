package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.util.List;

import com.umeox.babywei.util.TimeZoneUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderSetDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderSetDtoBuilder;
import com.umeox.babywei.appapi.web.rest.dto.TimeZoneDto;
import com.umeox.babywei.appapi.web.rest.dto.TimeZoneDtoBuilder;
import com.umeox.babywei.bean.Mark;
import com.umeox.babywei.bean.RedisCommand;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.HolderSet;
import com.umeox.babywei.domain.TimeZone;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.repository.HolderSetRepository;
import com.umeox.babywei.repository.TimeZoneRepository;
import com.umeox.babywei.service.HolderSetService;
import com.umeox.babywei.service.RedisQueueService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;

@RestController
@RequestMapping("/api/holderSet")
public class HolderSetController {
	
	@Autowired
	private HolderSetRepository holderSetRepository;
	@Autowired
	private HolderRepository holderRepository;
	@Autowired
	private TimeZoneRepository timeZoneRepository;
	@Autowired
	private HolderSetService holderSetService;
	@Autowired
	private RedisQueueService redisQueueService;
	
	/**
	 * 设置设备参数
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/update",method = RequestMethod.POST)
	public MyResponseBody update(@RequestParam(value = "memberId") Long memberId,
								 @RequestParam(value = "holderId") Long holderId,
								 @RequestParam(value = "itemFlag") Integer itemFlag,
								 @RequestParam(value = "itemVal") String itemVal){
		HolderSet holderSet = holderSetRepository.findFirstByHolderId(holderId);
		/*if (itemFlag < 0 || itemFlag > 5) {
			return fail(MyHttpStatus._400);
		}*/
		if (holderSet == null) {//添加
			Holder holder = holderRepository.findOne(holderId);
			if (holder == null) {
				return fail(MyHttpStatus._404);
			}
			holderSet = new HolderSet();
			holderSet.setHolder(holder);
		}
		holderSetService.update(holderSet, itemFlag, itemVal);
		if(itemFlag ==  100){
			//设备工作模式下发
			redisQueueService.k2HandleMark(new Mark(holderSet.getHolder().getId(),RedisCommand.CMD_DEVICE_WORK_MODEL));
		}else{
			redisQueueService.k2HandleMark(new Mark(holderSet.getHolder().getId(),RedisCommand.CMD_DEVICE_PARAM));
		}

		return success();
	}
	
	/**
	 * 获取设置设备参数
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/get",method = RequestMethod.GET)
	public MyResponseBody get(@RequestParam(value = "memberId") Long memberId,
							   @RequestParam(value = "holderId") Long holderId){
		Holder holder = holderRepository.findOne(holderId);
		if (holder == null) {
			return fail(MyHttpStatus._404);
		}
		HolderSet holderSet = holderSetRepository.findFirstByHolderId(holderId);
		HolderSetDto respData = HolderSetDtoBuilder.build(holder, holderSet);

		//旧版的设置是:Asia/Taipei(GMT+08:00) 新版：Asia/Taipei,为了兼容旧版本，执行如下逻辑：
		String timeZoneId = holder.getTimeZone();
		if (!StringUtils.isEmpty(timeZoneId)) {
			if (timeZoneId.contains("(GMT")) {
				timeZoneId = timeZoneId.substring(0, timeZoneId.indexOf("(GMT"));
			}
			TimeZone timeZone = timeZoneRepository.findOneByTimeZoneId(timeZoneId);
			if (timeZone != null) {
				respData.setTimeZoneId(timeZone.getTimeZoneId());
				//timeZoneId(GMT)
				respData.setTimeZone(timeZoneId+"("+ TimeZoneUtils.displayTimeZone(timeZoneId)+")");
			}else{
				respData.setTimeZoneId(timeZoneId);
				respData.setTimeZone(timeZoneId+"("+ TimeZoneUtils.displayTimeZone(timeZoneId)+")");
			}

		}
		
		return success(respData);
	}
	
	/**
	 * @Desc 获取时区列表
	 */
	//@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = "/listTimeZone",method = RequestMethod.GET)
	public MyResponseBody listTimeZone(@RequestParam(value = "memberId") Long memberId,
							   		   @RequestParam(value = "holderId") Long holderId){
		List<TimeZone> timeZoneList = timeZoneRepository.findAll();
		List<TimeZoneDto> respList = TimeZoneDtoBuilder.builder(timeZoneList);
		respList = TimeZoneDtoBuilder.sort(respList);
		return success(respList);
	}


}
