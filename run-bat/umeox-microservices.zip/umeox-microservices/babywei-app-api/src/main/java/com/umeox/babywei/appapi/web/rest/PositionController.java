package com.umeox.babywei.appapi.web.rest;

import static com.umeox.babywei.support.MyResponseBuilder.success;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.umeox.babywei.appapi.annotation.DataPermission;
import com.umeox.babywei.appapi.annotation.DataPermissionType;
import com.umeox.babywei.appapi.web.rest.dto.HolderPositionDto;
import com.umeox.babywei.appapi.web.rest.dto.HolderPositionDtoBuilder;
import com.umeox.babywei.domain.Barrier;
import com.umeox.babywei.domain.Device;
import com.umeox.babywei.domain.Holder;
import com.umeox.babywei.domain.Position;
import com.umeox.babywei.repository.BarrierRepository;
import com.umeox.babywei.repository.HolderRepository;
import com.umeox.babywei.service.PositionService;
import com.umeox.babywei.support.MyResponseBody;
import com.umeox.babywei.util.TimeUtils;
import com.umeox.babywei.web.rest.BaseController;


/**
 * 打点接口
 * @author umeox
 */
@RestController
@RequestMapping( { "/api/position" })
public class PositionController extends BaseController{
	private static final Logger log = LoggerFactory.getLogger(PositionController.class);
	
	@Autowired
	private BarrierRepository barrierRepository;
	@Autowired
	private PositionService positionService;
	@Autowired
	private HolderRepository holderRepository;
	
	/**
	 * 打点查询
	 * 3.4.1.2	GPS定位历史记录查询接口
	 */
	@DataPermission(value = DataPermissionType.HOLDER_FOLLOWER)
	@RequestMapping(value = { "/list" }, method = { RequestMethod.GET,RequestMethod.POST })
	public MyResponseBody list(@RequestParam(value = "holderId") Long holderId,
							   @RequestParam(value = "dept") Date dept,
							   @RequestParam(value = "dest") Date dest) {
		
		//解绑位置数据未删除，为了不让查收解绑之前的数据，故添加如下逻辑
		Holder holder = holderRepository.findOne(holderId);
		Device device = holder.getDevice();
		Date lastActivityDate = device.getLastActivityDate();
		
		if (!StringUtils.isEmpty(lastActivityDate) && dept != null) {
			String mcc = device.getMcc();
			if (StringUtils.isEmpty(mcc) && StringUtils.isEmpty(device.getTimeZone())) {
				//什么都不做
			} else {
				if (!StringUtils.isEmpty(mcc)) {
					mcc = Integer.toHexString(Integer.parseInt(mcc));//十进制转十六进制
				}
				String timezoneId = TimeUtils.getTimezoneId(device.getTimeZone(), mcc);
				lastActivityDate = TimeUtils.getDateByTimeZone(lastActivityDate, timezoneId);
			}
			
			if (dept.getTime() < lastActivityDate.getTime()) {
				dept = lastActivityDate;//查询日期必须大于等于激活日期
			}
		}
		
		List<Barrier> barriers = barrierRepository.findByHolderIdAndOpen(holderId, 1);
		List<Position> positions;
		try {
			positions = positionService.findPositionsByHolder(holderId, dept, dest);
		} catch (Exception e) {//位置表有可能还没有产生
			positions = new ArrayList<Position>();
		}
		
		HolderPositionDtoBuilder builder = new HolderPositionDtoBuilder();
		List<HolderPositionDto> dtoList = builder.build(positions,barriers);
		
		return success(dtoList);
	}

}
