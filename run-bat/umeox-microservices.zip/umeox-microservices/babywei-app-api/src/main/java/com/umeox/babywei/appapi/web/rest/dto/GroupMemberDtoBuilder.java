package com.umeox.babywei.appapi.web.rest.dto;

import com.umeox.babywei.ApplicationSupport;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Holder;

import java.util.ArrayList;
import java.util.List;

/**
 * @author umeox
 */
public class GroupMemberDtoBuilder {

    private final static SettingProperties setting;

    static {
        setting = (SettingProperties) ApplicationSupport.getBean("settingProperties");
    }


    public GroupMemberDto build(Holder holder) {
        GroupMemberDto dto = new GroupMemberDto();
        dto.setUserId(holder.getId());
        dto.setName(holder.getName());
        dto.setPhotoUrl(setting.getSiteUrl() + holder.getAvatar());
        return dto;
    }

    public List<GroupMemberDto> build(List<Holder> holderList) {
        List<GroupMemberDto> dtos = new ArrayList<GroupMemberDto>();
        for (Holder holder : holderList) {
            dtos.add(build(holder));
        }
        return dtos;
    }

}
