import java.util.Date;

/**
 * Created by Administrator on 2017/5/5.
 */
public class CommonStartTime {

    public static ThreadLocal<Long> startTime = new ThreadLocal<>();

    public static void main(String[] args) {

        if (startTime.get()==null){
            startTime.set(new Date().getTime());//开始时间
        }
        long start = startTime.get().longValue();

        System.out.println("cost time = " + (System.currentTimeMillis() - startTime.get().longValue() ));
    }
}
