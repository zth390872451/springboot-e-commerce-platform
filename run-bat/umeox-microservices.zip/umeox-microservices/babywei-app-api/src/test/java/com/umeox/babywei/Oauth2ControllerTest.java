package com.umeox.babywei.util;

import com.umeox.babywei.appapi.web.util.AESOperator;
import com.umeox.babywei.bean.Oauth2;
import com.umeox.babywei.conf.AppDetails;
import com.umeox.babywei.conf.RedisKeyPre;
import com.umeox.babywei.conf.SettingProperties;
import com.umeox.babywei.domain.Member;
import com.umeox.babywei.domain.MemberExt;
import com.umeox.babywei.plugin.JPushDeviceApi;
import com.umeox.babywei.plugin.QiniuClient;
import com.umeox.babywei.repository.MemberExtRepository;
import com.umeox.babywei.repository.MemberRepository;
import com.umeox.babywei.service.MemberService;
import com.umeox.babywei.service.RedisService;
import com.umeox.babywei.support.MyHttpStatus;
import com.umeox.babywei.support.MyResponseBody;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.resource.BaseOAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenProvider;
import org.springframework.security.oauth2.client.token.DefaultAccessTokenRequest;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordAccessTokenProvider;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.common.DefaultOAuth2RefreshToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.util.DigestUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.umeox.babywei.support.MyResponseBuilder.fail;
import static com.umeox.babywei.support.MyResponseBuilder.success;

/**
 * @Desc 授权
 *
 同一个会员登录（可能存在2个版本的APP）
	member.setClientId(client_id);后一个
 * @author umeox
 * @version II
 */
@RestController
@RequestMapping("/api/oauth2")
public class Oauth2ControllerTest {
	
	private static final Logger log = LoggerFactory.getLogger(Oauth2ControllerTest.class);
	
	@Autowired
	private ResourceOwnerPasswordResourceDetails resource;
	@Autowired
	private ClientCredentialsResourceDetails clientCredentials;
	@Autowired
	private RedisService redisService;
	@Autowired
	private MemberRepository memberRepository;
	@Autowired
	private MemberService memberService;
	@Autowired
	private SettingProperties setting;
	@Autowired
	private MemberExtRepository memberExtRepository;

	public static int password_count = 0;
	public static int client_count = 0;

	public static List<Member> memberList = new ArrayList<>();
	/**
	 * 获取token
	 */
	@RequestMapping(value = "/accessToken",method = RequestMethod.POST)
	public MyResponseBody accessToken(@RequestParam(value = "client_id") String client_id,
									  @RequestParam(value = "client_secret") String client_secret,
									  @RequestParam(value = "grant_type") String grant_type,
									  @RequestParam(value = "username") String username,
									  @RequestParam(value = "password") String password,
									  @RequestParam(value = "version") String version,
									  @RequestParam(value = "lang") String lang,
									  @RequestParam(value = "timezone") String timezone,
									  @RequestParam(value ="loginInfo",required = false) String loginInfo)/*throws Exception*/{
		if (memberList.size()==0){
			memberList = memberRepository.findMemberByTokenNotNullAndPushType(1);
		}
		/*count ++;
		log.info("请求count计数值："+count);*/
		long oauth2StartTime = System.currentTimeMillis();
		//App端dm5加密后不足32位加零补齐的情况
		String pre = "";
		if (password.length() < 32) {
			int len = 32 - password.length();
			pre = String.format("%0" + len + "d", 0);
		}
		
		//SettingProperties setting = (SettingProperties)ApplicationSupport.getBean("settingProperties");
		/*if (StringUtils.isEmpty(version)) {
			return fail(MyHttpStatus._400);
		}*/
		//resource.setAccessTokenUri(tokenUrl);
		
		//改进声明：因android和ios分配了不同的client_id，OAuth2认证是区分client_id生成token，为了解决android和ios同一个账号只在一个设备上有效的问题：
		// 1.  登录认证的时候去掉_android和_ios字符，统一为一种
		// 2.  后续给APP分配的client_id不要再区分平台
		// 3.  产生一个新的clinetId 只用于token生成
		// 4. 先实现传音版 wherecom_watchk2c_api_ios wherecom_watchk2c_api_android, 因其它版本的client_id规则和client_secrect值不一样
		// 5. 考虑对离线消息的影响
		String newClinetId = client_id;
		if (newClinetId != null && client_id.startsWith("wherecom_watchk2c_api")) {
			newClinetId = "wherecom_watchk2c_api";
		}
		//version.equals("1.0") 台湾的funpark的1.0版本iOS登录 继续走原来的登录逻辑
		log.info("Login,client_id:{},version:{}",newClinetId,version);
		if (AppDetails.FUNPARK_APP.contains(newClinetId) && !version.equalsIgnoreCase("iOS-1.0") ){//FUNPARK 对接之登录
			try {
				String plainPwd = AESOperator.getInstance().decrypt(password,null);//获得明文plainPwd
				if (false/* || !FunparkService.funParkLoginService(username, plainPwd, newClinetId)*/) //登录失败
					return fail(MyHttpStatus._401);
				else {//登录成功
					username = username.replace("@","$");//本地库保存$符号
					Member localMember = memberRepository.findOneByMobile(username);
					if (StringUtils.isEmpty(localMember)){//本地库不存在
						localMember = new Member();
						localMember.setMobile(username);
						localMember.setPassword(DigestUtils.md5DigestAsHex(plainPwd.getBytes()));
						memberRepository.save(localMember);
					}
				}
				//转换成md5加密的密码值
				password =  DigestUtils.md5DigestAsHex(plainPwd.getBytes());
				if (password.length() < 32) {
					int size = 32 - password.length();
					pre = String.format("%0" + size + "d", 0);
				}else {
					pre = "";
				}
			}catch (Exception e){
				log.error("funpark 登录失败:",e);
				return fail(MyHttpStatus._401);
			}
		}

		AccessTokenProvider provider = null;
		BaseOAuth2ProtectedResourceDetails resourceDetails = null;
		if (AppDetails.FUNPARK_APP.contains(newClinetId) && !version.equalsIgnoreCase("iOS-1.0") ){//受信用客户端的认证
				clientCredentials.setClientId(client_id);
				clientCredentials.setClientSecret(client_secret);
				clientCredentials.setGrantType("client_credentials");
				resourceDetails = clientCredentials;
				provider = new ClientCredentialsAccessTokenProvider();
				client_count++;
		}else {//密码认证
				resource.setClientId(newClinetId);
				resource.setClientSecret(client_secret);
				resource.setGrantType("password");
				if (memberList.size()>=password_count){
					resource.setUsername(memberList.get(password_count).getMobile());
					resource.setPassword(pre + memberList.get(password_count).getPassword());
				}else {
					resource.setUsername(username);
					resource.setPassword(password);
				}
				resourceDetails = resource;
				provider = new ResourceOwnerPasswordAccessTokenProvider();
				password_count++;
		}
		OAuth2AccessToken accessToken = null;
		try {
			accessToken = provider.obtainAccessToken(resourceDetails, new DefaultAccessTokenRequest());
		} catch (Exception e) {
			log.error("授权失败 newClinetId = {},username:{},原因：{}",newClinetId,username, e.getMessage());
			log.info("oauth2 auth failed, cost:{} ms",System.currentTimeMillis()-oauth2StartTime);
			return fail(MyHttpStatus._401);
		}
		log.info("oauth2 accessToken  cost:{} ms",System.currentTimeMillis()-oauth2StartTime);
		Member member = memberRepository.findOneByMobile(username);//因为会在 OAuth2 服务器进行用户名密码验证，所以不必再判断空异常
		//目前没有找到每次认证获取新的token方式，故用刷新token方式来处理
		//只实现传音K2C
		if (accessToken != null && client_id.startsWith("wherecom_watchk2c_api") && !StringUtils.isEmpty(accessToken.getRefreshToken().getValue())) {
		//client_id_key 这个字段 为 client_id 去除尾部的 _ios _android的部分
		// (如果是海外的wherecom_k2_app_api 或者 wherecom_k2_api_ios，则值为wherecom_k2_ap)
			String 	client_id_key = newClinetId;
			// 注释：  因海外服务器通过API访问极光服务不稳定，时间需要几秒钟或偶尔超过10几秒
			long startTime = System.currentTimeMillis();
			log.info("Start jpush API to reset alias:{}", CommonUtils.aliasHandle(member.getMobile()));
			JPushDeviceApi.deleteAliasByClientIdKey(client_id_key, CommonUtils.aliasHandle(member.getMobile()));
			log.info("Finish jpush API to reset alias:{},cost:{} ms",CommonUtils.aliasHandle(member.getMobile()),System.currentTimeMillis()-startTime);
			redisService.del(RedisKeyPre.OAUTH2_TOKEN+accessToken.getValue());
			OAuth2RefreshToken refreshToken = new DefaultOAuth2RefreshToken(accessToken.getRefreshToken().getValue());
			accessToken = provider.refreshAccessToken(resource, refreshToken, new DefaultAccessTokenRequest());
		}
		
		String token = accessToken.getValue();
		int expiresIn = accessToken.getExpiresIn();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("access_token", token);
		map.put("token_type", accessToken.getTokenType());
		map.put("expires_in", expiresIn);
		
		Oauth2 oauth2 = new Oauth2();
		oauth2.setClient_id(client_id);
		oauth2.setUser_id(username);
		oauth2.setVersion(version);
		oauth2.setLang(lang);
		oauth2.setTimezone(timezone);
		

		oauth2.setMemberId(member.getId());
		map.put("memberId", member.getId());
		map.put("mobile", member.getMobile());
		String avatar = !StringUtils.isEmpty(member.getAvatar()) ? (setting.getNginxUrl() + "/umeox" + member.getAvatar()) : "";
		map.put("avatar", avatar);
		if (version.contains("iOS")) {
			member.setToken("iOS");
		}else {
			member.setToken(null);
		}
		member.setPushType(Member.PUSH_TYPE_JPUSH);
		member.setClientId(client_id);
		if (member.getMemberExt() == null) {
			MemberExt memberExt = new MemberExt();
			memberExt.setMember(member);
			member.setMemberExt(memberExt);
		}


		/*if (!StringUtils.isEmpty(loginInfo)){//小米还是华为的安卓手机登录
			member.setLoginInfo(loginInfo);
			member.setToken(null);//ios标识位为null
		}else {
			member.setLoginInfo(null);
		}*/

		memberRepository.save(member);
		//TODO 删除upToken
		map.put("upToken", QiniuClient.getImUpToken());
		map.put("fileUrl", setting.getFileServerUrl());
		map.put("alias", member.getMobile());
		redisService.set(RedisKeyPre.OAUTH2_TOKEN+token, oauth2, expiresIn);
		log.info("oauth2 auth finished success cost:{} ms",System.currentTimeMillis()-oauth2StartTime);
		log.info("***password_count= {} ,client_count = {}***",password_count,client_count);
		return success(map);
	}





	/**
	 * 信任的客户端获取token
	 */
	@Deprecated
	@RequestMapping(value = "/clientToken",method = RequestMethod.POST)
	public MyResponseBody getToken(@RequestParam(value = "client_id") String client_id,
								  @RequestParam(value = "client_secret") String client_secret,
								  @RequestParam(value = "grant_type") String grant_type,
								  @RequestParam(value = "version") String version,
								  @RequestParam(value = "userId") String userId,
								  @RequestParam(value = "token") String encryptToken,
								  @RequestParam(value = "username") String username,
								  @RequestParam(value = "nickName") String nickName){
		//api--校讯通token和userId验证
		try {
			DESPlus72 des = new DESPlus72("aD2u1(qj");// 默认密钥
			String decryptToken = des.decrypt(encryptToken);
			String[] tokenArr = decryptToken.split("\\|");
			if (!userId.equals(tokenArr[0])) {
				return fail(MyHttpStatus._401_ILLEGALITY);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return fail(MyHttpStatus._401_ILLEGALITY);
		}
		
		clientCredentials.setClientId(client_id);
		clientCredentials.setClientSecret(client_secret);
		clientCredentials.setGrantType(grant_type);
		ClientCredentialsAccessTokenProvider provider = new ClientCredentialsAccessTokenProvider();
		OAuth2AccessToken accessToken = null;
		try {
			accessToken = provider.obtainAccessToken(clientCredentials, new DefaultAccessTokenRequest());
		} catch (Exception e) {
			e.printStackTrace();
			return fail(MyHttpStatus._401);
		}
		
		Oauth2 oauth2 = new Oauth2();
		oauth2.setClient_id(client_id);
		oauth2.setUser_id(username);
		oauth2.setVersion(version);
		
		Member member = memberRepository.findOneByMobile(username);
		boolean isAddOpenUser = false;
		if (member == null) {//未注册
			isAddOpenUser = true;
			member = new Member();
			member.setMobile(username);
			member.setPassword(DigestUtils.md5DigestAsHex(("gxxxt"+username).getBytes()));
		}
		if (version.contains("iOS")) {
			member.setToken("iOS");
		}else {
			member.setToken(null);
		}
		member.setNickName(nickName);
		member.setPushType(Member.PUSH_TYPE_JPUSH);
		member.setClientId(client_id);
		//memberRepository.save(member);
		memberService.setAuth(member, userId, isAddOpenUser);
		
		String token = accessToken.getValue();
		int expiresIn = accessToken.getExpiresIn();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("access_token", token);
		map.put("token_type", accessToken.getTokenType());
		map.put("expires_in", expiresIn);
		map.put("memberId", member.getId());
		map.put("mobile", member.getMobile());
		map.put("alias", member.getMobile());
		//map.put("upToken", QiniuClient.getImUpToken());
		//map.put("fileUrl", setting.getFileServerUrl());
		oauth2.setMemberId(member.getId());
		redisService.set(RedisKeyPre.OAUTH2_TOKEN+token, oauth2, expiresIn);
		
		return success(map);
	}
	
	/**
	 * 信任的客户端获取token
	 */
	@RequestMapping(value = "/getNormToken",method = RequestMethod.POST)
	public MyResponseBody getNormToken(@RequestParam(value = "client_id") String client_id,
								  @RequestParam(value = "client_secret") String client_secret,
								  @RequestParam(value = "version") String version,
								  @RequestParam(value = "lang") String lang,
								  @RequestParam(value = "mobile") String mobile){
		clientCredentials.setClientId(client_id);
		clientCredentials.setClientSecret(client_secret);
		clientCredentials.setGrantType("client_credentials");
		ClientCredentialsAccessTokenProvider provider = new ClientCredentialsAccessTokenProvider();
		OAuth2AccessToken accessToken = null;
		try {
			accessToken = provider.obtainAccessToken(clientCredentials, new DefaultAccessTokenRequest());
		} catch (Exception e) {
			e.printStackTrace();
			return fail(MyHttpStatus._401);
		}
		
		Oauth2 oauth2 = new Oauth2();
		oauth2.setClient_id(client_id);
		oauth2.setUser_id(mobile);
		oauth2.setVersion(version);
		
		Member member = memberRepository.findOneByMobile(mobile);
		if (member == null) {//未注册
			member = new Member();
			member.setMobile(mobile);
			member.setPassword(DigestUtils.md5DigestAsHex((RandomUtils.generateString(10)).getBytes()));
		}
		if (version.contains("iOS")) {
			member.setToken("iOS");
		}else {
			member.setToken(null);
		}
		member.setNickName(mobile);
		member.setPushType(Member.PUSH_TYPE_JPUSH);
		member.setClientId(client_id);
		//memberRepository.save(member);
		memberService.save(member, client_id);
		//memberService.setAuth(member, userId, isAddOpenUser);
		
		String token = accessToken.getValue();
		int expiresIn = accessToken.getExpiresIn();
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("access_token", token);
		map.put("token_type", accessToken.getTokenType());
		map.put("expires_in", expiresIn);
		map.put("memberId", member.getId());
		map.put("mobile", member.getMobile());
		map.put("alias", member.getMobile());
		oauth2.setMemberId(member.getId());
		redisService.set(RedisKeyPre.OAUTH2_TOKEN+token, oauth2, expiresIn);
		
		return success(map);
	}
}
