package com.umeox.babywei;

import com.umeox.babywei.util.CommonUtils;
import com.umeox.babywei.util.Encryptor;

public class T12 {

    public static void main(String[] args) {
        String mobile ="teny.huang$wherecom.com";
        String md5Alias = Encryptor.parseStrToMd5U16(mobile);
        String alias = CommonUtils.aliasHandle(mobile);
        System.out.println("alias = " + alias);
        System.out.println("md5Alias = " + md5Alias);
    }
}
