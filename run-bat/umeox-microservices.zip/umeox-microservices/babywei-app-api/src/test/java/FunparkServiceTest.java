import com.umeox.babywei.appapi.web.rest.AESTool;
import com.umeox.babywei.appapi.web.rest.FunparkService;
import com.umeox.babywei.support.MyResponseBody;

import java.util.HashMap;
import java.util.Map;

/**
 * Funpark对接业务 测试
 */
public class FunparkServiceTest {



    public static void main(String[] args)throws Exception {
// 1、邮件发送测试
//        MyResponseBody responseBody = FunparkService.sendEmail("zth390872451@126.com",1);
// 2、注册测试
//        testRegister();
//  3、登录测试
        testLogin();
//  4、修改密码测试
//        testFindPwd();
//  5、修改用户资料测试
//        FunparkService.funParkServiceUpdateInfo("江翠店1",0,"0282597588","zfd59872$rcasd.com");
//        testUpdateInfo();
//        System.out.println("md5DigestAsHex = " + DigestUtils.md5DigestAsHex("87654321".getBytes()));
        //方法一：中文操作系统中打印GBK
//        System.out.println(System.getProperty("file.encoding"));

        //方法二：中文操作系统中打印GBK
//        System.out.println(Charset.defaultCharset());

    }
    private static void testUpdateInfo() {
        Map<String,String> params = new HashMap<String, String>();
        params.put("username","zth390872451@126.com");
        params.put("nickName","乱码测试");
        params.put("gender","0");
        params.put("tel","15019271280");
        MyResponseBody test = FunparkService.updateInfo(params);
    }

    private static void testFindPwd() throws Exception{
        Map<String,String> params = new HashMap<String, String>();
        params.put("username","zth390872451@126.com");
        params.put("password", AESTool.getencrypt("876543210"));
        params.put("code","27547");
        MyResponseBody test = FunparkService.findPwd(params);
    }
    private static void testLogin() throws Exception{
        Map<String,String> params = new HashMap<String, String>();
        params.put("username","390872451$qq.com");
//        params.put("password","0911571399");
        params.put("password",AESTool.getencrypt("12345678"));
        MyResponseBody test = FunparkService.login(params);
    }
    private static void testRegister() throws Exception{
        Map<String,String> params = new HashMap<String, String>();
        params.put("username","xyz0526604@163.com");
//        params.put("username","390872451@qq.com");
        String getencrypt = AESTool.getencrypt("12345678");
        System.out.println("getencrypt = " + getencrypt+"*");
        params.put("password",getencrypt);
        params.put("code","38926");
        params.put("tel","15019271280");
        params.put("nickName","UTF8的编码");
        MyResponseBody test = FunparkService.register(params);
        System.out.println("test = " + test);
    }


}
