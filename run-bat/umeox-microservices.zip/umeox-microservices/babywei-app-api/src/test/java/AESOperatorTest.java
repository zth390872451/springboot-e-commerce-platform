
import com.umeox.babywei.appapi.web.util.AESOperator;
import org.springframework.util.DigestUtils;

/**
 * Created by Administrator on 2017/3/27.
 */
public class AESOperatorTest {

    public static void main(String[] args) throws Exception {
        String password= "0911571399";
        String encrypt = AESOperator.getInstance().encrypt(password, null);
        System.out.println("encrypt = " + encrypt);
        String decrypt = AESOperator.getInstance().decrypt(encrypt, null);
        System.out.println("decrypt = " + decrypt);

        String md5DigestAsHex = DigestUtils.md5DigestAsHex(password.getBytes());
        System.out.println("md5DigestAsHex = " + md5DigestAsHex);

        String text = "04A4D0F76AA7418E81CECF982E064195";
        encrypt = AESOperator.getInstance().decrypt(text, null);
        System.out.println("解密= " + encrypt);
    }
}
